"use strict";
(self["webpackChunkTweetClaw"] = self["webpackChunkTweetClaw"] || []).push([["src_shims_linkedom_ts-src_x_api_txid_ts"],{

/***/ "./src/shims/linkedom.ts"
/*!*******************************!*\
  !*** ./src/shims/linkedom.ts ***!
  \*******************************/
(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   parseHTML: () => (/* binding */ parseHTML)
/* harmony export */ });
// 仅提供库里会用到的 parseHTML，返回结构跟 linkedom 类似
function parseHTML(html) {
    const parser = new DOMParser();
    const document = parser.parseFromString(html, "text/html");
    return { window: { document } };
}


/***/ },

/***/ "./src/x_api/txid.ts"
/*!***************************!*\
  !*** ./src/x_api/txid.ts ***!
  \***************************/
(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   getTransactionIdFor: () => (/* binding */ getTransactionIdFor)
/* harmony export */ });
/* harmony import */ var x_client_transaction_id__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! x-client-transaction-id */ "./node_modules/x-client-transaction-id/esm/mod.js");
/**
 * Twitter Transaction ID (txid) generator.
 * Uses x-client-transaction-id library (same as TweetCat).
 */

let cachedDoc = null;
let lastFetched = 0;
async function getXDoc() {
    const now = Date.now();
    if (!cachedDoc || now - lastFetched > 60000) { // 缓存 60s
        const res = await fetch("https://x.com/", { credentials: "omit" });
        const html = await res.text();
        cachedDoc = new DOMParser().parseFromString(html, "text/html");
        lastFetched = now;
    }
    return cachedDoc;
}
async function getTransactionIdFor(method, path) {
    const doc = await getXDoc();
    const tx = await x_client_transaction_id__WEBPACK_IMPORTED_MODULE_0__.ClientTransaction.create(doc);
    return tx.generateTransactionId(method, path);
}


/***/ }

}]);
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoianMvc3JjX3NoaW1zX2xpbmtlZG9tX3RzLXNyY194X2FwaV90eGlkX3RzLmpzIiwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7QUFBQTtBQUNPO0FBQ1A7QUFDQTtBQUNBLGFBQWEsVUFBVTtBQUN2Qjs7Ozs7Ozs7Ozs7Ozs7OztBQ0xBO0FBQ0E7QUFDQTtBQUNBO0FBQzREO0FBQzVEO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsbURBQW1EO0FBQ25ELG9EQUFvRCxxQkFBcUI7QUFDekU7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ087QUFDUDtBQUNBLHFCQUFxQixzRUFBaUI7QUFDdEM7QUFDQSIsInNvdXJjZXMiOlsid2VicGFjazovL1R3ZWV0Q2xhdy8uL3NyYy9zaGltcy9saW5rZWRvbS50cyIsIndlYnBhY2s6Ly9Ud2VldENsYXcvLi9zcmMveF9hcGkvdHhpZC50cyJdLCJzb3VyY2VzQ29udGVudCI6WyIvLyDku4Xmj5DkvpvlupPph4zkvJrnlKjliLDnmoQgcGFyc2VIVE1M77yM6L+U5Zue57uT5p6E6LefIGxpbmtlZG9tIOexu+S8vFxuZXhwb3J0IGZ1bmN0aW9uIHBhcnNlSFRNTChodG1sKSB7XG4gICAgY29uc3QgcGFyc2VyID0gbmV3IERPTVBhcnNlcigpO1xuICAgIGNvbnN0IGRvY3VtZW50ID0gcGFyc2VyLnBhcnNlRnJvbVN0cmluZyhodG1sLCBcInRleHQvaHRtbFwiKTtcbiAgICByZXR1cm4geyB3aW5kb3c6IHsgZG9jdW1lbnQgfSB9O1xufVxuIiwiLyoqXG4gKiBUd2l0dGVyIFRyYW5zYWN0aW9uIElEICh0eGlkKSBnZW5lcmF0b3IuXG4gKiBVc2VzIHgtY2xpZW50LXRyYW5zYWN0aW9uLWlkIGxpYnJhcnkgKHNhbWUgYXMgVHdlZXRDYXQpLlxuICovXG5pbXBvcnQgeyBDbGllbnRUcmFuc2FjdGlvbiB9IGZyb20gXCJ4LWNsaWVudC10cmFuc2FjdGlvbi1pZFwiO1xubGV0IGNhY2hlZERvYyA9IG51bGw7XG5sZXQgbGFzdEZldGNoZWQgPSAwO1xuYXN5bmMgZnVuY3Rpb24gZ2V0WERvYygpIHtcbiAgICBjb25zdCBub3cgPSBEYXRlLm5vdygpO1xuICAgIGlmICghY2FjaGVkRG9jIHx8IG5vdyAtIGxhc3RGZXRjaGVkID4gNjAwMDApIHsgLy8g57yT5a2YIDYwc1xuICAgICAgICBjb25zdCByZXMgPSBhd2FpdCBmZXRjaChcImh0dHBzOi8veC5jb20vXCIsIHsgY3JlZGVudGlhbHM6IFwib21pdFwiIH0pO1xuICAgICAgICBjb25zdCBodG1sID0gYXdhaXQgcmVzLnRleHQoKTtcbiAgICAgICAgY2FjaGVkRG9jID0gbmV3IERPTVBhcnNlcigpLnBhcnNlRnJvbVN0cmluZyhodG1sLCBcInRleHQvaHRtbFwiKTtcbiAgICAgICAgbGFzdEZldGNoZWQgPSBub3c7XG4gICAgfVxuICAgIHJldHVybiBjYWNoZWREb2M7XG59XG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZ2V0VHJhbnNhY3Rpb25JZEZvcihtZXRob2QsIHBhdGgpIHtcbiAgICBjb25zdCBkb2MgPSBhd2FpdCBnZXRYRG9jKCk7XG4gICAgY29uc3QgdHggPSBhd2FpdCBDbGllbnRUcmFuc2FjdGlvbi5jcmVhdGUoZG9jKTtcbiAgICByZXR1cm4gdHguZ2VuZXJhdGVUcmFuc2FjdGlvbklkKG1ldGhvZCwgcGF0aCk7XG59XG4iXSwibmFtZXMiOltdLCJzb3VyY2VSb290IjoiIn0=