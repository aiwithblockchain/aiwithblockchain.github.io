"use strict";
(self["webpackChunkTweetClaw"] = self["webpackChunkTweetClaw"] || []).push([["src_shims_linkedom_ts-src_x_api_twitter_api_ts"],{

/***/ "./src/shims/linkedom.ts"
/*!*******************************!*\
  !*** ./src/shims/linkedom.ts ***!
  \*******************************/
(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   parseHTML: () => (/* binding */ parseHTML)
/* harmony export */ });
// 仅提供库里会用到的 parseHTML，返回结构跟 linkedom 类似
function parseHTML(html) {
    const parser = new DOMParser();
    const document = parser.parseFromString(html, "text/html");
    return { window: { document } };
}


/***/ },

/***/ "./src/x_api/feature_manager.ts"
/*!**************************************!*\
  !*** ./src/x_api/feature_manager.ts ***!
  \**************************************/
(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   baseFeatures: () => (/* binding */ baseFeatures),
/* harmony export */   buildFeatures: () => (/* binding */ buildFeatures),
/* harmony export */   cacheOperationFeatures: () => (/* binding */ cacheOperationFeatures),
/* harmony export */   extractMissingFeature: () => (/* binding */ extractMissingFeature),
/* harmony export */   getOperationFeatures: () => (/* binding */ getOperationFeatures),
/* harmony export */   searchTimelineFeatures: () => (/* binding */ searchTimelineFeatures)
/* harmony export */ });
/* harmony import */ var _capture_consts__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../capture/consts */ "./src/capture/consts.ts");
/**
 * Feature Manager for X GraphQL requests
 * Handles dynamic feature discovery from 400/403/404 errors.
 *
 * Strategy:
 * 1. Each operation has its own feature cache (per-operation features)
 * 2. When a request fails, we capture features from successful browser requests
 * 3. Features are merged: base + global dynamic + per-operation
 */

const __DBK_per_op_features = 'tc_per_op_features';
const baseFeatures = {
    responsive_web_graphql_timeline_navigation_enabled: true,
    responsive_web_graphql_skip_user_profile_image_extensions_enabled: false,
    creator_subscriptions_tweet_preview_api_enabled: true,
    responsive_web_edit_tweet_api_enabled: true,
    graphql_is_translatable_rweb_tweet_is_translatable_enabled: true,
    view_counts_everywhere_api_enabled: true,
    longform_notetweets_consumption_enabled: true,
    responsive_web_twitter_article_tweet_consumption_enabled: true,
    tweet_with_visibility_results_prefer_gql_limited_actions_policy_enabled: true,
    longform_notetweets_rich_text_read_enabled: true,
    longform_notetweets_inline_media_enabled: true,
    rweb_video_screen_enabled: false,
    standardized_nudges_misinfo: true,
    freedom_of_speech_not_reach_fetch_enabled: true,
    responsive_web_enhance_cards_enabled: false,
    articles_preview_enabled: true,
    communities_web_enable_tweet_community_results_fetch: true,
    c9s_tweet_anatomy_moderator_badge_enabled: true
};
// Per-operation features for SearchTimeline
const searchTimelineFeatures = {
    profile_label_improvements_pcf_label_in_post_enabled: true,
    responsive_web_profile_redirect_enabled: false,
    rweb_tipjar_consumption_enabled: false,
    verified_phone_label_enabled: false,
    premium_content_api_read_enabled: false,
    responsive_web_grok_analyze_button_fetch_trends_enabled: false,
    responsive_web_grok_analyze_post_followups_enabled: true,
    responsive_web_jetfuel_frame: true,
    responsive_web_grok_share_attachment_enabled: true,
    responsive_web_grok_annotations_enabled: true,
    tweet_awards_web_tipping_enabled: false,
    content_disclosure_indicator_enabled: true,
    content_disclosure_ai_generated_indicator_enabled: true,
    responsive_web_grok_show_grok_translated_post: false,
    responsive_web_grok_analysis_button_from_backend: true,
    post_ctas_fetch_enabled: true,
    longform_notetweets_inline_media_enabled: false,
    responsive_web_grok_image_annotation_enabled: true,
    responsive_web_grok_imagine_annotation_enabled: true,
    responsive_web_grok_community_note_auto_translation_is_enabled: false
};
async function extractMissingFeature(body) {
    if (!body)
        return null;
    // X normally returns: "cannot be null: some_feature_flag"
    const m = body.match(/cannot be null:\s*([a-zA-Z0-9_]+)/);
    if (!m)
        return null;
    const feature = m[1];
    const data = await chrome.storage.local.get(_capture_consts__WEBPACK_IMPORTED_MODULE_0__.__DBK_dynamic_features);
    const current = (data[_capture_consts__WEBPACK_IMPORTED_MODULE_0__.__DBK_dynamic_features] || {});
    if (!(feature in current)) {
        current[feature] = true;
        await chrome.storage.local.set({ [_capture_consts__WEBPACK_IMPORTED_MODULE_0__.__DBK_dynamic_features]: current });
        console.log("[TweetClaw-Feature] Auto-harvested new feature flag:", feature);
    }
    return feature;
}
/**
 * Build features for a specific operation
 * Priority: base < global dynamic < per-operation
 */
async function buildFeatures(op) {
    const data = await chrome.storage.local.get([_capture_consts__WEBPACK_IMPORTED_MODULE_0__.__DBK_dynamic_features, __DBK_per_op_features]);
    const globalDynamic = (data[_capture_consts__WEBPACK_IMPORTED_MODULE_0__.__DBK_dynamic_features] || {});
    const perOpFeatures = (data[__DBK_per_op_features] || {});
    const opSpecific = op ? (perOpFeatures[op] || {}) : {};
    // Special handling for SearchTimeline - use hardcoded features if not cached
    if (op === 'SearchTimeline' && Object.keys(opSpecific).length === 0) {
        return { ...baseFeatures, ...globalDynamic, ...searchTimelineFeatures };
    }
    return { ...baseFeatures, ...globalDynamic, ...opSpecific };
}
/**
 * Cache features for a specific operation (learned from successful browser requests)
 */
async function cacheOperationFeatures(op, features) {
    const data = await chrome.storage.local.get(__DBK_per_op_features);
    const perOpFeatures = (data[__DBK_per_op_features] || {});
    // Merge with existing features for this operation
    perOpFeatures[op] = { ...(perOpFeatures[op] || {}), ...features };
    await chrome.storage.local.set({ [__DBK_per_op_features]: perOpFeatures });
    console.log(`[TweetClaw-Feature] Cached features for ${op}:`, Object.keys(features).length, 'flags');
}
/**
 * Get cached features for a specific operation
 */
async function getOperationFeatures(op) {
    const data = await chrome.storage.local.get(__DBK_per_op_features);
    const perOpFeatures = (data[__DBK_per_op_features] || {});
    return perOpFeatures[op] || null;
}


/***/ },

/***/ "./src/x_api/twitter_api.ts"
/*!**********************************!*\
  !*** ./src/x_api/twitter_api.ts ***!
  \**********************************/
(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   fetchUserByRestId: () => (/* binding */ fetchUserByRestId),
/* harmony export */   fetchUserByScreenName: () => (/* binding */ fetchUserByScreenName),
/* harmony export */   fetchUserByUsername: () => (/* binding */ fetchUserByUsername),
/* harmony export */   performLegacyREST: () => (/* binding */ performLegacyREST),
/* harmony export */   performMutation: () => (/* binding */ performMutation),
/* harmony export */   performQuery: () => (/* binding */ performQuery),
/* harmony export */   uploadMedia: () => (/* binding */ uploadMedia)
/* harmony export */ });
/* harmony import */ var _capture_consts__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../capture/consts */ "./src/capture/consts.ts");
/* harmony import */ var _feature_manager__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./feature_manager */ "./src/x_api/feature_manager.ts");
/* harmony import */ var _txid__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./txid */ "./src/x_api/txid.ts");



/**
 * Twitter API Client
 * Designed to run in Content Script (for cookies) and Background (for harvesting).
 */
async function getAuthHeader() {
    const res = await chrome.storage.local.get(_capture_consts__WEBPACK_IMPORTED_MODULE_0__.__DBK_bearer_token);
    return res[_capture_consts__WEBPACK_IMPORTED_MODULE_0__.__DBK_bearer_token] || "";
}
async function getCsrfToken() {
    // Content script: read from document.cookie
    // Background: read from chrome.cookies
    if (typeof document !== 'undefined' && document.cookie) {
        const match = document.cookie.match(/(?:^|;\s*)ct0=([^;]+)/);
        if (match)
            return match[1];
    }
    return new Promise((resolve) => {
        chrome.cookies.get({ url: 'https://x.com', name: 'ct0' }, (cookie) => {
            resolve(cookie ? cookie.value : "");
        });
    });
}
async function getUrlWithQueryId(op) {
    const res = await chrome.storage.local.get(_capture_consts__WEBPACK_IMPORTED_MODULE_0__.__DBK_query_id_map);
    const map = (res[_capture_consts__WEBPACK_IMPORTED_MODULE_0__.__DBK_query_id_map] || {});
    const queryId = map[op];
    if (!queryId)
        return null;
    const url = `https://x.com/i/api/graphql/${queryId}/${op}`;
    const path = `/i/api/graphql/${queryId}/${op}`;
    return { url, path };
}
async function performMutation(op, variables, retryCount = 0) {
    const target = await getUrlWithQueryId(op);
    if (!target)
        throw new Error(`Missing harvested queryId for operation: ${op}`);
    const bearer = await getAuthHeader();
    const csrf = await getCsrfToken();
    // TweetCat txid logic
    const txid = await (0,_txid__WEBPACK_IMPORTED_MODULE_2__.getTransactionIdFor)('POST', target.path);
    const headers = {
        'authorization': bearer,
        'x-csrf-token': csrf,
        'x-client-transaction-id': txid,
        'content-type': 'application/json',
        'x-twitter-active-user': 'yes',
        'x-twitter-auth-type': 'OAuth2Session',
        'x-twitter-client-language': 'zh-cn',
        'referer': 'https://x.com/',
        'accept': '*/*'
    };
    // Some operations (like CreateBookmark, DeleteBookmark) don't need features
    const operationsWithoutFeatures = ['CreateBookmark', 'DeleteBookmark'];
    const needsFeatures = !operationsWithoutFeatures.includes(op);
    const payload = {
        variables,
        queryId: target.url.split('/')[6] // Fix: should be index 6, not 5
    };
    // Only add features if needed
    if (needsFeatures) {
        const features = await (0,_feature_manager__WEBPACK_IMPORTED_MODULE_1__.buildFeatures)(op);
        payload.features = features;
        console.log(`[TwitterAPI] ${op} request with features:`, Object.keys(features));
    }
    else {
        console.log(`[TwitterAPI] ${op} request without features`);
    }
    const response = await fetch(target.url, {
        method: 'POST',
        headers,
        body: JSON.stringify(payload),
        credentials: 'include'
    });
    if (!response.ok) {
        const text = await response.text();
        console.error(`[TwitterAPI] ${op} failed (${response.status}):`, text);
        // Try to extract missing feature from error response
        const missingFeature = await (0,_feature_manager__WEBPACK_IMPORTED_MODULE_1__.extractMissingFeature)(text);
        // If we found a missing feature and haven't retried yet, retry with the new feature
        if (missingFeature && retryCount === 0) {
            console.warn(`[TwitterAPI] ${op} missing feature: ${missingFeature}, retrying...`);
            return performMutation(op, variables, retryCount + 1);
        }
        throw new Error(`X API Error ${response.status} for ${op}: ${text}`);
    }
    return await response.json();
}
/**
 * 专门处理推特老旧的 1.1 REST API（如 friendships/create.json）
 * 这些接口不使用 GraphQL，也不需要 queryId。
 */
async function performLegacyREST(path, params) {
    const bearer = await getAuthHeader();
    const csrf = await getCsrfToken();
    const txid = await (0,_txid__WEBPACK_IMPORTED_MODULE_2__.getTransactionIdFor)('POST', path);
    const headers = {
        'authorization': bearer,
        'x-csrf-token': csrf,
        'x-client-transaction-id': txid,
        'content-type': 'application/x-www-form-urlencoded',
        'x-twitter-active-user': 'yes',
        'x-twitter-auth-type': 'OAuth2Session',
        'referer': 'https://x.com/',
        'accept': '*/*'
    };
    const url = `https://x.com${path}`;
    const body = new URLSearchParams(params).toString();
    const response = await fetch(url, {
        method: 'POST',
        headers,
        body,
        credentials: 'include'
    });
    if (!response.ok) {
        const text = await response.text();
        throw new Error(`X Legacy API Error ${response.status} for ${path}: ${text}`);
    }
    return await response.json();
}
/**
 * 使用稳定的 QueryId 抓取用户资料（绕过哈希变动问题）
 * 仅供在 Content Script 环境（由于 Cookie 权限问题）使用
 */
async function fetchUserByScreenName(screenName) {
    const STABLE_HASH = 'ck5KkZ8t5cOmoLssopN99Q';
    const variables = {
        screen_name: screenName,
        withSafetyModeUserFields: true,
    };
    const features = {
        hidden_profile_likes_enabled: true,
        hidden_profile_subscriptions_enabled: true,
        responsive_web_graphql_exclude_directive_enabled: true,
        verified_phone_label_enabled: false,
        subscriptions_verification_info_is_identity_verified_enabled: true,
        subscriptions_verification_info_verified_since_enabled: true,
        highlights_tweets_tab_ui_enabled: true,
        responsive_web_twitter_article_notes_tab_enabled: false,
        creator_subscriptions_tweet_preview_api_enabled: true,
        responsive_web_graphql_skip_user_profile_image_extensions_enabled: false,
        responsive_web_graphql_timeline_navigation_enabled: true,
    };
    const params = new URLSearchParams();
    params.append('variables', JSON.stringify(variables));
    params.append('features', JSON.stringify(features));
    const url = `https://x.com/i/api/graphql/${STABLE_HASH}/UserByScreenName?${params.toString()}`;
    // 优先使用动态 harvested 的 Bearer Token，fallback 到写死的默认值
    const bearerFromStorage = await getAuthHeader();
    const FALLBACK_BEARER = 'Bearer AAAAAAAAAAAAAAAAAAAAANRILgAAAAAAnNwIzUejRCOuH5E6I8xnZz4puTs%3D1Zv7ttfk8LF81IUq16cHjhLTvJu4FA33AGWWjCpTnA';
    const bearer = bearerFromStorage || FALLBACK_BEARER;
    // CSRF Token（仅限内容脚本上下文，document.cookie 可访问）
    const csrfToken = await getCsrfToken();
    console.log(`[TwitterAPI] fetchUserByScreenName: bearer=${bearer ? 'present' : 'MISSING'}, csrf=${csrfToken ? 'present' : 'MISSING'}`);
    const headers = {
        'authorization': bearer,
        'x-csrf-token': csrfToken,
        'content-type': 'application/json',
        'x-twitter-active-user': 'yes',
        'x-twitter-client-language': 'en',
        'referer': 'https://x.com/',
        'accept': '*/*'
    };
    console.log('[TwitterAPI] fetchUserByScreenName: sending fetch...');
    let response;
    try {
        response = await fetch(url, {
            method: 'GET',
            headers,
            credentials: 'include'
        });
    }
    catch (networkErr) {
        console.error('[TwitterAPI] fetchUserByScreenName: network error', networkErr);
        throw networkErr;
    }
    console.log(`[TwitterAPI] fetchUserByScreenName: response status ${response.status}`);
    if (!response.ok) {
        const errText = await response.text();
        console.error(`[TwitterAPI] fetchUserByScreenName: ${response.status}`, errText.slice(0, 200));
        throw new Error(`UserByScreenName failed: ${response.status}`);
    }
    const json = await response.json();
    console.log('[TwitterAPI] fetchUserByScreenName: got JSON, keys=', Object.keys(json));
    return json;
}
async function performQuery(op, variables, retryCount = 0) {
    const target = await getUrlWithQueryId(op);
    if (!target)
        throw new Error(`Missing harvested queryId for operation: ${op}`);
    const bearer = await getAuthHeader();
    const csrf = await getCsrfToken();
    const features = await (0,_feature_manager__WEBPACK_IMPORTED_MODULE_1__.buildFeatures)(op);
    // Add transaction ID for GET requests (same as performMutation)
    const txid = await (0,_txid__WEBPACK_IMPORTED_MODULE_2__.getTransactionIdFor)('GET', target.path);
    const params = new URLSearchParams();
    params.append('variables', JSON.stringify(variables));
    params.append('features', JSON.stringify(features));
    const url = `${target.url}?${params.toString()}`;
    const headers = {
        'authorization': bearer,
        'x-csrf-token': csrf,
        'x-client-transaction-id': txid,
        'content-type': 'application/json',
        'x-twitter-active-user': 'yes',
        'x-twitter-auth-type': 'OAuth2Session',
        'x-twitter-client-language': 'en',
        'referer': 'https://x.com/',
        'accept': '*/*'
    };
    const response = await fetch(url, {
        method: 'GET',
        headers,
        credentials: 'include'
    });
    if (!response.ok) {
        const text = await response.text();
        await (0,_feature_manager__WEBPACK_IMPORTED_MODULE_1__.extractMissingFeature)(text);
        // For 404 errors, retry once with fresh features
        if (response.status === 404 && retryCount === 0) {
            console.warn(`[TwitterAPI] ${op} query returned 404, retrying with fresh features...`);
            await new Promise(resolve => setTimeout(resolve, 500));
            return performQuery(op, variables, retryCount + 1);
        }
        throw new Error(`X API Error ${response.status} for ${op}: ${text}`);
    }
    const result = await response.json();
    console.log(`[TwitterAPI] GraphQL ${op} Response:`, result);
    return result;
}
/**
 * 根据用户名获取完整的用户 Profile 信息
 */
async function fetchUserByUsername(username) {
    const cleanUsername = username.startsWith('@') ? username.substring(1) : username;
    const data = await performQuery('UserByScreenName', {
        screen_name: cleanUsername,
        withSafetyModeUserFields: true
    });
    // 从复杂的 GraphQL 响应中提取用户对象
    const userResult = data?.data?.user?.result;
    if (!userResult || userResult.__typename === 'UserUnavailable') {
        return null;
    }
    return userResult;
}
/**
 * 根据 User ID 获取完整的用户 Profile 信息 (UserByRestId)
 */
async function fetchUserByRestId(userId) {
    const data = await performQuery('UserByRestId', {
        userId: userId,
        withSafetyModeUserFields: true
    });
    const userResult = data?.data?.user?.result;
    if (!userResult || userResult.__typename === 'UserUnavailable') {
        return null;
    }
    return userResult;
}
/**
 * 上传媒体文件(图片)
 * @param mediaData Base64 编码的媒体数据
 * @param mimeType MIME 类型,如 image/png, image/jpeg
 * @returns media_id_string
 */
async function uploadMedia(mediaData, mimeType) {
    const bearer = await getAuthHeader();
    const csrf = await getCsrfToken();
    // 将 base64 转换为 Blob
    const byteString = atob(mediaData);
    const ab = new ArrayBuffer(byteString.length);
    const ia = new Uint8Array(ab);
    for (let i = 0; i < byteString.length; i++) {
        ia[i] = byteString.charCodeAt(i);
    }
    const blob = new Blob([ab], { type: mimeType });
    const totalBytes = blob.size;
    // 根据 MIME 类型确定 media_category
    const isVideo = mimeType.startsWith('video/');
    const mediaCategory = isVideo ? 'tweet_video' : 'tweet_image';
    // 步骤 1: INIT
    const mediaType = encodeURIComponent(mimeType);
    const initUrl = `https://upload.x.com/i/media/upload.json?command=INIT&total_bytes=${totalBytes}&media_type=${mediaType}&media_category=${mediaCategory}`;
    const initTxid = await (0,_txid__WEBPACK_IMPORTED_MODULE_2__.getTransactionIdFor)('POST', '/i/media/upload.json');
    const initResponse = await fetch(initUrl, {
        method: 'POST',
        headers: {
            'authorization': bearer,
            'x-csrf-token': csrf,
            'x-client-transaction-id': initTxid,
            'x-twitter-auth-type': 'OAuth2Session',
        },
        credentials: 'include'
    });
    if (!initResponse.ok) {
        const text = await initResponse.text();
        throw new Error(`Media upload INIT failed: ${initResponse.status} ${text}`);
    }
    const initData = await initResponse.json();
    const mediaId = initData.media_id_string;
    console.log(`[TwitterAPI] Media upload INIT success, media_id=${mediaId}`);
    // 步骤 2: APPEND - 分块上传
    // Twitter 限制单次请求大小，大文件需要分块上传（每块最多 5MB）
    const CHUNK_SIZE = 5 * 1024 * 1024; // 5MB
    const totalChunks = Math.ceil(totalBytes / CHUNK_SIZE);
    console.log(`[TwitterAPI] Uploading ${totalBytes} bytes in ${totalChunks} chunk(s)`);
    for (let segmentIndex = 0; segmentIndex < totalChunks; segmentIndex++) {
        const start = segmentIndex * CHUNK_SIZE;
        const end = Math.min(start + CHUNK_SIZE, totalBytes);
        const chunk = blob.slice(start, end);
        console.log(`[TwitterAPI] Uploading chunk ${segmentIndex + 1}/${totalChunks} (${chunk.size} bytes)`);
        const appendUrl = `https://upload.x.com/i/media/upload.json?command=APPEND&media_id=${mediaId}&segment_index=${segmentIndex}`;
        const appendTxid = await (0,_txid__WEBPACK_IMPORTED_MODULE_2__.getTransactionIdFor)('POST', '/i/media/upload.json');
        const formData = new FormData();
        formData.append('media', chunk, 'blob');
        const appendResponse = await fetch(appendUrl, {
            method: 'POST',
            headers: {
                'authorization': bearer,
                'x-csrf-token': csrf,
                'x-client-transaction-id': appendTxid,
                'x-twitter-auth-type': 'OAuth2Session',
            },
            body: formData,
            credentials: 'include'
        });
        if (!appendResponse.ok) {
            const text = await appendResponse.text();
            throw new Error(`Media upload APPEND failed at chunk ${segmentIndex + 1}/${totalChunks}: ${appendResponse.status} ${text}`);
        }
        console.log(`[TwitterAPI] Chunk ${segmentIndex + 1}/${totalChunks} uploaded successfully`);
    }
    console.log(`[TwitterAPI] All chunks uploaded successfully`);
    // 步骤 3: FINALIZE
    const finalizeUrl = `https://upload.x.com/i/media/upload.json?command=FINALIZE&media_id=${mediaId}`;
    const finalizeTxid = await (0,_txid__WEBPACK_IMPORTED_MODULE_2__.getTransactionIdFor)('POST', '/i/media/upload.json');
    const finalizeResponse = await fetch(finalizeUrl, {
        method: 'POST',
        headers: {
            'authorization': bearer,
            'x-csrf-token': csrf,
            'x-client-transaction-id': finalizeTxid,
            'x-twitter-auth-type': 'OAuth2Session',
        },
        credentials: 'include'
    });
    if (!finalizeResponse.ok) {
        const text = await finalizeResponse.text();
        throw new Error(`Media upload FINALIZE failed: ${finalizeResponse.status} ${text}`);
    }
    const finalizeData = await finalizeResponse.json();
    console.log(`[TwitterAPI] Media upload FINALIZE success, media_id=${finalizeData.media_id_string}`);
    // 步骤 4: 如果是视频,需要轮询 STATUS 等待处理完成
    if (isVideo) {
        console.log(`[TwitterAPI] Video detected, waiting for processing...`);
        let processingComplete = false;
        let attempts = 0;
        const maxAttempts = 60; // 最多等待 60 次 (约 5 分钟)
        while (!processingComplete && attempts < maxAttempts) {
            attempts++;
            await new Promise(resolve => setTimeout(resolve, 5000)); // 等待 5 秒
            const statusUrl = `https://upload.x.com/i/media/upload.json?command=STATUS&media_id=${mediaId}`;
            const statusTxid = await (0,_txid__WEBPACK_IMPORTED_MODULE_2__.getTransactionIdFor)('GET', '/i/media/upload.json');
            const statusResponse = await fetch(statusUrl, {
                method: 'GET',
                headers: {
                    'authorization': bearer,
                    'x-csrf-token': csrf,
                    'x-client-transaction-id': statusTxid,
                    'x-twitter-auth-type': 'OAuth2Session',
                },
                credentials: 'include'
            });
            if (!statusResponse.ok) {
                console.warn(`[TwitterAPI] STATUS check failed: ${statusResponse.status}`);
                break;
            }
            const statusData = await statusResponse.json();
            console.log(`[TwitterAPI] Video processing status: ${statusData.processing_info?.state || 'unknown'}`);
            if (statusData.processing_info?.state === 'succeeded') {
                processingComplete = true;
                console.log(`[TwitterAPI] Video processing completed successfully`);
            }
            else if (statusData.processing_info?.state === 'failed') {
                throw new Error(`Video processing failed: ${statusData.processing_info?.error?.message || 'unknown error'}`);
            }
            // 如果是 'pending' 或 'in_progress',继续轮询
        }
        if (!processingComplete) {
            console.warn(`[TwitterAPI] Video processing timeout after ${attempts} attempts`);
        }
    }
    return finalizeData.media_id_string;
}


/***/ },

/***/ "./src/x_api/txid.ts"
/*!***************************!*\
  !*** ./src/x_api/txid.ts ***!
  \***************************/
(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   getTransactionIdFor: () => (/* binding */ getTransactionIdFor)
/* harmony export */ });
/* harmony import */ var x_client_transaction_id__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! x-client-transaction-id */ "./node_modules/x-client-transaction-id/esm/mod.js");
/**
 * Twitter Transaction ID (txid) generator.
 * Uses x-client-transaction-id library (same as TweetCat).
 */

let cachedDoc = null;
let lastFetched = 0;
async function getXDoc() {
    const now = Date.now();
    if (!cachedDoc || now - lastFetched > 60000) { // 缓存 60s
        const res = await fetch("https://x.com/", { credentials: "omit" });
        const html = await res.text();
        cachedDoc = new DOMParser().parseFromString(html, "text/html");
        lastFetched = now;
    }
    return cachedDoc;
}
async function getTransactionIdFor(method, path) {
    const doc = await getXDoc();
    const tx = await x_client_transaction_id__WEBPACK_IMPORTED_MODULE_0__.ClientTransaction.create(doc);
    return tx.generateTransactionId(method, path);
}


/***/ }

}]);
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoianMvc3JjX3NoaW1zX2xpbmtlZG9tX3RzLXNyY194X2FwaV90d2l0dGVyX2FwaV90cy5qcyIsIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7O0FBQUE7QUFDTztBQUNQO0FBQ0E7QUFDQSxhQUFhLFVBQVU7QUFDdkI7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQ0xBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUMyRDtBQUMzRDtBQUNPO0FBQ1A7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNPO0FBQ1A7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ087QUFDUDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLGdEQUFnRCxtRUFBc0I7QUFDdEUsMEJBQTBCLG1FQUFzQixPQUFPO0FBQ3ZEO0FBQ0E7QUFDQSx5Q0FBeUMsQ0FBQyxtRUFBc0IsWUFBWTtBQUM1RTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ087QUFDUCxpREFBaUQsbUVBQXNCO0FBQ3ZFLGdDQUFnQyxtRUFBc0IsT0FBTztBQUM3RCw0REFBNEQ7QUFDNUQsb0RBQW9EO0FBQ3BEO0FBQ0E7QUFDQSxpQkFBaUI7QUFDakI7QUFDQSxhQUFhO0FBQ2I7QUFDQTtBQUNBO0FBQ0E7QUFDTztBQUNQO0FBQ0EsNERBQTREO0FBQzVEO0FBQ0EsMEJBQTBCLDJCQUEyQjtBQUNyRCxxQ0FBcUMsd0NBQXdDO0FBQzdFLDJEQUEyRCxHQUFHO0FBQzlEO0FBQ0E7QUFDQTtBQUNBO0FBQ087QUFDUDtBQUNBLDREQUE0RDtBQUM1RDtBQUNBOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUN4RzJFO0FBQ0Y7QUFDNUI7QUFDN0M7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLCtDQUErQywrREFBa0I7QUFDakUsZUFBZSwrREFBa0I7QUFDakM7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLG1EQUFtRCxZQUFZO0FBQy9EO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsNkJBQTZCLG1DQUFtQztBQUNoRTtBQUNBLFNBQVM7QUFDVCxLQUFLO0FBQ0w7QUFDQTtBQUNBLCtDQUErQywrREFBa0I7QUFDakUscUJBQXFCLCtEQUFrQixPQUFPO0FBQzlDO0FBQ0E7QUFDQTtBQUNBLCtDQUErQyxRQUFRLEdBQUcsR0FBRztBQUM3RCxtQ0FBbUMsUUFBUSxHQUFHLEdBQUc7QUFDakQsYUFBYTtBQUNiO0FBQ087QUFDUDtBQUNBO0FBQ0Esb0VBQW9FLEdBQUc7QUFDdkU7QUFDQTtBQUNBO0FBQ0EsdUJBQXVCLDBEQUFtQjtBQUMxQztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsK0JBQStCLCtEQUFhO0FBQzVDO0FBQ0Esb0NBQW9DLElBQUk7QUFDeEM7QUFDQTtBQUNBLG9DQUFvQyxJQUFJO0FBQ3hDO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLEtBQUs7QUFDTDtBQUNBO0FBQ0Esc0NBQXNDLElBQUksVUFBVSxnQkFBZ0I7QUFDcEU7QUFDQSxxQ0FBcUMsdUVBQXFCO0FBQzFEO0FBQ0E7QUFDQSx5Q0FBeUMsSUFBSSxtQkFBbUIsZUFBZTtBQUMvRTtBQUNBO0FBQ0EsdUNBQXVDLGlCQUFpQixNQUFNLEdBQUcsSUFBSSxLQUFLO0FBQzFFO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ087QUFDUDtBQUNBO0FBQ0EsdUJBQXVCLDBEQUFtQjtBQUMxQztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLGdDQUFnQyxLQUFLO0FBQ3JDO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLEtBQUs7QUFDTDtBQUNBO0FBQ0EsOENBQThDLGlCQUFpQixNQUFNLEtBQUssSUFBSSxLQUFLO0FBQ25GO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ087QUFDUDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSwrQ0FBK0MsWUFBWSxvQkFBb0Isa0JBQWtCO0FBQ2pHO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLDhEQUE4RCwrQkFBK0IsU0FBUyxrQ0FBa0M7QUFDeEk7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxTQUFTO0FBQ1Q7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLHVFQUF1RSxnQkFBZ0I7QUFDdkY7QUFDQTtBQUNBLDZEQUE2RCxnQkFBZ0I7QUFDN0Usb0RBQW9ELGdCQUFnQjtBQUNwRTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ087QUFDUDtBQUNBO0FBQ0Esb0VBQW9FLEdBQUc7QUFDdkU7QUFDQTtBQUNBLDJCQUEyQiwrREFBYTtBQUN4QztBQUNBLHVCQUF1QiwwREFBbUI7QUFDMUM7QUFDQTtBQUNBO0FBQ0EsbUJBQW1CLFdBQVcsR0FBRyxrQkFBa0I7QUFDbkQ7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsS0FBSztBQUNMO0FBQ0E7QUFDQSxjQUFjLHVFQUFxQjtBQUNuQztBQUNBO0FBQ0EseUNBQXlDLElBQUk7QUFDN0M7QUFDQTtBQUNBO0FBQ0EsdUNBQXVDLGlCQUFpQixNQUFNLEdBQUcsSUFBSSxLQUFLO0FBQzFFO0FBQ0E7QUFDQSx3Q0FBd0MsSUFBSTtBQUM1QztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ087QUFDUDtBQUNBO0FBQ0E7QUFDQTtBQUNBLEtBQUs7QUFDTDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNPO0FBQ1A7QUFDQTtBQUNBO0FBQ0EsS0FBSztBQUNMO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNPO0FBQ1A7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0Esb0JBQW9CLHVCQUF1QjtBQUMzQztBQUNBO0FBQ0Esa0NBQWtDLGdCQUFnQjtBQUNsRDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSx5RkFBeUYsV0FBVyxjQUFjLFVBQVUsa0JBQWtCLGNBQWM7QUFDNUosMkJBQTJCLDBEQUFtQjtBQUM5QztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLFNBQVM7QUFDVDtBQUNBLEtBQUs7QUFDTDtBQUNBO0FBQ0EscURBQXFELHFCQUFxQixFQUFFLEtBQUs7QUFDakY7QUFDQTtBQUNBO0FBQ0Esb0VBQW9FLFFBQVE7QUFDNUU7QUFDQTtBQUNBLHdDQUF3QztBQUN4QztBQUNBLDBDQUEwQyxZQUFZLFdBQVcsYUFBYTtBQUM5RSwrQkFBK0IsNEJBQTRCO0FBQzNEO0FBQ0E7QUFDQTtBQUNBLG9EQUFvRCxpQkFBaUIsR0FBRyxhQUFhLEdBQUcsWUFBWTtBQUNwRyw4RkFBOEYsUUFBUSxpQkFBaUIsYUFBYTtBQUNwSSxpQ0FBaUMsMERBQW1CO0FBQ3BEO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLGFBQWE7QUFDYjtBQUNBO0FBQ0EsU0FBUztBQUNUO0FBQ0E7QUFDQSxtRUFBbUUsaUJBQWlCLEdBQUcsWUFBWSxJQUFJLHVCQUF1QixFQUFFLEtBQUs7QUFDckk7QUFDQSwwQ0FBMEMsaUJBQWlCLEdBQUcsYUFBYTtBQUMzRTtBQUNBO0FBQ0E7QUFDQSw4RkFBOEYsUUFBUTtBQUN0RywrQkFBK0IsMERBQW1CO0FBQ2xEO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsU0FBUztBQUNUO0FBQ0EsS0FBSztBQUNMO0FBQ0E7QUFDQSx5REFBeUQseUJBQXlCLEVBQUUsS0FBSztBQUN6RjtBQUNBO0FBQ0Esd0VBQXdFLDZCQUE2QjtBQUNyRztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsZ0NBQWdDO0FBQ2hDO0FBQ0E7QUFDQSxxRUFBcUU7QUFDckUsa0dBQWtHLFFBQVE7QUFDMUcscUNBQXFDLDBEQUFtQjtBQUN4RDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLGlCQUFpQjtBQUNqQjtBQUNBLGFBQWE7QUFDYjtBQUNBLGtFQUFrRSxzQkFBc0I7QUFDeEY7QUFDQTtBQUNBO0FBQ0EsaUVBQWlFLCtDQUErQztBQUNoSDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsNERBQTRELDhEQUE4RDtBQUMxSDtBQUNBO0FBQ0E7QUFDQTtBQUNBLHdFQUF3RSxVQUFVO0FBQ2xGO0FBQ0E7QUFDQTtBQUNBOzs7Ozs7Ozs7Ozs7Ozs7O0FDNVlBO0FBQ0E7QUFDQTtBQUNBO0FBQzREO0FBQzVEO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsbURBQW1EO0FBQ25ELG9EQUFvRCxxQkFBcUI7QUFDekU7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ087QUFDUDtBQUNBLHFCQUFxQixzRUFBaUI7QUFDdEM7QUFDQSIsInNvdXJjZXMiOlsid2VicGFjazovL1R3ZWV0Q2xhdy8uL3NyYy9zaGltcy9saW5rZWRvbS50cyIsIndlYnBhY2s6Ly9Ud2VldENsYXcvLi9zcmMveF9hcGkvZmVhdHVyZV9tYW5hZ2VyLnRzIiwid2VicGFjazovL1R3ZWV0Q2xhdy8uL3NyYy94X2FwaS90d2l0dGVyX2FwaS50cyIsIndlYnBhY2s6Ly9Ud2VldENsYXcvLi9zcmMveF9hcGkvdHhpZC50cyJdLCJzb3VyY2VzQ29udGVudCI6WyIvLyDku4Xmj5DkvpvlupPph4zkvJrnlKjliLDnmoQgcGFyc2VIVE1M77yM6L+U5Zue57uT5p6E6LefIGxpbmtlZG9tIOexu+S8vFxuZXhwb3J0IGZ1bmN0aW9uIHBhcnNlSFRNTChodG1sKSB7XG4gICAgY29uc3QgcGFyc2VyID0gbmV3IERPTVBhcnNlcigpO1xuICAgIGNvbnN0IGRvY3VtZW50ID0gcGFyc2VyLnBhcnNlRnJvbVN0cmluZyhodG1sLCBcInRleHQvaHRtbFwiKTtcbiAgICByZXR1cm4geyB3aW5kb3c6IHsgZG9jdW1lbnQgfSB9O1xufVxuIiwiLyoqXG4gKiBGZWF0dXJlIE1hbmFnZXIgZm9yIFggR3JhcGhRTCByZXF1ZXN0c1xuICogSGFuZGxlcyBkeW5hbWljIGZlYXR1cmUgZGlzY292ZXJ5IGZyb20gNDAwLzQwMy80MDQgZXJyb3JzLlxuICpcbiAqIFN0cmF0ZWd5OlxuICogMS4gRWFjaCBvcGVyYXRpb24gaGFzIGl0cyBvd24gZmVhdHVyZSBjYWNoZSAocGVyLW9wZXJhdGlvbiBmZWF0dXJlcylcbiAqIDIuIFdoZW4gYSByZXF1ZXN0IGZhaWxzLCB3ZSBjYXB0dXJlIGZlYXR1cmVzIGZyb20gc3VjY2Vzc2Z1bCBicm93c2VyIHJlcXVlc3RzXG4gKiAzLiBGZWF0dXJlcyBhcmUgbWVyZ2VkOiBiYXNlICsgZ2xvYmFsIGR5bmFtaWMgKyBwZXItb3BlcmF0aW9uXG4gKi9cbmltcG9ydCB7IF9fREJLX2R5bmFtaWNfZmVhdHVyZXMgfSBmcm9tICcuLi9jYXB0dXJlL2NvbnN0cyc7XG5jb25zdCBfX0RCS19wZXJfb3BfZmVhdHVyZXMgPSAndGNfcGVyX29wX2ZlYXR1cmVzJztcbmV4cG9ydCBjb25zdCBiYXNlRmVhdHVyZXMgPSB7XG4gICAgcmVzcG9uc2l2ZV93ZWJfZ3JhcGhxbF90aW1lbGluZV9uYXZpZ2F0aW9uX2VuYWJsZWQ6IHRydWUsXG4gICAgcmVzcG9uc2l2ZV93ZWJfZ3JhcGhxbF9za2lwX3VzZXJfcHJvZmlsZV9pbWFnZV9leHRlbnNpb25zX2VuYWJsZWQ6IGZhbHNlLFxuICAgIGNyZWF0b3Jfc3Vic2NyaXB0aW9uc190d2VldF9wcmV2aWV3X2FwaV9lbmFibGVkOiB0cnVlLFxuICAgIHJlc3BvbnNpdmVfd2ViX2VkaXRfdHdlZXRfYXBpX2VuYWJsZWQ6IHRydWUsXG4gICAgZ3JhcGhxbF9pc190cmFuc2xhdGFibGVfcndlYl90d2VldF9pc190cmFuc2xhdGFibGVfZW5hYmxlZDogdHJ1ZSxcbiAgICB2aWV3X2NvdW50c19ldmVyeXdoZXJlX2FwaV9lbmFibGVkOiB0cnVlLFxuICAgIGxvbmdmb3JtX25vdGV0d2VldHNfY29uc3VtcHRpb25fZW5hYmxlZDogdHJ1ZSxcbiAgICByZXNwb25zaXZlX3dlYl90d2l0dGVyX2FydGljbGVfdHdlZXRfY29uc3VtcHRpb25fZW5hYmxlZDogdHJ1ZSxcbiAgICB0d2VldF93aXRoX3Zpc2liaWxpdHlfcmVzdWx0c19wcmVmZXJfZ3FsX2xpbWl0ZWRfYWN0aW9uc19wb2xpY3lfZW5hYmxlZDogdHJ1ZSxcbiAgICBsb25nZm9ybV9ub3RldHdlZXRzX3JpY2hfdGV4dF9yZWFkX2VuYWJsZWQ6IHRydWUsXG4gICAgbG9uZ2Zvcm1fbm90ZXR3ZWV0c19pbmxpbmVfbWVkaWFfZW5hYmxlZDogdHJ1ZSxcbiAgICByd2ViX3ZpZGVvX3NjcmVlbl9lbmFibGVkOiBmYWxzZSxcbiAgICBzdGFuZGFyZGl6ZWRfbnVkZ2VzX21pc2luZm86IHRydWUsXG4gICAgZnJlZWRvbV9vZl9zcGVlY2hfbm90X3JlYWNoX2ZldGNoX2VuYWJsZWQ6IHRydWUsXG4gICAgcmVzcG9uc2l2ZV93ZWJfZW5oYW5jZV9jYXJkc19lbmFibGVkOiBmYWxzZSxcbiAgICBhcnRpY2xlc19wcmV2aWV3X2VuYWJsZWQ6IHRydWUsXG4gICAgY29tbXVuaXRpZXNfd2ViX2VuYWJsZV90d2VldF9jb21tdW5pdHlfcmVzdWx0c19mZXRjaDogdHJ1ZSxcbiAgICBjOXNfdHdlZXRfYW5hdG9teV9tb2RlcmF0b3JfYmFkZ2VfZW5hYmxlZDogdHJ1ZVxufTtcbi8vIFBlci1vcGVyYXRpb24gZmVhdHVyZXMgZm9yIFNlYXJjaFRpbWVsaW5lXG5leHBvcnQgY29uc3Qgc2VhcmNoVGltZWxpbmVGZWF0dXJlcyA9IHtcbiAgICBwcm9maWxlX2xhYmVsX2ltcHJvdmVtZW50c19wY2ZfbGFiZWxfaW5fcG9zdF9lbmFibGVkOiB0cnVlLFxuICAgIHJlc3BvbnNpdmVfd2ViX3Byb2ZpbGVfcmVkaXJlY3RfZW5hYmxlZDogZmFsc2UsXG4gICAgcndlYl90aXBqYXJfY29uc3VtcHRpb25fZW5hYmxlZDogZmFsc2UsXG4gICAgdmVyaWZpZWRfcGhvbmVfbGFiZWxfZW5hYmxlZDogZmFsc2UsXG4gICAgcHJlbWl1bV9jb250ZW50X2FwaV9yZWFkX2VuYWJsZWQ6IGZhbHNlLFxuICAgIHJlc3BvbnNpdmVfd2ViX2dyb2tfYW5hbHl6ZV9idXR0b25fZmV0Y2hfdHJlbmRzX2VuYWJsZWQ6IGZhbHNlLFxuICAgIHJlc3BvbnNpdmVfd2ViX2dyb2tfYW5hbHl6ZV9wb3N0X2ZvbGxvd3Vwc19lbmFibGVkOiB0cnVlLFxuICAgIHJlc3BvbnNpdmVfd2ViX2pldGZ1ZWxfZnJhbWU6IHRydWUsXG4gICAgcmVzcG9uc2l2ZV93ZWJfZ3Jva19zaGFyZV9hdHRhY2htZW50X2VuYWJsZWQ6IHRydWUsXG4gICAgcmVzcG9uc2l2ZV93ZWJfZ3Jva19hbm5vdGF0aW9uc19lbmFibGVkOiB0cnVlLFxuICAgIHR3ZWV0X2F3YXJkc193ZWJfdGlwcGluZ19lbmFibGVkOiBmYWxzZSxcbiAgICBjb250ZW50X2Rpc2Nsb3N1cmVfaW5kaWNhdG9yX2VuYWJsZWQ6IHRydWUsXG4gICAgY29udGVudF9kaXNjbG9zdXJlX2FpX2dlbmVyYXRlZF9pbmRpY2F0b3JfZW5hYmxlZDogdHJ1ZSxcbiAgICByZXNwb25zaXZlX3dlYl9ncm9rX3Nob3dfZ3Jva190cmFuc2xhdGVkX3Bvc3Q6IGZhbHNlLFxuICAgIHJlc3BvbnNpdmVfd2ViX2dyb2tfYW5hbHlzaXNfYnV0dG9uX2Zyb21fYmFja2VuZDogdHJ1ZSxcbiAgICBwb3N0X2N0YXNfZmV0Y2hfZW5hYmxlZDogdHJ1ZSxcbiAgICBsb25nZm9ybV9ub3RldHdlZXRzX2lubGluZV9tZWRpYV9lbmFibGVkOiBmYWxzZSxcbiAgICByZXNwb25zaXZlX3dlYl9ncm9rX2ltYWdlX2Fubm90YXRpb25fZW5hYmxlZDogdHJ1ZSxcbiAgICByZXNwb25zaXZlX3dlYl9ncm9rX2ltYWdpbmVfYW5ub3RhdGlvbl9lbmFibGVkOiB0cnVlLFxuICAgIHJlc3BvbnNpdmVfd2ViX2dyb2tfY29tbXVuaXR5X25vdGVfYXV0b190cmFuc2xhdGlvbl9pc19lbmFibGVkOiBmYWxzZVxufTtcbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBleHRyYWN0TWlzc2luZ0ZlYXR1cmUoYm9keSkge1xuICAgIGlmICghYm9keSlcbiAgICAgICAgcmV0dXJuIG51bGw7XG4gICAgLy8gWCBub3JtYWxseSByZXR1cm5zOiBcImNhbm5vdCBiZSBudWxsOiBzb21lX2ZlYXR1cmVfZmxhZ1wiXG4gICAgY29uc3QgbSA9IGJvZHkubWF0Y2goL2Nhbm5vdCBiZSBudWxsOlxccyooW2EtekEtWjAtOV9dKykvKTtcbiAgICBpZiAoIW0pXG4gICAgICAgIHJldHVybiBudWxsO1xuICAgIGNvbnN0IGZlYXR1cmUgPSBtWzFdO1xuICAgIGNvbnN0IGRhdGEgPSBhd2FpdCBjaHJvbWUuc3RvcmFnZS5sb2NhbC5nZXQoX19EQktfZHluYW1pY19mZWF0dXJlcyk7XG4gICAgY29uc3QgY3VycmVudCA9IChkYXRhW19fREJLX2R5bmFtaWNfZmVhdHVyZXNdIHx8IHt9KTtcbiAgICBpZiAoIShmZWF0dXJlIGluIGN1cnJlbnQpKSB7XG4gICAgICAgIGN1cnJlbnRbZmVhdHVyZV0gPSB0cnVlO1xuICAgICAgICBhd2FpdCBjaHJvbWUuc3RvcmFnZS5sb2NhbC5zZXQoeyBbX19EQktfZHluYW1pY19mZWF0dXJlc106IGN1cnJlbnQgfSk7XG4gICAgICAgIGNvbnNvbGUubG9nKFwiW1R3ZWV0Q2xhdy1GZWF0dXJlXSBBdXRvLWhhcnZlc3RlZCBuZXcgZmVhdHVyZSBmbGFnOlwiLCBmZWF0dXJlKTtcbiAgICB9XG4gICAgcmV0dXJuIGZlYXR1cmU7XG59XG4vKipcbiAqIEJ1aWxkIGZlYXR1cmVzIGZvciBhIHNwZWNpZmljIG9wZXJhdGlvblxuICogUHJpb3JpdHk6IGJhc2UgPCBnbG9iYWwgZHluYW1pYyA8IHBlci1vcGVyYXRpb25cbiAqL1xuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGJ1aWxkRmVhdHVyZXMob3ApIHtcbiAgICBjb25zdCBkYXRhID0gYXdhaXQgY2hyb21lLnN0b3JhZ2UubG9jYWwuZ2V0KFtfX0RCS19keW5hbWljX2ZlYXR1cmVzLCBfX0RCS19wZXJfb3BfZmVhdHVyZXNdKTtcbiAgICBjb25zdCBnbG9iYWxEeW5hbWljID0gKGRhdGFbX19EQktfZHluYW1pY19mZWF0dXJlc10gfHwge30pO1xuICAgIGNvbnN0IHBlck9wRmVhdHVyZXMgPSAoZGF0YVtfX0RCS19wZXJfb3BfZmVhdHVyZXNdIHx8IHt9KTtcbiAgICBjb25zdCBvcFNwZWNpZmljID0gb3AgPyAocGVyT3BGZWF0dXJlc1tvcF0gfHwge30pIDoge307XG4gICAgLy8gU3BlY2lhbCBoYW5kbGluZyBmb3IgU2VhcmNoVGltZWxpbmUgLSB1c2UgaGFyZGNvZGVkIGZlYXR1cmVzIGlmIG5vdCBjYWNoZWRcbiAgICBpZiAob3AgPT09ICdTZWFyY2hUaW1lbGluZScgJiYgT2JqZWN0LmtleXMob3BTcGVjaWZpYykubGVuZ3RoID09PSAwKSB7XG4gICAgICAgIHJldHVybiB7IC4uLmJhc2VGZWF0dXJlcywgLi4uZ2xvYmFsRHluYW1pYywgLi4uc2VhcmNoVGltZWxpbmVGZWF0dXJlcyB9O1xuICAgIH1cbiAgICByZXR1cm4geyAuLi5iYXNlRmVhdHVyZXMsIC4uLmdsb2JhbER5bmFtaWMsIC4uLm9wU3BlY2lmaWMgfTtcbn1cbi8qKlxuICogQ2FjaGUgZmVhdHVyZXMgZm9yIGEgc3BlY2lmaWMgb3BlcmF0aW9uIChsZWFybmVkIGZyb20gc3VjY2Vzc2Z1bCBicm93c2VyIHJlcXVlc3RzKVxuICovXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gY2FjaGVPcGVyYXRpb25GZWF0dXJlcyhvcCwgZmVhdHVyZXMpIHtcbiAgICBjb25zdCBkYXRhID0gYXdhaXQgY2hyb21lLnN0b3JhZ2UubG9jYWwuZ2V0KF9fREJLX3Blcl9vcF9mZWF0dXJlcyk7XG4gICAgY29uc3QgcGVyT3BGZWF0dXJlcyA9IChkYXRhW19fREJLX3Blcl9vcF9mZWF0dXJlc10gfHwge30pO1xuICAgIC8vIE1lcmdlIHdpdGggZXhpc3RpbmcgZmVhdHVyZXMgZm9yIHRoaXMgb3BlcmF0aW9uXG4gICAgcGVyT3BGZWF0dXJlc1tvcF0gPSB7IC4uLihwZXJPcEZlYXR1cmVzW29wXSB8fCB7fSksIC4uLmZlYXR1cmVzIH07XG4gICAgYXdhaXQgY2hyb21lLnN0b3JhZ2UubG9jYWwuc2V0KHsgW19fREJLX3Blcl9vcF9mZWF0dXJlc106IHBlck9wRmVhdHVyZXMgfSk7XG4gICAgY29uc29sZS5sb2coYFtUd2VldENsYXctRmVhdHVyZV0gQ2FjaGVkIGZlYXR1cmVzIGZvciAke29wfTpgLCBPYmplY3Qua2V5cyhmZWF0dXJlcykubGVuZ3RoLCAnZmxhZ3MnKTtcbn1cbi8qKlxuICogR2V0IGNhY2hlZCBmZWF0dXJlcyBmb3IgYSBzcGVjaWZpYyBvcGVyYXRpb25cbiAqL1xuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGdldE9wZXJhdGlvbkZlYXR1cmVzKG9wKSB7XG4gICAgY29uc3QgZGF0YSA9IGF3YWl0IGNocm9tZS5zdG9yYWdlLmxvY2FsLmdldChfX0RCS19wZXJfb3BfZmVhdHVyZXMpO1xuICAgIGNvbnN0IHBlck9wRmVhdHVyZXMgPSAoZGF0YVtfX0RCS19wZXJfb3BfZmVhdHVyZXNdIHx8IHt9KTtcbiAgICByZXR1cm4gcGVyT3BGZWF0dXJlc1tvcF0gfHwgbnVsbDtcbn1cbiIsImltcG9ydCB7IF9fREJLX3F1ZXJ5X2lkX21hcCwgX19EQktfYmVhcmVyX3Rva2VuIH0gZnJvbSAnLi4vY2FwdHVyZS9jb25zdHMnO1xuaW1wb3J0IHsgYnVpbGRGZWF0dXJlcywgZXh0cmFjdE1pc3NpbmdGZWF0dXJlIH0gZnJvbSAnLi9mZWF0dXJlX21hbmFnZXInO1xuaW1wb3J0IHsgZ2V0VHJhbnNhY3Rpb25JZEZvciB9IGZyb20gJy4vdHhpZCc7XG4vKipcbiAqIFR3aXR0ZXIgQVBJIENsaWVudFxuICogRGVzaWduZWQgdG8gcnVuIGluIENvbnRlbnQgU2NyaXB0IChmb3IgY29va2llcykgYW5kIEJhY2tncm91bmQgKGZvciBoYXJ2ZXN0aW5nKS5cbiAqL1xuYXN5bmMgZnVuY3Rpb24gZ2V0QXV0aEhlYWRlcigpIHtcbiAgICBjb25zdCByZXMgPSBhd2FpdCBjaHJvbWUuc3RvcmFnZS5sb2NhbC5nZXQoX19EQktfYmVhcmVyX3Rva2VuKTtcbiAgICByZXR1cm4gcmVzW19fREJLX2JlYXJlcl90b2tlbl0gfHwgXCJcIjtcbn1cbmFzeW5jIGZ1bmN0aW9uIGdldENzcmZUb2tlbigpIHtcbiAgICAvLyBDb250ZW50IHNjcmlwdDogcmVhZCBmcm9tIGRvY3VtZW50LmNvb2tpZVxuICAgIC8vIEJhY2tncm91bmQ6IHJlYWQgZnJvbSBjaHJvbWUuY29va2llc1xuICAgIGlmICh0eXBlb2YgZG9jdW1lbnQgIT09ICd1bmRlZmluZWQnICYmIGRvY3VtZW50LmNvb2tpZSkge1xuICAgICAgICBjb25zdCBtYXRjaCA9IGRvY3VtZW50LmNvb2tpZS5tYXRjaCgvKD86Xnw7XFxzKiljdDA9KFteO10rKS8pO1xuICAgICAgICBpZiAobWF0Y2gpXG4gICAgICAgICAgICByZXR1cm4gbWF0Y2hbMV07XG4gICAgfVxuICAgIHJldHVybiBuZXcgUHJvbWlzZSgocmVzb2x2ZSkgPT4ge1xuICAgICAgICBjaHJvbWUuY29va2llcy5nZXQoeyB1cmw6ICdodHRwczovL3guY29tJywgbmFtZTogJ2N0MCcgfSwgKGNvb2tpZSkgPT4ge1xuICAgICAgICAgICAgcmVzb2x2ZShjb29raWUgPyBjb29raWUudmFsdWUgOiBcIlwiKTtcbiAgICAgICAgfSk7XG4gICAgfSk7XG59XG5hc3luYyBmdW5jdGlvbiBnZXRVcmxXaXRoUXVlcnlJZChvcCkge1xuICAgIGNvbnN0IHJlcyA9IGF3YWl0IGNocm9tZS5zdG9yYWdlLmxvY2FsLmdldChfX0RCS19xdWVyeV9pZF9tYXApO1xuICAgIGNvbnN0IG1hcCA9IChyZXNbX19EQktfcXVlcnlfaWRfbWFwXSB8fCB7fSk7XG4gICAgY29uc3QgcXVlcnlJZCA9IG1hcFtvcF07XG4gICAgaWYgKCFxdWVyeUlkKVxuICAgICAgICByZXR1cm4gbnVsbDtcbiAgICBjb25zdCB1cmwgPSBgaHR0cHM6Ly94LmNvbS9pL2FwaS9ncmFwaHFsLyR7cXVlcnlJZH0vJHtvcH1gO1xuICAgIGNvbnN0IHBhdGggPSBgL2kvYXBpL2dyYXBocWwvJHtxdWVyeUlkfS8ke29wfWA7XG4gICAgcmV0dXJuIHsgdXJsLCBwYXRoIH07XG59XG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gcGVyZm9ybU11dGF0aW9uKG9wLCB2YXJpYWJsZXMsIHJldHJ5Q291bnQgPSAwKSB7XG4gICAgY29uc3QgdGFyZ2V0ID0gYXdhaXQgZ2V0VXJsV2l0aFF1ZXJ5SWQob3ApO1xuICAgIGlmICghdGFyZ2V0KVxuICAgICAgICB0aHJvdyBuZXcgRXJyb3IoYE1pc3NpbmcgaGFydmVzdGVkIHF1ZXJ5SWQgZm9yIG9wZXJhdGlvbjogJHtvcH1gKTtcbiAgICBjb25zdCBiZWFyZXIgPSBhd2FpdCBnZXRBdXRoSGVhZGVyKCk7XG4gICAgY29uc3QgY3NyZiA9IGF3YWl0IGdldENzcmZUb2tlbigpO1xuICAgIC8vIFR3ZWV0Q2F0IHR4aWQgbG9naWNcbiAgICBjb25zdCB0eGlkID0gYXdhaXQgZ2V0VHJhbnNhY3Rpb25JZEZvcignUE9TVCcsIHRhcmdldC5wYXRoKTtcbiAgICBjb25zdCBoZWFkZXJzID0ge1xuICAgICAgICAnYXV0aG9yaXphdGlvbic6IGJlYXJlcixcbiAgICAgICAgJ3gtY3NyZi10b2tlbic6IGNzcmYsXG4gICAgICAgICd4LWNsaWVudC10cmFuc2FjdGlvbi1pZCc6IHR4aWQsXG4gICAgICAgICdjb250ZW50LXR5cGUnOiAnYXBwbGljYXRpb24vanNvbicsXG4gICAgICAgICd4LXR3aXR0ZXItYWN0aXZlLXVzZXInOiAneWVzJyxcbiAgICAgICAgJ3gtdHdpdHRlci1hdXRoLXR5cGUnOiAnT0F1dGgyU2Vzc2lvbicsXG4gICAgICAgICd4LXR3aXR0ZXItY2xpZW50LWxhbmd1YWdlJzogJ3poLWNuJyxcbiAgICAgICAgJ3JlZmVyZXInOiAnaHR0cHM6Ly94LmNvbS8nLFxuICAgICAgICAnYWNjZXB0JzogJyovKidcbiAgICB9O1xuICAgIC8vIFNvbWUgb3BlcmF0aW9ucyAobGlrZSBDcmVhdGVCb29rbWFyaywgRGVsZXRlQm9va21hcmspIGRvbid0IG5lZWQgZmVhdHVyZXNcbiAgICBjb25zdCBvcGVyYXRpb25zV2l0aG91dEZlYXR1cmVzID0gWydDcmVhdGVCb29rbWFyaycsICdEZWxldGVCb29rbWFyayddO1xuICAgIGNvbnN0IG5lZWRzRmVhdHVyZXMgPSAhb3BlcmF0aW9uc1dpdGhvdXRGZWF0dXJlcy5pbmNsdWRlcyhvcCk7XG4gICAgY29uc3QgcGF5bG9hZCA9IHtcbiAgICAgICAgdmFyaWFibGVzLFxuICAgICAgICBxdWVyeUlkOiB0YXJnZXQudXJsLnNwbGl0KCcvJylbNl0gLy8gRml4OiBzaG91bGQgYmUgaW5kZXggNiwgbm90IDVcbiAgICB9O1xuICAgIC8vIE9ubHkgYWRkIGZlYXR1cmVzIGlmIG5lZWRlZFxuICAgIGlmIChuZWVkc0ZlYXR1cmVzKSB7XG4gICAgICAgIGNvbnN0IGZlYXR1cmVzID0gYXdhaXQgYnVpbGRGZWF0dXJlcyhvcCk7XG4gICAgICAgIHBheWxvYWQuZmVhdHVyZXMgPSBmZWF0dXJlcztcbiAgICAgICAgY29uc29sZS5sb2coYFtUd2l0dGVyQVBJXSAke29wfSByZXF1ZXN0IHdpdGggZmVhdHVyZXM6YCwgT2JqZWN0LmtleXMoZmVhdHVyZXMpKTtcbiAgICB9XG4gICAgZWxzZSB7XG4gICAgICAgIGNvbnNvbGUubG9nKGBbVHdpdHRlckFQSV0gJHtvcH0gcmVxdWVzdCB3aXRob3V0IGZlYXR1cmVzYCk7XG4gICAgfVxuICAgIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgZmV0Y2godGFyZ2V0LnVybCwge1xuICAgICAgICBtZXRob2Q6ICdQT1NUJyxcbiAgICAgICAgaGVhZGVycyxcbiAgICAgICAgYm9keTogSlNPTi5zdHJpbmdpZnkocGF5bG9hZCksXG4gICAgICAgIGNyZWRlbnRpYWxzOiAnaW5jbHVkZSdcbiAgICB9KTtcbiAgICBpZiAoIXJlc3BvbnNlLm9rKSB7XG4gICAgICAgIGNvbnN0IHRleHQgPSBhd2FpdCByZXNwb25zZS50ZXh0KCk7XG4gICAgICAgIGNvbnNvbGUuZXJyb3IoYFtUd2l0dGVyQVBJXSAke29wfSBmYWlsZWQgKCR7cmVzcG9uc2Uuc3RhdHVzfSk6YCwgdGV4dCk7XG4gICAgICAgIC8vIFRyeSB0byBleHRyYWN0IG1pc3NpbmcgZmVhdHVyZSBmcm9tIGVycm9yIHJlc3BvbnNlXG4gICAgICAgIGNvbnN0IG1pc3NpbmdGZWF0dXJlID0gYXdhaXQgZXh0cmFjdE1pc3NpbmdGZWF0dXJlKHRleHQpO1xuICAgICAgICAvLyBJZiB3ZSBmb3VuZCBhIG1pc3NpbmcgZmVhdHVyZSBhbmQgaGF2ZW4ndCByZXRyaWVkIHlldCwgcmV0cnkgd2l0aCB0aGUgbmV3IGZlYXR1cmVcbiAgICAgICAgaWYgKG1pc3NpbmdGZWF0dXJlICYmIHJldHJ5Q291bnQgPT09IDApIHtcbiAgICAgICAgICAgIGNvbnNvbGUud2FybihgW1R3aXR0ZXJBUEldICR7b3B9IG1pc3NpbmcgZmVhdHVyZTogJHttaXNzaW5nRmVhdHVyZX0sIHJldHJ5aW5nLi4uYCk7XG4gICAgICAgICAgICByZXR1cm4gcGVyZm9ybU11dGF0aW9uKG9wLCB2YXJpYWJsZXMsIHJldHJ5Q291bnQgKyAxKTtcbiAgICAgICAgfVxuICAgICAgICB0aHJvdyBuZXcgRXJyb3IoYFggQVBJIEVycm9yICR7cmVzcG9uc2Uuc3RhdHVzfSBmb3IgJHtvcH06ICR7dGV4dH1gKTtcbiAgICB9XG4gICAgcmV0dXJuIGF3YWl0IHJlc3BvbnNlLmpzb24oKTtcbn1cbi8qKlxuICog5LiT6Zeo5aSE55CG5o6o54m56ICB5pen55qEIDEuMSBSRVNUIEFQSe+8iOWmgiBmcmllbmRzaGlwcy9jcmVhdGUuanNvbu+8iVxuICog6L+Z5Lqb5o6l5Y+j5LiN5L2/55SoIEdyYXBoUUzvvIzkuZ/kuI3pnIDopoEgcXVlcnlJZOOAglxuICovXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gcGVyZm9ybUxlZ2FjeVJFU1QocGF0aCwgcGFyYW1zKSB7XG4gICAgY29uc3QgYmVhcmVyID0gYXdhaXQgZ2V0QXV0aEhlYWRlcigpO1xuICAgIGNvbnN0IGNzcmYgPSBhd2FpdCBnZXRDc3JmVG9rZW4oKTtcbiAgICBjb25zdCB0eGlkID0gYXdhaXQgZ2V0VHJhbnNhY3Rpb25JZEZvcignUE9TVCcsIHBhdGgpO1xuICAgIGNvbnN0IGhlYWRlcnMgPSB7XG4gICAgICAgICdhdXRob3JpemF0aW9uJzogYmVhcmVyLFxuICAgICAgICAneC1jc3JmLXRva2VuJzogY3NyZixcbiAgICAgICAgJ3gtY2xpZW50LXRyYW5zYWN0aW9uLWlkJzogdHhpZCxcbiAgICAgICAgJ2NvbnRlbnQtdHlwZSc6ICdhcHBsaWNhdGlvbi94LXd3dy1mb3JtLXVybGVuY29kZWQnLFxuICAgICAgICAneC10d2l0dGVyLWFjdGl2ZS11c2VyJzogJ3llcycsXG4gICAgICAgICd4LXR3aXR0ZXItYXV0aC10eXBlJzogJ09BdXRoMlNlc3Npb24nLFxuICAgICAgICAncmVmZXJlcic6ICdodHRwczovL3guY29tLycsXG4gICAgICAgICdhY2NlcHQnOiAnKi8qJ1xuICAgIH07XG4gICAgY29uc3QgdXJsID0gYGh0dHBzOi8veC5jb20ke3BhdGh9YDtcbiAgICBjb25zdCBib2R5ID0gbmV3IFVSTFNlYXJjaFBhcmFtcyhwYXJhbXMpLnRvU3RyaW5nKCk7XG4gICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBmZXRjaCh1cmwsIHtcbiAgICAgICAgbWV0aG9kOiAnUE9TVCcsXG4gICAgICAgIGhlYWRlcnMsXG4gICAgICAgIGJvZHksXG4gICAgICAgIGNyZWRlbnRpYWxzOiAnaW5jbHVkZSdcbiAgICB9KTtcbiAgICBpZiAoIXJlc3BvbnNlLm9rKSB7XG4gICAgICAgIGNvbnN0IHRleHQgPSBhd2FpdCByZXNwb25zZS50ZXh0KCk7XG4gICAgICAgIHRocm93IG5ldyBFcnJvcihgWCBMZWdhY3kgQVBJIEVycm9yICR7cmVzcG9uc2Uuc3RhdHVzfSBmb3IgJHtwYXRofTogJHt0ZXh0fWApO1xuICAgIH1cbiAgICByZXR1cm4gYXdhaXQgcmVzcG9uc2UuanNvbigpO1xufVxuLyoqXG4gKiDkvb/nlKjnqLPlrprnmoQgUXVlcnlJZCDmipPlj5bnlKjmiLfotYTmlpnvvIjnu5Xov4flk4jluIzlj5jliqjpl67popjvvIlcbiAqIOS7heS+m+WcqCBDb250ZW50IFNjcmlwdCDnjq/looPvvIjnlLHkuo4gQ29va2llIOadg+mZkOmXrumimO+8ieS9v+eUqFxuICovXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZmV0Y2hVc2VyQnlTY3JlZW5OYW1lKHNjcmVlbk5hbWUpIHtcbiAgICBjb25zdCBTVEFCTEVfSEFTSCA9ICdjazVLa1o4dDVjT21vTHNzb3BOOTlRJztcbiAgICBjb25zdCB2YXJpYWJsZXMgPSB7XG4gICAgICAgIHNjcmVlbl9uYW1lOiBzY3JlZW5OYW1lLFxuICAgICAgICB3aXRoU2FmZXR5TW9kZVVzZXJGaWVsZHM6IHRydWUsXG4gICAgfTtcbiAgICBjb25zdCBmZWF0dXJlcyA9IHtcbiAgICAgICAgaGlkZGVuX3Byb2ZpbGVfbGlrZXNfZW5hYmxlZDogdHJ1ZSxcbiAgICAgICAgaGlkZGVuX3Byb2ZpbGVfc3Vic2NyaXB0aW9uc19lbmFibGVkOiB0cnVlLFxuICAgICAgICByZXNwb25zaXZlX3dlYl9ncmFwaHFsX2V4Y2x1ZGVfZGlyZWN0aXZlX2VuYWJsZWQ6IHRydWUsXG4gICAgICAgIHZlcmlmaWVkX3Bob25lX2xhYmVsX2VuYWJsZWQ6IGZhbHNlLFxuICAgICAgICBzdWJzY3JpcHRpb25zX3ZlcmlmaWNhdGlvbl9pbmZvX2lzX2lkZW50aXR5X3ZlcmlmaWVkX2VuYWJsZWQ6IHRydWUsXG4gICAgICAgIHN1YnNjcmlwdGlvbnNfdmVyaWZpY2F0aW9uX2luZm9fdmVyaWZpZWRfc2luY2VfZW5hYmxlZDogdHJ1ZSxcbiAgICAgICAgaGlnaGxpZ2h0c190d2VldHNfdGFiX3VpX2VuYWJsZWQ6IHRydWUsXG4gICAgICAgIHJlc3BvbnNpdmVfd2ViX3R3aXR0ZXJfYXJ0aWNsZV9ub3Rlc190YWJfZW5hYmxlZDogZmFsc2UsXG4gICAgICAgIGNyZWF0b3Jfc3Vic2NyaXB0aW9uc190d2VldF9wcmV2aWV3X2FwaV9lbmFibGVkOiB0cnVlLFxuICAgICAgICByZXNwb25zaXZlX3dlYl9ncmFwaHFsX3NraXBfdXNlcl9wcm9maWxlX2ltYWdlX2V4dGVuc2lvbnNfZW5hYmxlZDogZmFsc2UsXG4gICAgICAgIHJlc3BvbnNpdmVfd2ViX2dyYXBocWxfdGltZWxpbmVfbmF2aWdhdGlvbl9lbmFibGVkOiB0cnVlLFxuICAgIH07XG4gICAgY29uc3QgcGFyYW1zID0gbmV3IFVSTFNlYXJjaFBhcmFtcygpO1xuICAgIHBhcmFtcy5hcHBlbmQoJ3ZhcmlhYmxlcycsIEpTT04uc3RyaW5naWZ5KHZhcmlhYmxlcykpO1xuICAgIHBhcmFtcy5hcHBlbmQoJ2ZlYXR1cmVzJywgSlNPTi5zdHJpbmdpZnkoZmVhdHVyZXMpKTtcbiAgICBjb25zdCB1cmwgPSBgaHR0cHM6Ly94LmNvbS9pL2FwaS9ncmFwaHFsLyR7U1RBQkxFX0hBU0h9L1VzZXJCeVNjcmVlbk5hbWU/JHtwYXJhbXMudG9TdHJpbmcoKX1gO1xuICAgIC8vIOS8mOWFiOS9v+eUqOWKqOaAgSBoYXJ2ZXN0ZWQg55qEIEJlYXJlciBUb2tlbu+8jGZhbGxiYWNrIOWIsOWGmeatu+eahOm7mOiupOWAvFxuICAgIGNvbnN0IGJlYXJlckZyb21TdG9yYWdlID0gYXdhaXQgZ2V0QXV0aEhlYWRlcigpO1xuICAgIGNvbnN0IEZBTExCQUNLX0JFQVJFUiA9ICdCZWFyZXIgQUFBQUFBQUFBQUFBQUFBQUFBQUFBTlJJTGdBQUFBQUFuTndJelVlalJDT3VINUU2STh4blp6NHB1VHMlM0QxWnY3dHRmazhMRjgxSVVxMTZjSGpoTFR2SnU0RkEzM0FHV1dqQ3BUbkEnO1xuICAgIGNvbnN0IGJlYXJlciA9IGJlYXJlckZyb21TdG9yYWdlIHx8IEZBTExCQUNLX0JFQVJFUjtcbiAgICAvLyBDU1JGIFRva2Vu77yI5LuF6ZmQ5YaF5a656ISa5pys5LiK5LiL5paH77yMZG9jdW1lbnQuY29va2llIOWPr+iuv+mXru+8iVxuICAgIGNvbnN0IGNzcmZUb2tlbiA9IGF3YWl0IGdldENzcmZUb2tlbigpO1xuICAgIGNvbnNvbGUubG9nKGBbVHdpdHRlckFQSV0gZmV0Y2hVc2VyQnlTY3JlZW5OYW1lOiBiZWFyZXI9JHtiZWFyZXIgPyAncHJlc2VudCcgOiAnTUlTU0lORyd9LCBjc3JmPSR7Y3NyZlRva2VuID8gJ3ByZXNlbnQnIDogJ01JU1NJTkcnfWApO1xuICAgIGNvbnN0IGhlYWRlcnMgPSB7XG4gICAgICAgICdhdXRob3JpemF0aW9uJzogYmVhcmVyLFxuICAgICAgICAneC1jc3JmLXRva2VuJzogY3NyZlRva2VuLFxuICAgICAgICAnY29udGVudC10eXBlJzogJ2FwcGxpY2F0aW9uL2pzb24nLFxuICAgICAgICAneC10d2l0dGVyLWFjdGl2ZS11c2VyJzogJ3llcycsXG4gICAgICAgICd4LXR3aXR0ZXItY2xpZW50LWxhbmd1YWdlJzogJ2VuJyxcbiAgICAgICAgJ3JlZmVyZXInOiAnaHR0cHM6Ly94LmNvbS8nLFxuICAgICAgICAnYWNjZXB0JzogJyovKidcbiAgICB9O1xuICAgIGNvbnNvbGUubG9nKCdbVHdpdHRlckFQSV0gZmV0Y2hVc2VyQnlTY3JlZW5OYW1lOiBzZW5kaW5nIGZldGNoLi4uJyk7XG4gICAgbGV0IHJlc3BvbnNlO1xuICAgIHRyeSB7XG4gICAgICAgIHJlc3BvbnNlID0gYXdhaXQgZmV0Y2godXJsLCB7XG4gICAgICAgICAgICBtZXRob2Q6ICdHRVQnLFxuICAgICAgICAgICAgaGVhZGVycyxcbiAgICAgICAgICAgIGNyZWRlbnRpYWxzOiAnaW5jbHVkZSdcbiAgICAgICAgfSk7XG4gICAgfVxuICAgIGNhdGNoIChuZXR3b3JrRXJyKSB7XG4gICAgICAgIGNvbnNvbGUuZXJyb3IoJ1tUd2l0dGVyQVBJXSBmZXRjaFVzZXJCeVNjcmVlbk5hbWU6IG5ldHdvcmsgZXJyb3InLCBuZXR3b3JrRXJyKTtcbiAgICAgICAgdGhyb3cgbmV0d29ya0VycjtcbiAgICB9XG4gICAgY29uc29sZS5sb2coYFtUd2l0dGVyQVBJXSBmZXRjaFVzZXJCeVNjcmVlbk5hbWU6IHJlc3BvbnNlIHN0YXR1cyAke3Jlc3BvbnNlLnN0YXR1c31gKTtcbiAgICBpZiAoIXJlc3BvbnNlLm9rKSB7XG4gICAgICAgIGNvbnN0IGVyclRleHQgPSBhd2FpdCByZXNwb25zZS50ZXh0KCk7XG4gICAgICAgIGNvbnNvbGUuZXJyb3IoYFtUd2l0dGVyQVBJXSBmZXRjaFVzZXJCeVNjcmVlbk5hbWU6ICR7cmVzcG9uc2Uuc3RhdHVzfWAsIGVyclRleHQuc2xpY2UoMCwgMjAwKSk7XG4gICAgICAgIHRocm93IG5ldyBFcnJvcihgVXNlckJ5U2NyZWVuTmFtZSBmYWlsZWQ6ICR7cmVzcG9uc2Uuc3RhdHVzfWApO1xuICAgIH1cbiAgICBjb25zdCBqc29uID0gYXdhaXQgcmVzcG9uc2UuanNvbigpO1xuICAgIGNvbnNvbGUubG9nKCdbVHdpdHRlckFQSV0gZmV0Y2hVc2VyQnlTY3JlZW5OYW1lOiBnb3QgSlNPTiwga2V5cz0nLCBPYmplY3Qua2V5cyhqc29uKSk7XG4gICAgcmV0dXJuIGpzb247XG59XG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gcGVyZm9ybVF1ZXJ5KG9wLCB2YXJpYWJsZXMsIHJldHJ5Q291bnQgPSAwKSB7XG4gICAgY29uc3QgdGFyZ2V0ID0gYXdhaXQgZ2V0VXJsV2l0aFF1ZXJ5SWQob3ApO1xuICAgIGlmICghdGFyZ2V0KVxuICAgICAgICB0aHJvdyBuZXcgRXJyb3IoYE1pc3NpbmcgaGFydmVzdGVkIHF1ZXJ5SWQgZm9yIG9wZXJhdGlvbjogJHtvcH1gKTtcbiAgICBjb25zdCBiZWFyZXIgPSBhd2FpdCBnZXRBdXRoSGVhZGVyKCk7XG4gICAgY29uc3QgY3NyZiA9IGF3YWl0IGdldENzcmZUb2tlbigpO1xuICAgIGNvbnN0IGZlYXR1cmVzID0gYXdhaXQgYnVpbGRGZWF0dXJlcyhvcCk7XG4gICAgLy8gQWRkIHRyYW5zYWN0aW9uIElEIGZvciBHRVQgcmVxdWVzdHMgKHNhbWUgYXMgcGVyZm9ybU11dGF0aW9uKVxuICAgIGNvbnN0IHR4aWQgPSBhd2FpdCBnZXRUcmFuc2FjdGlvbklkRm9yKCdHRVQnLCB0YXJnZXQucGF0aCk7XG4gICAgY29uc3QgcGFyYW1zID0gbmV3IFVSTFNlYXJjaFBhcmFtcygpO1xuICAgIHBhcmFtcy5hcHBlbmQoJ3ZhcmlhYmxlcycsIEpTT04uc3RyaW5naWZ5KHZhcmlhYmxlcykpO1xuICAgIHBhcmFtcy5hcHBlbmQoJ2ZlYXR1cmVzJywgSlNPTi5zdHJpbmdpZnkoZmVhdHVyZXMpKTtcbiAgICBjb25zdCB1cmwgPSBgJHt0YXJnZXQudXJsfT8ke3BhcmFtcy50b1N0cmluZygpfWA7XG4gICAgY29uc3QgaGVhZGVycyA9IHtcbiAgICAgICAgJ2F1dGhvcml6YXRpb24nOiBiZWFyZXIsXG4gICAgICAgICd4LWNzcmYtdG9rZW4nOiBjc3JmLFxuICAgICAgICAneC1jbGllbnQtdHJhbnNhY3Rpb24taWQnOiB0eGlkLFxuICAgICAgICAnY29udGVudC10eXBlJzogJ2FwcGxpY2F0aW9uL2pzb24nLFxuICAgICAgICAneC10d2l0dGVyLWFjdGl2ZS11c2VyJzogJ3llcycsXG4gICAgICAgICd4LXR3aXR0ZXItYXV0aC10eXBlJzogJ09BdXRoMlNlc3Npb24nLFxuICAgICAgICAneC10d2l0dGVyLWNsaWVudC1sYW5ndWFnZSc6ICdlbicsXG4gICAgICAgICdyZWZlcmVyJzogJ2h0dHBzOi8veC5jb20vJyxcbiAgICAgICAgJ2FjY2VwdCc6ICcqLyonXG4gICAgfTtcbiAgICBjb25zdCByZXNwb25zZSA9IGF3YWl0IGZldGNoKHVybCwge1xuICAgICAgICBtZXRob2Q6ICdHRVQnLFxuICAgICAgICBoZWFkZXJzLFxuICAgICAgICBjcmVkZW50aWFsczogJ2luY2x1ZGUnXG4gICAgfSk7XG4gICAgaWYgKCFyZXNwb25zZS5vaykge1xuICAgICAgICBjb25zdCB0ZXh0ID0gYXdhaXQgcmVzcG9uc2UudGV4dCgpO1xuICAgICAgICBhd2FpdCBleHRyYWN0TWlzc2luZ0ZlYXR1cmUodGV4dCk7XG4gICAgICAgIC8vIEZvciA0MDQgZXJyb3JzLCByZXRyeSBvbmNlIHdpdGggZnJlc2ggZmVhdHVyZXNcbiAgICAgICAgaWYgKHJlc3BvbnNlLnN0YXR1cyA9PT0gNDA0ICYmIHJldHJ5Q291bnQgPT09IDApIHtcbiAgICAgICAgICAgIGNvbnNvbGUud2FybihgW1R3aXR0ZXJBUEldICR7b3B9IHF1ZXJ5IHJldHVybmVkIDQwNCwgcmV0cnlpbmcgd2l0aCBmcmVzaCBmZWF0dXJlcy4uLmApO1xuICAgICAgICAgICAgYXdhaXQgbmV3IFByb21pc2UocmVzb2x2ZSA9PiBzZXRUaW1lb3V0KHJlc29sdmUsIDUwMCkpO1xuICAgICAgICAgICAgcmV0dXJuIHBlcmZvcm1RdWVyeShvcCwgdmFyaWFibGVzLCByZXRyeUNvdW50ICsgMSk7XG4gICAgICAgIH1cbiAgICAgICAgdGhyb3cgbmV3IEVycm9yKGBYIEFQSSBFcnJvciAke3Jlc3BvbnNlLnN0YXR1c30gZm9yICR7b3B9OiAke3RleHR9YCk7XG4gICAgfVxuICAgIGNvbnN0IHJlc3VsdCA9IGF3YWl0IHJlc3BvbnNlLmpzb24oKTtcbiAgICBjb25zb2xlLmxvZyhgW1R3aXR0ZXJBUEldIEdyYXBoUUwgJHtvcH0gUmVzcG9uc2U6YCwgcmVzdWx0KTtcbiAgICByZXR1cm4gcmVzdWx0O1xufVxuLyoqXG4gKiDmoLnmja7nlKjmiLflkI3ojrflj5blrozmlbTnmoTnlKjmiLcgUHJvZmlsZSDkv6Hmga9cbiAqL1xuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGZldGNoVXNlckJ5VXNlcm5hbWUodXNlcm5hbWUpIHtcbiAgICBjb25zdCBjbGVhblVzZXJuYW1lID0gdXNlcm5hbWUuc3RhcnRzV2l0aCgnQCcpID8gdXNlcm5hbWUuc3Vic3RyaW5nKDEpIDogdXNlcm5hbWU7XG4gICAgY29uc3QgZGF0YSA9IGF3YWl0IHBlcmZvcm1RdWVyeSgnVXNlckJ5U2NyZWVuTmFtZScsIHtcbiAgICAgICAgc2NyZWVuX25hbWU6IGNsZWFuVXNlcm5hbWUsXG4gICAgICAgIHdpdGhTYWZldHlNb2RlVXNlckZpZWxkczogdHJ1ZVxuICAgIH0pO1xuICAgIC8vIOS7juWkjeadgueahCBHcmFwaFFMIOWTjeW6lOS4reaPkOWPlueUqOaIt+WvueixoVxuICAgIGNvbnN0IHVzZXJSZXN1bHQgPSBkYXRhPy5kYXRhPy51c2VyPy5yZXN1bHQ7XG4gICAgaWYgKCF1c2VyUmVzdWx0IHx8IHVzZXJSZXN1bHQuX190eXBlbmFtZSA9PT0gJ1VzZXJVbmF2YWlsYWJsZScpIHtcbiAgICAgICAgcmV0dXJuIG51bGw7XG4gICAgfVxuICAgIHJldHVybiB1c2VyUmVzdWx0O1xufVxuLyoqXG4gKiDmoLnmja4gVXNlciBJRCDojrflj5blrozmlbTnmoTnlKjmiLcgUHJvZmlsZSDkv6Hmga8gKFVzZXJCeVJlc3RJZClcbiAqL1xuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGZldGNoVXNlckJ5UmVzdElkKHVzZXJJZCkge1xuICAgIGNvbnN0IGRhdGEgPSBhd2FpdCBwZXJmb3JtUXVlcnkoJ1VzZXJCeVJlc3RJZCcsIHtcbiAgICAgICAgdXNlcklkOiB1c2VySWQsXG4gICAgICAgIHdpdGhTYWZldHlNb2RlVXNlckZpZWxkczogdHJ1ZVxuICAgIH0pO1xuICAgIGNvbnN0IHVzZXJSZXN1bHQgPSBkYXRhPy5kYXRhPy51c2VyPy5yZXN1bHQ7XG4gICAgaWYgKCF1c2VyUmVzdWx0IHx8IHVzZXJSZXN1bHQuX190eXBlbmFtZSA9PT0gJ1VzZXJVbmF2YWlsYWJsZScpIHtcbiAgICAgICAgcmV0dXJuIG51bGw7XG4gICAgfVxuICAgIHJldHVybiB1c2VyUmVzdWx0O1xufVxuLyoqXG4gKiDkuIrkvKDlqpLkvZPmlofku7Yo5Zu+54mHKVxuICogQHBhcmFtIG1lZGlhRGF0YSBCYXNlNjQg57yW56CB55qE5aqS5L2T5pWw5o2uXG4gKiBAcGFyYW0gbWltZVR5cGUgTUlNRSDnsbvlnoss5aaCIGltYWdlL3BuZywgaW1hZ2UvanBlZ1xuICogQHJldHVybnMgbWVkaWFfaWRfc3RyaW5nXG4gKi9cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiB1cGxvYWRNZWRpYShtZWRpYURhdGEsIG1pbWVUeXBlKSB7XG4gICAgY29uc3QgYmVhcmVyID0gYXdhaXQgZ2V0QXV0aEhlYWRlcigpO1xuICAgIGNvbnN0IGNzcmYgPSBhd2FpdCBnZXRDc3JmVG9rZW4oKTtcbiAgICAvLyDlsIYgYmFzZTY0IOi9rOaNouS4uiBCbG9iXG4gICAgY29uc3QgYnl0ZVN0cmluZyA9IGF0b2IobWVkaWFEYXRhKTtcbiAgICBjb25zdCBhYiA9IG5ldyBBcnJheUJ1ZmZlcihieXRlU3RyaW5nLmxlbmd0aCk7XG4gICAgY29uc3QgaWEgPSBuZXcgVWludDhBcnJheShhYik7XG4gICAgZm9yIChsZXQgaSA9IDA7IGkgPCBieXRlU3RyaW5nLmxlbmd0aDsgaSsrKSB7XG4gICAgICAgIGlhW2ldID0gYnl0ZVN0cmluZy5jaGFyQ29kZUF0KGkpO1xuICAgIH1cbiAgICBjb25zdCBibG9iID0gbmV3IEJsb2IoW2FiXSwgeyB0eXBlOiBtaW1lVHlwZSB9KTtcbiAgICBjb25zdCB0b3RhbEJ5dGVzID0gYmxvYi5zaXplO1xuICAgIC8vIOagueaNriBNSU1FIOexu+Wei+ehruWumiBtZWRpYV9jYXRlZ29yeVxuICAgIGNvbnN0IGlzVmlkZW8gPSBtaW1lVHlwZS5zdGFydHNXaXRoKCd2aWRlby8nKTtcbiAgICBjb25zdCBtZWRpYUNhdGVnb3J5ID0gaXNWaWRlbyA/ICd0d2VldF92aWRlbycgOiAndHdlZXRfaW1hZ2UnO1xuICAgIC8vIOatpemqpCAxOiBJTklUXG4gICAgY29uc3QgbWVkaWFUeXBlID0gZW5jb2RlVVJJQ29tcG9uZW50KG1pbWVUeXBlKTtcbiAgICBjb25zdCBpbml0VXJsID0gYGh0dHBzOi8vdXBsb2FkLnguY29tL2kvbWVkaWEvdXBsb2FkLmpzb24/Y29tbWFuZD1JTklUJnRvdGFsX2J5dGVzPSR7dG90YWxCeXRlc30mbWVkaWFfdHlwZT0ke21lZGlhVHlwZX0mbWVkaWFfY2F0ZWdvcnk9JHttZWRpYUNhdGVnb3J5fWA7XG4gICAgY29uc3QgaW5pdFR4aWQgPSBhd2FpdCBnZXRUcmFuc2FjdGlvbklkRm9yKCdQT1NUJywgJy9pL21lZGlhL3VwbG9hZC5qc29uJyk7XG4gICAgY29uc3QgaW5pdFJlc3BvbnNlID0gYXdhaXQgZmV0Y2goaW5pdFVybCwge1xuICAgICAgICBtZXRob2Q6ICdQT1NUJyxcbiAgICAgICAgaGVhZGVyczoge1xuICAgICAgICAgICAgJ2F1dGhvcml6YXRpb24nOiBiZWFyZXIsXG4gICAgICAgICAgICAneC1jc3JmLXRva2VuJzogY3NyZixcbiAgICAgICAgICAgICd4LWNsaWVudC10cmFuc2FjdGlvbi1pZCc6IGluaXRUeGlkLFxuICAgICAgICAgICAgJ3gtdHdpdHRlci1hdXRoLXR5cGUnOiAnT0F1dGgyU2Vzc2lvbicsXG4gICAgICAgIH0sXG4gICAgICAgIGNyZWRlbnRpYWxzOiAnaW5jbHVkZSdcbiAgICB9KTtcbiAgICBpZiAoIWluaXRSZXNwb25zZS5vaykge1xuICAgICAgICBjb25zdCB0ZXh0ID0gYXdhaXQgaW5pdFJlc3BvbnNlLnRleHQoKTtcbiAgICAgICAgdGhyb3cgbmV3IEVycm9yKGBNZWRpYSB1cGxvYWQgSU5JVCBmYWlsZWQ6ICR7aW5pdFJlc3BvbnNlLnN0YXR1c30gJHt0ZXh0fWApO1xuICAgIH1cbiAgICBjb25zdCBpbml0RGF0YSA9IGF3YWl0IGluaXRSZXNwb25zZS5qc29uKCk7XG4gICAgY29uc3QgbWVkaWFJZCA9IGluaXREYXRhLm1lZGlhX2lkX3N0cmluZztcbiAgICBjb25zb2xlLmxvZyhgW1R3aXR0ZXJBUEldIE1lZGlhIHVwbG9hZCBJTklUIHN1Y2Nlc3MsIG1lZGlhX2lkPSR7bWVkaWFJZH1gKTtcbiAgICAvLyDmraXpqqQgMjogQVBQRU5EIC0g5YiG5Z2X5LiK5LygXG4gICAgLy8gVHdpdHRlciDpmZDliLbljZXmrKHor7fmsYLlpKflsI/vvIzlpKfmlofku7bpnIDopoHliIblnZfkuIrkvKDvvIjmr4/lnZfmnIDlpJogNU1C77yJXG4gICAgY29uc3QgQ0hVTktfU0laRSA9IDUgKiAxMDI0ICogMTAyNDsgLy8gNU1CXG4gICAgY29uc3QgdG90YWxDaHVua3MgPSBNYXRoLmNlaWwodG90YWxCeXRlcyAvIENIVU5LX1NJWkUpO1xuICAgIGNvbnNvbGUubG9nKGBbVHdpdHRlckFQSV0gVXBsb2FkaW5nICR7dG90YWxCeXRlc30gYnl0ZXMgaW4gJHt0b3RhbENodW5rc30gY2h1bmsocylgKTtcbiAgICBmb3IgKGxldCBzZWdtZW50SW5kZXggPSAwOyBzZWdtZW50SW5kZXggPCB0b3RhbENodW5rczsgc2VnbWVudEluZGV4KyspIHtcbiAgICAgICAgY29uc3Qgc3RhcnQgPSBzZWdtZW50SW5kZXggKiBDSFVOS19TSVpFO1xuICAgICAgICBjb25zdCBlbmQgPSBNYXRoLm1pbihzdGFydCArIENIVU5LX1NJWkUsIHRvdGFsQnl0ZXMpO1xuICAgICAgICBjb25zdCBjaHVuayA9IGJsb2Iuc2xpY2Uoc3RhcnQsIGVuZCk7XG4gICAgICAgIGNvbnNvbGUubG9nKGBbVHdpdHRlckFQSV0gVXBsb2FkaW5nIGNodW5rICR7c2VnbWVudEluZGV4ICsgMX0vJHt0b3RhbENodW5rc30gKCR7Y2h1bmsuc2l6ZX0gYnl0ZXMpYCk7XG4gICAgICAgIGNvbnN0IGFwcGVuZFVybCA9IGBodHRwczovL3VwbG9hZC54LmNvbS9pL21lZGlhL3VwbG9hZC5qc29uP2NvbW1hbmQ9QVBQRU5EJm1lZGlhX2lkPSR7bWVkaWFJZH0mc2VnbWVudF9pbmRleD0ke3NlZ21lbnRJbmRleH1gO1xuICAgICAgICBjb25zdCBhcHBlbmRUeGlkID0gYXdhaXQgZ2V0VHJhbnNhY3Rpb25JZEZvcignUE9TVCcsICcvaS9tZWRpYS91cGxvYWQuanNvbicpO1xuICAgICAgICBjb25zdCBmb3JtRGF0YSA9IG5ldyBGb3JtRGF0YSgpO1xuICAgICAgICBmb3JtRGF0YS5hcHBlbmQoJ21lZGlhJywgY2h1bmssICdibG9iJyk7XG4gICAgICAgIGNvbnN0IGFwcGVuZFJlc3BvbnNlID0gYXdhaXQgZmV0Y2goYXBwZW5kVXJsLCB7XG4gICAgICAgICAgICBtZXRob2Q6ICdQT1NUJyxcbiAgICAgICAgICAgIGhlYWRlcnM6IHtcbiAgICAgICAgICAgICAgICAnYXV0aG9yaXphdGlvbic6IGJlYXJlcixcbiAgICAgICAgICAgICAgICAneC1jc3JmLXRva2VuJzogY3NyZixcbiAgICAgICAgICAgICAgICAneC1jbGllbnQtdHJhbnNhY3Rpb24taWQnOiBhcHBlbmRUeGlkLFxuICAgICAgICAgICAgICAgICd4LXR3aXR0ZXItYXV0aC10eXBlJzogJ09BdXRoMlNlc3Npb24nLFxuICAgICAgICAgICAgfSxcbiAgICAgICAgICAgIGJvZHk6IGZvcm1EYXRhLFxuICAgICAgICAgICAgY3JlZGVudGlhbHM6ICdpbmNsdWRlJ1xuICAgICAgICB9KTtcbiAgICAgICAgaWYgKCFhcHBlbmRSZXNwb25zZS5vaykge1xuICAgICAgICAgICAgY29uc3QgdGV4dCA9IGF3YWl0IGFwcGVuZFJlc3BvbnNlLnRleHQoKTtcbiAgICAgICAgICAgIHRocm93IG5ldyBFcnJvcihgTWVkaWEgdXBsb2FkIEFQUEVORCBmYWlsZWQgYXQgY2h1bmsgJHtzZWdtZW50SW5kZXggKyAxfS8ke3RvdGFsQ2h1bmtzfTogJHthcHBlbmRSZXNwb25zZS5zdGF0dXN9ICR7dGV4dH1gKTtcbiAgICAgICAgfVxuICAgICAgICBjb25zb2xlLmxvZyhgW1R3aXR0ZXJBUEldIENodW5rICR7c2VnbWVudEluZGV4ICsgMX0vJHt0b3RhbENodW5rc30gdXBsb2FkZWQgc3VjY2Vzc2Z1bGx5YCk7XG4gICAgfVxuICAgIGNvbnNvbGUubG9nKGBbVHdpdHRlckFQSV0gQWxsIGNodW5rcyB1cGxvYWRlZCBzdWNjZXNzZnVsbHlgKTtcbiAgICAvLyDmraXpqqQgMzogRklOQUxJWkVcbiAgICBjb25zdCBmaW5hbGl6ZVVybCA9IGBodHRwczovL3VwbG9hZC54LmNvbS9pL21lZGlhL3VwbG9hZC5qc29uP2NvbW1hbmQ9RklOQUxJWkUmbWVkaWFfaWQ9JHttZWRpYUlkfWA7XG4gICAgY29uc3QgZmluYWxpemVUeGlkID0gYXdhaXQgZ2V0VHJhbnNhY3Rpb25JZEZvcignUE9TVCcsICcvaS9tZWRpYS91cGxvYWQuanNvbicpO1xuICAgIGNvbnN0IGZpbmFsaXplUmVzcG9uc2UgPSBhd2FpdCBmZXRjaChmaW5hbGl6ZVVybCwge1xuICAgICAgICBtZXRob2Q6ICdQT1NUJyxcbiAgICAgICAgaGVhZGVyczoge1xuICAgICAgICAgICAgJ2F1dGhvcml6YXRpb24nOiBiZWFyZXIsXG4gICAgICAgICAgICAneC1jc3JmLXRva2VuJzogY3NyZixcbiAgICAgICAgICAgICd4LWNsaWVudC10cmFuc2FjdGlvbi1pZCc6IGZpbmFsaXplVHhpZCxcbiAgICAgICAgICAgICd4LXR3aXR0ZXItYXV0aC10eXBlJzogJ09BdXRoMlNlc3Npb24nLFxuICAgICAgICB9LFxuICAgICAgICBjcmVkZW50aWFsczogJ2luY2x1ZGUnXG4gICAgfSk7XG4gICAgaWYgKCFmaW5hbGl6ZVJlc3BvbnNlLm9rKSB7XG4gICAgICAgIGNvbnN0IHRleHQgPSBhd2FpdCBmaW5hbGl6ZVJlc3BvbnNlLnRleHQoKTtcbiAgICAgICAgdGhyb3cgbmV3IEVycm9yKGBNZWRpYSB1cGxvYWQgRklOQUxJWkUgZmFpbGVkOiAke2ZpbmFsaXplUmVzcG9uc2Uuc3RhdHVzfSAke3RleHR9YCk7XG4gICAgfVxuICAgIGNvbnN0IGZpbmFsaXplRGF0YSA9IGF3YWl0IGZpbmFsaXplUmVzcG9uc2UuanNvbigpO1xuICAgIGNvbnNvbGUubG9nKGBbVHdpdHRlckFQSV0gTWVkaWEgdXBsb2FkIEZJTkFMSVpFIHN1Y2Nlc3MsIG1lZGlhX2lkPSR7ZmluYWxpemVEYXRhLm1lZGlhX2lkX3N0cmluZ31gKTtcbiAgICAvLyDmraXpqqQgNDog5aaC5p6c5piv6KeG6aKRLOmcgOimgei9ruivoiBTVEFUVVMg562J5b6F5aSE55CG5a6M5oiQXG4gICAgaWYgKGlzVmlkZW8pIHtcbiAgICAgICAgY29uc29sZS5sb2coYFtUd2l0dGVyQVBJXSBWaWRlbyBkZXRlY3RlZCwgd2FpdGluZyBmb3IgcHJvY2Vzc2luZy4uLmApO1xuICAgICAgICBsZXQgcHJvY2Vzc2luZ0NvbXBsZXRlID0gZmFsc2U7XG4gICAgICAgIGxldCBhdHRlbXB0cyA9IDA7XG4gICAgICAgIGNvbnN0IG1heEF0dGVtcHRzID0gNjA7IC8vIOacgOWkmuetieW+hSA2MCDmrKEgKOe6piA1IOWIhumSnylcbiAgICAgICAgd2hpbGUgKCFwcm9jZXNzaW5nQ29tcGxldGUgJiYgYXR0ZW1wdHMgPCBtYXhBdHRlbXB0cykge1xuICAgICAgICAgICAgYXR0ZW1wdHMrKztcbiAgICAgICAgICAgIGF3YWl0IG5ldyBQcm9taXNlKHJlc29sdmUgPT4gc2V0VGltZW91dChyZXNvbHZlLCA1MDAwKSk7IC8vIOetieW+hSA1IOenklxuICAgICAgICAgICAgY29uc3Qgc3RhdHVzVXJsID0gYGh0dHBzOi8vdXBsb2FkLnguY29tL2kvbWVkaWEvdXBsb2FkLmpzb24/Y29tbWFuZD1TVEFUVVMmbWVkaWFfaWQ9JHttZWRpYUlkfWA7XG4gICAgICAgICAgICBjb25zdCBzdGF0dXNUeGlkID0gYXdhaXQgZ2V0VHJhbnNhY3Rpb25JZEZvcignR0VUJywgJy9pL21lZGlhL3VwbG9hZC5qc29uJyk7XG4gICAgICAgICAgICBjb25zdCBzdGF0dXNSZXNwb25zZSA9IGF3YWl0IGZldGNoKHN0YXR1c1VybCwge1xuICAgICAgICAgICAgICAgIG1ldGhvZDogJ0dFVCcsXG4gICAgICAgICAgICAgICAgaGVhZGVyczoge1xuICAgICAgICAgICAgICAgICAgICAnYXV0aG9yaXphdGlvbic6IGJlYXJlcixcbiAgICAgICAgICAgICAgICAgICAgJ3gtY3NyZi10b2tlbic6IGNzcmYsXG4gICAgICAgICAgICAgICAgICAgICd4LWNsaWVudC10cmFuc2FjdGlvbi1pZCc6IHN0YXR1c1R4aWQsXG4gICAgICAgICAgICAgICAgICAgICd4LXR3aXR0ZXItYXV0aC10eXBlJzogJ09BdXRoMlNlc3Npb24nLFxuICAgICAgICAgICAgICAgIH0sXG4gICAgICAgICAgICAgICAgY3JlZGVudGlhbHM6ICdpbmNsdWRlJ1xuICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICBpZiAoIXN0YXR1c1Jlc3BvbnNlLm9rKSB7XG4gICAgICAgICAgICAgICAgY29uc29sZS53YXJuKGBbVHdpdHRlckFQSV0gU1RBVFVTIGNoZWNrIGZhaWxlZDogJHtzdGF0dXNSZXNwb25zZS5zdGF0dXN9YCk7XG4gICAgICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBjb25zdCBzdGF0dXNEYXRhID0gYXdhaXQgc3RhdHVzUmVzcG9uc2UuanNvbigpO1xuICAgICAgICAgICAgY29uc29sZS5sb2coYFtUd2l0dGVyQVBJXSBWaWRlbyBwcm9jZXNzaW5nIHN0YXR1czogJHtzdGF0dXNEYXRhLnByb2Nlc3NpbmdfaW5mbz8uc3RhdGUgfHwgJ3Vua25vd24nfWApO1xuICAgICAgICAgICAgaWYgKHN0YXR1c0RhdGEucHJvY2Vzc2luZ19pbmZvPy5zdGF0ZSA9PT0gJ3N1Y2NlZWRlZCcpIHtcbiAgICAgICAgICAgICAgICBwcm9jZXNzaW5nQ29tcGxldGUgPSB0cnVlO1xuICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKGBbVHdpdHRlckFQSV0gVmlkZW8gcHJvY2Vzc2luZyBjb21wbGV0ZWQgc3VjY2Vzc2Z1bGx5YCk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBlbHNlIGlmIChzdGF0dXNEYXRhLnByb2Nlc3NpbmdfaW5mbz8uc3RhdGUgPT09ICdmYWlsZWQnKSB7XG4gICAgICAgICAgICAgICAgdGhyb3cgbmV3IEVycm9yKGBWaWRlbyBwcm9jZXNzaW5nIGZhaWxlZDogJHtzdGF0dXNEYXRhLnByb2Nlc3NpbmdfaW5mbz8uZXJyb3I/Lm1lc3NhZ2UgfHwgJ3Vua25vd24gZXJyb3InfWApO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgLy8g5aaC5p6c5pivICdwZW5kaW5nJyDmiJYgJ2luX3Byb2dyZXNzJyznu6fnu63ova7or6JcbiAgICAgICAgfVxuICAgICAgICBpZiAoIXByb2Nlc3NpbmdDb21wbGV0ZSkge1xuICAgICAgICAgICAgY29uc29sZS53YXJuKGBbVHdpdHRlckFQSV0gVmlkZW8gcHJvY2Vzc2luZyB0aW1lb3V0IGFmdGVyICR7YXR0ZW1wdHN9IGF0dGVtcHRzYCk7XG4gICAgICAgIH1cbiAgICB9XG4gICAgcmV0dXJuIGZpbmFsaXplRGF0YS5tZWRpYV9pZF9zdHJpbmc7XG59XG4iLCIvKipcbiAqIFR3aXR0ZXIgVHJhbnNhY3Rpb24gSUQgKHR4aWQpIGdlbmVyYXRvci5cbiAqIFVzZXMgeC1jbGllbnQtdHJhbnNhY3Rpb24taWQgbGlicmFyeSAoc2FtZSBhcyBUd2VldENhdCkuXG4gKi9cbmltcG9ydCB7IENsaWVudFRyYW5zYWN0aW9uIH0gZnJvbSBcIngtY2xpZW50LXRyYW5zYWN0aW9uLWlkXCI7XG5sZXQgY2FjaGVkRG9jID0gbnVsbDtcbmxldCBsYXN0RmV0Y2hlZCA9IDA7XG5hc3luYyBmdW5jdGlvbiBnZXRYRG9jKCkge1xuICAgIGNvbnN0IG5vdyA9IERhdGUubm93KCk7XG4gICAgaWYgKCFjYWNoZWREb2MgfHwgbm93IC0gbGFzdEZldGNoZWQgPiA2MDAwMCkgeyAvLyDnvJPlrZggNjBzXG4gICAgICAgIGNvbnN0IHJlcyA9IGF3YWl0IGZldGNoKFwiaHR0cHM6Ly94LmNvbS9cIiwgeyBjcmVkZW50aWFsczogXCJvbWl0XCIgfSk7XG4gICAgICAgIGNvbnN0IGh0bWwgPSBhd2FpdCByZXMudGV4dCgpO1xuICAgICAgICBjYWNoZWREb2MgPSBuZXcgRE9NUGFyc2VyKCkucGFyc2VGcm9tU3RyaW5nKGh0bWwsIFwidGV4dC9odG1sXCIpO1xuICAgICAgICBsYXN0RmV0Y2hlZCA9IG5vdztcbiAgICB9XG4gICAgcmV0dXJuIGNhY2hlZERvYztcbn1cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBnZXRUcmFuc2FjdGlvbklkRm9yKG1ldGhvZCwgcGF0aCkge1xuICAgIGNvbnN0IGRvYyA9IGF3YWl0IGdldFhEb2MoKTtcbiAgICBjb25zdCB0eCA9IGF3YWl0IENsaWVudFRyYW5zYWN0aW9uLmNyZWF0ZShkb2MpO1xuICAgIHJldHVybiB0eC5nZW5lcmF0ZVRyYW5zYWN0aW9uSWQobWV0aG9kLCBwYXRoKTtcbn1cbiJdLCJuYW1lcyI6W10sInNvdXJjZVJvb3QiOiIifQ==