"use strict";
(self["webpackChunkTweetClaw"] = self["webpackChunkTweetClaw"] || []).push([["src_x_api_twitter_api_ts"],{

/***/ "./src/x_api/feature_manager.ts"
/*!**************************************!*\
  !*** ./src/x_api/feature_manager.ts ***!
  \**************************************/
(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   baseFeatures: () => (/* binding */ baseFeatures),
/* harmony export */   buildFeatures: () => (/* binding */ buildFeatures),
/* harmony export */   extractMissingFeature: () => (/* binding */ extractMissingFeature)
/* harmony export */ });
/* harmony import */ var _capture_consts__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../capture/consts */ "./src/capture/consts.ts");
/**
 * Feature Manager for X GraphQL requests
 * Handles dynamic feature discovery from 400/403 errors.
 */

const baseFeatures = {
    responsive_web_graphql_timeline_navigation_enabled: true,
    responsive_web_graphql_skip_user_profile_image_extensions_enabled: false,
    creator_subscriptions_tweet_preview_api_enabled: true,
    responsive_web_edit_tweet_api_enabled: true,
    graphql_is_translatable_rweb_tweet_is_translatable_enabled: true,
    view_counts_everywhere_api_enabled: true,
    longform_notetweets_consumption_enabled: true,
    responsive_web_twitter_article_tweet_consumption_enabled: true,
    tweet_with_visibility_results_prefer_gql_limited_actions_policy_enabled: true,
    longform_notetweets_rich_text_read_enabled: true,
    longform_notetweets_inline_media_enabled: true,
    rweb_video_screen_enabled: false,
    standardized_nudges_misinfo: true,
    freedom_of_speech_not_reach_fetch_enabled: true,
    responsive_web_enhance_cards_enabled: false,
    articles_preview_enabled: true,
    communities_web_enable_tweet_community_results_fetch: true,
    c9s_tweet_anatomy_moderator_badge_enabled: true
};
async function extractMissingFeature(body) {
    if (!body)
        return null;
    // X normally returns: "cannot be null: some_feature_flag"
    const m = body.match(/cannot be null:\s*([a-zA-Z0-9_]+)/);
    if (!m)
        return null;
    const feature = m[1];
    const data = await chrome.storage.local.get(_capture_consts__WEBPACK_IMPORTED_MODULE_0__.__DBK_dynamic_features);
    const current = (data[_capture_consts__WEBPACK_IMPORTED_MODULE_0__.__DBK_dynamic_features] || {});
    if (!(feature in current)) {
        current[feature] = true;
        await chrome.storage.local.set({ [_capture_consts__WEBPACK_IMPORTED_MODULE_0__.__DBK_dynamic_features]: current });
        console.log("[TweetClaw-Feature] Auto-harvested new feature flag:", feature);
    }
    return feature;
}
async function buildFeatures() {
    const data = await chrome.storage.local.get(_capture_consts__WEBPACK_IMPORTED_MODULE_0__.__DBK_dynamic_features);
    const dynamic = (data[_capture_consts__WEBPACK_IMPORTED_MODULE_0__.__DBK_dynamic_features] || {});
    return { ...baseFeatures, ...dynamic };
}


/***/ },

/***/ "./src/x_api/twitter_api.ts"
/*!**********************************!*\
  !*** ./src/x_api/twitter_api.ts ***!
  \**********************************/
(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   fetchUserByRestId: () => (/* binding */ fetchUserByRestId),
/* harmony export */   fetchUserByUsername: () => (/* binding */ fetchUserByUsername),
/* harmony export */   performLegacyREST: () => (/* binding */ performLegacyREST),
/* harmony export */   performMutation: () => (/* binding */ performMutation),
/* harmony export */   performQuery: () => (/* binding */ performQuery)
/* harmony export */ });
/* harmony import */ var _capture_consts__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../capture/consts */ "./src/capture/consts.ts");
/* harmony import */ var _feature_manager__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./feature_manager */ "./src/x_api/feature_manager.ts");
/* harmony import */ var _txid__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./txid */ "./src/x_api/txid.ts");



/**
 * Twitter API Client
 * Designed to run in Content Script (for cookies) and Background (for harvesting).
 */
async function getAuthHeader() {
    const res = await chrome.storage.local.get(_capture_consts__WEBPACK_IMPORTED_MODULE_0__.__DBK_bearer_token);
    return res[_capture_consts__WEBPACK_IMPORTED_MODULE_0__.__DBK_bearer_token] || "";
}
async function getCsrfToken() {
    // Content script: read from document.cookie
    // Background: read from chrome.cookies
    if (typeof document !== 'undefined' && document.cookie) {
        const match = document.cookie.match(/(?:^|;\s*)ct0=([^;]+)/);
        if (match)
            return match[1];
    }
    return new Promise((resolve) => {
        chrome.cookies.get({ url: 'https://x.com', name: 'ct0' }, (cookie) => {
            resolve(cookie ? cookie.value : "");
        });
    });
}
async function getUrlWithQueryId(op) {
    const res = await chrome.storage.local.get(_capture_consts__WEBPACK_IMPORTED_MODULE_0__.__DBK_query_id_map);
    const map = (res[_capture_consts__WEBPACK_IMPORTED_MODULE_0__.__DBK_query_id_map] || {});
    const queryId = map[op];
    if (!queryId)
        return null;
    const url = `https://x.com/i/api/graphql/${queryId}/${op}`;
    const path = `/i/api/graphql/${queryId}/${op}`;
    return { url, path };
}
async function performMutation(op, variables) {
    const target = await getUrlWithQueryId(op);
    if (!target)
        throw new Error(`Missing harvested queryId for operation: ${op}`);
    const bearer = await getAuthHeader();
    const csrf = await getCsrfToken();
    const features = await (0,_feature_manager__WEBPACK_IMPORTED_MODULE_1__.buildFeatures)();
    // TweetCat txid logic
    const txid = await (0,_txid__WEBPACK_IMPORTED_MODULE_2__.getTransactionIdFor)('POST', target.path);
    const headers = {
        'authorization': bearer,
        'x-csrf-token': csrf,
        'x-client-transaction-id': txid,
        'content-type': 'application/json',
        'x-twitter-active-user': 'yes',
        'x-twitter-auth-type': 'OAuth2Session',
        'referer': 'https://x.com/',
        'accept': '*/*'
    };
    const payload = {
        variables,
        features,
        queryId: target.url.split('/')[5]
    };
    const response = await fetch(target.url, {
        method: 'POST',
        headers,
        body: JSON.stringify(payload),
        credentials: 'include' // Crucial for cookies in Content Script
    });
    if (!response.ok) {
        const text = await response.text();
        await (0,_feature_manager__WEBPACK_IMPORTED_MODULE_1__.extractMissingFeature)(text);
        throw new Error(`X API Error ${response.status} for ${op}: ${text}`);
    }
    return await response.json();
}
/**
 * 专门处理推特老旧的 1.1 REST API（如 friendships/create.json）
 * 这些接口不使用 GraphQL，也不需要 queryId。
 */
async function performLegacyREST(path, params) {
    const bearer = await getAuthHeader();
    const csrf = await getCsrfToken();
    const txid = await (0,_txid__WEBPACK_IMPORTED_MODULE_2__.getTransactionIdFor)('POST', path);
    const headers = {
        'authorization': bearer,
        'x-csrf-token': csrf,
        'x-client-transaction-id': txid,
        'content-type': 'application/x-www-form-urlencoded',
        'x-twitter-active-user': 'yes',
        'x-twitter-auth-type': 'OAuth2Session',
        'referer': 'https://x.com/',
        'accept': '*/*'
    };
    const url = `https://x.com${path}`;
    const body = new URLSearchParams(params).toString();
    const response = await fetch(url, {
        method: 'POST',
        headers,
        body,
        credentials: 'include'
    });
    if (!response.ok) {
        const text = await response.text();
        throw new Error(`X Legacy API Error ${response.status} for ${path}: ${text}`);
    }
    return await response.json();
}
async function performQuery(op, variables) {
    const target = await getUrlWithQueryId(op);
    if (!target)
        throw new Error(`Missing harvested queryId for operation: ${op}`);
    const bearer = await getAuthHeader();
    const csrf = await getCsrfToken();
    const features = await (0,_feature_manager__WEBPACK_IMPORTED_MODULE_1__.buildFeatures)();
    const params = new URLSearchParams();
    params.append('variables', JSON.stringify(variables));
    params.append('features', JSON.stringify(features));
    const url = `${target.url}?${params.toString()}`;
    const headers = {
        'authorization': bearer,
        'x-csrf-token': csrf,
        'content-type': 'application/json',
        'x-twitter-active-user': 'yes',
        'x-twitter-auth-type': 'OAuth2Session',
        'referer': 'https://x.com/',
        'accept': '*/*'
    };
    const response = await fetch(url, {
        method: 'GET',
        headers,
        credentials: 'include'
    });
    if (!response.ok) {
        const text = await response.text();
        await (0,_feature_manager__WEBPACK_IMPORTED_MODULE_1__.extractMissingFeature)(text);
        throw new Error(`X API Error ${response.status} for ${op}: ${text}`);
    }
    const result = await response.json();
    console.log(`[TwitterAPI] GraphQL ${op} Response:`, result);
    return result;
}
/**
 * 根据用户名获取完整的用户 Profile 信息
 */
async function fetchUserByUsername(username) {
    const cleanUsername = username.startsWith('@') ? username.substring(1) : username;
    const data = await performQuery('UserByScreenName', {
        screen_name: cleanUsername,
        withSafetyModeUserFields: true
    });
    // 从复杂的 GraphQL 响应中提取用户对象
    const userResult = data?.data?.user?.result;
    if (!userResult || userResult.__typename === 'UserUnavailable') {
        return null;
    }
    return userResult;
}
/**
 * 根据 User ID 获取完整的用户 Profile 信息 (UserByRestId)
 */
async function fetchUserByRestId(userId) {
    const data = await performQuery('UserByRestId', {
        userId: userId,
        withSafetyModeUserFields: true
    });
    const userResult = data?.data?.user?.result;
    if (!userResult || userResult.__typename === 'UserUnavailable') {
        return null;
    }
    return userResult;
}


/***/ },

/***/ "./src/x_api/txid.ts"
/*!***************************!*\
  !*** ./src/x_api/txid.ts ***!
  \***************************/
(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   getTransactionIdFor: () => (/* binding */ getTransactionIdFor)
/* harmony export */ });
/**
 * Twitter Transaction ID (txid) generator.
 * Ported from TweetCat project.
 */
const KEY = "86C9766BF24F33C4BA215BDD305DAB25";
function getAlphaCheckSum(method, path, time) {
    const s = `${method}!${path}!${time}!${KEY}`;
    let hash = 0;
    for (let i = 0; i < s.length; i++) {
        hash = (hash << 5) - hash + s.charCodeAt(i);
        hash |= 0;
    }
    return Math.abs(hash).toString(36);
}
async function getTransactionIdFor(method, path) {
    const t = Math.floor(Date.now() / 1000);
    const checksum = getAlphaCheckSum(method.toUpperCase(), path, t);
    // Format: <timestamp_base36>:<checksum>
    const tBase36 = t.toString(36);
    return `${tBase36}:${checksum}`;
}


/***/ }

}]);
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoianMvc3JjX3hfYXBpX3R3aXR0ZXJfYXBpX3RzLmpzIiwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7QUFBQTtBQUNBO0FBQ0E7QUFDQTtBQUMyRDtBQUNwRDtBQUNQO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ087QUFDUDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLGdEQUFnRCxtRUFBc0I7QUFDdEUsMEJBQTBCLG1FQUFzQixPQUFPO0FBQ3ZEO0FBQ0E7QUFDQSx5Q0FBeUMsQ0FBQyxtRUFBc0IsWUFBWTtBQUM1RTtBQUNBO0FBQ0E7QUFDQTtBQUNPO0FBQ1AsZ0RBQWdELG1FQUFzQjtBQUN0RSwwQkFBMEIsbUVBQXNCLE9BQU87QUFDdkQsYUFBYTtBQUNiOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDOUMyRTtBQUNGO0FBQzVCO0FBQzdDO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSwrQ0FBK0MsK0RBQWtCO0FBQ2pFLGVBQWUsK0RBQWtCO0FBQ2pDO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxtREFBbUQsWUFBWTtBQUMvRDtBQUNBO0FBQ0E7QUFDQTtBQUNBLDZCQUE2QixtQ0FBbUM7QUFDaEU7QUFDQSxTQUFTO0FBQ1QsS0FBSztBQUNMO0FBQ0E7QUFDQSwrQ0FBK0MsK0RBQWtCO0FBQ2pFLHFCQUFxQiwrREFBa0IsT0FBTztBQUM5QztBQUNBO0FBQ0E7QUFDQSwrQ0FBK0MsUUFBUSxHQUFHLEdBQUc7QUFDN0QsbUNBQW1DLFFBQVEsR0FBRyxHQUFHO0FBQ2pELGFBQWE7QUFDYjtBQUNPO0FBQ1A7QUFDQTtBQUNBLG9FQUFvRSxHQUFHO0FBQ3ZFO0FBQ0E7QUFDQSwyQkFBMkIsK0RBQWE7QUFDeEM7QUFDQSx1QkFBdUIsMERBQW1CO0FBQzFDO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxLQUFLO0FBQ0w7QUFDQTtBQUNBLGNBQWMsdUVBQXFCO0FBQ25DLHVDQUF1QyxpQkFBaUIsTUFBTSxHQUFHLElBQUksS0FBSztBQUMxRTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNPO0FBQ1A7QUFDQTtBQUNBLHVCQUF1QiwwREFBbUI7QUFDMUM7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxnQ0FBZ0MsS0FBSztBQUNyQztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxLQUFLO0FBQ0w7QUFDQTtBQUNBLDhDQUE4QyxpQkFBaUIsTUFBTSxLQUFLLElBQUksS0FBSztBQUNuRjtBQUNBO0FBQ0E7QUFDTztBQUNQO0FBQ0E7QUFDQSxvRUFBb0UsR0FBRztBQUN2RTtBQUNBO0FBQ0EsMkJBQTJCLCtEQUFhO0FBQ3hDO0FBQ0E7QUFDQTtBQUNBLG1CQUFtQixXQUFXLEdBQUcsa0JBQWtCO0FBQ25EO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsS0FBSztBQUNMO0FBQ0E7QUFDQSxjQUFjLHVFQUFxQjtBQUNuQyx1Q0FBdUMsaUJBQWlCLE1BQU0sR0FBRyxJQUFJLEtBQUs7QUFDMUU7QUFDQTtBQUNBLHdDQUF3QyxJQUFJO0FBQzVDO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDTztBQUNQO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsS0FBSztBQUNMO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ087QUFDUDtBQUNBO0FBQ0E7QUFDQSxLQUFLO0FBQ0w7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOzs7Ozs7Ozs7Ozs7Ozs7QUN2S0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsaUJBQWlCLE9BQU8sR0FBRyxLQUFLLEdBQUcsS0FBSyxHQUFHLElBQUk7QUFDL0M7QUFDQSxvQkFBb0IsY0FBYztBQUNsQztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ087QUFDUDtBQUNBO0FBQ0E7QUFDQTtBQUNBLGNBQWMsUUFBUSxHQUFHLFNBQVM7QUFDbEMiLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9Ud2VldENsYXcvLi9zcmMveF9hcGkvZmVhdHVyZV9tYW5hZ2VyLnRzIiwid2VicGFjazovL1R3ZWV0Q2xhdy8uL3NyYy94X2FwaS90d2l0dGVyX2FwaS50cyIsIndlYnBhY2s6Ly9Ud2VldENsYXcvLi9zcmMveF9hcGkvdHhpZC50cyJdLCJzb3VyY2VzQ29udGVudCI6WyIvKipcbiAqIEZlYXR1cmUgTWFuYWdlciBmb3IgWCBHcmFwaFFMIHJlcXVlc3RzXG4gKiBIYW5kbGVzIGR5bmFtaWMgZmVhdHVyZSBkaXNjb3ZlcnkgZnJvbSA0MDAvNDAzIGVycm9ycy5cbiAqL1xuaW1wb3J0IHsgX19EQktfZHluYW1pY19mZWF0dXJlcyB9IGZyb20gJy4uL2NhcHR1cmUvY29uc3RzJztcbmV4cG9ydCBjb25zdCBiYXNlRmVhdHVyZXMgPSB7XG4gICAgcmVzcG9uc2l2ZV93ZWJfZ3JhcGhxbF90aW1lbGluZV9uYXZpZ2F0aW9uX2VuYWJsZWQ6IHRydWUsXG4gICAgcmVzcG9uc2l2ZV93ZWJfZ3JhcGhxbF9za2lwX3VzZXJfcHJvZmlsZV9pbWFnZV9leHRlbnNpb25zX2VuYWJsZWQ6IGZhbHNlLFxuICAgIGNyZWF0b3Jfc3Vic2NyaXB0aW9uc190d2VldF9wcmV2aWV3X2FwaV9lbmFibGVkOiB0cnVlLFxuICAgIHJlc3BvbnNpdmVfd2ViX2VkaXRfdHdlZXRfYXBpX2VuYWJsZWQ6IHRydWUsXG4gICAgZ3JhcGhxbF9pc190cmFuc2xhdGFibGVfcndlYl90d2VldF9pc190cmFuc2xhdGFibGVfZW5hYmxlZDogdHJ1ZSxcbiAgICB2aWV3X2NvdW50c19ldmVyeXdoZXJlX2FwaV9lbmFibGVkOiB0cnVlLFxuICAgIGxvbmdmb3JtX25vdGV0d2VldHNfY29uc3VtcHRpb25fZW5hYmxlZDogdHJ1ZSxcbiAgICByZXNwb25zaXZlX3dlYl90d2l0dGVyX2FydGljbGVfdHdlZXRfY29uc3VtcHRpb25fZW5hYmxlZDogdHJ1ZSxcbiAgICB0d2VldF93aXRoX3Zpc2liaWxpdHlfcmVzdWx0c19wcmVmZXJfZ3FsX2xpbWl0ZWRfYWN0aW9uc19wb2xpY3lfZW5hYmxlZDogdHJ1ZSxcbiAgICBsb25nZm9ybV9ub3RldHdlZXRzX3JpY2hfdGV4dF9yZWFkX2VuYWJsZWQ6IHRydWUsXG4gICAgbG9uZ2Zvcm1fbm90ZXR3ZWV0c19pbmxpbmVfbWVkaWFfZW5hYmxlZDogdHJ1ZSxcbiAgICByd2ViX3ZpZGVvX3NjcmVlbl9lbmFibGVkOiBmYWxzZSxcbiAgICBzdGFuZGFyZGl6ZWRfbnVkZ2VzX21pc2luZm86IHRydWUsXG4gICAgZnJlZWRvbV9vZl9zcGVlY2hfbm90X3JlYWNoX2ZldGNoX2VuYWJsZWQ6IHRydWUsXG4gICAgcmVzcG9uc2l2ZV93ZWJfZW5oYW5jZV9jYXJkc19lbmFibGVkOiBmYWxzZSxcbiAgICBhcnRpY2xlc19wcmV2aWV3X2VuYWJsZWQ6IHRydWUsXG4gICAgY29tbXVuaXRpZXNfd2ViX2VuYWJsZV90d2VldF9jb21tdW5pdHlfcmVzdWx0c19mZXRjaDogdHJ1ZSxcbiAgICBjOXNfdHdlZXRfYW5hdG9teV9tb2RlcmF0b3JfYmFkZ2VfZW5hYmxlZDogdHJ1ZVxufTtcbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBleHRyYWN0TWlzc2luZ0ZlYXR1cmUoYm9keSkge1xuICAgIGlmICghYm9keSlcbiAgICAgICAgcmV0dXJuIG51bGw7XG4gICAgLy8gWCBub3JtYWxseSByZXR1cm5zOiBcImNhbm5vdCBiZSBudWxsOiBzb21lX2ZlYXR1cmVfZmxhZ1wiXG4gICAgY29uc3QgbSA9IGJvZHkubWF0Y2goL2Nhbm5vdCBiZSBudWxsOlxccyooW2EtekEtWjAtOV9dKykvKTtcbiAgICBpZiAoIW0pXG4gICAgICAgIHJldHVybiBudWxsO1xuICAgIGNvbnN0IGZlYXR1cmUgPSBtWzFdO1xuICAgIGNvbnN0IGRhdGEgPSBhd2FpdCBjaHJvbWUuc3RvcmFnZS5sb2NhbC5nZXQoX19EQktfZHluYW1pY19mZWF0dXJlcyk7XG4gICAgY29uc3QgY3VycmVudCA9IChkYXRhW19fREJLX2R5bmFtaWNfZmVhdHVyZXNdIHx8IHt9KTtcbiAgICBpZiAoIShmZWF0dXJlIGluIGN1cnJlbnQpKSB7XG4gICAgICAgIGN1cnJlbnRbZmVhdHVyZV0gPSB0cnVlO1xuICAgICAgICBhd2FpdCBjaHJvbWUuc3RvcmFnZS5sb2NhbC5zZXQoeyBbX19EQktfZHluYW1pY19mZWF0dXJlc106IGN1cnJlbnQgfSk7XG4gICAgICAgIGNvbnNvbGUubG9nKFwiW1R3ZWV0Q2xhdy1GZWF0dXJlXSBBdXRvLWhhcnZlc3RlZCBuZXcgZmVhdHVyZSBmbGFnOlwiLCBmZWF0dXJlKTtcbiAgICB9XG4gICAgcmV0dXJuIGZlYXR1cmU7XG59XG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gYnVpbGRGZWF0dXJlcygpIHtcbiAgICBjb25zdCBkYXRhID0gYXdhaXQgY2hyb21lLnN0b3JhZ2UubG9jYWwuZ2V0KF9fREJLX2R5bmFtaWNfZmVhdHVyZXMpO1xuICAgIGNvbnN0IGR5bmFtaWMgPSAoZGF0YVtfX0RCS19keW5hbWljX2ZlYXR1cmVzXSB8fCB7fSk7XG4gICAgcmV0dXJuIHsgLi4uYmFzZUZlYXR1cmVzLCAuLi5keW5hbWljIH07XG59XG4iLCJpbXBvcnQgeyBfX0RCS19xdWVyeV9pZF9tYXAsIF9fREJLX2JlYXJlcl90b2tlbiB9IGZyb20gJy4uL2NhcHR1cmUvY29uc3RzJztcbmltcG9ydCB7IGJ1aWxkRmVhdHVyZXMsIGV4dHJhY3RNaXNzaW5nRmVhdHVyZSB9IGZyb20gJy4vZmVhdHVyZV9tYW5hZ2VyJztcbmltcG9ydCB7IGdldFRyYW5zYWN0aW9uSWRGb3IgfSBmcm9tICcuL3R4aWQnO1xuLyoqXG4gKiBUd2l0dGVyIEFQSSBDbGllbnRcbiAqIERlc2lnbmVkIHRvIHJ1biBpbiBDb250ZW50IFNjcmlwdCAoZm9yIGNvb2tpZXMpIGFuZCBCYWNrZ3JvdW5kIChmb3IgaGFydmVzdGluZykuXG4gKi9cbmFzeW5jIGZ1bmN0aW9uIGdldEF1dGhIZWFkZXIoKSB7XG4gICAgY29uc3QgcmVzID0gYXdhaXQgY2hyb21lLnN0b3JhZ2UubG9jYWwuZ2V0KF9fREJLX2JlYXJlcl90b2tlbik7XG4gICAgcmV0dXJuIHJlc1tfX0RCS19iZWFyZXJfdG9rZW5dIHx8IFwiXCI7XG59XG5hc3luYyBmdW5jdGlvbiBnZXRDc3JmVG9rZW4oKSB7XG4gICAgLy8gQ29udGVudCBzY3JpcHQ6IHJlYWQgZnJvbSBkb2N1bWVudC5jb29raWVcbiAgICAvLyBCYWNrZ3JvdW5kOiByZWFkIGZyb20gY2hyb21lLmNvb2tpZXNcbiAgICBpZiAodHlwZW9mIGRvY3VtZW50ICE9PSAndW5kZWZpbmVkJyAmJiBkb2N1bWVudC5jb29raWUpIHtcbiAgICAgICAgY29uc3QgbWF0Y2ggPSBkb2N1bWVudC5jb29raWUubWF0Y2goLyg/Ol58O1xccyopY3QwPShbXjtdKykvKTtcbiAgICAgICAgaWYgKG1hdGNoKVxuICAgICAgICAgICAgcmV0dXJuIG1hdGNoWzFdO1xuICAgIH1cbiAgICByZXR1cm4gbmV3IFByb21pc2UoKHJlc29sdmUpID0+IHtcbiAgICAgICAgY2hyb21lLmNvb2tpZXMuZ2V0KHsgdXJsOiAnaHR0cHM6Ly94LmNvbScsIG5hbWU6ICdjdDAnIH0sIChjb29raWUpID0+IHtcbiAgICAgICAgICAgIHJlc29sdmUoY29va2llID8gY29va2llLnZhbHVlIDogXCJcIik7XG4gICAgICAgIH0pO1xuICAgIH0pO1xufVxuYXN5bmMgZnVuY3Rpb24gZ2V0VXJsV2l0aFF1ZXJ5SWQob3ApIHtcbiAgICBjb25zdCByZXMgPSBhd2FpdCBjaHJvbWUuc3RvcmFnZS5sb2NhbC5nZXQoX19EQktfcXVlcnlfaWRfbWFwKTtcbiAgICBjb25zdCBtYXAgPSAocmVzW19fREJLX3F1ZXJ5X2lkX21hcF0gfHwge30pO1xuICAgIGNvbnN0IHF1ZXJ5SWQgPSBtYXBbb3BdO1xuICAgIGlmICghcXVlcnlJZClcbiAgICAgICAgcmV0dXJuIG51bGw7XG4gICAgY29uc3QgdXJsID0gYGh0dHBzOi8veC5jb20vaS9hcGkvZ3JhcGhxbC8ke3F1ZXJ5SWR9LyR7b3B9YDtcbiAgICBjb25zdCBwYXRoID0gYC9pL2FwaS9ncmFwaHFsLyR7cXVlcnlJZH0vJHtvcH1gO1xuICAgIHJldHVybiB7IHVybCwgcGF0aCB9O1xufVxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIHBlcmZvcm1NdXRhdGlvbihvcCwgdmFyaWFibGVzKSB7XG4gICAgY29uc3QgdGFyZ2V0ID0gYXdhaXQgZ2V0VXJsV2l0aFF1ZXJ5SWQob3ApO1xuICAgIGlmICghdGFyZ2V0KVxuICAgICAgICB0aHJvdyBuZXcgRXJyb3IoYE1pc3NpbmcgaGFydmVzdGVkIHF1ZXJ5SWQgZm9yIG9wZXJhdGlvbjogJHtvcH1gKTtcbiAgICBjb25zdCBiZWFyZXIgPSBhd2FpdCBnZXRBdXRoSGVhZGVyKCk7XG4gICAgY29uc3QgY3NyZiA9IGF3YWl0IGdldENzcmZUb2tlbigpO1xuICAgIGNvbnN0IGZlYXR1cmVzID0gYXdhaXQgYnVpbGRGZWF0dXJlcygpO1xuICAgIC8vIFR3ZWV0Q2F0IHR4aWQgbG9naWNcbiAgICBjb25zdCB0eGlkID0gYXdhaXQgZ2V0VHJhbnNhY3Rpb25JZEZvcignUE9TVCcsIHRhcmdldC5wYXRoKTtcbiAgICBjb25zdCBoZWFkZXJzID0ge1xuICAgICAgICAnYXV0aG9yaXphdGlvbic6IGJlYXJlcixcbiAgICAgICAgJ3gtY3NyZi10b2tlbic6IGNzcmYsXG4gICAgICAgICd4LWNsaWVudC10cmFuc2FjdGlvbi1pZCc6IHR4aWQsXG4gICAgICAgICdjb250ZW50LXR5cGUnOiAnYXBwbGljYXRpb24vanNvbicsXG4gICAgICAgICd4LXR3aXR0ZXItYWN0aXZlLXVzZXInOiAneWVzJyxcbiAgICAgICAgJ3gtdHdpdHRlci1hdXRoLXR5cGUnOiAnT0F1dGgyU2Vzc2lvbicsXG4gICAgICAgICdyZWZlcmVyJzogJ2h0dHBzOi8veC5jb20vJyxcbiAgICAgICAgJ2FjY2VwdCc6ICcqLyonXG4gICAgfTtcbiAgICBjb25zdCBwYXlsb2FkID0ge1xuICAgICAgICB2YXJpYWJsZXMsXG4gICAgICAgIGZlYXR1cmVzLFxuICAgICAgICBxdWVyeUlkOiB0YXJnZXQudXJsLnNwbGl0KCcvJylbNV1cbiAgICB9O1xuICAgIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgZmV0Y2godGFyZ2V0LnVybCwge1xuICAgICAgICBtZXRob2Q6ICdQT1NUJyxcbiAgICAgICAgaGVhZGVycyxcbiAgICAgICAgYm9keTogSlNPTi5zdHJpbmdpZnkocGF5bG9hZCksXG4gICAgICAgIGNyZWRlbnRpYWxzOiAnaW5jbHVkZScgLy8gQ3J1Y2lhbCBmb3IgY29va2llcyBpbiBDb250ZW50IFNjcmlwdFxuICAgIH0pO1xuICAgIGlmICghcmVzcG9uc2Uub2spIHtcbiAgICAgICAgY29uc3QgdGV4dCA9IGF3YWl0IHJlc3BvbnNlLnRleHQoKTtcbiAgICAgICAgYXdhaXQgZXh0cmFjdE1pc3NpbmdGZWF0dXJlKHRleHQpO1xuICAgICAgICB0aHJvdyBuZXcgRXJyb3IoYFggQVBJIEVycm9yICR7cmVzcG9uc2Uuc3RhdHVzfSBmb3IgJHtvcH06ICR7dGV4dH1gKTtcbiAgICB9XG4gICAgcmV0dXJuIGF3YWl0IHJlc3BvbnNlLmpzb24oKTtcbn1cbi8qKlxuICog5LiT6Zeo5aSE55CG5o6o54m56ICB5pen55qEIDEuMSBSRVNUIEFQSe+8iOWmgiBmcmllbmRzaGlwcy9jcmVhdGUuanNvbu+8iVxuICog6L+Z5Lqb5o6l5Y+j5LiN5L2/55SoIEdyYXBoUUzvvIzkuZ/kuI3pnIDopoEgcXVlcnlJZOOAglxuICovXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gcGVyZm9ybUxlZ2FjeVJFU1QocGF0aCwgcGFyYW1zKSB7XG4gICAgY29uc3QgYmVhcmVyID0gYXdhaXQgZ2V0QXV0aEhlYWRlcigpO1xuICAgIGNvbnN0IGNzcmYgPSBhd2FpdCBnZXRDc3JmVG9rZW4oKTtcbiAgICBjb25zdCB0eGlkID0gYXdhaXQgZ2V0VHJhbnNhY3Rpb25JZEZvcignUE9TVCcsIHBhdGgpO1xuICAgIGNvbnN0IGhlYWRlcnMgPSB7XG4gICAgICAgICdhdXRob3JpemF0aW9uJzogYmVhcmVyLFxuICAgICAgICAneC1jc3JmLXRva2VuJzogY3NyZixcbiAgICAgICAgJ3gtY2xpZW50LXRyYW5zYWN0aW9uLWlkJzogdHhpZCxcbiAgICAgICAgJ2NvbnRlbnQtdHlwZSc6ICdhcHBsaWNhdGlvbi94LXd3dy1mb3JtLXVybGVuY29kZWQnLFxuICAgICAgICAneC10d2l0dGVyLWFjdGl2ZS11c2VyJzogJ3llcycsXG4gICAgICAgICd4LXR3aXR0ZXItYXV0aC10eXBlJzogJ09BdXRoMlNlc3Npb24nLFxuICAgICAgICAncmVmZXJlcic6ICdodHRwczovL3guY29tLycsXG4gICAgICAgICdhY2NlcHQnOiAnKi8qJ1xuICAgIH07XG4gICAgY29uc3QgdXJsID0gYGh0dHBzOi8veC5jb20ke3BhdGh9YDtcbiAgICBjb25zdCBib2R5ID0gbmV3IFVSTFNlYXJjaFBhcmFtcyhwYXJhbXMpLnRvU3RyaW5nKCk7XG4gICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBmZXRjaCh1cmwsIHtcbiAgICAgICAgbWV0aG9kOiAnUE9TVCcsXG4gICAgICAgIGhlYWRlcnMsXG4gICAgICAgIGJvZHksXG4gICAgICAgIGNyZWRlbnRpYWxzOiAnaW5jbHVkZSdcbiAgICB9KTtcbiAgICBpZiAoIXJlc3BvbnNlLm9rKSB7XG4gICAgICAgIGNvbnN0IHRleHQgPSBhd2FpdCByZXNwb25zZS50ZXh0KCk7XG4gICAgICAgIHRocm93IG5ldyBFcnJvcihgWCBMZWdhY3kgQVBJIEVycm9yICR7cmVzcG9uc2Uuc3RhdHVzfSBmb3IgJHtwYXRofTogJHt0ZXh0fWApO1xuICAgIH1cbiAgICByZXR1cm4gYXdhaXQgcmVzcG9uc2UuanNvbigpO1xufVxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIHBlcmZvcm1RdWVyeShvcCwgdmFyaWFibGVzKSB7XG4gICAgY29uc3QgdGFyZ2V0ID0gYXdhaXQgZ2V0VXJsV2l0aFF1ZXJ5SWQob3ApO1xuICAgIGlmICghdGFyZ2V0KVxuICAgICAgICB0aHJvdyBuZXcgRXJyb3IoYE1pc3NpbmcgaGFydmVzdGVkIHF1ZXJ5SWQgZm9yIG9wZXJhdGlvbjogJHtvcH1gKTtcbiAgICBjb25zdCBiZWFyZXIgPSBhd2FpdCBnZXRBdXRoSGVhZGVyKCk7XG4gICAgY29uc3QgY3NyZiA9IGF3YWl0IGdldENzcmZUb2tlbigpO1xuICAgIGNvbnN0IGZlYXR1cmVzID0gYXdhaXQgYnVpbGRGZWF0dXJlcygpO1xuICAgIGNvbnN0IHBhcmFtcyA9IG5ldyBVUkxTZWFyY2hQYXJhbXMoKTtcbiAgICBwYXJhbXMuYXBwZW5kKCd2YXJpYWJsZXMnLCBKU09OLnN0cmluZ2lmeSh2YXJpYWJsZXMpKTtcbiAgICBwYXJhbXMuYXBwZW5kKCdmZWF0dXJlcycsIEpTT04uc3RyaW5naWZ5KGZlYXR1cmVzKSk7XG4gICAgY29uc3QgdXJsID0gYCR7dGFyZ2V0LnVybH0/JHtwYXJhbXMudG9TdHJpbmcoKX1gO1xuICAgIGNvbnN0IGhlYWRlcnMgPSB7XG4gICAgICAgICdhdXRob3JpemF0aW9uJzogYmVhcmVyLFxuICAgICAgICAneC1jc3JmLXRva2VuJzogY3NyZixcbiAgICAgICAgJ2NvbnRlbnQtdHlwZSc6ICdhcHBsaWNhdGlvbi9qc29uJyxcbiAgICAgICAgJ3gtdHdpdHRlci1hY3RpdmUtdXNlcic6ICd5ZXMnLFxuICAgICAgICAneC10d2l0dGVyLWF1dGgtdHlwZSc6ICdPQXV0aDJTZXNzaW9uJyxcbiAgICAgICAgJ3JlZmVyZXInOiAnaHR0cHM6Ly94LmNvbS8nLFxuICAgICAgICAnYWNjZXB0JzogJyovKidcbiAgICB9O1xuICAgIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgZmV0Y2godXJsLCB7XG4gICAgICAgIG1ldGhvZDogJ0dFVCcsXG4gICAgICAgIGhlYWRlcnMsXG4gICAgICAgIGNyZWRlbnRpYWxzOiAnaW5jbHVkZSdcbiAgICB9KTtcbiAgICBpZiAoIXJlc3BvbnNlLm9rKSB7XG4gICAgICAgIGNvbnN0IHRleHQgPSBhd2FpdCByZXNwb25zZS50ZXh0KCk7XG4gICAgICAgIGF3YWl0IGV4dHJhY3RNaXNzaW5nRmVhdHVyZSh0ZXh0KTtcbiAgICAgICAgdGhyb3cgbmV3IEVycm9yKGBYIEFQSSBFcnJvciAke3Jlc3BvbnNlLnN0YXR1c30gZm9yICR7b3B9OiAke3RleHR9YCk7XG4gICAgfVxuICAgIGNvbnN0IHJlc3VsdCA9IGF3YWl0IHJlc3BvbnNlLmpzb24oKTtcbiAgICBjb25zb2xlLmxvZyhgW1R3aXR0ZXJBUEldIEdyYXBoUUwgJHtvcH0gUmVzcG9uc2U6YCwgcmVzdWx0KTtcbiAgICByZXR1cm4gcmVzdWx0O1xufVxuLyoqXG4gKiDmoLnmja7nlKjmiLflkI3ojrflj5blrozmlbTnmoTnlKjmiLcgUHJvZmlsZSDkv6Hmga9cbiAqL1xuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGZldGNoVXNlckJ5VXNlcm5hbWUodXNlcm5hbWUpIHtcbiAgICBjb25zdCBjbGVhblVzZXJuYW1lID0gdXNlcm5hbWUuc3RhcnRzV2l0aCgnQCcpID8gdXNlcm5hbWUuc3Vic3RyaW5nKDEpIDogdXNlcm5hbWU7XG4gICAgY29uc3QgZGF0YSA9IGF3YWl0IHBlcmZvcm1RdWVyeSgnVXNlckJ5U2NyZWVuTmFtZScsIHtcbiAgICAgICAgc2NyZWVuX25hbWU6IGNsZWFuVXNlcm5hbWUsXG4gICAgICAgIHdpdGhTYWZldHlNb2RlVXNlckZpZWxkczogdHJ1ZVxuICAgIH0pO1xuICAgIC8vIOS7juWkjeadgueahCBHcmFwaFFMIOWTjeW6lOS4reaPkOWPlueUqOaIt+WvueixoVxuICAgIGNvbnN0IHVzZXJSZXN1bHQgPSBkYXRhPy5kYXRhPy51c2VyPy5yZXN1bHQ7XG4gICAgaWYgKCF1c2VyUmVzdWx0IHx8IHVzZXJSZXN1bHQuX190eXBlbmFtZSA9PT0gJ1VzZXJVbmF2YWlsYWJsZScpIHtcbiAgICAgICAgcmV0dXJuIG51bGw7XG4gICAgfVxuICAgIHJldHVybiB1c2VyUmVzdWx0O1xufVxuLyoqXG4gKiDmoLnmja4gVXNlciBJRCDojrflj5blrozmlbTnmoTnlKjmiLcgUHJvZmlsZSDkv6Hmga8gKFVzZXJCeVJlc3RJZClcbiAqL1xuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGZldGNoVXNlckJ5UmVzdElkKHVzZXJJZCkge1xuICAgIGNvbnN0IGRhdGEgPSBhd2FpdCBwZXJmb3JtUXVlcnkoJ1VzZXJCeVJlc3RJZCcsIHtcbiAgICAgICAgdXNlcklkOiB1c2VySWQsXG4gICAgICAgIHdpdGhTYWZldHlNb2RlVXNlckZpZWxkczogdHJ1ZVxuICAgIH0pO1xuICAgIGNvbnN0IHVzZXJSZXN1bHQgPSBkYXRhPy5kYXRhPy51c2VyPy5yZXN1bHQ7XG4gICAgaWYgKCF1c2VyUmVzdWx0IHx8IHVzZXJSZXN1bHQuX190eXBlbmFtZSA9PT0gJ1VzZXJVbmF2YWlsYWJsZScpIHtcbiAgICAgICAgcmV0dXJuIG51bGw7XG4gICAgfVxuICAgIHJldHVybiB1c2VyUmVzdWx0O1xufVxuIiwiLyoqXG4gKiBUd2l0dGVyIFRyYW5zYWN0aW9uIElEICh0eGlkKSBnZW5lcmF0b3IuXG4gKiBQb3J0ZWQgZnJvbSBUd2VldENhdCBwcm9qZWN0LlxuICovXG5jb25zdCBLRVkgPSBcIjg2Qzk3NjZCRjI0RjMzQzRCQTIxNUJERDMwNURBQjI1XCI7XG5mdW5jdGlvbiBnZXRBbHBoYUNoZWNrU3VtKG1ldGhvZCwgcGF0aCwgdGltZSkge1xuICAgIGNvbnN0IHMgPSBgJHttZXRob2R9ISR7cGF0aH0hJHt0aW1lfSEke0tFWX1gO1xuICAgIGxldCBoYXNoID0gMDtcbiAgICBmb3IgKGxldCBpID0gMDsgaSA8IHMubGVuZ3RoOyBpKyspIHtcbiAgICAgICAgaGFzaCA9IChoYXNoIDw8IDUpIC0gaGFzaCArIHMuY2hhckNvZGVBdChpKTtcbiAgICAgICAgaGFzaCB8PSAwO1xuICAgIH1cbiAgICByZXR1cm4gTWF0aC5hYnMoaGFzaCkudG9TdHJpbmcoMzYpO1xufVxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGdldFRyYW5zYWN0aW9uSWRGb3IobWV0aG9kLCBwYXRoKSB7XG4gICAgY29uc3QgdCA9IE1hdGguZmxvb3IoRGF0ZS5ub3coKSAvIDEwMDApO1xuICAgIGNvbnN0IGNoZWNrc3VtID0gZ2V0QWxwaGFDaGVja1N1bShtZXRob2QudG9VcHBlckNhc2UoKSwgcGF0aCwgdCk7XG4gICAgLy8gRm9ybWF0OiA8dGltZXN0YW1wX2Jhc2UzNj46PGNoZWNrc3VtPlxuICAgIGNvbnN0IHRCYXNlMzYgPSB0LnRvU3RyaW5nKDM2KTtcbiAgICByZXR1cm4gYCR7dEJhc2UzNn06JHtjaGVja3N1bX1gO1xufVxuIl0sIm5hbWVzIjpbXSwic291cmNlUm9vdCI6IiJ9