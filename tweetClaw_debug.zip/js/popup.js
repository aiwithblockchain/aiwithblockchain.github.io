/******/ (() => { // webpackBootstrap
/*!****************************!*\
  !*** ./src/popup/popup.ts ***!
  \****************************/
document.addEventListener('DOMContentLoaded', () => {
    const mainView = document.getElementById('mainView');
    const xSettingsView = document.getElementById('xSettingsView');
    const btnX = document.getElementById('btnX');
    const btnBack = document.getElementById('btnBack');
    const portInput = document.getElementById('portInput');
    const saveBtn = document.getElementById('saveBtn');
    const statusDot = document.getElementById('statusDot');
    const statusText = document.getElementById('statusText');
    const statusUrl = document.getElementById('statusUrl');
    const statusMsg = document.getElementById('statusMsg');
    // ── View Switching ───────────────────────────────────────────
    btnX.addEventListener('click', () => {
        mainView.classList.add('hidden');
        xSettingsView.classList.remove('hidden');
    });
    btnBack.addEventListener('click', () => {
        xSettingsView.classList.add('hidden');
        mainView.classList.remove('hidden');
    });
    // ── Load saved port ──────────────────────────────────────────
    chrome.storage.local.get('wsPort').then(res => {
        portInput.value = String(res.wsPort || 10086);
    });
    // ── Query live connection status from background ─────────────
    function refreshStatus() {
        // Only refresh status if we are on the X settings view
        if (xSettingsView.classList.contains('hidden'))
            return;
        chrome.runtime.sendMessage({ type: 'GET_BRIDGE_STATUS' }).then((res) => {
            if (!res)
                return;
            if (res.connected) {
                statusDot.className = 'dot connected';
                statusText.textContent = 'Connected to LocalBridgeMac';
                const version = res.serverInfo?.serverVersion ? ` v${res.serverInfo.serverVersion}` : '';
                statusUrl.textContent = res.wsUrl + version;
            }
            else {
                statusDot.className = 'dot disconnected';
                statusText.textContent = 'Waiting for LocalBridgeMac…';
                statusUrl.textContent = res.wsUrl || '';
            }
        }).catch(() => {
            statusDot.className = 'dot disconnected';
            statusText.textContent = 'Unable to reach background';
            statusUrl.textContent = '';
        });
    }
    refreshStatus();
    // Poll every 2 seconds while popup is open
    const pollInterval = setInterval(refreshStatus, 2000);
    window.addEventListener('unload', () => clearInterval(pollInterval));
    // ── Save port & reconnect ────────────────────────────────────
    saveBtn.addEventListener('click', () => {
        const p = parseInt(portInput.value.trim());
        if (!p || p < 1024 || p > 65535) {
            alert('Invalid port number (must be 1024 – 65535)');
            return;
        }
        chrome.storage.local.set({ wsPort: p }).then(() => {
            statusMsg.textContent = 'Saved! Reconnecting…';
            chrome.runtime.sendMessage({ type: 'WS_PORT_CHANGED', port: p })
                .catch(() => { })
                .finally(() => {
                setTimeout(() => {
                    statusMsg.textContent = '';
                    refreshStatus();
                }, 1500);
            });
        });
    });
    // ── Debug link ───────────────────────────────────────────────
    const debugLink = document.getElementById('debugLink');
    if (debugLink) {
        debugLink.addEventListener('click', (e) => {
            e.preventDefault();
            const debugUrl = chrome.runtime.getURL('debug.html');
            chrome.tabs.query({ url: debugUrl }).then(existing => {
                if (existing.length > 0 && existing[0].id) {
                    chrome.tabs.update(existing[0].id, { active: true });
                    if (existing[0].windowId) {
                        chrome.windows.update(existing[0].windowId, { focused: true }).catch(() => { });
                    }
                }
                else {
                    chrome.tabs.create({ url: debugUrl });
                }
            });
            window.close();
        });
    }
});

/******/ })()
;
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoianMvcG9wdXAuanMiLCJtYXBwaW5ncyI6Ijs7OztBQUFBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLEtBQUs7QUFDTDtBQUNBO0FBQ0E7QUFDQSxLQUFLO0FBQ0w7QUFDQTtBQUNBO0FBQ0EsS0FBSztBQUNMO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxxQ0FBcUMsMkJBQTJCO0FBQ2hFO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxxRUFBcUUsNkJBQTZCO0FBQ2xHO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsU0FBUztBQUNUO0FBQ0E7QUFDQTtBQUNBLFNBQVM7QUFDVDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxtQ0FBbUMsV0FBVztBQUM5QztBQUNBLHlDQUF5QyxrQ0FBa0M7QUFDM0UsZ0NBQWdDO0FBQ2hDO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsaUJBQWlCO0FBQ2pCLGFBQWE7QUFDYixTQUFTO0FBQ1QsS0FBSztBQUNMO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLGdDQUFnQyxlQUFlO0FBQy9DO0FBQ0EseURBQXlELGNBQWM7QUFDdkU7QUFDQSxzRUFBc0UsZUFBZSxpQkFBaUI7QUFDdEc7QUFDQTtBQUNBO0FBQ0EseUNBQXlDLGVBQWU7QUFDeEQ7QUFDQSxhQUFhO0FBQ2I7QUFDQSxTQUFTO0FBQ1Q7QUFDQSxDQUFDIiwic291cmNlcyI6WyJ3ZWJwYWNrOi8vVHdlZXRDbGF3Ly4vc3JjL3BvcHVwL3BvcHVwLnRzIl0sInNvdXJjZXNDb250ZW50IjpbImRvY3VtZW50LmFkZEV2ZW50TGlzdGVuZXIoJ0RPTUNvbnRlbnRMb2FkZWQnLCAoKSA9PiB7XG4gICAgY29uc3QgbWFpblZpZXcgPSBkb2N1bWVudC5nZXRFbGVtZW50QnlJZCgnbWFpblZpZXcnKTtcbiAgICBjb25zdCB4U2V0dGluZ3NWaWV3ID0gZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoJ3hTZXR0aW5nc1ZpZXcnKTtcbiAgICBjb25zdCBidG5YID0gZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoJ2J0blgnKTtcbiAgICBjb25zdCBidG5CYWNrID0gZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoJ2J0bkJhY2snKTtcbiAgICBjb25zdCBwb3J0SW5wdXQgPSBkb2N1bWVudC5nZXRFbGVtZW50QnlJZCgncG9ydElucHV0Jyk7XG4gICAgY29uc3Qgc2F2ZUJ0biA9IGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKCdzYXZlQnRuJyk7XG4gICAgY29uc3Qgc3RhdHVzRG90ID0gZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoJ3N0YXR1c0RvdCcpO1xuICAgIGNvbnN0IHN0YXR1c1RleHQgPSBkb2N1bWVudC5nZXRFbGVtZW50QnlJZCgnc3RhdHVzVGV4dCcpO1xuICAgIGNvbnN0IHN0YXR1c1VybCA9IGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKCdzdGF0dXNVcmwnKTtcbiAgICBjb25zdCBzdGF0dXNNc2cgPSBkb2N1bWVudC5nZXRFbGVtZW50QnlJZCgnc3RhdHVzTXNnJyk7XG4gICAgLy8g4pSA4pSAIFZpZXcgU3dpdGNoaW5nIOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgFxuICAgIGJ0blguYWRkRXZlbnRMaXN0ZW5lcignY2xpY2snLCAoKSA9PiB7XG4gICAgICAgIG1haW5WaWV3LmNsYXNzTGlzdC5hZGQoJ2hpZGRlbicpO1xuICAgICAgICB4U2V0dGluZ3NWaWV3LmNsYXNzTGlzdC5yZW1vdmUoJ2hpZGRlbicpO1xuICAgIH0pO1xuICAgIGJ0bkJhY2suYWRkRXZlbnRMaXN0ZW5lcignY2xpY2snLCAoKSA9PiB7XG4gICAgICAgIHhTZXR0aW5nc1ZpZXcuY2xhc3NMaXN0LmFkZCgnaGlkZGVuJyk7XG4gICAgICAgIG1haW5WaWV3LmNsYXNzTGlzdC5yZW1vdmUoJ2hpZGRlbicpO1xuICAgIH0pO1xuICAgIC8vIOKUgOKUgCBMb2FkIHNhdmVkIHBvcnQg4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSAXG4gICAgY2hyb21lLnN0b3JhZ2UubG9jYWwuZ2V0KCd3c1BvcnQnKS50aGVuKHJlcyA9PiB7XG4gICAgICAgIHBvcnRJbnB1dC52YWx1ZSA9IFN0cmluZyhyZXMud3NQb3J0IHx8IDEwMDg2KTtcbiAgICB9KTtcbiAgICAvLyDilIDilIAgUXVlcnkgbGl2ZSBjb25uZWN0aW9uIHN0YXR1cyBmcm9tIGJhY2tncm91bmQg4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSAXG4gICAgZnVuY3Rpb24gcmVmcmVzaFN0YXR1cygpIHtcbiAgICAgICAgLy8gT25seSByZWZyZXNoIHN0YXR1cyBpZiB3ZSBhcmUgb24gdGhlIFggc2V0dGluZ3Mgdmlld1xuICAgICAgICBpZiAoeFNldHRpbmdzVmlldy5jbGFzc0xpc3QuY29udGFpbnMoJ2hpZGRlbicpKVxuICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICBjaHJvbWUucnVudGltZS5zZW5kTWVzc2FnZSh7IHR5cGU6ICdHRVRfQlJJREdFX1NUQVRVUycgfSkudGhlbigocmVzKSA9PiB7XG4gICAgICAgICAgICBpZiAoIXJlcylcbiAgICAgICAgICAgICAgICByZXR1cm47XG4gICAgICAgICAgICBpZiAocmVzLmNvbm5lY3RlZCkge1xuICAgICAgICAgICAgICAgIHN0YXR1c0RvdC5jbGFzc05hbWUgPSAnZG90IGNvbm5lY3RlZCc7XG4gICAgICAgICAgICAgICAgc3RhdHVzVGV4dC50ZXh0Q29udGVudCA9ICdDb25uZWN0ZWQgdG8gTG9jYWxCcmlkZ2VNYWMnO1xuICAgICAgICAgICAgICAgIGNvbnN0IHZlcnNpb24gPSByZXMuc2VydmVySW5mbz8uc2VydmVyVmVyc2lvbiA/IGAgdiR7cmVzLnNlcnZlckluZm8uc2VydmVyVmVyc2lvbn1gIDogJyc7XG4gICAgICAgICAgICAgICAgc3RhdHVzVXJsLnRleHRDb250ZW50ID0gcmVzLndzVXJsICsgdmVyc2lvbjtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGVsc2Uge1xuICAgICAgICAgICAgICAgIHN0YXR1c0RvdC5jbGFzc05hbWUgPSAnZG90IGRpc2Nvbm5lY3RlZCc7XG4gICAgICAgICAgICAgICAgc3RhdHVzVGV4dC50ZXh0Q29udGVudCA9ICdXYWl0aW5nIGZvciBMb2NhbEJyaWRnZU1hY+KApic7XG4gICAgICAgICAgICAgICAgc3RhdHVzVXJsLnRleHRDb250ZW50ID0gcmVzLndzVXJsIHx8ICcnO1xuICAgICAgICAgICAgfVxuICAgICAgICB9KS5jYXRjaCgoKSA9PiB7XG4gICAgICAgICAgICBzdGF0dXNEb3QuY2xhc3NOYW1lID0gJ2RvdCBkaXNjb25uZWN0ZWQnO1xuICAgICAgICAgICAgc3RhdHVzVGV4dC50ZXh0Q29udGVudCA9ICdVbmFibGUgdG8gcmVhY2ggYmFja2dyb3VuZCc7XG4gICAgICAgICAgICBzdGF0dXNVcmwudGV4dENvbnRlbnQgPSAnJztcbiAgICAgICAgfSk7XG4gICAgfVxuICAgIHJlZnJlc2hTdGF0dXMoKTtcbiAgICAvLyBQb2xsIGV2ZXJ5IDIgc2Vjb25kcyB3aGlsZSBwb3B1cCBpcyBvcGVuXG4gICAgY29uc3QgcG9sbEludGVydmFsID0gc2V0SW50ZXJ2YWwocmVmcmVzaFN0YXR1cywgMjAwMCk7XG4gICAgd2luZG93LmFkZEV2ZW50TGlzdGVuZXIoJ3VubG9hZCcsICgpID0+IGNsZWFySW50ZXJ2YWwocG9sbEludGVydmFsKSk7XG4gICAgLy8g4pSA4pSAIFNhdmUgcG9ydCAmIHJlY29ubmVjdCDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIBcbiAgICBzYXZlQnRuLmFkZEV2ZW50TGlzdGVuZXIoJ2NsaWNrJywgKCkgPT4ge1xuICAgICAgICBjb25zdCBwID0gcGFyc2VJbnQocG9ydElucHV0LnZhbHVlLnRyaW0oKSk7XG4gICAgICAgIGlmICghcCB8fCBwIDwgMTAyNCB8fCBwID4gNjU1MzUpIHtcbiAgICAgICAgICAgIGFsZXJ0KCdJbnZhbGlkIHBvcnQgbnVtYmVyIChtdXN0IGJlIDEwMjQg4oCTIDY1NTM1KScpO1xuICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICB9XG4gICAgICAgIGNocm9tZS5zdG9yYWdlLmxvY2FsLnNldCh7IHdzUG9ydDogcCB9KS50aGVuKCgpID0+IHtcbiAgICAgICAgICAgIHN0YXR1c01zZy50ZXh0Q29udGVudCA9ICdTYXZlZCEgUmVjb25uZWN0aW5n4oCmJztcbiAgICAgICAgICAgIGNocm9tZS5ydW50aW1lLnNlbmRNZXNzYWdlKHsgdHlwZTogJ1dTX1BPUlRfQ0hBTkdFRCcsIHBvcnQ6IHAgfSlcbiAgICAgICAgICAgICAgICAuY2F0Y2goKCkgPT4geyB9KVxuICAgICAgICAgICAgICAgIC5maW5hbGx5KCgpID0+IHtcbiAgICAgICAgICAgICAgICBzZXRUaW1lb3V0KCgpID0+IHtcbiAgICAgICAgICAgICAgICAgICAgc3RhdHVzTXNnLnRleHRDb250ZW50ID0gJyc7XG4gICAgICAgICAgICAgICAgICAgIHJlZnJlc2hTdGF0dXMoKTtcbiAgICAgICAgICAgICAgICB9LCAxNTAwKTtcbiAgICAgICAgICAgIH0pO1xuICAgICAgICB9KTtcbiAgICB9KTtcbiAgICAvLyDilIDilIAgRGVidWcgbGluayDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIBcbiAgICBjb25zdCBkZWJ1Z0xpbmsgPSBkb2N1bWVudC5nZXRFbGVtZW50QnlJZCgnZGVidWdMaW5rJyk7XG4gICAgaWYgKGRlYnVnTGluaykge1xuICAgICAgICBkZWJ1Z0xpbmsuYWRkRXZlbnRMaXN0ZW5lcignY2xpY2snLCAoZSkgPT4ge1xuICAgICAgICAgICAgZS5wcmV2ZW50RGVmYXVsdCgpO1xuICAgICAgICAgICAgY29uc3QgZGVidWdVcmwgPSBjaHJvbWUucnVudGltZS5nZXRVUkwoJ2RlYnVnLmh0bWwnKTtcbiAgICAgICAgICAgIGNocm9tZS50YWJzLnF1ZXJ5KHsgdXJsOiBkZWJ1Z1VybCB9KS50aGVuKGV4aXN0aW5nID0+IHtcbiAgICAgICAgICAgICAgICBpZiAoZXhpc3RpbmcubGVuZ3RoID4gMCAmJiBleGlzdGluZ1swXS5pZCkge1xuICAgICAgICAgICAgICAgICAgICBjaHJvbWUudGFicy51cGRhdGUoZXhpc3RpbmdbMF0uaWQsIHsgYWN0aXZlOiB0cnVlIH0pO1xuICAgICAgICAgICAgICAgICAgICBpZiAoZXhpc3RpbmdbMF0ud2luZG93SWQpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIGNocm9tZS53aW5kb3dzLnVwZGF0ZShleGlzdGluZ1swXS53aW5kb3dJZCwgeyBmb2N1c2VkOiB0cnVlIH0pLmNhdGNoKCgpID0+IHsgfSk7XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgZWxzZSB7XG4gICAgICAgICAgICAgICAgICAgIGNocm9tZS50YWJzLmNyZWF0ZSh7IHVybDogZGVidWdVcmwgfSk7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICB3aW5kb3cuY2xvc2UoKTtcbiAgICAgICAgfSk7XG4gICAgfVxufSk7XG4iXSwibmFtZXMiOltdLCJzb3VyY2VSb290IjoiIn0=