/******/ (() => { // webpackBootstrap
/******/ 	"use strict";
/******/ 	var __webpack_modules__ = ({

/***/ "./src/utils/route-parser.ts"
/*!***********************************!*\
  !*** ./src/utils/route-parser.ts ***!
  \***********************************/
(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   extractTweetId: () => (/* binding */ extractTweetId),
/* harmony export */   parseRouteKind: () => (/* binding */ parseRouteKind)
/* harmony export */ });
function parseRouteKind(url) {
    if (!url || !(url.includes('x.com') || url.includes('twitter.com')))
        return 'none';
    try {
        const u = new URL(url);
        const path = u.pathname;
        if (path === '/home' || path === '/')
            return 'home';
        if (path.includes('/search'))
            return 'search';
        if (path.includes('/status/'))
            return 'thread';
        if (path.includes('/notifications'))
            return 'notification';
        return 'profile';
    }
    catch {
        return 'unknown';
    }
}
function extractTweetId(url) {
    if (!url)
        return null;
    try {
        const u = new URL(url);
        const match = u.pathname.match(/\/status\/(\d+)/);
        return match ? match[1] : null;
    }
    catch {
        return null;
    }
}


/***/ },

/***/ "./src/utils/x-url-utils.ts"
/*!**********************************!*\
  !*** ./src/utils/x-url-utils.ts ***!
  \**********************************/
(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   formatTweetDetailUrl: () => (/* binding */ formatTweetDetailUrl),
/* harmony export */   validateTweetDetailParams: () => (/* binding */ validateTweetDetailParams)
/* harmony export */ });
/**
 * x-url-utils.ts - Shared helpers for X URL generation and validation.
 */
function validateTweetDetailParams(screenName, tweetId) {
    if (!screenName)
        return { ok: false, error: 'screenName is required' };
    if (!tweetId)
        return { ok: false, error: 'tweetId is required' };
    if (screenName.includes(' ') || screenName.includes('/')) {
        return { ok: false, error: 'Invalid screenName: must not contain spaces or slashes.' };
    }
    if (!/^\d+$/.test(tweetId)) {
        return { ok: false, error: 'Invalid tweetId: must be a numeric string.' };
    }
    return { ok: true };
}
function formatTweetDetailUrl(screenName, tweetId) {
    const cleanedHandle = screenName.startsWith('@') ? screenName.slice(1) : screenName;
    return `https://x.com/${cleanedHandle}/status/${tweetId}`;
}


/***/ }

/******/ 	});
/************************************************************************/
/******/ 	// The module cache
/******/ 	var __webpack_module_cache__ = {};
/******/ 	
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/ 		// Check if module is in cache
/******/ 		var cachedModule = __webpack_module_cache__[moduleId];
/******/ 		if (cachedModule !== undefined) {
/******/ 			return cachedModule.exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = __webpack_module_cache__[moduleId] = {
/******/ 			// no module.id needed
/******/ 			// no module.loaded needed
/******/ 			exports: {}
/******/ 		};
/******/ 	
/******/ 		// Execute the module function
/******/ 		if (!(moduleId in __webpack_modules__)) {
/******/ 			delete __webpack_module_cache__[moduleId];
/******/ 			var e = new Error("Cannot find module '" + moduleId + "'");
/******/ 			e.code = 'MODULE_NOT_FOUND';
/******/ 			throw e;
/******/ 		}
/******/ 		__webpack_modules__[moduleId](module, module.exports, __webpack_require__);
/******/ 	
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/ 	
/************************************************************************/
/******/ 	/* webpack/runtime/define property getters */
/******/ 	(() => {
/******/ 		// define getter functions for harmony exports
/******/ 		__webpack_require__.d = (exports, definition) => {
/******/ 			for(var key in definition) {
/******/ 				if(__webpack_require__.o(definition, key) && !__webpack_require__.o(exports, key)) {
/******/ 					Object.defineProperty(exports, key, { enumerable: true, get: definition[key] });
/******/ 				}
/******/ 			}
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/hasOwnProperty shorthand */
/******/ 	(() => {
/******/ 		__webpack_require__.o = (obj, prop) => (Object.prototype.hasOwnProperty.call(obj, prop))
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/make namespace object */
/******/ 	(() => {
/******/ 		// define __esModule on exports
/******/ 		__webpack_require__.r = (exports) => {
/******/ 			if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 				Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 			}
/******/ 			Object.defineProperty(exports, '__esModule', { value: true });
/******/ 		};
/******/ 	})();
/******/ 	
/************************************************************************/
var __webpack_exports__ = {};
// This entry needs to be wrapped in an IIFE because it needs to be isolated against other modules in the chunk.
(() => {
/*!****************************!*\
  !*** ./src/debug/debug.ts ***!
  \****************************/
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _utils_route_parser__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../utils/route-parser */ "./src/utils/route-parser.ts");
/* harmony import */ var _utils_x_url_utils__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../utils/x-url-utils */ "./src/utils/x-url-utils.ts");
/**
 * debug.ts - TweetClaw Debug Panel (v5.4)
 *
 * 修复：
 *   - D 区 toggle 冒泡问题：expanded content 改为 .api-hit 的兄弟节点
 *   - E 区空白时补充提示 + 推文作者参考信息
 */


// ─────────────────────────────────────────────
// UI 视觉增强：强制提升标签对比度 (v5.4.1)
// ─────────────────────────────────────────────
const style = document.createElement('style');
style.textContent = `
    /* 强制提升所有 sys-stat 标签的对比度 */
    .sys-stat span:first-child:not(.val) { 
        color: #cbd5e0 !important; 
        opacity: 0.9 !important;
    }
    /* 提升 text-muted 在暗色背景下的可见度 */
    .text-muted { 
        color: #a0aec0 !important; 
    }
`;
document.head.appendChild(style);
let selectedTabId = null;
let tabList = [];
let bridgeOnline = false;
let currentHits = []; // D 区当前显示的 hits，供 Modal 引用
const manualOverrides = new Map();
const selectedReplyIds = new Map();
const selectedProfileTweetIds = new Map();
let lastFilledIds = new Map();
let replyDraftText = '';
let isReviewConfirmed = false;
let lastReviewNote = null;
let lastPageContext = null;
// New state maps for inputs to avoid data loss on frequent re-renders
const navUrlDrafts = new Map();
const openTweetScreenNameDrafts = new Map();
const openTweetIdDrafts = new Map();
let lastOpenTweetRequests = new Map();
const APPROVAL_STATE = {
    DRAFT_EMPTY: 'DRAFT_EMPTY',
    DRAFT_NOT_READY: 'DRAFT_NOT_READY',
    READY_FOR_REVIEW: 'READY_FOR_REVIEW',
    LOCKED_LOGGED_OUT: 'LOCKED_LOGGED_OUT'
};
function getCurrentReplyIntent(tid, pageContext, currentInputValue) {
    const isManual = manualOverrides.get(tid) || false;
    const selectedReplyId = selectedReplyIds.get(tid) || null;
    const isTweetDetail = pageContext.scene === 'tweet_detail';
    const curEntity = pageContext.currentEntity;
    let targetType = 'NONE';
    let targetId = '';
    let authorHandle = '';
    if (isManual) {
        targetType = 'manual target';
        targetId = currentInputValue;
    }
    else if (isTweetDetail && selectedReplyId) {
        const reply = (pageContext.repliesSnapshot || []).find((r) => r.tweetId === selectedReplyId);
        targetType = 'selected reply';
        targetId = selectedReplyId;
        authorHandle = reply?.authorHandle || '';
    }
    else if (isTweetDetail && curEntity) {
        targetType = 'current tweet';
        targetId = curEntity.entityId;
        authorHandle = curEntity.authorHandle || '';
    }
    return { targetType, targetId, authorHandle };
}
// ─────────────────────────────────────────────
// 事件代理
// ─────────────────────────────────────────────
// ─────────────────────────────────────────────
// Modal（D 区 hit 详情弹窗）
// ─────────────────────────────────────────────
function showHitModal(h) {
    // 清掉旧 modal（如有）
    document.getElementById('tc-hit-modal')?.remove();
    let apiPath = '—';
    let queryParamsHtml = '';
    let fallbackUrlHtml = '';
    try {
        if (h.apiUrl) {
            const u = new URL(h.apiUrl);
            apiPath = u.pathname;
            const params = new URLSearchParams(u.search);
            const parsedParams = {};
            let hasParams = false;
            for (const [key, value] of params.entries()) {
                hasParams = true;
                try {
                    parsedParams[key] = JSON.parse(value);
                }
                catch {
                    parsedParams[key] = value;
                }
            }
            if (hasParams) {
                const paramsJson = safeJson(parsedParams);
                queryParamsHtml = `
                <div class="tc-modal-section">
                    <div class="tc-modal-label text-warning">QUERY PARAMETERS</div>
                    <pre class="tc-modal-pre">${paramsJson}</pre>
                </div>`;
            }
        }
    }
    catch {
        apiPath = h.apiUrl || '—';
        fallbackUrlHtml = `
        <div class="tc-modal-section">
            <div class="tc-modal-label">RAW API URL</div>
            <pre class="tc-modal-pre">${h.apiUrl}</pre>
        </div>`;
    }
    const reqJson = safeJson(h.requestBody);
    const respJson = safeJson(h.responseBody || {});
    const modal = document.createElement('div');
    modal.id = 'tc-hit-modal';
    modal.innerHTML = `
    <div class="tc-modal-backdrop"></div>
    <div class="tc-modal-box">
        <div class="tc-modal-header">
            <span class="method" style="margin-right:10px">${h.method || 'POST'}</span>
            <span class="fw-bold text-white" style="font-size:14px; margin-right:10px">${h.op}</span>
            <span class="text-info" style="font-size:11px; flex:1; overflow:hidden; text-overflow:ellipsis; white-space:nowrap" title="${apiPath}">${apiPath}</span>
            <span class="text-muted" style="font-size:10px; margin-right:12px">${new Date(h.timestamp).toLocaleTimeString()}</span>
            <button id="tc-modal-close" style="background:none;border:none;color:#a0aec0;font-size:18px;cursor:pointer;line-height:1">✕</button>
        </div>
        <div class="tc-modal-body">
            <div class="tc-modal-section" style="display:flex; gap: 20px;">
                <div style="flex:1; overflow:hidden;">
                    <div class="tc-modal-label">API PATH</div>
                    <div class="text-light" style="font-size:11px; word-break:break-all;">${apiPath}</div>
                </div>
                <div style="flex:1; overflow:hidden;">
                    <div class="tc-modal-label">PAGE URL</div>
                    <div class="text-muted" style="font-size:11px; word-break:break-all;">${h.pageUrl || '—'}</div>
                </div>
            </div>
            ${fallbackUrlHtml}
            ${queryParamsHtml}
            ${h.requestBody ? `
            <div class="tc-modal-section">
                <div class="tc-modal-label text-primary">REQUEST BODY</div>
                <pre class="tc-modal-pre">${reqJson}</pre>
            </div>` : ''}
            <div class="tc-modal-section">
                <div class="tc-modal-label text-success">RESPONSE BODY</div>
                <pre class="tc-modal-pre">${respJson}</pre>
            </div>
        </div>
    </div>`;
    document.body.appendChild(modal);
    const close = () => document.getElementById('tc-hit-modal')?.remove();
    document.getElementById('tc-modal-close').onclick = close;
    modal.querySelector('.tc-modal-backdrop').addEventListener('click', close);
}
function setupDelegation() {
    document.addEventListener('click', (e) => {
        const target = e.target;
        // 选择 X tab
        const tabEl = target.closest('.tab-item');
        if (tabEl?.dataset.id && !target.closest('button')) {
            selectedTabId = parseInt(tabEl.dataset.id);
            refreshData();
            return;
        }
        // Workspace Control: Focus Tab
        const focusBtn = target.closest('.btn-tab-focus');
        if (focusBtn?.dataset.id) {
            const tid = parseInt(focusBtn.dataset.id);
            sendMsg({ type: 'FOCUS_X_TAB', tabId: tid }).then(() => refreshData());
            return;
        }
        // Workspace Control: Close Tab
        const closeBtn = target.closest('.btn-tab-close');
        if (closeBtn?.dataset.id) {
            const tid = parseInt(closeBtn.dataset.id);
            if (confirm(`Close tab ${tid}?`)) {
                sendMsg({ type: 'CLOSE_X_TAB', tabId: tid }).then(() => {
                    if (selectedTabId === tid)
                        selectedTabId = null;
                    navUrlDrafts.delete(tid);
                    openTweetScreenNameDrafts.delete(tid);
                    openTweetIdDrafts.delete(tid);
                    refreshData();
                });
            }
            return;
        }
        // Workspace Control: Navigate Tab
        const navBtn = target.closest('.btn-tab-navigate');
        if (navBtn?.dataset.id) {
            const tid = parseInt(navBtn.dataset.id);
            const input = document.getElementById('nav-url-input');
            const url = input?.value?.trim();
            if (url) {
                sendMsg({ type: 'NAVIGATE_X_TAB', tabId: tid, url }).then((resp) => {
                    if (resp?.ok) {
                        navUrlDrafts.delete(tid);
                        refreshData();
                    }
                    else if (resp?.error) {
                        alert(`Navigation failed: ${resp.error}`);
                    }
                });
            }
            return;
        }
        // Workspace Control: Open Tweet (Semantic)
        const openTweetBtn = target.closest('.btn-tab-open-tweet');
        if (openTweetBtn?.dataset.id) {
            const tid = parseInt(openTweetBtn.dataset.id);
            const sNameInput = document.getElementById('open-tweet-screen-name');
            const tIdInput = document.getElementById('open-tweet-id');
            const screenName = sNameInput?.value?.trim() || '';
            const tweetId = tIdInput?.value?.trim() || '';
            const valid = (0,_utils_x_url_utils__WEBPACK_IMPORTED_MODULE_1__.validateTweetDetailParams)(screenName, tweetId);
            if (valid.ok) {
                // Record request for mismatch warning
                lastOpenTweetRequests.set(tid, { screenName, tweetId, timestamp: Date.now() });
                const url = (0,_utils_x_url_utils__WEBPACK_IMPORTED_MODULE_1__.formatTweetDetailUrl)(screenName, tweetId);
                sendMsg({ type: 'NAVIGATE_X_TAB', tabId: tid, url }).then((resp) => {
                    if (resp?.ok) {
                        openTweetScreenNameDrafts.delete(tid);
                        openTweetIdDrafts.delete(tid);
                        refreshData();
                    }
                    else if (resp?.error) {
                        alert(`Open Tweet failed: ${resp.error}`);
                    }
                });
            }
            else {
                alert(`Invalid Parameters: ${valid.error}`);
            }
            return;
        }
        // Workspace Control: Create Tab
        const createBtn = target.closest('#btn-create-tab');
        if (createBtn) {
            sendMsg({ type: 'CREATE_X_TAB', url: 'https://x.com/' }).then((resp) => {
                if (resp?.ok) {
                    selectedTabId = resp.tabId;
                    refreshData();
                }
            });
            return;
        }
        // D 区：Details 按钮 → 弹 Modal
        const detailBtn = target.closest('.btn-hit-detail');
        if (detailBtn?.dataset.hitIndex !== undefined) {
            const idx = parseInt(detailBtn.dataset.hitIndex);
            if (!isNaN(idx) && currentHits[idx])
                showHitModal(currentHits[idx]);
            return;
        }
        // 统一写操作按钮（F 区手动/快捷合并操作）
        const manualActionBtn = target.closest('.btn-manual-action');
        if (manualActionBtn?.dataset.tabid) {
            const { action, tabid } = manualActionBtn.dataset;
            const inputEl = document.getElementById('manual-target-id');
            const inputVal = inputEl?.value?.trim();
            if (inputVal && action)
                doAction(parseInt(tabid), inputVal, action, manualActionBtn);
            else if (!inputVal)
                alert("Please enter a valid target ID (Tweet ID or User ID) first.");
            return;
        }
        // Track manual changes to target ID
        if (target.id === 'manual-target-id' && selectedTabId !== null) {
            manualOverrides.set(selectedTabId, true);
            isReviewConfirmed = false;
        }
        // Selection of Reply from Snapshot
        const replyRow = target.closest('.tc-reply-row');
        if (replyRow?.dataset.id && selectedTabId !== null) {
            const rid = replyRow.dataset.id;
            const currentSelected = selectedReplyIds.get(selectedTabId);
            if (currentSelected === rid) {
                // Toggle off
                selectedReplyIds.set(selectedTabId, null);
            }
            else {
                // Select new
                selectedReplyIds.set(selectedTabId, rid);
                manualOverrides.set(selectedTabId, false); // Clicking a reply clears manual override
                isReviewConfirmed = false;
            }
            refreshData();
            return;
        }
        // Selection of Profile Tweet from Snapshot
        const profileTweetRow = target.closest('.tc-profile-tweet-row');
        if (profileTweetRow?.dataset.id && selectedTabId !== null) {
            const tid = profileTweetRow.dataset.id;
            const currentSelected = selectedProfileTweetIds.get(selectedTabId);
            if (currentSelected === tid) {
                // Toggle off
                selectedProfileTweetIds.set(selectedTabId, null);
            }
            else {
                // Select new
                selectedProfileTweetIds.set(selectedTabId, tid);
            }
            refreshData();
            return;
        }
        // Review Only Button
        const reviewBtn = target.closest('#btn-review-only');
        if (reviewBtn && selectedTabId !== null && lastPageContext) {
            const inputEl = document.getElementById('manual-target-id');
            const inputVal = inputEl?.value?.trim();
            // Re-derive the target just like renderReplyDraftUI
            const intent = getCurrentReplyIntent(selectedTabId, lastPageContext, inputVal || '');
            isReviewConfirmed = true;
            lastReviewNote = {
                targetId: intent.targetId,
                targetType: intent.targetType,
                draftText: replyDraftText,
                timestamp: Date.now(),
                reviewConfirmed: true
            };
            refreshData();
            return;
        }
    });
    // Handle input event specifically for manual override detection
    document.addEventListener('input', (e) => {
        const target = e.target;
        if (target.id === 'manual-target-id' && selectedTabId !== null) {
            manualOverrides.set(selectedTabId, true);
            isReviewConfirmed = false;
        }
        if (target.id === 'reply-draft-text') {
            replyDraftText = target.value;
            isReviewConfirmed = false;
            // A simple trick: update the preview div directly.
            const previewEl = document.getElementById('reply-intent-preview-container');
            if (previewEl) {
                refreshData();
            }
        }
        if (target.id === 'nav-url-input' && selectedTabId !== null) {
            navUrlDrafts.set(selectedTabId, target.value);
        }
        if (target.id === 'open-tweet-screen-name' && selectedTabId !== null) {
            openTweetScreenNameDrafts.set(selectedTabId, target.value);
        }
        if (target.id === 'open-tweet-id' && selectedTabId !== null) {
            openTweetIdDrafts.set(selectedTabId, target.value);
        }
    });
}
// ─────────────────────────────────────────────
// Background 推送监听
// ─────────────────────────────────────────────
chrome.runtime.onMessage.addListener((message) => {
    if (message.type !== 'DEBUG_UPDATE_PUSH')
        return;
    if (selectedTabId === null || selectedTabId === message.tabId) {
        refreshData();
    }
    else {
        refreshTabListOnly();
    }
});
// ─────────────────────────────────────────────
// Bridge Ping
// ─────────────────────────────────────────────
async function checkBridge() {
    if (selectedTabId === null) {
        bridgeOnline = false;
        return;
    }
    try {
        const resp = await new Promise(r => {
            chrome.tabs.sendMessage(selectedTabId, { type: 'TC_PING' }, res => {
                if (chrome.runtime.lastError)
                    r({ ok: false });
                else
                    r(res || { ok: false });
            });
        });
        bridgeOnline = !!(resp?.ok);
    }
    catch {
        bridgeOnline = false;
    }
}
// ─────────────────────────────────────────────
// 数据拉取
// ─────────────────────────────────────────────
async function refreshTabListOnly() {
    tabList = await sendMsg({ type: 'LIST_ALL_X_TABS' }) || [];
    renderTabList();
    renderSidebarEnv();
}
async function refreshData() {
    try {
        tabList = await sendMsg({ type: 'LIST_ALL_X_TABS' }) || [];
        // 验证当前选中的 tab 还是否存在
        if (selectedTabId !== null) {
            const exists = tabList.some(t => t.id === selectedTabId);
            if (!exists)
                selectedTabId = null;
        }
        // 如果没有选中且有可用 tab，默认选第一个
        if (selectedTabId === null && tabList.length > 0) {
            selectedTabId = tabList[0].id;
        }
        renderTabList();
        if (selectedTabId !== null) {
            const detail = await sendMsg({ type: 'GET_TAB_DATA', tabId: selectedTabId });
            const pageContext = await sendMsg({ type: 'GET_PAGE_CONTEXT', tabId: selectedTabId });
            await checkBridge();
            // --- Focus Preservation Start ---
            const activeId = document.activeElement?.id;
            const selectionStart = document.activeElement?.selectionStart;
            const selectionEnd = document.activeElement?.selectionEnd;
            // --------------------------------
            lastPageContext = pageContext;
            renderDetailView(detail || {}, pageContext || {});
            // --- Focus Preservation End ---
            if (activeId) {
                const el = document.getElementById(activeId);
                if (el) {
                    el.focus();
                    if (selectionStart !== undefined && selectionStart !== null) {
                        el.setSelectionRange(selectionStart, selectionEnd || selectionStart);
                    }
                }
            }
            // ------------------------------
        }
        else {
            renderEmptyState();
        }
        renderSidebarEnv();
    }
    catch (e) {
        console.error('[TweetClaw-Debug] refreshData error:', e);
    }
}
function sendMsg(msg) {
    return new Promise(resolve => {
        chrome.runtime.sendMessage(msg, res => {
            if (chrome.runtime.lastError) {
                console.warn('[TweetClaw-Debug] sendMessage error:', chrome.runtime.lastError.message);
                resolve(null);
            }
            else {
                resolve(res);
            }
        });
    });
}
// ─────────────────────────────────────────────
// 侧边栏：Tab 列表
// ─────────────────────────────────────────────
function renderTabList() {
    const container = document.getElementById('tab-list');
    if (!container)
        return;
    // Add Create Tab button at the top
    let html = `
    <div class="mb-3 px-1">
        <button id="btn-create-tab" class="btn btn-primary btn-sm w-100" style="font-size:11px;">+ Open x.com</button>
    </div>`;
    if (tabList.length === 0) {
        html += `<div class="text-muted small p-2">No X tabs open.</div>`;
        container.innerHTML = html;
        return;
    }
    html += tabList.map(t => {
        const isSelected = t.id === selectedTabId;
        // 优先用账号 handle，否则从 URL 提取有意义的路径标识
        const identity = t.account?.handle || urlLabel(t.url);
        const rKind = (0,_utils_route_parser__WEBPACK_IMPORTED_MODULE_0__.parseRouteKind)(t.url);
        return `
        <div class="tab-item ${isSelected ? 'active' : ''}" data-id="${t.id}">
            <div class="d-flex justify-content-between align-items-center mb-1">
                <span class="fw-bold small ${isSelected ? 'text-white' : 'text-info'}">${identity}</span>
                <span class="status-badge ${t.active ? 'bg-success-subtle' : 'bg-secondary'}">${t.active ? 'ACTIVE' : 'IDLE'}</span>
            </div>
            <div class="text-truncate" style="opacity:.6;font-size:10px;">TAB ${t.id} · ${rKind.toUpperCase()}</div>
            <div class="d-flex gap-1 mt-2">
                <button class="btn btn-outline-info btn-xs btn-tab-focus" data-id="${t.id}" style="font-size:9px; padding:1px 6px;">Focus</button>
                <button class="btn btn-outline-danger btn-xs btn-tab-close" data-id="${t.id}" style="font-size:9px; padding:1px 6px;">Close</button>
            </div>
        </div>`;
    }).join('');
    container.innerHTML = html;
}
// ─────────────────────────────────────────────
// 侧边栏：执行环境
// ─────────────────────────────────────────────
function renderSidebarEnv() {
    const el = document.getElementById('sidebar-env');
    if (!el)
        return;
    let html = `
        <div class="sys-stat"><span>Write Policy</span><span class="val text-success">Content Script ✓</span></div>
        <div class="sys-stat"><span>Exec Bridge</span>
            <span class="val ${bridgeOnline ? 'text-success' : 'text-danger'}">${bridgeOnline ? 'ONLINE ✓' : 'OFFLINE ✗'}</span>
        </div>
        <div class="sys-stat"><span>Inject Role</span><span class="val text-warning">Passive Sensor</span></div>
        <div class="sys-stat"><span>Inject Writes</span><span class="val text-success">None ✓</span></div>`;
    if (lastReviewNote) {
        const timeStr = new Date(lastReviewNote.timestamp).toLocaleTimeString();
        html += `
            <div class="mt-3 pt-2 border-top border-secondary" style="font-size:9px; line-height:1.2">
                <div style="color:#a0aec0; text-transform:uppercase; font-weight:700; margin-bottom:2px">Last Review Note</div>
                <div class="text-info">${lastReviewNote.targetType.toUpperCase()} (${lastReviewNote.targetId})</div>
                <div class="text-truncate" style="opacity:0.8">Text: ${lastReviewNote.draftText || '—'}</div>
                <div class="text-muted" style="font-size:8px">at ${timeStr}</div>
            </div>`;
    }
    el.innerHTML = html;
}
// ─────────────────────────────────────────────
// 空状态
// ─────────────────────────────────────────────
function renderEmptyState() {
    const c = document.getElementById('tab-data-view');
    if (c)
        c.innerHTML = `
        <div class="text-center mt-5 text-muted">
            <h4>No X tab selected</h4>
            <p class="small">Open x.com and select a tab on the left</p>
        </div>`;
}
// ─────────────────────────────────────────────
// 工具函数
// ─────────────────────────────────────────────
/**
 * 从 X/Twitter tab URL 提取简短可读标识。
 * 例：https://x.com/home          → "x.com/home"
 *     https://x.com/coder/status → "x.com/coder"
 *     https://twitter.com/…      → "twitter.com/…"
 */
function urlLabel(url) {
    if (!url)
        return 'X Tab';
    try {
        const u = new URL(url);
        const parts = u.pathname.split('/').filter(Boolean); // ['home'] or ['user','status','id']
        const slug = parts.length > 0 ? `/${parts[0]}` : '';
        return u.hostname.replace('www.', '') + slug;
    }
    catch {
        return 'X Tab';
    }
}
function fmtTime(ts) {
    if (!ts)
        return '—';
    const sec = Math.round((Date.now() - ts) / 1000);
    if (sec < 5)
        return 'just now';
    if (sec < 60)
        return `${sec}s ago`;
    if (sec < 3600)
        return `${Math.floor(sec / 60)}m ago`;
    return new Date(ts).toLocaleTimeString();
}
function badge(ok, t = 'ACTIVE', f = 'OFFLINE') {
    return ok
        ? `<span class="badge bg-success">${t}</span>`
        : `<span class="badge bg-danger">${f}</span>`;
}
function truncate(s, n = 120) {
    if (!s)
        return '—';
    return s.length > n ? s.slice(0, n) + '…' : s;
}
function nFmt(num) {
    if (num === null || num === undefined)
        return '—';
    if (typeof num === 'string')
        return num;
    if (num >= 1000000)
        return (num / 1000000).toFixed(1) + 'M';
    if (num >= 1000)
        return (num / 1000).toFixed(1) + 'k';
    return num.toString();
}
function safeJson(obj, indent = 2) {
    try {
        return JSON.stringify(obj, null, indent);
    }
    catch {
        return String(obj);
    }
}
function reqSummary(obj) {
    if (!obj)
        return '—';
    if (typeof obj === 'string')
        return truncate(obj, 80);
    const keys = Object.keys(obj).slice(0, 4).join(', ');
    return `{${keys}${Object.keys(obj).length > 4 ? '…' : ''}}`;
}
// ─────────────────────────────────────────────
// Scene Card 渲染
// ─────────────────────────────────────────────
function renderSceneCard(context) {
    if (!context)
        return '';
    const sceneName = (context.scene || 'UNKNOWN').toUpperCase().replace(/_/g, ' ');
    const routeName = (context.routeKind || 'NONE').toUpperCase();
    // 如果不是 X 页面，简化显示
    if (context.scene === 'not_x') {
        return `
            <div class="card mb-3 border-secondary">
                <div class="card-body py-2 text-center text-muted small">
                    Current tab is not on X workspace.
                </div>
            </div>`;
    }
    return `
        <div class="card mb-3">
            <div class="card-header d-flex justify-content-between align-items-center">
                <span class="text-info fw-bold">SCENE: ${sceneName}</span>
                <span class="badge bg-dark text-info border border-info" style="font-size:10px">ROUTE: ${routeName}</span>
            </div>
            <div class="card-body py-1">
                <div class="sys-stat"><span>URL</span><span class="val text-truncate" style="max-width:260px; font-size:10px; opacity:0.7">${context.currentUrl || '—'}</span></div>
                <div class="mt-2" style="font-size:10px; color:#cbd5e0; text-transform:uppercase; font-weight:700; letter-spacing:0.5px">Capabilities</div>
                <div class="d-flex flex-wrap gap-1 mt-1 mb-2">
                    ${(context.availableActions || []).map((a) => `<span class="badge bg-info text-dark" style="font-size:9px; opacity:0.9; font-weight:600">${a}</span>`).join('')}
                    ${(context.availableActions || []).length === 0 ? '<span class="text-muted small">None</span>' : ''}
                </div>
            </div>
        </div>`;
}
function renderMismatchWarning(tid, pageContext) {
    const lastRequest = lastOpenTweetRequests.get(tid);
    if (!lastRequest)
        return '';
    // If we've navigated away from tweet_detail, clear the request
    if (pageContext.scene !== 'tweet_detail') {
        lastOpenTweetRequests.delete(tid);
        return '';
    }
    const currentEntity = pageContext.currentEntity;
    const currentHandle = currentEntity?.authorHandle;
    const currentId = currentEntity?.entityId;
    // If we have an entity ID and it doesn't match the requested one, 
    // it means the user has navigated away from the requested tweet.
    if (currentId && currentId !== lastRequest.tweetId) {
        lastOpenTweetRequests.delete(tid);
        return '';
    }
    if (!currentHandle)
        return '';
    const cleanRequested = lastRequest.screenName.replace('@', '').toLowerCase();
    const cleanActual = currentHandle.replace('@', '').toLowerCase();
    if (cleanRequested !== cleanActual) {
        return `
            <div class="alert alert-warning py-2 px-3 mb-3 border-warning" style="font-size: 11px; background: rgba(255, 193, 7, 0.1);">
                <div class="fw-bold mb-1">⚠ AUTHOR MISMATCH WARNING</div>
                <div class="d-flex flex-column gap-1">
                    <div>Requested: <span class="text-info">@${lastRequest.screenName.replace('@', '')}</span></div>
                    <div>Resolved: <span class="text-warning">@${currentHandle.replace('@', '')}</span></div>
                    <div class="mt-1 opacity-75">Navigated successfully, but author does not match requested screenName.</div>
                </div>
            </div>`;
    }
    return '';
}
// ─────────────────────────────────────────────
// Entity Card 渲染 (NEW)
// ─────────────────────────────────────────────
// ─────────────────────────────────────────────
// Entity Card 渲染 (NEW)
// ─────────────────────────────────────────────
function renderEntityCard(entity, scene) {
    if (scene !== 'tweet_detail' && scene !== 'profile') {
        return `
            <div class="card mb-3 opacity-75">
                <div class="card-header d-flex justify-content-between align-items-center">
                    <span class="text-muted fw-bold">CURRENT ENTITY</span>
                    <span class="text-muted" style="font-size:10px">N/A FOR THIS SCENE</span>
                </div>
                <div class="card-body py-3 text-center text-muted italic" style="font-size:11px">
                    Entity selection is active only in <strong>Tweet Detail</strong> or <strong>Profile</strong> views.
                </div>
            </div>`;
    }
    if (!entity) {
        return `
            <div class="card mb-3 border-warning">
                <div class="card-header text-warning fw-bold">CURRENT ENTITY: PENDING</div>
                <div class="card-body py-3 text-center text-muted italic" style="font-size:11px">
                    Identifying entity details... Scroll or interact with the page.
                </div>
            </div>`;
    }
    if (entity.entityType !== 'tweet')
        return '';
    const isUrlOnly = entity.source === 'url_only';
    const sourceLabel = isUrlOnly ? '<span class="text-warning" style="font-size:10px">ENTITY PARTIALLY RESOLVED FROM URL ONLY</span>' : '<span class="text-success" style="font-size:10px">ENTITY RESOLVED (MERGED)</span>';
    return `
        <div class="card mb-3">
            <div class="card-header d-flex justify-content-between align-items-center">
                <span class="text-primary fw-bold">CURRENT ENTITY: TWEET</span>
                ${sourceLabel}
            </div>
            <div class="card-body py-2">
                <div class="row">
                    <div class="col-8 border-right">
                        <div class="sys-stat"><span>Tweet ID</span><span class="val text-warning">${entity.entityId}</span></div>
                        <div class="sys-stat"><span>Author</span><span class="val text-info">${entity.authorHandle || '—'} ${entity.authorName ? `<small class="text-muted">(${entity.authorName})</small>` : ''}</span></div>
                        <div class="sys-stat"><span>Author ID</span><span class="val" style="font-size:10px; opacity:0.7">${entity.authorId || '—'}</span></div>
                        <div class="sys-stat"><span>Created At</span><span class="val" style="font-size:10px">${entity.createdAt || '—'}</span></div>
                        <div class="sys-stat"><span>Ownership</span><span class="val ${entity.isOwnedByActiveAccount ? 'text-success' : 'text-muted'}">${entity.isOwnedByActiveAccount ? 'OWNED BY ACTIVE ACCOUNT' : 'OTHERS'}</span></div>
                        <div class="mt-2" style="font-size:10px; color:#cbd5e0; text-transform:uppercase; font-weight:700">Content Snapshot</div>
                        <div class="p-2 mt-1 bg-dark rounded text-light" style="font-size:11px; max-height: 80px; overflow-y: auto;">
                            ${entity.text || '<span class="text-muted italic">No content captured.</span>'}
                        </div>
                    </div>
                    <div class="col-4">
                        <div class="mt-1" style="font-size:10px; color:#cbd5e0; text-transform:uppercase; font-weight:700">Metrics</div>
                        <div class="sys-stat mt-2"><span>Like</span><span class="val">${entity.likeCount ?? '—'}</span></div>
                        <div class="sys-stat"><span>Reply</span><span class="val">${entity.replyCount ?? '—'}</span></div>
                        <div class="sys-stat"><span>Repost</span><span class="val">${entity.retweetCount ?? '—'}</span></div>
                        <div class="sys-stat"><span>Bookmark</span><span class="val">${entity.bookmarkCount ?? '—'}</span></div>
                    </div>
                </div>
                ${isUrlOnly ? `
                <div class="mt-2 text-center">
                    <div class="alert alert-warning py-1 px-2 m-0" style="font-size:10px">
                        Partial data. Open this tweet on X to capture full details.
                    </div>
                </div>` : ''}
            </div>
        </div>`;
}
// ─────────────────────────────────────────────
// Replies Snapshot 渲染 (NEW)
// ─────────────────────────────────────────────
function renderRepliesSnapshot(replies, scene) {
    if (scene !== 'tweet_detail')
        return '';
    // 空状态：使用与上方 Section 一致的标识颜色
    if (!replies || replies.length === 0) {
        return `
            <div class="card mb-3 border-secondary">
                <div class="card-header text-info fw-bold">REPLIES SNAPSHOT</div>
                <div class="card-body py-3 text-center text-secondary italic" style="font-size:11px; opacity: 0.6">
                    No active replies captured yet.
                </div>
            </div>`;
    }
    const count = replies.length;
    const displayList = replies.slice(0, 5);
    const selectedId = selectedTabId !== null ? selectedReplyIds.get(selectedTabId) : null;
    // 有数据状态：使用鲜艳的绿色强调捕获成功
    return `
        <div class="card mb-3 border-success" style="border-width: 1px">
            <div class="card-header d-flex justify-content-between align-items-center" style="background: rgba(25, 135, 84, 0.05)">
                <span class="text-success fw-bold">REPLIES SNAPSHOT</span>
                <span class="badge bg-dark text-success border border-success" style="font-size:10px; box-shadow: 0 0 5px rgba(25,135,84,0.3)">${count} CAPTURED</span>
            </div>
            <div class="card-body p-0">
                <table class="table table-dark table-hover mb-0" style="font-size:11px">
                    <tbody>
                        ${displayList.map(r => {
        const isSelected = r.tweetId === selectedId;
        return `
                            <tr class="tc-reply-row ${isSelected ? 'table-primary shadow-sm' : ''}" 
                                data-id="${r.tweetId}" 
                                style="cursor: pointer; transition: all 0.2s; ${isSelected ? 'background: rgba(13, 110, 253, 0.2) !important; border-left: 3px solid #0d6efd;' : ''}">
                                <td class="ps-3 py-2" style="width: 25%">
                                    <div class="fw-bold text-info text-truncate">${r.authorHandle}</div>
                                    <div style="font-size:9px; color: #8899A6">${fmtTime(new Date(r.createdAt).getTime())}</div>
                                    ${r.isByActiveAccount ? '<span class="badge bg-success text-white ms-1" style="font-size:8px; padding: 1px 4px; border-radius: 4px; vertical-align: middle">YOU</span>' : ''}
                                </td>
                                <td class="py-2">
                                    <div class="text-light-emphasis fw-medium" style="display: -webkit-box; -webkit-line-clamp: 2; -webkit-box-orient: vertical; overflow: hidden; line-height: 1.3">
                                        ${truncate(r.text, 100)}
                                    </div>
                                    <div class="mt-1 d-flex gap-2" style="font-size:9px; opacity:0.85">
                                        <span class="text-secondary">Like: ${r.likeCount ?? 0}</span>
                                        <span class="text-secondary">RT: ${r.repostCount ?? 0}</span>
                                        <span class="text-secondary">Reply: ${r.replyCount ?? 0}</span>
                                    </div>
                                </td>
                            </tr>
                        `;
    }).join('')}
                    </tbody>
                </table>
                ${count > 5 ? `<div class="text-center py-1 text-secondary small border-top bg-dark" style="font-size:9px; opacity: 0.6">Only showing first 5 replies.</div>` : ''}
            </div>
        </div>`;
}
// ─────────────────────────────────────────────
// Profile Tweets Snapshot 渲染 (NEW)
// ─────────────────────────────────────────────
function renderProfileTweetsSnapshot(tweets, scene, selectedId) {
    if (scene !== 'profile')
        return '';
    if (!tweets || tweets.length === 0) {
        return `
            <div class="card mb-3 border-secondary">
                <div class="card-header text-info fw-bold">PROFILE TWEETS SNAPSHOT</div>
                <div class="card-body py-3 text-center text-secondary italic" style="font-size:11px; opacity: 0.6">
                    No profile tweets captured yet. <br>
                    <small>Scroll the profile page to trigger extraction.</small>
                </div>
            </div>`;
    }
    const count = tweets.length;
    const displayList = tweets.slice(0, 5);
    return `
        <div class="card mb-3 border-success" style="border-width: 1px">
            <div class="card-header d-flex justify-content-between align-items-center" style="background: rgba(25, 135, 84, 0.05)">
                <span class="text-success fw-bold">PROFILE TWEETS SNAPSHOT</span>
                <span class="badge bg-dark text-success border border-success" style="font-size:10px">${count} CAPTURED</span>
            </div>
            <div class="card-body p-0">
                <table class="table table-dark table-hover mb-0" style="font-size:11px">
                    <tbody>
                        ${displayList.map(t => {
        const isSelected = t.tweetId === selectedId;
        return `
                            <tr class="tc-profile-tweet-row ${isSelected ? 'table-primary shadow-sm' : ''}" 
                                data-id="${t.tweetId}" 
                                style="cursor: pointer; transition: all 0.2s; ${isSelected ? 'background: rgba(13, 110, 253, 0.2) !important; border-left: 3px solid #0d6efd;' : ''}">
                                <td class="ps-3 py-2" style="width: 25%">
                                    <div class="fw-bold text-info text-truncate">${t.authorHandle}</div>
                                    <div style="font-size:9px; color: #8899A6">${t.createdAt ? fmtTime(new Date(t.createdAt).getTime()) : '—'}</div>
                                    ${t.isOwnedByActiveAccount ? '<span class="badge bg-warning text-dark ms-1" style="font-size:8px; padding: 1px 4px; border-radius: 4px; vertical-align: middle">OWNED</span>' : ''}
                                </td>
                                <td class="py-2">
                                    <div class="text-light-emphasis" style="display: -webkit-box; -webkit-line-clamp: 2; -webkit-box-orient: vertical; overflow: hidden; line-height: 1.3">
                                        ${truncate(t.text, 100)}
                                    </div>
                                    <div class="mt-1 d-flex gap-2" style="font-size:9px; opacity:0.85">
                                        <span class="text-secondary">Likes: ${nFmt(t.likeCount)}</span>
                                        <span class="text-secondary">RTs: ${nFmt(t.repostCount)}</span>
                                        <span class="text-secondary">Replies: ${nFmt(t.replyCount)}</span>
                                    </div>
                                </td>
                            </tr>
                        `;
    }).join('')}
                    </tbody>
                </table>
                <div class="card-footer py-1 d-flex justify-content-between align-items-center bg-dark" style="font-size:9px; opacity: 0.8">
                    <span class="text-secondary">${count > 5 ? 'Only showing first 5 tweets.' : ''}</span>
                    ${selectedId ? `<span class="text-info fw-bold">Selected: ${selectedId}</span>` : '<span class="text-muted">No tweet selected</span>'}
                </div>
            </div>
        </div>`;
}
// ─────────────────────────────────────────────
// Selected Reply Detail 渲染 (NEW)
// ─────────────────────────────────────────────
function renderSelectedReplyCard(replies, scene) {
    if (scene !== 'tweet_detail' || selectedTabId === null)
        return '';
    const selectedId = selectedReplyIds.get(selectedTabId);
    if (!selectedId)
        return '';
    const selectedReply = (replies || []).find(r => r.tweetId === selectedId);
    if (!selectedReply)
        return '';
    return `
        <div class="card mb-3 border-primary" style="border-width: 1px">
            <div class="card-header d-flex justify-content-between align-items-center" style="background: rgba(13, 110, 253, 0.05)">
                <span class="text-primary fw-bold">SELECTED REPLY DETAIL</span>
                <span class="badge bg-dark text-primary border border-primary" style="font-size:10px">READ ONLY</span>
            </div>
            <div class="card-body py-2">
                <div class="row">
                    <div class="col-8 border-right">
                        <div class="sys-stat"><span>Reply ID</span><span class="val text-warning">${selectedReply.tweetId}</span></div>
                        <div class="sys-stat"><span>Author</span><span class="val text-info">${selectedReply.authorHandle || '—'} ${selectedReply.authorName ? `<small class="text-muted">(${selectedReply.authorName})</small>` : ''}</span></div>
                        <div class="sys-stat"><span>Author ID</span><span class="val" style="font-size:10px; opacity:0.7">${selectedReply.authorId || '—'}</span></div>
                        <div class="sys-stat"><span>Created At</span><span class="val" style="font-size:10px">${selectedReply.createdAt || '—'}</span></div>
                        <div class="sys-stat"><span>Ownership</span><span class="val ${selectedReply.isByActiveAccount ? 'text-success' : 'text-muted'}">${selectedReply.isByActiveAccount ? 'YOU' : 'OTHERS'}</span></div>
                        <div class="mt-2" style="font-size:10px; color:#cbd5e0; text-transform:uppercase; font-weight:700">Content Snapshot</div>
                        <div class="p-2 mt-1 bg-dark rounded text-light" style="font-size:11px; max-height: 80px; overflow-y: auto;">
                            ${selectedReply.text || '<span class="text-muted italic">No content captured.</span>'}
                        </div>
                    </div>
                    <div class="col-4">
                        <div class="mt-1" style="font-size:10px; color:#cbd5e0; text-transform:uppercase; font-weight:700">Metrics</div>
                        <div class="sys-stat mt-2"><span>Like</span><span class="val">${selectedReply.likeCount ?? '—'}</span></div>
                        <div class="sys-stat"><span>Reply</span><span class="val">${selectedReply.replyCount ?? '—'}</span></div>
                        <div class="sys-stat"><span>Repost</span><span class="val">${selectedReply.repostCount ?? '—'}</span></div>
                    </div>
                </div>
            </div>
        </div>`;
}
// ─────────────────────────────────────────────
// Selected Profile Tweet Detail 渲染 (NEW)
// ─────────────────────────────────────────────
function renderSelectedProfileTweetCard(tweets, scene) {
    if (scene !== 'profile' || selectedTabId === null)
        return '';
    const selectedId = selectedProfileTweetIds.get(selectedTabId);
    if (!selectedId)
        return '';
    const selectedTweet = (tweets || []).find(t => t.tweetId === selectedId);
    if (!selectedTweet)
        return '';
    return `
        <div class="card mb-3 border-primary" style="border-width: 1px">
            <div class="card-header d-flex justify-content-between align-items-center" style="background: rgba(13, 110, 253, 0.05)">
                <span class="text-primary fw-bold">SELECTED PROFILE TWEET DETAIL</span>
                <span class="badge bg-dark text-primary border border-primary" style="font-size:10px">READ ONLY</span>
            </div>
            <div class="card-body py-2">
                <div class="row">
                    <div class="col-8 border-right">
                        <div class="sys-stat"><span>Tweet ID</span><span class="val text-warning">${selectedTweet.tweetId}</span></div>
                        <div class="sys-stat"><span>Author</span><span class="val text-info">${selectedTweet.authorHandle || '—'} ${selectedTweet.authorName ? `<small class="text-muted">(${selectedTweet.authorName})</small>` : ''}</span></div>
                        <div class="sys-stat"><span>Created At</span><span class="val" style="font-size:10px">${selectedTweet.createdAt || '—'}</span></div>
                        <div class="sys-stat"><span>Ownership</span><span class="val ${selectedTweet.isOwnedByActiveAccount ? 'text-success' : 'text-muted'}">${selectedTweet.isOwnedByActiveAccount ? 'OWNED' : 'OTHERS'}</span></div>
                        <div class="mt-2" style="font-size:10px; color:#cbd5e0; text-transform:uppercase; font-weight:700">Content Snapshot</div>
                        <div class="p-2 mt-1 bg-dark rounded text-light" style="font-size:11px; max-height: 80px; overflow-y: auto;">
                            ${selectedTweet.text || '<span class="text-muted italic">No content captured.</span>'}
                        </div>
                    </div>
                    <div class="col-4">
                        <div class="mt-1" style="font-size:10px; color:#cbd5e0; text-transform:uppercase; font-weight:700">Metrics</div>
                        <div class="sys-stat mt-2"><span>Like</span><span class="val">${nFmt(selectedTweet.likeCount)}</span></div>
                        <div class="sys-stat"><span>Reply</span><span class="val">${nFmt(selectedTweet.replyCount)}</span></div>
                        <div class="sys-stat"><span>Repost</span><span class="val">${nFmt(selectedTweet.repostCount)}</span></div>
                    </div>
                </div>
            </div>
        </div>`;
}
/**
 * Candidate Intent / Execution Candidate Card for Selected Profile Tweet
 * (Read-only, informs the operator this tweet is a candidate for future actions)
 */
function renderProfileTweetCandidateIntentCard(tweets, scene) {
    if (scene !== 'profile' || selectedTabId === null)
        return '';
    const selectedId = selectedProfileTweetIds.get(selectedTabId);
    if (!selectedId)
        return '';
    const selectedTweet = (tweets || []).find(t => t.tweetId === selectedId);
    if (!selectedTweet)
        return '';
    return `
        <div class="mb-3 p-2 border-start border-3" style="background: rgba(45,55,72,0.2); border-color: #4a5568; border-radius: 0 4px 4px 0">
            <div class="d-flex justify-content-between align-items-center">
                <div style="font-size: 11px;">
                    <span class="text-muted fw-bold">Candidate Type:</span>
                    <span class="ms-1 fw-bold text-white">PROFILE TWEET</span>
                    <span class="ms-1 text-info" style="font-size: 10px">@${(selectedTweet.authorHandle || '').replace('@', '')}</span>
                </div>
                <span class="badge bg-dark text-muted border border-secondary" style="font-size:8px">READ ONLY CANDIDATE</span>
            </div>
            <div class="mt-1 d-flex justify-content-between align-items-center">
                <span class="font-monospace text-warning" style="font-size: 10px; opacity: 0.9">${selectedTweet.tweetId}</span>
                <span class="text-muted" style="font-size: 9px; font-style: italic">Not yet bound to action target</span>
            </div>
            <div class="mt-1" style="font-size: 9px; color: #a0aec0">
                Ownership: ${selectedTweet.isOwnedByActiveAccount ? 'OWNED' : 'OTHERS'}
            </div>
        </div>`;
}
// ─────────────────────────────────────────────
// Execution Intent 渲染 (NEW)
// ─────────────────────────────────────────────
function renderExecutionIntent(tid, pageContext, currentInputValue) {
    const { targetType, targetId, authorHandle } = getCurrentReplyIntent(tid, pageContext, currentInputValue);
    let sourceLabel = 'NONE';
    let badgeClass = 'bg-secondary';
    let borderColor = '#cbd5e0';
    if (targetType === 'manual target') {
        sourceLabel = 'MANUAL OVERRIDE';
        badgeClass = 'bg-warning text-dark';
        borderColor = '#ffc107';
    }
    else if (targetType === 'selected reply') {
        sourceLabel = 'AUTO: SELECTED REPLY';
        badgeClass = 'bg-primary';
        borderColor = '#0d6efd';
    }
    else if (targetType === 'current tweet') {
        sourceLabel = 'AUTO: CURRENT ENTITY';
        badgeClass = 'bg-success';
        borderColor = '#198754';
    }
    if (targetType === 'NONE') {
        return `
            <div class="mb-2 p-2 border-start border-3" style="background: rgba(45,55,72,0.2); border-color: #4a5568; border-radius: 0 4px 4px 0">
                <div class="d-flex justify-content-between align-items-center">
                    <div style="font-size: 11px;">
                        <span class="text-muted fw-bold">INTENT:</span>
                        <span class="ms-1 text-muted italic">NO TARGET</span>
                    </div>
                    <span class="badge bg-dark text-muted border border-secondary" style="font-size:8px">NONE</span>
                </div>
            </div>`;
    }
    return `
        <div class="mb-2 p-2 border-start border-3" style="background: rgba(45,55,72,0.2); border-color: ${borderColor}; border-radius: 0 4px 4px 0">
            <div class="d-flex justify-content-between align-items-center">
                <div style="font-size: 11px;">
                    <span class="text-muted fw-bold">INTENT:</span>
                    <span class="ms-1 fw-bold text-white">${targetType.toUpperCase()}</span>
                    ${authorHandle ? `<span class="ms-1 text-info" style="font-size: 10px">@${authorHandle.replace('@', '')}</span>` : ''}
                </div>
                <span class="badge ${badgeClass}" style="font-size:8px; font-weight: normal">${sourceLabel}</span>
            </div>
            <div class="mt-1 font-monospace text-warning" style="font-size: 10px; opacity: 0.9">${targetId || 'EMPTY'}</div>
        </div>`;
}
// ─────────────────────────────────────────────
// Reply Draft UI 渲染 (NEW)
// ─────────────────────────────────────────────
function renderReplyDraftUI(tid, pageContext, currentInputValue, isLoggedOut) {
    const { targetType, targetId, authorHandle } = getCurrentReplyIntent(tid, pageContext, currentInputValue);
    if (targetType === 'NONE')
        return '';
    const hasTarget = !!targetId;
    const hasText = !!replyDraftText.trim();
    let currentState = APPROVAL_STATE.DRAFT_EMPTY;
    if (isLoggedOut) {
        currentState = APPROVAL_STATE.LOCKED_LOGGED_OUT;
    }
    else if (!hasText) {
        currentState = APPROVAL_STATE.DRAFT_EMPTY;
    }
    else if (!hasTarget) {
        currentState = APPROVAL_STATE.DRAFT_NOT_READY;
    }
    else {
        currentState = APPROVAL_STATE.READY_FOR_REVIEW;
    }
    let statusHtml = '';
    let statusLabel = '';
    let statusColor = 'text-muted';
    let showReviewBtn = false;
    let reviewConfirmedHtml = '';
    switch (currentState) {
        case APPROVAL_STATE.LOCKED_LOGGED_OUT:
            statusLabel = 'LOCKED (LOGGED OUT)';
            statusColor = 'text-danger';
            statusHtml = '<span class="text-danger" style="font-size:10px">Please log in to X to continue.</span>';
            break;
        case APPROVAL_STATE.DRAFT_EMPTY:
            statusLabel = 'DRAFT EMPTY';
            statusHtml = '<span class="text-muted" style="font-size:10px">Waiting for draft content...</span>';
            break;
        case APPROVAL_STATE.DRAFT_NOT_READY:
            statusLabel = 'DRAFT NOT READY';
            statusColor = 'text-warning';
            statusHtml = '<span class="text-warning" style="font-size:10px">Has draft but no valid target detected.</span>';
            break;
        case APPROVAL_STATE.READY_FOR_REVIEW:
            statusLabel = 'READY FOR HUMAN REVIEW';
            statusColor = 'text-info';
            statusHtml = '<span class="text-info" style="font-size:10px">Content and target are ready for review.</span>';
            showReviewBtn = true;
            if (isReviewConfirmed) {
                reviewConfirmedHtml = `
                <div class="mt-2 text-center p-2 rounded" style="background: rgba(25, 135, 84, 0.2); border: 1px solid rgba(25, 135, 84, 0.4)">
                    <span class="text-success fw-bold" style="font-size:11px">READY: REVIEW CONFIRMED (STILL NOT SENT)</span>
                </div>`;
            }
            break;
    }
    return `
        <div id="reply-intent-preview-container">
            <div class="mt-4">
                <div style="font-size:10px; color:#cbd5e0; text-transform:uppercase; font-weight:700; margin-bottom:6px">Reply Draft</div>
                <textarea id="reply-draft-text" class="form-control form-control-sm bg-black text-light border-secondary" rows="2" placeholder="Write your reply draft here..." style="font-size:11px;">${replyDraftText}</textarea>
            </div>
            
            <div class="mt-3 p-2" style="background: rgba(0,0,0,0.2); border: 1px solid #2d3748; border-radius: 6px;">
                <div class="d-flex justify-content-between align-items-center mb-2">
                    <div style="font-size:10px; color:#cbd5e0; text-transform:uppercase; font-weight:700">Reply Intent Preview</div>
                    <span class="badge bg-dark border ${statusColor.replace('text-', 'border-')}" style="font-size:8px; ${statusColor.replace('text-', 'color:')}">${statusLabel}</span>
                </div>
                <div class="sys-stat"><span>Target</span><span class="val text-info" style="font-size:10px">${targetType.toUpperCase()} ${authorHandle ? `(@${authorHandle.replace('@', '')})` : ''}</span></div>
                <div class="sys-stat"><span>ID</span><span class="val text-warning" style="font-size:10px">${targetId || '—'}</span></div>
                <div class="sys-stat"><span>Draft</span><span class="val text-truncate" style="max-width: 150px; font-size:10px">${replyDraftText || '—'}</span></div>
                <div class="mt-1 text-center">
                    ${statusHtml}
                </div>
                ${reviewConfirmedHtml}
                ${showReviewBtn && !isReviewConfirmed ? `
                <div class="mt-2 pt-2 border-top border-secondary">
                    <button id="btn-review-only" class="btn btn-info btn-sm w-100 py-1" style="font-size:11px; font-weight:bold">Review Only (Local Confirmation)</button>
                </div>` : ''}
            </div>
        </div>
    `;
}
// ─────────────────────────────────────────────
// E 区：Session / Identity 渲染
// 有 account → 展示正式身份
// 无 account 但有 featuredTweet → 展示"已观察到的推文作者"作为参考
// 都没有 → 提示用户操作
// ─────────────────────────────────────────────
function renderIdentityPanel(account, featuredTweet, dataId, scene) {
    if (account) {
        return `
            <div class="sys-stat"><span>Handle</span><span class="val text-info">${account.handle}</span></div>
            <div class="sys-stat"><span>User ID</span><span class="val" style="font-size:11px">${account.userId}</span></div>
            <div class="sys-stat"><span>Display Name</span><span class="val">${account.displayName || '—'}</span></div>
            <div class="sys-stat"><span>Verified</span>${badge(!!account.verified, 'YES', 'NO')}</div>`;
    }
    if (scene === 'identity_resolving') {
        return `
            <div class="text-info small mb-2 d-flex align-items-center" style="font-size:11px">
                <div class="spinner-border spinner-border-sm me-2" role="status" style="width:10px; height:10px"></div>
                Resolving identity...<br>
            </div>
            <div class="text-muted" style="font-size:10px">
                Waiting for <code>Viewer</code> capture. <br>
                <span class="text-warning">Scroll the page or try refreshing if stuck.</span>
            </div>`;
    }
    // 保底显示：如果我们有 UID（来自 Cookie），即使没拿到 Handle 也展示它
    const uidHtml = account?.userId ? `<div class="sys-stat"><span>Verified UID</span><span class="val text-success">${account.userId}</span></div>` : '';
    // 没有身份 → 先给提示，再展示推文作者参考
    const hint = `
        <div class="text-warning small mb-2" style="font-size:11px">
            ⚠ Identity not fully captured.<br>
            <span class="text-muted">Need <code>Viewer</code> or <code>settings.json</code> intercept.</span>
        </div>
        ${uidHtml}
        <div class="mt-2 text-center"><button class="btn btn-dark btn-sm" style="font-size:9px" onclick="location.reload()">REFRESH DEBUG PANEL</button></div>`;
    if (!featuredTweet)
        return hint;
    // 有推文但无身份：展示"已观察到的推文作者"
    return hint + `
        <hr class="border-secondary my-2">
        <div style="font-size:10px;color:#8899A6;margin-bottom:6px">OBSERVED TWEET AUTHOR (reference)</div>
        <div class="sys-stat"><span>Author Handle</span><span class="val text-secondary">${featuredTweet.authorHandle || '—'}</span></div>
        <div class="sys-stat"><span>Author Name</span><span class="val text-secondary">${featuredTweet.authorName || '—'}</span></div>
        <div class="sys-stat"><span>Author ID</span><span class="val text-secondary" style="font-size:10px">${featuredTweet.authorId || '—'}</span></div>`;
}
// ─────────────────────────────────────────────
// 主渲染：A/B/C/D/E/F 六区
// ─────────────────────────────────────────────
function renderDetailView(data, pageContext) {
    const container = document.getElementById('tab-data-view');
    if (!container)
        return;
    const hits = (data.apiHits || []);
    const hookSt = data.hookStatus || { fetch: false, xhr: false };
    const stats = data.stats || {};
    const allOps = (data.allWatchedOps || []);
    const account = data.account || null;
    const mainTweet = data.featuredTweet || null;
    const lastHit = hits.length > 0 ? hits[0].timestamp : null;
    const tabMeta = tabList.find(t => t.id === selectedTabId) || {};
    const isXPage = /^https?:\/\/(twitter\.com|x\.com)/.test(tabMeta.url || '');
    // 保存 hits 供 Modal 引用
    currentHits = hits;
    // ── D 区：卡片渲染（无嵌套滚动，Details 按钮弹 Modal）
    function renderHitCard(h, i) {
        let apiPath = '—';
        try {
            apiPath = h.apiUrl ? new URL(h.apiUrl).pathname.split('/').slice(-2).join('/') : '—';
        }
        catch {
            apiPath = h.op;
        }
        const paramSummary = reqSummary(h.requestBody);
        const isId = ['AuthenticatedUserQuery', 'Viewer', 'AccountSettings', 'settings.json', 'VerifyCredentials'].includes(h.op);
        return `
        <div class="hit-card ${isId ? 'hit-card-id' : ''}">
            <div class="hit-card-top">
                <span class="method">${h.method || 'GET'}</span>
                <span class="hit-card-op" title="${h.op}">${h.op}</span>
                ${isId ? '<span class="badge bg-warning text-dark" style="font-size:9px">IDENTITY</span>' : ''}
                <span class="hit-time ms-auto">${new Date(h.timestamp).toLocaleTimeString()}</span>
            </div>
            <div class="hit-card-path" title="${h.apiUrl || ''}">${apiPath}</div>
            <div class="hit-card-params">${paramSummary !== '—' ? paramSummary : '<span class="text-muted">no params</span>'}</div>
            <div class="hit-card-footer">
                <span class="text-success" style="font-size:10px">● 200</span>
                <button class="btn-hit-detail" data-hit-index="${i}">Details ›</button>
            </div>
        </div>`;
    }
    const isLoggedOut = pageContext?.scene === 'login_required';
    const hasTarget = !!mainTweet?.id;
    const canWrite = !isLoggedOut && (pageContext?.scene !== 'identity_resolving');
    // ── Target ID Binding Logic ──
    const tid = selectedTabId;
    const curEntityId = pageContext.currentEntity?.entityId || '';
    const isTweetDetail = pageContext.scene === 'tweet_detail';
    let isManual = manualOverrides.get(tid) || false;
    let lastFilled = lastFilledIds.get(tid) || '';
    let selectedReplyId = selectedReplyIds.get(tid) || null;
    // Auto-fill trigger: switched to a different tweet detail
    if (isTweetDetail && curEntityId && curEntityId !== lastFilled) {
        isManual = false;
        lastFilled = curEntityId;
        selectedReplyId = null; // Clear reply selection when switching main tweet
        manualOverrides.set(tid, false);
        lastFilledIds.set(tid, curEntityId);
        selectedReplyIds.set(tid, null);
    }
    // Auto-clear trigger: leaving tweet_detail when it was previously auto-filled
    if (!isTweetDetail && !isManual && lastFilled !== '') {
        lastFilled = '';
        lastFilledIds.set(tid, '');
        selectedReplyIds.set(tid, null);
    }
    // Selection of Profile Tweet clearing
    if (pageContext.scene !== 'profile' && selectedProfileTweetIds.get(tid)) {
        selectedProfileTweetIds.set(tid, null);
    }
    // Determine value to show in input
    const existingInput = document.getElementById('manual-target-id');
    let displayTargetId = '';
    let sourceLabelHtml = '';
    if (isManual) {
        displayTargetId = existingInput ? existingInput.value : '';
        sourceLabelHtml = `<span class="badge bg-warning-subtle text-warning border border-warning ms-2" style="font-size:9px; font-weight:normal">MANUAL OVERRIDE</span>`;
    }
    else if (isTweetDetail && selectedReplyId) {
        displayTargetId = selectedReplyId;
        sourceLabelHtml = `<span class="badge bg-primary text-white border border-primary ms-2" style="font-size:9px; font-weight:normal">AUTO: SELECTED REPLY</span>`;
    }
    else if (isTweetDetail && lastFilled) {
        displayTargetId = lastFilled;
        sourceLabelHtml = `<span class="badge bg-success-subtle text-success border border-success ms-2" style="font-size:9px; font-weight:normal">AUTO: CURRENT ENTITY</span>`;
    }
    container.innerHTML = `
<!-- ═══ ROW 0: Scene & Entity Card (NEW) ═══ -->
<div class="row mb-1">
    <div class="col-12">
        ${renderSceneCard(pageContext)}
        ${renderMismatchWarning(tid, pageContext)}
        ${renderEntityCard(pageContext.currentEntity, pageContext.scene)}
        ${renderProfileTweetsSnapshot(pageContext.profileTweetsSnapshot || [], pageContext.scene, selectedProfileTweetIds.get(tid) || null)}
        ${renderSelectedProfileTweetCard(pageContext.profileTweetsSnapshot || [], pageContext.scene)}
        ${renderProfileTweetCandidateIntentCard(pageContext.profileTweetsSnapshot || [], pageContext.scene)}
        ${renderRepliesSnapshot(pageContext.repliesSnapshot || [], pageContext.scene)}
        ${renderSelectedReplyCard(pageContext.repliesSnapshot || [], pageContext.scene)}
    </div>
</div>

<!-- ═══ ROW 1: Tab Info · Hook Status ═══ -->

<!-- ═══ ROW 1: Tab Info · Hook Status ═══ -->
<div class="row mb-3">
    <div class="col-6">
        <div class="card h-100">
            <div class="card-header text-info">A · Current Tab</div>
            <div class="card-body py-2">
                <div class="sys-stat"><span class="text-muted">Tab ID</span><span class="val">${data.id ?? '—'}</span></div>
                <div class="sys-stat"><span class="text-muted">Active</span>${badge(!!tabMeta.active, 'YES', 'NO')}</div>
                <div class="sys-stat"><span class="text-muted">X / Twitter</span>${badge(isXPage, 'YES', 'NO')}</div>
                <div class="sys-stat"><span class="text-muted">Last Op</span><span class="val text-warning" style="font-size:11px">${data.lastOp || '—'}</span></div>
                <div class="mt-2" style="font-size:10px;color:#cbd5e0">URL</div>
                <div class="text-light text-truncate" style="font-size:10px">${tabMeta.url || data.url || '—'}</div>
                <div class="mt-2" style="font-size:10px;color:#cbd5e0">NAVIGATE TAB</div>
                <div class="d-flex gap-1 mt-1">
                    <input type="text" id="nav-url-input" class="form-control form-control-sm bg-dark text-light border-secondary" placeholder="https://x.com/..." style="font-size:10px;" value="${navUrlDrafts.get(tid) || tabMeta.url || data.url || ''}">
                    <button class="btn btn-outline-info btn-xs btn-tab-navigate" data-id="${data.id}" style="font-size:10px; padding: 2px 8px;">GO</button>
                </div>
                <div class="mt-2" style="font-size:10px;color:#cbd5e0">OPEN TWEET (Semantic)</div>
                <div class="d-flex gap-1 mt-1">
                    <input type="text" id="open-tweet-screen-name" class="form-control form-control-sm bg-dark text-light border-secondary" placeholder="screenName" style="font-size:10px; flex: 1;" value="${openTweetScreenNameDrafts.get(tid) || ''}">
                    <input type="text" id="open-tweet-id" class="form-control form-control-sm bg-dark text-light border-secondary" placeholder="tweetId" style="font-size:10px; flex: 2;" value="${openTweetIdDrafts.get(tid) || ''}">
                    <button class="btn btn-outline-info btn-xs btn-tab-open-tweet" data-id="${data.id}" style="font-size:10px; padding: 2px 8px;">OPEN</button>
                </div>
            </div>
        </div>
    </div>
    <div class="col-6">
        <div class="card h-100">
            <div class="card-header text-warning">B · Inject &amp; Hook Status</div>
            <div class="card-body py-2">
                <div class="sys-stat"><span class="text-muted">Inject Active</span>${badge(hookSt.fetch || hookSt.xhr, 'YES', 'UNKNOWN')}</div>
                <div class="sys-stat"><span class="text-muted">Fetch Hook</span>${badge(hookSt.fetch)}</div>
                <div class="sys-stat"><span class="text-muted">XHR Hook</span>${badge(hookSt.xhr)}</div>
                <div class="sys-stat"><span class="text-muted">Last API Hit</span><span class="val">${fmtTime(lastHit)}</span></div>
                <div class="sys-stat"><span class="text-muted">Last BG Sync</span><span class="val">${fmtTime(data.lastBgSync)}</span></div>
                <div class="sys-stat"><span class="text-muted">Anomaly</span><span class="val text-success">None</span></div>
            </div>
        </div>
    </div>
</div>

<!-- ═══ ROW 2: Identity · Write Env ═══ -->
<div class="row mb-3">
    <div class="col-6">
        <div class="card h-100">
            <div class="card-header text-success">E · Session / Identity</div>
            <div class="card-body py-2">
                ${renderIdentityPanel(account, mainTweet, data.id, pageContext?.scene)}
            </div>
        </div>
    </div>
    <div class="col-6">
        <div class="card h-100 ${isLoggedOut ? 'border-danger opacity-75' : ''}">
            <div class="card-header text-danger d-flex justify-content-between">
                <span>F · Write Execution Env</span>
                ${isLoggedOut ? '<span class="badge bg-danger">LOGGED OUT</span>' : ''}
            </div>
            <div class="card-body py-2">
                <div class="sys-stat"><span class="text-muted">Write Env</span><span class="val ${isLoggedOut ? 'text-danger' : 'text-success'}">${isLoggedOut ? 'LOCKED' : 'Content Script ✓'}</span></div>
                <div class="sys-stat"><span class="text-muted">Content Bridge</span>${badge(!isLoggedOut && bridgeOnline, 'ONLINE', 'OFFLINE')}</div>
                <div class="sys-stat"><span class="text-muted">Inject Writes</span><span class="val ${isLoggedOut ? 'text-muted' : 'text-success'}">${isLoggedOut ? 'Disabled' : 'None ✓'}</span></div>
                <div class="sys-stat"><span class="text-muted">Anomaly</span>
                    <span class="val ${isLoggedOut ? 'text-warning' : (bridgeOnline ? 'text-success' : 'text-danger')}">${isLoggedOut ? 'Session Invalid' : (bridgeOnline ? 'None' : '⚠ Bridge offline')}</span>
                </div>
                ${!isLoggedOut && mainTweet ? `
                <hr class="my-2 border-secondary">
                <div style="color:#8899A6;font-size:10px;margin-bottom:6px">LAST CAPTURED CONTENT</div>
                <div class="text-muted mb-1" style="font-size:10px">
                    <strong class="text-light">${mainTweet.authorName || ''}</strong>
                    <span> @${mainTweet.authorHandle?.replace('@', '') || ''}</span>
                    <br><span style="opacity:.6">Tweet ID: ${mainTweet.id}  |  User ID: ${mainTweet.authorId || ''}</span>
                </div>` : (isLoggedOut ? '' : (pageContext?.scene === 'identity_resolving' ? '<div class="text-info small mt-2">Waiting for identity...</div>' : '<div class="text-muted small mt-2">No tweet captured yet.</div>'))}
                
                <hr class="my-3 border-secondary">
                ${renderExecutionIntent(data.id, pageContext, displayTargetId)}
                <div style="color:#cbd5e0;font-size:10px;margin-bottom:6px">
                    EXECUTE ACTION (Target ID)
                </div>
                <div class="d-flex gap-2 align-items-center mb-2">
                    <input type="text" id="manual-target-id" class="form-control form-control-sm bg-dark text-light border-secondary" placeholder="Enter target Tweet ID or User ID..." style="font-size:11px;" value="${displayTargetId}" ${!canWrite ? 'disabled' : ''}>
                </div>
                <div class="d-flex gap-1 flex-wrap">
                    <button class="btn btn-outline-primary btn-manual-action btn-sm" data-tabid="${data.id}" data-action="like" ${!canWrite ? 'disabled' : ''}>LIKE</button>
                    <button class="btn btn-outline-success btn-manual-action btn-sm" data-tabid="${data.id}" data-action="retweet" ${!canWrite ? 'disabled' : ''}>RT</button>
                    <button class="btn btn-outline-warning btn-manual-action btn-sm" data-tabid="${data.id}" data-action="bookmark" ${!canWrite ? 'disabled' : ''}>SAVE</button>
                    <button class="btn btn-outline-info btn-manual-action btn-sm" data-tabid="${data.id}" data-action="follow" ${!canWrite ? 'disabled' : ''}>FOLLOW</button>
                    <button class="btn btn-outline-secondary btn-manual-action btn-sm" data-tabid="${data.id}" data-action="unfollow" ${!canWrite ? 'disabled' : ''}>UNFOLLOW</button>
                </div>
                ${renderReplyDraftUI(data.id, pageContext, displayTargetId, isLoggedOut)}
                ${isLoggedOut ? '<div class="mt-2 text-danger" style="font-size:10px">⚠ Actions locked until X session is restored.</div>' : (!hasTarget && !isLoggedOut ? '<div class="mt-1 text-muted" style="font-size:9px">Pick a tweet on X to enable actions.</div>' : '')}
            </div>
        </div>
    </div>
</div>

<!-- ═══ ROW 3: API Hit Matrix ═══ -->
<div class="row mb-3">
    <div class="col-12">
        <div class="card">
            <div class="card-header text-primary">C · Watched API Hit Matrix (${allOps.length} ops)</div>
            <div style="overflow:auto">
                <table class="table table-dark table-hover mb-0" style="font-size:11px">
                    <thead><tr>
                        <th class="ps-3">Operation</th>
                        <th>Status</th>
                        <th>Hits</th>
                        <th>Last Hit</th>
                        <th>Cache</th>
                        <th class="pe-3">Request Summary</th>
                    </tr></thead>
                    <tbody>
                    ${allOps.map(op => {
        const s = stats[op];
        const cached = !!data.data?.[op];
        const lastHitRow = hits.find((h) => h.op === op);
        return `<tr>
                            <td class="ps-3 fw-bold">${op}</td>
                            <td>${s ? '<span class="text-success">● HIT</span>' : '<span class="text-muted">○ —</span>'}</td>
                            <td>${s?.count || 0}</td>
                            <td>${s ? fmtTime(s.lastHit) : '—'}</td>
                            <td>${cached ? '<span class="text-info">✓</span>' : '<span class="text-muted">—</span>'}</td>
                            <td class="pe-3 text-muted" style="font-size:10px;max-width:220px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap">
                                ${lastHitRow ? reqSummary(lastHitRow.requestBody) : '—'}
                            </td>
                        </tr>`;
    }).join('')}
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<!-- ═══ ROW 4: Raw Intercept Grid ═══ -->
<div class="row">
    <div class="col-12">
        <div class="card">
            <div class="card-header text-secondary d-flex align-items-center">
                <span>D · Raw Intercept Stream</span>
                <span class="badge bg-secondary ms-2">${hits.length}</span>
                <span style="font-size:10px;color:#cbd5e0;margin-left:8px">Click Details to inspect</span>
            </div>
            <div class="p-3">
                ${hits.length === 0
        ? `<div class="text-muted small">No intercepts yet — open or scroll x.com to trigger.</div>`
        : `<div class="hit-grid">${hits.map((h, i) => renderHitCard(h, i)).join('')}</div>`}
            </div>
        </div>
    </div>
</div>`;
}
// ─────────────────────────────────────────────
// 写操作执行与 Toast 遮罩
// ─────────────────────────────────────────────
function showToast(message, isError = false, autoCloseTime = 0) {
    let t = document.getElementById('tc-toast');
    if (!t) {
        t = document.createElement('div');
        t.id = 'tc-toast';
        document.body.appendChild(t);
    }
    t.innerHTML = `
    <div style="position:fixed;inset:0;background:rgba(0,0,0,.6);z-index:10000;display:flex;align-items:center;justify-content:center;backdrop-filter:blur(2px)">
        <div style="background:#1a202c;border:2px solid ${isError ? '#f56565' : '#4ade80'};border-radius:12px;padding:24px 40px;text-align:center;box-shadow:0 10px 30px rgba(0,0,0,.5)">
            <h4 style="color:${isError ? '#f56565' : '#4ade80'};margin:0;">${message}</h4>
        </div>
    </div>`;
    if (autoCloseTime > 0) {
        setTimeout(() => { if (t)
            t.remove(); }, autoCloseTime);
    }
}
async function doAction(tabId, targetId, action, btn) {
    btn.disabled = true;
    const orig = btn.innerText;
    btn.innerText = '…';
    showToast(`EXECUTING: ${action.toUpperCase()}...`, false);
    // 因为 Follow 往往需要 userId，在此我们默认使用 targetId
    // 如果用户填错了类型或者输入框为空，会在底层抛出错误。
    const resp = await sendMsg({ type: 'EXEC_PROXY_ACTION', tabId, tweetId: targetId, userId: targetId, action });
    btn.disabled = false;
    btn.innerText = orig;
    if (resp?.ok) {
        showToast(`✅ ${action.toUpperCase()} SUCCESS!`, false, 2000);
    }
    else {
        showToast(`❌ ${action.toUpperCase()} FAILED\n\n<span style="font-size:12px;color:#cbd5e0;display:block;margin-top:10px">${resp?.error?.message || 'Unknown error'}</span>`, true, 4000);
        console.error('[TweetClaw-Debug] Action failed:', resp);
    }
}
// ─────────────────────────────────────────────
// 初始化
// ─────────────────────────────────────────────
setupDelegation();
refreshData();
console.log('[TweetClaw-Debug] v5.4 loaded.');

})();

/******/ })()
;
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoianMvZGVidWcuanMiLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7O0FBQU87QUFDUDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNPO0FBQ1A7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7Ozs7Ozs7Ozs7Ozs7OztBQy9CQTtBQUNBO0FBQ0E7QUFDTztBQUNQO0FBQ0EsaUJBQWlCO0FBQ2pCO0FBQ0EsaUJBQWlCO0FBQ2pCO0FBQ0EsaUJBQWlCO0FBQ2pCO0FBQ0E7QUFDQSxpQkFBaUI7QUFDakI7QUFDQSxhQUFhO0FBQ2I7QUFDTztBQUNQO0FBQ0EsNEJBQTRCLGNBQWMsVUFBVSxRQUFRO0FBQzVEOzs7Ozs7O1VDbkJBO1VBQ0E7O1VBRUE7VUFDQTtVQUNBO1VBQ0E7VUFDQTtVQUNBO1VBQ0E7VUFDQTtVQUNBO1VBQ0E7VUFDQTtVQUNBO1VBQ0E7O1VBRUE7VUFDQTtVQUNBO1VBQ0E7VUFDQTtVQUNBO1VBQ0E7VUFDQTs7VUFFQTtVQUNBO1VBQ0E7Ozs7O1dDNUJBO1dBQ0E7V0FDQTtXQUNBO1dBQ0EseUNBQXlDLHdDQUF3QztXQUNqRjtXQUNBO1dBQ0EsRTs7Ozs7V0NQQSx3Rjs7Ozs7V0NBQTtXQUNBO1dBQ0E7V0FDQSx1REFBdUQsaUJBQWlCO1dBQ3hFO1dBQ0EsZ0RBQWdELGFBQWE7V0FDN0QsRTs7Ozs7Ozs7Ozs7OztBQ05BO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ3VEO0FBQ2dDO0FBQ3ZGO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0Esc0JBQXNCO0FBQ3RCO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLGFBQWE7QUFDYjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLGdEQUFnRCxXQUFXO0FBQzNEO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLHdDQUF3QyxTQUFTO0FBQ2pEO0FBQ0E7QUFDQTtBQUNBLGtEQUFrRDtBQUNsRDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSw2REFBNkQsbUJBQW1CO0FBQ2hGLG9FQUFvRSxxQkFBcUIsS0FBSztBQUM5RiwyREFBMkQsUUFBUSxpQkFBaUIsd0JBQXdCLDZCQUE2QixRQUFRLElBQUksUUFBUTtBQUM3Siw0REFBNEQscUJBQXFCLDJDQUEyQztBQUM1SCwrREFBK0QsWUFBWSxjQUFjLGVBQWUsZUFBZTtBQUN2SDtBQUNBO0FBQ0EsK0RBQStELFVBQVU7QUFDekUsb0NBQW9DLGdCQUFnQjtBQUNwRDtBQUNBLG1FQUFtRSxxQkFBcUIsSUFBSSxRQUFRO0FBQ3BHO0FBQ0Esb0NBQW9DLGdCQUFnQjtBQUNwRDtBQUNBLG1FQUFtRSxxQkFBcUIsSUFBSSxpQkFBaUI7QUFDN0c7QUFDQTtBQUNBLGNBQWM7QUFDZCxjQUFjO0FBQ2QsY0FBYztBQUNkO0FBQ0E7QUFDQSw0Q0FBNEMsUUFBUTtBQUNwRDtBQUNBO0FBQ0E7QUFDQSw0Q0FBNEMsU0FBUztBQUNyRDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLHNCQUFzQixpQ0FBaUM7QUFDdkQ7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EscUNBQXFDLElBQUk7QUFDekMsMEJBQTBCLGlDQUFpQztBQUMzRDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxpQkFBaUI7QUFDakI7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSwwQkFBMEIseUNBQXlDO0FBQ25FO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxvREFBb0QsV0FBVztBQUMvRDtBQUNBLGlCQUFpQjtBQUNqQjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsMEJBQTBCLDZFQUF5QjtBQUNuRDtBQUNBO0FBQ0EsaURBQWlELDRDQUE0QztBQUM3Riw0QkFBNEIsd0VBQW9CO0FBQ2hELDBCQUEwQix5Q0FBeUM7QUFDbkU7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0Esb0RBQW9ELFdBQVc7QUFDL0Q7QUFDQSxpQkFBaUI7QUFDakI7QUFDQTtBQUNBLDZDQUE2QyxZQUFZO0FBQ3pEO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLHNCQUFzQiw2Q0FBNkM7QUFDbkU7QUFDQTtBQUNBO0FBQ0E7QUFDQSxhQUFhO0FBQ2I7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxvQkFBb0IsZ0JBQWdCO0FBQ3BDO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsMkRBQTJEO0FBQzNEO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLEtBQUs7QUFDTDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLEtBQUs7QUFDTDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLENBQUM7QUFDRDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLHFEQUFxRCxpQkFBaUI7QUFDdEU7QUFDQSx3QkFBd0IsV0FBVztBQUNuQztBQUNBLCtCQUErQixXQUFXO0FBQzFDLGFBQWE7QUFDYixTQUFTO0FBQ1Q7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSw4QkFBOEIseUJBQXlCO0FBQ3ZEO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxrQ0FBa0MseUJBQXlCO0FBQzNEO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLDJDQUEyQyw0Q0FBNEM7QUFDdkYsZ0RBQWdELGdEQUFnRDtBQUNoRztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLHlDQUF5QyxtQkFBbUI7QUFDNUQ7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxTQUFTO0FBQ1QsS0FBSztBQUNMO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSwrRkFBK0Y7QUFDL0Y7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxzQkFBc0IsbUVBQWM7QUFDcEM7QUFDQSwrQkFBK0IsMkJBQTJCLGFBQWEsS0FBSztBQUM1RTtBQUNBLDZDQUE2Qyx3Q0FBd0MsSUFBSSxTQUFTO0FBQ2xHLDRDQUE0QyxnREFBZ0QsSUFBSSw2QkFBNkI7QUFDN0g7QUFDQSx5REFBeUQsZUFBZSxRQUFRLE1BQU0sSUFBSSxvQkFBb0I7QUFDOUc7QUFDQSxxRkFBcUYsS0FBSyx3QkFBd0IsZ0JBQWdCO0FBQ2xJLHVGQUF1RixLQUFLLHdCQUF3QixnQkFBZ0I7QUFDcEk7QUFDQTtBQUNBLEtBQUs7QUFDTDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSwrQkFBK0IsOENBQThDLElBQUksd0NBQXdDO0FBQ3pIO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLHFGQUFxRjtBQUNyRiwyQ0FBMkMsMEJBQTBCLGlCQUFpQjtBQUN0Rix5Q0FBeUMseUNBQXlDLEdBQUcsd0JBQXdCO0FBQzdHLHVFQUF1RSxnQ0FBZ0M7QUFDdkcsbUVBQW1FLFFBQVE7QUFDM0U7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsNkRBQTZEO0FBQzdELDRDQUE0QyxTQUFTO0FBQ3JEO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0Esa0JBQWtCLElBQUk7QUFDdEI7QUFDQSxrQkFBa0IscUJBQXFCO0FBQ3ZDO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsNENBQTRDLEVBQUU7QUFDOUMsMkNBQTJDLEVBQUU7QUFDN0M7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxhQUFhLEVBQUUsS0FBSyxFQUFFLHdDQUF3QztBQUM5RDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSx5REFBeUQsVUFBVTtBQUNuRSx5R0FBeUcsVUFBVTtBQUNuSDtBQUNBO0FBQ0EsOEdBQThHLGdCQUFnQixlQUFlLDBCQUEwQjtBQUN2Syx5REFBeUQsZUFBZSwwQkFBMEIsaUJBQWlCO0FBQ25IO0FBQ0Esc0JBQXNCLHlHQUF5RyxhQUFhLG1CQUFtQixFQUFFO0FBQ2pLLHNCQUFzQjtBQUN0QjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLG1HQUFtRyxtQ0FBbUM7QUFDdEk7QUFDQTtBQUNBLCtEQUErRCx3Q0FBd0M7QUFDdkcsaUVBQWlFLCtCQUErQjtBQUNoRztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxrQkFBa0I7QUFDbEI7QUFDQTtBQUNBO0FBQ0E7QUFDQSxvR0FBb0csZ0JBQWdCO0FBQ3BILCtGQUErRiw0QkFBNEIsRUFBRSxrREFBa0Qsa0JBQWtCLGdCQUFnQjtBQUNqTiw2R0FBNkcsZUFBZSx1QkFBdUI7QUFDbkosZ0hBQWdILHdCQUF3QjtBQUN4SSx1RkFBdUYsOERBQThELElBQUkscUVBQXFFO0FBQzlOLGlFQUFpRSxlQUFlLDBCQUEwQjtBQUMxRyxnR0FBZ0csa0JBQWtCLGlCQUFpQjtBQUNuSSw4QkFBOEI7QUFDOUI7QUFDQTtBQUNBO0FBQ0EsaUVBQWlFLGVBQWUsMEJBQTBCO0FBQzFHLHdGQUF3Rix3QkFBd0I7QUFDaEgsb0ZBQW9GLHlCQUF5QjtBQUM3RyxxRkFBcUYsMkJBQTJCO0FBQ2hILHVGQUF1Riw0QkFBNEI7QUFDbkg7QUFDQTtBQUNBLGtCQUFrQjtBQUNsQjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLHFHQUFxRztBQUNyRztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxzR0FBc0csMkNBQTJDLE9BQU87QUFDeEo7QUFDQTtBQUNBO0FBQ0E7QUFDQSwwQkFBMEI7QUFDMUI7QUFDQTtBQUNBLHNEQUFzRCw0Q0FBNEM7QUFDbEcsMkNBQTJDLFVBQVU7QUFDckQsd0RBQXdELHNCQUFzQixFQUFFLDhEQUE4RCwrQkFBK0IsT0FBTztBQUNwTDtBQUNBLG1GQUFtRixlQUFlO0FBQ2xHLCtEQUErRCxrQkFBa0IseUNBQXlDO0FBQzFILHNDQUFzQyw0RkFBNEYsa0JBQWtCLG9CQUFvQjtBQUN4SztBQUNBO0FBQ0EsNEdBQTRHLHVCQUF1Qiw4QkFBOEIsa0JBQWtCO0FBQ25MLDBDQUEwQztBQUMxQztBQUNBLHlGQUF5RjtBQUN6Riw2RUFBNkUsaUJBQWlCO0FBQzlGLDJFQUEyRSxtQkFBbUI7QUFDOUYsOEVBQThFLGtCQUFrQjtBQUNoRztBQUNBO0FBQ0E7QUFDQTtBQUNBLEtBQUs7QUFDTDtBQUNBO0FBQ0Esa0JBQWtCLHlHQUF5RztBQUMzSDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLHFHQUFxRztBQUNyRztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0Esd0dBQXdHLE9BQU87QUFDL0c7QUFDQTtBQUNBO0FBQ0E7QUFDQSwwQkFBMEI7QUFDMUI7QUFDQTtBQUNBLDhEQUE4RCw0Q0FBNEM7QUFDMUcsMkNBQTJDLFVBQVU7QUFDckQsd0RBQXdELHNCQUFzQixFQUFFLDhEQUE4RCwrQkFBK0IsT0FBTztBQUNwTDtBQUNBLG1GQUFtRixlQUFlO0FBQ2xHLCtEQUErRCxrQkFBa0IsNkRBQTZEO0FBQzlJLHNDQUFzQyxnR0FBZ0csa0JBQWtCLG9CQUFvQjtBQUM1SztBQUNBO0FBQ0Esa0dBQWtHLHVCQUF1Qiw4QkFBOEIsa0JBQWtCO0FBQ3pLLDBDQUEwQztBQUMxQztBQUNBLHlGQUF5RjtBQUN6Riw4RUFBOEUsa0JBQWtCO0FBQ2hHLDRFQUE0RSxvQkFBb0I7QUFDaEcsZ0ZBQWdGLG1CQUFtQjtBQUNuRztBQUNBO0FBQ0E7QUFDQTtBQUNBLEtBQUs7QUFDTDtBQUNBO0FBQ0EsOEhBQThIO0FBQzlILG1EQUFtRCxnREFBZ0Q7QUFDbkcsc0JBQXNCLDBEQUEwRCxXQUFXO0FBQzNGO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0Esb0dBQW9HLHNCQUFzQjtBQUMxSCwrRkFBK0YsbUNBQW1DLEVBQUUseURBQXlELHlCQUF5QixnQkFBZ0I7QUFDdE8sNkdBQTZHLGVBQWUsOEJBQThCO0FBQzFKLGdIQUFnSCwrQkFBK0I7QUFDL0ksdUZBQXVGLGdFQUFnRSxJQUFJLG1EQUFtRDtBQUM5TSxpRUFBaUUsZUFBZSwwQkFBMEI7QUFDMUcsZ0dBQWdHLGtCQUFrQixpQkFBaUI7QUFDbkksOEJBQThCO0FBQzlCO0FBQ0E7QUFDQTtBQUNBLGlFQUFpRSxlQUFlLDBCQUEwQjtBQUMxRyx3RkFBd0YsK0JBQStCO0FBQ3ZILG9GQUFvRixnQ0FBZ0M7QUFDcEgscUZBQXFGLGlDQUFpQztBQUN0SDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0Esb0dBQW9HLHNCQUFzQjtBQUMxSCwrRkFBK0YsbUNBQW1DLEVBQUUseURBQXlELHlCQUF5QixnQkFBZ0I7QUFDdE8sZ0hBQWdILCtCQUErQjtBQUMvSSx1RkFBdUYscUVBQXFFLElBQUksMERBQTBEO0FBQzFOLGlFQUFpRSxlQUFlLDBCQUEwQjtBQUMxRyxnR0FBZ0csa0JBQWtCLGlCQUFpQjtBQUNuSSw4QkFBOEI7QUFDOUI7QUFDQTtBQUNBO0FBQ0EsaUVBQWlFLGVBQWUsMEJBQTBCO0FBQzFHLHdGQUF3Riw4QkFBOEI7QUFDdEgsb0ZBQW9GLCtCQUErQjtBQUNuSCxxRkFBcUYsZ0NBQWdDO0FBQ3JIO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsMkZBQTJGLHVCQUF1QjtBQUNsSDtBQUNBLDRDQUE0QztBQUM1QztBQUNBO0FBQ0EsNEVBQTRFLG9EQUFvRDtBQUNoSTtBQUNBO0FBQ0E7QUFDQTtBQUNBLGtGQUFrRixnQkFBZ0Isc0JBQXNCO0FBQ3hILGdFQUFnRTtBQUNoRTtBQUNBLHFEQUFxRDtBQUNyRCw2QkFBNkI7QUFDN0I7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxZQUFZLHFDQUFxQztBQUNqRDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsK0ZBQStGLHVCQUF1QjtBQUN0SDtBQUNBLGdEQUFnRDtBQUNoRDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsMkZBQTJGLGdCQUFnQixjQUFjO0FBQ3pIO0FBQ0EsNENBQTRDO0FBQzVDO0FBQ0EsNERBQTRELHlCQUF5QjtBQUNyRixzQkFBc0Isd0VBQXdFLDhCQUE4QjtBQUM1SDtBQUNBLHFDQUFxQyxXQUFXLHdCQUF3Qix1QkFBdUIsWUFBWTtBQUMzRztBQUNBLGtGQUFrRixnQkFBZ0Isb0JBQW9CO0FBQ3RIO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLFlBQVkscUNBQXFDO0FBQ2pEO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxxR0FBcUc7QUFDckc7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLDRDQUE0QyxlQUFlLDBCQUEwQixpQkFBaUI7QUFDdEcsc01BQXNNLElBQUksZUFBZTtBQUN6TjtBQUNBO0FBQ0Esc0VBQXNFLDJCQUEyQixtQkFBbUI7QUFDcEg7QUFDQSxnREFBZ0QsZUFBZSwwQkFBMEI7QUFDekYsd0RBQXdELHdDQUF3Qyx3QkFBd0IsRUFBRSx1Q0FBdUMsSUFBSSxZQUFZO0FBQ2pMO0FBQ0EsOEdBQThHLDBCQUEwQixFQUFFLG9CQUFvQiw4QkFBOEIsUUFBUTtBQUNwTSw2R0FBNkcsZ0JBQWdCO0FBQzdILGlIQUFpSCxrQkFBa0Isc0JBQXNCO0FBQ3pKO0FBQ0Esc0JBQXNCO0FBQ3RCO0FBQ0Esa0JBQWtCO0FBQ2xCLGtCQUFrQjtBQUNsQjtBQUNBLCtHQUErRztBQUMvRztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsbUZBQW1GLGVBQWU7QUFDbEcsaUdBQWlHLGVBQWU7QUFDaEgsK0VBQStFLDJCQUEyQjtBQUMxRyx5REFBeUQsdUNBQXVDO0FBQ2hHO0FBQ0E7QUFDQTtBQUNBO0FBQ0Esb0dBQW9HO0FBQ3BHO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSx1SEFBdUgsZUFBZTtBQUN0STtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxVQUFVO0FBQ1Y7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsbUNBQW1DLGNBQWM7QUFDakQsMkZBQTJGLGtDQUFrQztBQUM3SCx5RkFBeUYsZ0NBQWdDO0FBQ3pILDhHQUE4Ryw4QkFBOEI7QUFDNUk7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0Esd0NBQXdDO0FBQ3hDO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLCtCQUErQiwwQkFBMEI7QUFDekQ7QUFDQSx1Q0FBdUMsa0JBQWtCO0FBQ3pELG1EQUFtRCxLQUFLLElBQUksS0FBSztBQUNqRSxrQkFBa0I7QUFDbEIsaURBQWlELDJDQUEyQztBQUM1RjtBQUNBLGdEQUFnRCxlQUFlLElBQUksUUFBUTtBQUMzRSwyQ0FBMkMsa0ZBQWtGO0FBQzdIO0FBQ0E7QUFDQSxpRUFBaUUsRUFBRTtBQUNuRTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsZ0NBQWdDO0FBQ2hDO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSwrSEFBK0g7QUFDL0g7QUFDQTtBQUNBO0FBQ0Esc0hBQXNIO0FBQ3RIO0FBQ0E7QUFDQTtBQUNBLCtIQUErSDtBQUMvSDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsVUFBVTtBQUNWLFVBQVU7QUFDVixVQUFVO0FBQ1YsVUFBVTtBQUNWLFVBQVU7QUFDVixVQUFVO0FBQ1YsVUFBVTtBQUNWLFVBQVU7QUFDVjtBQUNBOztBQUVBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLGdHQUFnRyxlQUFlO0FBQy9HLDhFQUE4RSxxQ0FBcUM7QUFDbkgsbUZBQW1GLDRCQUE0QjtBQUMvRyxxSUFBcUksbUJBQW1CO0FBQ3hKLHdEQUF3RDtBQUN4RCwrRUFBK0UsK0JBQStCO0FBQzlHLHdEQUF3RDtBQUN4RDtBQUNBLHlMQUF5TCxXQUFXLHVEQUF1RDtBQUMzUCw0RkFBNEYsUUFBUSx5QkFBeUIsaUJBQWlCO0FBQzlJO0FBQ0Esd0RBQXdEO0FBQ3hEO0FBQ0EsNExBQTRMLFFBQVEsV0FBVyx5Q0FBeUM7QUFDeFAsZ0xBQWdMLFFBQVEsV0FBVyxpQ0FBaUM7QUFDcE8sOEZBQThGLFFBQVEseUJBQXlCLGlCQUFpQjtBQUNoSjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxtRUFBbUU7QUFDbkU7QUFDQSxxRkFBcUYsb0RBQW9EO0FBQ3pJLGtGQUFrRixvQkFBb0I7QUFDdEcsZ0ZBQWdGLGtCQUFrQjtBQUNsRyxzR0FBc0csaUJBQWlCO0FBQ3ZILHNHQUFzRyx5QkFBeUI7QUFDL0g7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxrQkFBa0I7QUFDbEI7QUFDQTtBQUNBO0FBQ0E7QUFDQSxpQ0FBaUMsOENBQThDO0FBQy9FO0FBQ0E7QUFDQSxrQkFBa0I7QUFDbEI7QUFDQTtBQUNBLGtHQUFrRyw2Q0FBNkMsSUFBSSw0Q0FBNEM7QUFDL0wsc0ZBQXNGLHlEQUF5RDtBQUMvSSxzR0FBc0csNENBQTRDLElBQUksb0NBQW9DO0FBQzFMO0FBQ0EsdUNBQXVDLCtFQUErRSxJQUFJLCtFQUErRTtBQUN6TTtBQUNBLGtCQUFrQjtBQUNsQjtBQUNBLDBDQUEwQyxlQUFlO0FBQ3pEO0FBQ0EsaURBQWlELDJCQUEyQjtBQUM1RSw4QkFBOEIsK0NBQStDO0FBQzdFLDZEQUE2RCxlQUFlLGNBQWMseUJBQXlCO0FBQ25IO0FBQ0E7QUFDQTtBQUNBLGtCQUFrQjtBQUNsQiwwQ0FBMEMsZUFBZTtBQUN6RDtBQUNBO0FBQ0E7QUFDQSw4TUFBOE0sV0FBVyxnQkFBZ0IsSUFBSSw0QkFBNEI7QUFDelE7QUFDQTtBQUNBLG1HQUFtRyxRQUFRLHVCQUF1Qiw0QkFBNEI7QUFDOUosbUdBQW1HLFFBQVEsMEJBQTBCLDRCQUE0QjtBQUNqSyxtR0FBbUcsUUFBUSwyQkFBMkIsNEJBQTRCO0FBQ2xLLGdHQUFnRyxRQUFRLHlCQUF5Qiw0QkFBNEI7QUFDN0oscUdBQXFHLFFBQVEsMkJBQTJCLDRCQUE0QjtBQUNwSztBQUNBLGtCQUFrQjtBQUNsQixrQkFBa0I7QUFDbEI7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQSxnRkFBZ0YsZUFBZTtBQUMvRjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0Esc0JBQXNCO0FBQ3RCO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsdURBQXVELEdBQUc7QUFDMUQsa0NBQWtDLHNGQUFzRjtBQUN4SCxrQ0FBa0MsY0FBYztBQUNoRCxrQ0FBa0MsNkJBQTZCO0FBQy9ELGtDQUFrQyxrRkFBa0Y7QUFDcEgsOEVBQThFLGdCQUFnQixnQkFBZ0IsdUJBQXVCO0FBQ3JJLGtDQUFrQztBQUNsQztBQUNBO0FBQ0EsS0FBSztBQUNMO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSx3REFBd0QsWUFBWTtBQUNwRSw0Q0FBNEMsY0FBYztBQUMxRDtBQUNBO0FBQ0Esa0JBQWtCO0FBQ2xCO0FBQ0EsbUNBQW1DLGlEQUFpRDtBQUNwRjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLCtCQUErQixRQUFRLDBCQUEwQixjQUFjLGFBQWEsbUJBQW1CLHVCQUF1QjtBQUN0SSx1Q0FBdUMsbUJBQW1CLGlDQUFpQyxtQkFBbUIsa0JBQWtCLGtCQUFrQjtBQUNsSiwrQkFBK0IsaUNBQWlDLFNBQVMsSUFBSSxRQUFRO0FBQ3JGO0FBQ0E7QUFDQTtBQUNBLDJCQUEyQjtBQUMzQix5QkFBeUI7QUFDekI7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsNEJBQTRCLHFCQUFxQjtBQUNqRDtBQUNBO0FBQ0EsaUNBQWlDLCtFQUErRTtBQUNoSDtBQUNBO0FBQ0E7QUFDQSx1QkFBdUIsc0JBQXNCO0FBQzdDO0FBQ0E7QUFDQSx1QkFBdUIsc0JBQXNCLHNDQUFzQyxjQUFjLGNBQWMsbUJBQW1CLHdDQUF3QztBQUMxSztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EiLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9Ud2VldENsYXcvLi9zcmMvdXRpbHMvcm91dGUtcGFyc2VyLnRzIiwid2VicGFjazovL1R3ZWV0Q2xhdy8uL3NyYy91dGlscy94LXVybC11dGlscy50cyIsIndlYnBhY2s6Ly9Ud2VldENsYXcvd2VicGFjay9ib290c3RyYXAiLCJ3ZWJwYWNrOi8vVHdlZXRDbGF3L3dlYnBhY2svcnVudGltZS9kZWZpbmUgcHJvcGVydHkgZ2V0dGVycyIsIndlYnBhY2s6Ly9Ud2VldENsYXcvd2VicGFjay9ydW50aW1lL2hhc093blByb3BlcnR5IHNob3J0aGFuZCIsIndlYnBhY2s6Ly9Ud2VldENsYXcvd2VicGFjay9ydW50aW1lL21ha2UgbmFtZXNwYWNlIG9iamVjdCIsIndlYnBhY2s6Ly9Ud2VldENsYXcvLi9zcmMvZGVidWcvZGVidWcudHMiXSwic291cmNlc0NvbnRlbnQiOlsiZXhwb3J0IGZ1bmN0aW9uIHBhcnNlUm91dGVLaW5kKHVybCkge1xuICAgIGlmICghdXJsIHx8ICEodXJsLmluY2x1ZGVzKCd4LmNvbScpIHx8IHVybC5pbmNsdWRlcygndHdpdHRlci5jb20nKSkpXG4gICAgICAgIHJldHVybiAnbm9uZSc7XG4gICAgdHJ5IHtcbiAgICAgICAgY29uc3QgdSA9IG5ldyBVUkwodXJsKTtcbiAgICAgICAgY29uc3QgcGF0aCA9IHUucGF0aG5hbWU7XG4gICAgICAgIGlmIChwYXRoID09PSAnL2hvbWUnIHx8IHBhdGggPT09ICcvJylcbiAgICAgICAgICAgIHJldHVybiAnaG9tZSc7XG4gICAgICAgIGlmIChwYXRoLmluY2x1ZGVzKCcvc2VhcmNoJykpXG4gICAgICAgICAgICByZXR1cm4gJ3NlYXJjaCc7XG4gICAgICAgIGlmIChwYXRoLmluY2x1ZGVzKCcvc3RhdHVzLycpKVxuICAgICAgICAgICAgcmV0dXJuICd0aHJlYWQnO1xuICAgICAgICBpZiAocGF0aC5pbmNsdWRlcygnL25vdGlmaWNhdGlvbnMnKSlcbiAgICAgICAgICAgIHJldHVybiAnbm90aWZpY2F0aW9uJztcbiAgICAgICAgcmV0dXJuICdwcm9maWxlJztcbiAgICB9XG4gICAgY2F0Y2gge1xuICAgICAgICByZXR1cm4gJ3Vua25vd24nO1xuICAgIH1cbn1cbmV4cG9ydCBmdW5jdGlvbiBleHRyYWN0VHdlZXRJZCh1cmwpIHtcbiAgICBpZiAoIXVybClcbiAgICAgICAgcmV0dXJuIG51bGw7XG4gICAgdHJ5IHtcbiAgICAgICAgY29uc3QgdSA9IG5ldyBVUkwodXJsKTtcbiAgICAgICAgY29uc3QgbWF0Y2ggPSB1LnBhdGhuYW1lLm1hdGNoKC9cXC9zdGF0dXNcXC8oXFxkKykvKTtcbiAgICAgICAgcmV0dXJuIG1hdGNoID8gbWF0Y2hbMV0gOiBudWxsO1xuICAgIH1cbiAgICBjYXRjaCB7XG4gICAgICAgIHJldHVybiBudWxsO1xuICAgIH1cbn1cbiIsIi8qKlxuICogeC11cmwtdXRpbHMudHMgLSBTaGFyZWQgaGVscGVycyBmb3IgWCBVUkwgZ2VuZXJhdGlvbiBhbmQgdmFsaWRhdGlvbi5cbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIHZhbGlkYXRlVHdlZXREZXRhaWxQYXJhbXMoc2NyZWVuTmFtZSwgdHdlZXRJZCkge1xuICAgIGlmICghc2NyZWVuTmFtZSlcbiAgICAgICAgcmV0dXJuIHsgb2s6IGZhbHNlLCBlcnJvcjogJ3NjcmVlbk5hbWUgaXMgcmVxdWlyZWQnIH07XG4gICAgaWYgKCF0d2VldElkKVxuICAgICAgICByZXR1cm4geyBvazogZmFsc2UsIGVycm9yOiAndHdlZXRJZCBpcyByZXF1aXJlZCcgfTtcbiAgICBpZiAoc2NyZWVuTmFtZS5pbmNsdWRlcygnICcpIHx8IHNjcmVlbk5hbWUuaW5jbHVkZXMoJy8nKSkge1xuICAgICAgICByZXR1cm4geyBvazogZmFsc2UsIGVycm9yOiAnSW52YWxpZCBzY3JlZW5OYW1lOiBtdXN0IG5vdCBjb250YWluIHNwYWNlcyBvciBzbGFzaGVzLicgfTtcbiAgICB9XG4gICAgaWYgKCEvXlxcZCskLy50ZXN0KHR3ZWV0SWQpKSB7XG4gICAgICAgIHJldHVybiB7IG9rOiBmYWxzZSwgZXJyb3I6ICdJbnZhbGlkIHR3ZWV0SWQ6IG11c3QgYmUgYSBudW1lcmljIHN0cmluZy4nIH07XG4gICAgfVxuICAgIHJldHVybiB7IG9rOiB0cnVlIH07XG59XG5leHBvcnQgZnVuY3Rpb24gZm9ybWF0VHdlZXREZXRhaWxVcmwoc2NyZWVuTmFtZSwgdHdlZXRJZCkge1xuICAgIGNvbnN0IGNsZWFuZWRIYW5kbGUgPSBzY3JlZW5OYW1lLnN0YXJ0c1dpdGgoJ0AnKSA/IHNjcmVlbk5hbWUuc2xpY2UoMSkgOiBzY3JlZW5OYW1lO1xuICAgIHJldHVybiBgaHR0cHM6Ly94LmNvbS8ke2NsZWFuZWRIYW5kbGV9L3N0YXR1cy8ke3R3ZWV0SWR9YDtcbn1cbiIsIi8vIFRoZSBtb2R1bGUgY2FjaGVcbnZhciBfX3dlYnBhY2tfbW9kdWxlX2NhY2hlX18gPSB7fTtcblxuLy8gVGhlIHJlcXVpcmUgZnVuY3Rpb25cbmZ1bmN0aW9uIF9fd2VicGFja19yZXF1aXJlX18obW9kdWxlSWQpIHtcblx0Ly8gQ2hlY2sgaWYgbW9kdWxlIGlzIGluIGNhY2hlXG5cdHZhciBjYWNoZWRNb2R1bGUgPSBfX3dlYnBhY2tfbW9kdWxlX2NhY2hlX19bbW9kdWxlSWRdO1xuXHRpZiAoY2FjaGVkTW9kdWxlICE9PSB1bmRlZmluZWQpIHtcblx0XHRyZXR1cm4gY2FjaGVkTW9kdWxlLmV4cG9ydHM7XG5cdH1cblx0Ly8gQ3JlYXRlIGEgbmV3IG1vZHVsZSAoYW5kIHB1dCBpdCBpbnRvIHRoZSBjYWNoZSlcblx0dmFyIG1vZHVsZSA9IF9fd2VicGFja19tb2R1bGVfY2FjaGVfX1ttb2R1bGVJZF0gPSB7XG5cdFx0Ly8gbm8gbW9kdWxlLmlkIG5lZWRlZFxuXHRcdC8vIG5vIG1vZHVsZS5sb2FkZWQgbmVlZGVkXG5cdFx0ZXhwb3J0czoge31cblx0fTtcblxuXHQvLyBFeGVjdXRlIHRoZSBtb2R1bGUgZnVuY3Rpb25cblx0aWYgKCEobW9kdWxlSWQgaW4gX193ZWJwYWNrX21vZHVsZXNfXykpIHtcblx0XHRkZWxldGUgX193ZWJwYWNrX21vZHVsZV9jYWNoZV9fW21vZHVsZUlkXTtcblx0XHR2YXIgZSA9IG5ldyBFcnJvcihcIkNhbm5vdCBmaW5kIG1vZHVsZSAnXCIgKyBtb2R1bGVJZCArIFwiJ1wiKTtcblx0XHRlLmNvZGUgPSAnTU9EVUxFX05PVF9GT1VORCc7XG5cdFx0dGhyb3cgZTtcblx0fVxuXHRfX3dlYnBhY2tfbW9kdWxlc19fW21vZHVsZUlkXShtb2R1bGUsIG1vZHVsZS5leHBvcnRzLCBfX3dlYnBhY2tfcmVxdWlyZV9fKTtcblxuXHQvLyBSZXR1cm4gdGhlIGV4cG9ydHMgb2YgdGhlIG1vZHVsZVxuXHRyZXR1cm4gbW9kdWxlLmV4cG9ydHM7XG59XG5cbiIsIi8vIGRlZmluZSBnZXR0ZXIgZnVuY3Rpb25zIGZvciBoYXJtb255IGV4cG9ydHNcbl9fd2VicGFja19yZXF1aXJlX18uZCA9IChleHBvcnRzLCBkZWZpbml0aW9uKSA9PiB7XG5cdGZvcih2YXIga2V5IGluIGRlZmluaXRpb24pIHtcblx0XHRpZihfX3dlYnBhY2tfcmVxdWlyZV9fLm8oZGVmaW5pdGlvbiwga2V5KSAmJiAhX193ZWJwYWNrX3JlcXVpcmVfXy5vKGV4cG9ydHMsIGtleSkpIHtcblx0XHRcdE9iamVjdC5kZWZpbmVQcm9wZXJ0eShleHBvcnRzLCBrZXksIHsgZW51bWVyYWJsZTogdHJ1ZSwgZ2V0OiBkZWZpbml0aW9uW2tleV0gfSk7XG5cdFx0fVxuXHR9XG59OyIsIl9fd2VicGFja19yZXF1aXJlX18ubyA9IChvYmosIHByb3ApID0+IChPYmplY3QucHJvdG90eXBlLmhhc093blByb3BlcnR5LmNhbGwob2JqLCBwcm9wKSkiLCIvLyBkZWZpbmUgX19lc01vZHVsZSBvbiBleHBvcnRzXG5fX3dlYnBhY2tfcmVxdWlyZV9fLnIgPSAoZXhwb3J0cykgPT4ge1xuXHRpZih0eXBlb2YgU3ltYm9sICE9PSAndW5kZWZpbmVkJyAmJiBTeW1ib2wudG9TdHJpbmdUYWcpIHtcblx0XHRPYmplY3QuZGVmaW5lUHJvcGVydHkoZXhwb3J0cywgU3ltYm9sLnRvU3RyaW5nVGFnLCB7IHZhbHVlOiAnTW9kdWxlJyB9KTtcblx0fVxuXHRPYmplY3QuZGVmaW5lUHJvcGVydHkoZXhwb3J0cywgJ19fZXNNb2R1bGUnLCB7IHZhbHVlOiB0cnVlIH0pO1xufTsiLCIvKipcbiAqIGRlYnVnLnRzIC0gVHdlZXRDbGF3IERlYnVnIFBhbmVsICh2NS40KVxuICpcbiAqIOS/ruWkje+8mlxuICogICAtIEQg5Yy6IHRvZ2dsZSDlhpLms6Hpl67popjvvJpleHBhbmRlZCBjb250ZW50IOaUueS4uiAuYXBpLWhpdCDnmoTlhYTlvJ/oioLngrlcbiAqICAgLSBFIOWMuuepuueZveaXtuihpeWFheaPkOekuiArIOaOqOaWh+S9nOiAheWPguiAg+S/oeaBr1xuICovXG5pbXBvcnQgeyBwYXJzZVJvdXRlS2luZCB9IGZyb20gJy4uL3V0aWxzL3JvdXRlLXBhcnNlcic7XG5pbXBvcnQgeyB2YWxpZGF0ZVR3ZWV0RGV0YWlsUGFyYW1zLCBmb3JtYXRUd2VldERldGFpbFVybCB9IGZyb20gJy4uL3V0aWxzL3gtdXJsLXV0aWxzJztcbi8vIOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgFxuLy8gVUkg6KeG6KeJ5aKe5by677ya5by65Yi25o+Q5Y2H5qCH562+5a+55q+U5bqmICh2NS40LjEpXG4vLyDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIBcbmNvbnN0IHN0eWxlID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudCgnc3R5bGUnKTtcbnN0eWxlLnRleHRDb250ZW50ID0gYFxuICAgIC8qIOW8uuWItuaPkOWNh+aJgOaciSBzeXMtc3RhdCDmoIfnrb7nmoTlr7nmr5TluqYgKi9cbiAgICAuc3lzLXN0YXQgc3BhbjpmaXJzdC1jaGlsZDpub3QoLnZhbCkgeyBcbiAgICAgICAgY29sb3I6ICNjYmQ1ZTAgIWltcG9ydGFudDsgXG4gICAgICAgIG9wYWNpdHk6IDAuOSAhaW1wb3J0YW50O1xuICAgIH1cbiAgICAvKiDmj5DljYcgdGV4dC1tdXRlZCDlnKjmmpfoibLog4zmma/kuIvnmoTlj6/op4HluqYgKi9cbiAgICAudGV4dC1tdXRlZCB7IFxuICAgICAgICBjb2xvcjogI2EwYWVjMCAhaW1wb3J0YW50OyBcbiAgICB9XG5gO1xuZG9jdW1lbnQuaGVhZC5hcHBlbmRDaGlsZChzdHlsZSk7XG5sZXQgc2VsZWN0ZWRUYWJJZCA9IG51bGw7XG5sZXQgdGFiTGlzdCA9IFtdO1xubGV0IGJyaWRnZU9ubGluZSA9IGZhbHNlO1xubGV0IGN1cnJlbnRIaXRzID0gW107IC8vIEQg5Yy65b2T5YmN5pi+56S655qEIGhpdHPvvIzkvpsgTW9kYWwg5byV55SoXG5jb25zdCBtYW51YWxPdmVycmlkZXMgPSBuZXcgTWFwKCk7XG5jb25zdCBzZWxlY3RlZFJlcGx5SWRzID0gbmV3IE1hcCgpO1xuY29uc3Qgc2VsZWN0ZWRQcm9maWxlVHdlZXRJZHMgPSBuZXcgTWFwKCk7XG5sZXQgbGFzdEZpbGxlZElkcyA9IG5ldyBNYXAoKTtcbmxldCByZXBseURyYWZ0VGV4dCA9ICcnO1xubGV0IGlzUmV2aWV3Q29uZmlybWVkID0gZmFsc2U7XG5sZXQgbGFzdFJldmlld05vdGUgPSBudWxsO1xubGV0IGxhc3RQYWdlQ29udGV4dCA9IG51bGw7XG4vLyBOZXcgc3RhdGUgbWFwcyBmb3IgaW5wdXRzIHRvIGF2b2lkIGRhdGEgbG9zcyBvbiBmcmVxdWVudCByZS1yZW5kZXJzXG5jb25zdCBuYXZVcmxEcmFmdHMgPSBuZXcgTWFwKCk7XG5jb25zdCBvcGVuVHdlZXRTY3JlZW5OYW1lRHJhZnRzID0gbmV3IE1hcCgpO1xuY29uc3Qgb3BlblR3ZWV0SWREcmFmdHMgPSBuZXcgTWFwKCk7XG5sZXQgbGFzdE9wZW5Ud2VldFJlcXVlc3RzID0gbmV3IE1hcCgpO1xuY29uc3QgQVBQUk9WQUxfU1RBVEUgPSB7XG4gICAgRFJBRlRfRU1QVFk6ICdEUkFGVF9FTVBUWScsXG4gICAgRFJBRlRfTk9UX1JFQURZOiAnRFJBRlRfTk9UX1JFQURZJyxcbiAgICBSRUFEWV9GT1JfUkVWSUVXOiAnUkVBRFlfRk9SX1JFVklFVycsXG4gICAgTE9DS0VEX0xPR0dFRF9PVVQ6ICdMT0NLRURfTE9HR0VEX09VVCdcbn07XG5mdW5jdGlvbiBnZXRDdXJyZW50UmVwbHlJbnRlbnQodGlkLCBwYWdlQ29udGV4dCwgY3VycmVudElucHV0VmFsdWUpIHtcbiAgICBjb25zdCBpc01hbnVhbCA9IG1hbnVhbE92ZXJyaWRlcy5nZXQodGlkKSB8fCBmYWxzZTtcbiAgICBjb25zdCBzZWxlY3RlZFJlcGx5SWQgPSBzZWxlY3RlZFJlcGx5SWRzLmdldCh0aWQpIHx8IG51bGw7XG4gICAgY29uc3QgaXNUd2VldERldGFpbCA9IHBhZ2VDb250ZXh0LnNjZW5lID09PSAndHdlZXRfZGV0YWlsJztcbiAgICBjb25zdCBjdXJFbnRpdHkgPSBwYWdlQ29udGV4dC5jdXJyZW50RW50aXR5O1xuICAgIGxldCB0YXJnZXRUeXBlID0gJ05PTkUnO1xuICAgIGxldCB0YXJnZXRJZCA9ICcnO1xuICAgIGxldCBhdXRob3JIYW5kbGUgPSAnJztcbiAgICBpZiAoaXNNYW51YWwpIHtcbiAgICAgICAgdGFyZ2V0VHlwZSA9ICdtYW51YWwgdGFyZ2V0JztcbiAgICAgICAgdGFyZ2V0SWQgPSBjdXJyZW50SW5wdXRWYWx1ZTtcbiAgICB9XG4gICAgZWxzZSBpZiAoaXNUd2VldERldGFpbCAmJiBzZWxlY3RlZFJlcGx5SWQpIHtcbiAgICAgICAgY29uc3QgcmVwbHkgPSAocGFnZUNvbnRleHQucmVwbGllc1NuYXBzaG90IHx8IFtdKS5maW5kKChyKSA9PiByLnR3ZWV0SWQgPT09IHNlbGVjdGVkUmVwbHlJZCk7XG4gICAgICAgIHRhcmdldFR5cGUgPSAnc2VsZWN0ZWQgcmVwbHknO1xuICAgICAgICB0YXJnZXRJZCA9IHNlbGVjdGVkUmVwbHlJZDtcbiAgICAgICAgYXV0aG9ySGFuZGxlID0gcmVwbHk/LmF1dGhvckhhbmRsZSB8fCAnJztcbiAgICB9XG4gICAgZWxzZSBpZiAoaXNUd2VldERldGFpbCAmJiBjdXJFbnRpdHkpIHtcbiAgICAgICAgdGFyZ2V0VHlwZSA9ICdjdXJyZW50IHR3ZWV0JztcbiAgICAgICAgdGFyZ2V0SWQgPSBjdXJFbnRpdHkuZW50aXR5SWQ7XG4gICAgICAgIGF1dGhvckhhbmRsZSA9IGN1ckVudGl0eS5hdXRob3JIYW5kbGUgfHwgJyc7XG4gICAgfVxuICAgIHJldHVybiB7IHRhcmdldFR5cGUsIHRhcmdldElkLCBhdXRob3JIYW5kbGUgfTtcbn1cbi8vIOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgFxuLy8g5LqL5Lu25Luj55CGXG4vLyDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIBcbi8vIOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgFxuLy8gTW9kYWzvvIhEIOWMuiBoaXQg6K+m5oOF5by556qX77yJXG4vLyDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIBcbmZ1bmN0aW9uIHNob3dIaXRNb2RhbChoKSB7XG4gICAgLy8g5riF5o6J5penIG1vZGFs77yI5aaC5pyJ77yJXG4gICAgZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoJ3RjLWhpdC1tb2RhbCcpPy5yZW1vdmUoKTtcbiAgICBsZXQgYXBpUGF0aCA9ICfigJQnO1xuICAgIGxldCBxdWVyeVBhcmFtc0h0bWwgPSAnJztcbiAgICBsZXQgZmFsbGJhY2tVcmxIdG1sID0gJyc7XG4gICAgdHJ5IHtcbiAgICAgICAgaWYgKGguYXBpVXJsKSB7XG4gICAgICAgICAgICBjb25zdCB1ID0gbmV3IFVSTChoLmFwaVVybCk7XG4gICAgICAgICAgICBhcGlQYXRoID0gdS5wYXRobmFtZTtcbiAgICAgICAgICAgIGNvbnN0IHBhcmFtcyA9IG5ldyBVUkxTZWFyY2hQYXJhbXModS5zZWFyY2gpO1xuICAgICAgICAgICAgY29uc3QgcGFyc2VkUGFyYW1zID0ge307XG4gICAgICAgICAgICBsZXQgaGFzUGFyYW1zID0gZmFsc2U7XG4gICAgICAgICAgICBmb3IgKGNvbnN0IFtrZXksIHZhbHVlXSBvZiBwYXJhbXMuZW50cmllcygpKSB7XG4gICAgICAgICAgICAgICAgaGFzUGFyYW1zID0gdHJ1ZTtcbiAgICAgICAgICAgICAgICB0cnkge1xuICAgICAgICAgICAgICAgICAgICBwYXJzZWRQYXJhbXNba2V5XSA9IEpTT04ucGFyc2UodmFsdWUpO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICBjYXRjaCB7XG4gICAgICAgICAgICAgICAgICAgIHBhcnNlZFBhcmFtc1trZXldID0gdmFsdWU7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfVxuICAgICAgICAgICAgaWYgKGhhc1BhcmFtcykge1xuICAgICAgICAgICAgICAgIGNvbnN0IHBhcmFtc0pzb24gPSBzYWZlSnNvbihwYXJzZWRQYXJhbXMpO1xuICAgICAgICAgICAgICAgIHF1ZXJ5UGFyYW1zSHRtbCA9IGBcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzPVwidGMtbW9kYWwtc2VjdGlvblwiPlxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzPVwidGMtbW9kYWwtbGFiZWwgdGV4dC13YXJuaW5nXCI+UVVFUlkgUEFSQU1FVEVSUzwvZGl2PlxuICAgICAgICAgICAgICAgICAgICA8cHJlIGNsYXNzPVwidGMtbW9kYWwtcHJlXCI+JHtwYXJhbXNKc29ufTwvcHJlPlxuICAgICAgICAgICAgICAgIDwvZGl2PmA7XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICB9XG4gICAgY2F0Y2gge1xuICAgICAgICBhcGlQYXRoID0gaC5hcGlVcmwgfHwgJ+KAlCc7XG4gICAgICAgIGZhbGxiYWNrVXJsSHRtbCA9IGBcbiAgICAgICAgPGRpdiBjbGFzcz1cInRjLW1vZGFsLXNlY3Rpb25cIj5cbiAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJ0Yy1tb2RhbC1sYWJlbFwiPlJBVyBBUEkgVVJMPC9kaXY+XG4gICAgICAgICAgICA8cHJlIGNsYXNzPVwidGMtbW9kYWwtcHJlXCI+JHtoLmFwaVVybH08L3ByZT5cbiAgICAgICAgPC9kaXY+YDtcbiAgICB9XG4gICAgY29uc3QgcmVxSnNvbiA9IHNhZmVKc29uKGgucmVxdWVzdEJvZHkpO1xuICAgIGNvbnN0IHJlc3BKc29uID0gc2FmZUpzb24oaC5yZXNwb25zZUJvZHkgfHwge30pO1xuICAgIGNvbnN0IG1vZGFsID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudCgnZGl2Jyk7XG4gICAgbW9kYWwuaWQgPSAndGMtaGl0LW1vZGFsJztcbiAgICBtb2RhbC5pbm5lckhUTUwgPSBgXG4gICAgPGRpdiBjbGFzcz1cInRjLW1vZGFsLWJhY2tkcm9wXCI+PC9kaXY+XG4gICAgPGRpdiBjbGFzcz1cInRjLW1vZGFsLWJveFwiPlxuICAgICAgICA8ZGl2IGNsYXNzPVwidGMtbW9kYWwtaGVhZGVyXCI+XG4gICAgICAgICAgICA8c3BhbiBjbGFzcz1cIm1ldGhvZFwiIHN0eWxlPVwibWFyZ2luLXJpZ2h0OjEwcHhcIj4ke2gubWV0aG9kIHx8ICdQT1NUJ308L3NwYW4+XG4gICAgICAgICAgICA8c3BhbiBjbGFzcz1cImZ3LWJvbGQgdGV4dC13aGl0ZVwiIHN0eWxlPVwiZm9udC1zaXplOjE0cHg7IG1hcmdpbi1yaWdodDoxMHB4XCI+JHtoLm9wfTwvc3Bhbj5cbiAgICAgICAgICAgIDxzcGFuIGNsYXNzPVwidGV4dC1pbmZvXCIgc3R5bGU9XCJmb250LXNpemU6MTFweDsgZmxleDoxOyBvdmVyZmxvdzpoaWRkZW47IHRleHQtb3ZlcmZsb3c6ZWxsaXBzaXM7IHdoaXRlLXNwYWNlOm5vd3JhcFwiIHRpdGxlPVwiJHthcGlQYXRofVwiPiR7YXBpUGF0aH08L3NwYW4+XG4gICAgICAgICAgICA8c3BhbiBjbGFzcz1cInRleHQtbXV0ZWRcIiBzdHlsZT1cImZvbnQtc2l6ZToxMHB4OyBtYXJnaW4tcmlnaHQ6MTJweFwiPiR7bmV3IERhdGUoaC50aW1lc3RhbXApLnRvTG9jYWxlVGltZVN0cmluZygpfTwvc3Bhbj5cbiAgICAgICAgICAgIDxidXR0b24gaWQ9XCJ0Yy1tb2RhbC1jbG9zZVwiIHN0eWxlPVwiYmFja2dyb3VuZDpub25lO2JvcmRlcjpub25lO2NvbG9yOiNhMGFlYzA7Zm9udC1zaXplOjE4cHg7Y3Vyc29yOnBvaW50ZXI7bGluZS1oZWlnaHQ6MVwiPuKclTwvYnV0dG9uPlxuICAgICAgICA8L2Rpdj5cbiAgICAgICAgPGRpdiBjbGFzcz1cInRjLW1vZGFsLWJvZHlcIj5cbiAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJ0Yy1tb2RhbC1zZWN0aW9uXCIgc3R5bGU9XCJkaXNwbGF5OmZsZXg7IGdhcDogMjBweDtcIj5cbiAgICAgICAgICAgICAgICA8ZGl2IHN0eWxlPVwiZmxleDoxOyBvdmVyZmxvdzpoaWRkZW47XCI+XG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJ0Yy1tb2RhbC1sYWJlbFwiPkFQSSBQQVRIPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJ0ZXh0LWxpZ2h0XCIgc3R5bGU9XCJmb250LXNpemU6MTFweDsgd29yZC1icmVhazpicmVhay1hbGw7XCI+JHthcGlQYXRofTwvZGl2PlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgIDxkaXYgc3R5bGU9XCJmbGV4OjE7IG92ZXJmbG93OmhpZGRlbjtcIj5cbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzcz1cInRjLW1vZGFsLWxhYmVsXCI+UEFHRSBVUkw8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzcz1cInRleHQtbXV0ZWRcIiBzdHlsZT1cImZvbnQtc2l6ZToxMXB4OyB3b3JkLWJyZWFrOmJyZWFrLWFsbDtcIj4ke2gucGFnZVVybCB8fCAn4oCUJ308L2Rpdj5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgJHtmYWxsYmFja1VybEh0bWx9XG4gICAgICAgICAgICAke3F1ZXJ5UGFyYW1zSHRtbH1cbiAgICAgICAgICAgICR7aC5yZXF1ZXN0Qm9keSA/IGBcbiAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJ0Yy1tb2RhbC1zZWN0aW9uXCI+XG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzcz1cInRjLW1vZGFsLWxhYmVsIHRleHQtcHJpbWFyeVwiPlJFUVVFU1QgQk9EWTwvZGl2PlxuICAgICAgICAgICAgICAgIDxwcmUgY2xhc3M9XCJ0Yy1tb2RhbC1wcmVcIj4ke3JlcUpzb259PC9wcmU+XG4gICAgICAgICAgICA8L2Rpdj5gIDogJyd9XG4gICAgICAgICAgICA8ZGl2IGNsYXNzPVwidGMtbW9kYWwtc2VjdGlvblwiPlxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJ0Yy1tb2RhbC1sYWJlbCB0ZXh0LXN1Y2Nlc3NcIj5SRVNQT05TRSBCT0RZPC9kaXY+XG4gICAgICAgICAgICAgICAgPHByZSBjbGFzcz1cInRjLW1vZGFsLXByZVwiPiR7cmVzcEpzb259PC9wcmU+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgPC9kaXY+XG4gICAgPC9kaXY+YDtcbiAgICBkb2N1bWVudC5ib2R5LmFwcGVuZENoaWxkKG1vZGFsKTtcbiAgICBjb25zdCBjbG9zZSA9ICgpID0+IGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKCd0Yy1oaXQtbW9kYWwnKT8ucmVtb3ZlKCk7XG4gICAgZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoJ3RjLW1vZGFsLWNsb3NlJykub25jbGljayA9IGNsb3NlO1xuICAgIG1vZGFsLnF1ZXJ5U2VsZWN0b3IoJy50Yy1tb2RhbC1iYWNrZHJvcCcpLmFkZEV2ZW50TGlzdGVuZXIoJ2NsaWNrJywgY2xvc2UpO1xufVxuZnVuY3Rpb24gc2V0dXBEZWxlZ2F0aW9uKCkge1xuICAgIGRvY3VtZW50LmFkZEV2ZW50TGlzdGVuZXIoJ2NsaWNrJywgKGUpID0+IHtcbiAgICAgICAgY29uc3QgdGFyZ2V0ID0gZS50YXJnZXQ7XG4gICAgICAgIC8vIOmAieaLqSBYIHRhYlxuICAgICAgICBjb25zdCB0YWJFbCA9IHRhcmdldC5jbG9zZXN0KCcudGFiLWl0ZW0nKTtcbiAgICAgICAgaWYgKHRhYkVsPy5kYXRhc2V0LmlkICYmICF0YXJnZXQuY2xvc2VzdCgnYnV0dG9uJykpIHtcbiAgICAgICAgICAgIHNlbGVjdGVkVGFiSWQgPSBwYXJzZUludCh0YWJFbC5kYXRhc2V0LmlkKTtcbiAgICAgICAgICAgIHJlZnJlc2hEYXRhKCk7XG4gICAgICAgICAgICByZXR1cm47XG4gICAgICAgIH1cbiAgICAgICAgLy8gV29ya3NwYWNlIENvbnRyb2w6IEZvY3VzIFRhYlxuICAgICAgICBjb25zdCBmb2N1c0J0biA9IHRhcmdldC5jbG9zZXN0KCcuYnRuLXRhYi1mb2N1cycpO1xuICAgICAgICBpZiAoZm9jdXNCdG4/LmRhdGFzZXQuaWQpIHtcbiAgICAgICAgICAgIGNvbnN0IHRpZCA9IHBhcnNlSW50KGZvY3VzQnRuLmRhdGFzZXQuaWQpO1xuICAgICAgICAgICAgc2VuZE1zZyh7IHR5cGU6ICdGT0NVU19YX1RBQicsIHRhYklkOiB0aWQgfSkudGhlbigoKSA9PiByZWZyZXNoRGF0YSgpKTtcbiAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgfVxuICAgICAgICAvLyBXb3Jrc3BhY2UgQ29udHJvbDogQ2xvc2UgVGFiXG4gICAgICAgIGNvbnN0IGNsb3NlQnRuID0gdGFyZ2V0LmNsb3Nlc3QoJy5idG4tdGFiLWNsb3NlJyk7XG4gICAgICAgIGlmIChjbG9zZUJ0bj8uZGF0YXNldC5pZCkge1xuICAgICAgICAgICAgY29uc3QgdGlkID0gcGFyc2VJbnQoY2xvc2VCdG4uZGF0YXNldC5pZCk7XG4gICAgICAgICAgICBpZiAoY29uZmlybShgQ2xvc2UgdGFiICR7dGlkfT9gKSkge1xuICAgICAgICAgICAgICAgIHNlbmRNc2coeyB0eXBlOiAnQ0xPU0VfWF9UQUInLCB0YWJJZDogdGlkIH0pLnRoZW4oKCkgPT4ge1xuICAgICAgICAgICAgICAgICAgICBpZiAoc2VsZWN0ZWRUYWJJZCA9PT0gdGlkKVxuICAgICAgICAgICAgICAgICAgICAgICAgc2VsZWN0ZWRUYWJJZCA9IG51bGw7XG4gICAgICAgICAgICAgICAgICAgIG5hdlVybERyYWZ0cy5kZWxldGUodGlkKTtcbiAgICAgICAgICAgICAgICAgICAgb3BlblR3ZWV0U2NyZWVuTmFtZURyYWZ0cy5kZWxldGUodGlkKTtcbiAgICAgICAgICAgICAgICAgICAgb3BlblR3ZWV0SWREcmFmdHMuZGVsZXRlKHRpZCk7XG4gICAgICAgICAgICAgICAgICAgIHJlZnJlc2hEYXRhKCk7XG4gICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICByZXR1cm47XG4gICAgICAgIH1cbiAgICAgICAgLy8gV29ya3NwYWNlIENvbnRyb2w6IE5hdmlnYXRlIFRhYlxuICAgICAgICBjb25zdCBuYXZCdG4gPSB0YXJnZXQuY2xvc2VzdCgnLmJ0bi10YWItbmF2aWdhdGUnKTtcbiAgICAgICAgaWYgKG5hdkJ0bj8uZGF0YXNldC5pZCkge1xuICAgICAgICAgICAgY29uc3QgdGlkID0gcGFyc2VJbnQobmF2QnRuLmRhdGFzZXQuaWQpO1xuICAgICAgICAgICAgY29uc3QgaW5wdXQgPSBkb2N1bWVudC5nZXRFbGVtZW50QnlJZCgnbmF2LXVybC1pbnB1dCcpO1xuICAgICAgICAgICAgY29uc3QgdXJsID0gaW5wdXQ/LnZhbHVlPy50cmltKCk7XG4gICAgICAgICAgICBpZiAodXJsKSB7XG4gICAgICAgICAgICAgICAgc2VuZE1zZyh7IHR5cGU6ICdOQVZJR0FURV9YX1RBQicsIHRhYklkOiB0aWQsIHVybCB9KS50aGVuKChyZXNwKSA9PiB7XG4gICAgICAgICAgICAgICAgICAgIGlmIChyZXNwPy5vaykge1xuICAgICAgICAgICAgICAgICAgICAgICAgbmF2VXJsRHJhZnRzLmRlbGV0ZSh0aWQpO1xuICAgICAgICAgICAgICAgICAgICAgICAgcmVmcmVzaERhdGEoKTtcbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICBlbHNlIGlmIChyZXNwPy5lcnJvcikge1xuICAgICAgICAgICAgICAgICAgICAgICAgYWxlcnQoYE5hdmlnYXRpb24gZmFpbGVkOiAke3Jlc3AuZXJyb3J9YCk7XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgfVxuICAgICAgICAvLyBXb3Jrc3BhY2UgQ29udHJvbDogT3BlbiBUd2VldCAoU2VtYW50aWMpXG4gICAgICAgIGNvbnN0IG9wZW5Ud2VldEJ0biA9IHRhcmdldC5jbG9zZXN0KCcuYnRuLXRhYi1vcGVuLXR3ZWV0Jyk7XG4gICAgICAgIGlmIChvcGVuVHdlZXRCdG4/LmRhdGFzZXQuaWQpIHtcbiAgICAgICAgICAgIGNvbnN0IHRpZCA9IHBhcnNlSW50KG9wZW5Ud2VldEJ0bi5kYXRhc2V0LmlkKTtcbiAgICAgICAgICAgIGNvbnN0IHNOYW1lSW5wdXQgPSBkb2N1bWVudC5nZXRFbGVtZW50QnlJZCgnb3Blbi10d2VldC1zY3JlZW4tbmFtZScpO1xuICAgICAgICAgICAgY29uc3QgdElkSW5wdXQgPSBkb2N1bWVudC5nZXRFbGVtZW50QnlJZCgnb3Blbi10d2VldC1pZCcpO1xuICAgICAgICAgICAgY29uc3Qgc2NyZWVuTmFtZSA9IHNOYW1lSW5wdXQ/LnZhbHVlPy50cmltKCkgfHwgJyc7XG4gICAgICAgICAgICBjb25zdCB0d2VldElkID0gdElkSW5wdXQ/LnZhbHVlPy50cmltKCkgfHwgJyc7XG4gICAgICAgICAgICBjb25zdCB2YWxpZCA9IHZhbGlkYXRlVHdlZXREZXRhaWxQYXJhbXMoc2NyZWVuTmFtZSwgdHdlZXRJZCk7XG4gICAgICAgICAgICBpZiAodmFsaWQub2spIHtcbiAgICAgICAgICAgICAgICAvLyBSZWNvcmQgcmVxdWVzdCBmb3IgbWlzbWF0Y2ggd2FybmluZ1xuICAgICAgICAgICAgICAgIGxhc3RPcGVuVHdlZXRSZXF1ZXN0cy5zZXQodGlkLCB7IHNjcmVlbk5hbWUsIHR3ZWV0SWQsIHRpbWVzdGFtcDogRGF0ZS5ub3coKSB9KTtcbiAgICAgICAgICAgICAgICBjb25zdCB1cmwgPSBmb3JtYXRUd2VldERldGFpbFVybChzY3JlZW5OYW1lLCB0d2VldElkKTtcbiAgICAgICAgICAgICAgICBzZW5kTXNnKHsgdHlwZTogJ05BVklHQVRFX1hfVEFCJywgdGFiSWQ6IHRpZCwgdXJsIH0pLnRoZW4oKHJlc3ApID0+IHtcbiAgICAgICAgICAgICAgICAgICAgaWYgKHJlc3A/Lm9rKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICBvcGVuVHdlZXRTY3JlZW5OYW1lRHJhZnRzLmRlbGV0ZSh0aWQpO1xuICAgICAgICAgICAgICAgICAgICAgICAgb3BlblR3ZWV0SWREcmFmdHMuZGVsZXRlKHRpZCk7XG4gICAgICAgICAgICAgICAgICAgICAgICByZWZyZXNoRGF0YSgpO1xuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgIGVsc2UgaWYgKHJlc3A/LmVycm9yKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICBhbGVydChgT3BlbiBUd2VldCBmYWlsZWQ6ICR7cmVzcC5lcnJvcn1gKTtcbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgZWxzZSB7XG4gICAgICAgICAgICAgICAgYWxlcnQoYEludmFsaWQgUGFyYW1ldGVyczogJHt2YWxpZC5lcnJvcn1gKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgfVxuICAgICAgICAvLyBXb3Jrc3BhY2UgQ29udHJvbDogQ3JlYXRlIFRhYlxuICAgICAgICBjb25zdCBjcmVhdGVCdG4gPSB0YXJnZXQuY2xvc2VzdCgnI2J0bi1jcmVhdGUtdGFiJyk7XG4gICAgICAgIGlmIChjcmVhdGVCdG4pIHtcbiAgICAgICAgICAgIHNlbmRNc2coeyB0eXBlOiAnQ1JFQVRFX1hfVEFCJywgdXJsOiAnaHR0cHM6Ly94LmNvbS8nIH0pLnRoZW4oKHJlc3ApID0+IHtcbiAgICAgICAgICAgICAgICBpZiAocmVzcD8ub2spIHtcbiAgICAgICAgICAgICAgICAgICAgc2VsZWN0ZWRUYWJJZCA9IHJlc3AudGFiSWQ7XG4gICAgICAgICAgICAgICAgICAgIHJlZnJlc2hEYXRhKCk7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICByZXR1cm47XG4gICAgICAgIH1cbiAgICAgICAgLy8gRCDljLrvvJpEZXRhaWxzIOaMiemSriDihpIg5by5IE1vZGFsXG4gICAgICAgIGNvbnN0IGRldGFpbEJ0biA9IHRhcmdldC5jbG9zZXN0KCcuYnRuLWhpdC1kZXRhaWwnKTtcbiAgICAgICAgaWYgKGRldGFpbEJ0bj8uZGF0YXNldC5oaXRJbmRleCAhPT0gdW5kZWZpbmVkKSB7XG4gICAgICAgICAgICBjb25zdCBpZHggPSBwYXJzZUludChkZXRhaWxCdG4uZGF0YXNldC5oaXRJbmRleCk7XG4gICAgICAgICAgICBpZiAoIWlzTmFOKGlkeCkgJiYgY3VycmVudEhpdHNbaWR4XSlcbiAgICAgICAgICAgICAgICBzaG93SGl0TW9kYWwoY3VycmVudEhpdHNbaWR4XSk7XG4gICAgICAgICAgICByZXR1cm47XG4gICAgICAgIH1cbiAgICAgICAgLy8g57uf5LiA5YaZ5pON5L2c5oyJ6ZKu77yIRiDljLrmiYvliqgv5b+r5o235ZCI5bm25pON5L2c77yJXG4gICAgICAgIGNvbnN0IG1hbnVhbEFjdGlvbkJ0biA9IHRhcmdldC5jbG9zZXN0KCcuYnRuLW1hbnVhbC1hY3Rpb24nKTtcbiAgICAgICAgaWYgKG1hbnVhbEFjdGlvbkJ0bj8uZGF0YXNldC50YWJpZCkge1xuICAgICAgICAgICAgY29uc3QgeyBhY3Rpb24sIHRhYmlkIH0gPSBtYW51YWxBY3Rpb25CdG4uZGF0YXNldDtcbiAgICAgICAgICAgIGNvbnN0IGlucHV0RWwgPSBkb2N1bWVudC5nZXRFbGVtZW50QnlJZCgnbWFudWFsLXRhcmdldC1pZCcpO1xuICAgICAgICAgICAgY29uc3QgaW5wdXRWYWwgPSBpbnB1dEVsPy52YWx1ZT8udHJpbSgpO1xuICAgICAgICAgICAgaWYgKGlucHV0VmFsICYmIGFjdGlvbilcbiAgICAgICAgICAgICAgICBkb0FjdGlvbihwYXJzZUludCh0YWJpZCksIGlucHV0VmFsLCBhY3Rpb24sIG1hbnVhbEFjdGlvbkJ0bik7XG4gICAgICAgICAgICBlbHNlIGlmICghaW5wdXRWYWwpXG4gICAgICAgICAgICAgICAgYWxlcnQoXCJQbGVhc2UgZW50ZXIgYSB2YWxpZCB0YXJnZXQgSUQgKFR3ZWV0IElEIG9yIFVzZXIgSUQpIGZpcnN0LlwiKTtcbiAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgfVxuICAgICAgICAvLyBUcmFjayBtYW51YWwgY2hhbmdlcyB0byB0YXJnZXQgSURcbiAgICAgICAgaWYgKHRhcmdldC5pZCA9PT0gJ21hbnVhbC10YXJnZXQtaWQnICYmIHNlbGVjdGVkVGFiSWQgIT09IG51bGwpIHtcbiAgICAgICAgICAgIG1hbnVhbE92ZXJyaWRlcy5zZXQoc2VsZWN0ZWRUYWJJZCwgdHJ1ZSk7XG4gICAgICAgICAgICBpc1Jldmlld0NvbmZpcm1lZCA9IGZhbHNlO1xuICAgICAgICB9XG4gICAgICAgIC8vIFNlbGVjdGlvbiBvZiBSZXBseSBmcm9tIFNuYXBzaG90XG4gICAgICAgIGNvbnN0IHJlcGx5Um93ID0gdGFyZ2V0LmNsb3Nlc3QoJy50Yy1yZXBseS1yb3cnKTtcbiAgICAgICAgaWYgKHJlcGx5Um93Py5kYXRhc2V0LmlkICYmIHNlbGVjdGVkVGFiSWQgIT09IG51bGwpIHtcbiAgICAgICAgICAgIGNvbnN0IHJpZCA9IHJlcGx5Um93LmRhdGFzZXQuaWQ7XG4gICAgICAgICAgICBjb25zdCBjdXJyZW50U2VsZWN0ZWQgPSBzZWxlY3RlZFJlcGx5SWRzLmdldChzZWxlY3RlZFRhYklkKTtcbiAgICAgICAgICAgIGlmIChjdXJyZW50U2VsZWN0ZWQgPT09IHJpZCkge1xuICAgICAgICAgICAgICAgIC8vIFRvZ2dsZSBvZmZcbiAgICAgICAgICAgICAgICBzZWxlY3RlZFJlcGx5SWRzLnNldChzZWxlY3RlZFRhYklkLCBudWxsKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGVsc2Uge1xuICAgICAgICAgICAgICAgIC8vIFNlbGVjdCBuZXdcbiAgICAgICAgICAgICAgICBzZWxlY3RlZFJlcGx5SWRzLnNldChzZWxlY3RlZFRhYklkLCByaWQpO1xuICAgICAgICAgICAgICAgIG1hbnVhbE92ZXJyaWRlcy5zZXQoc2VsZWN0ZWRUYWJJZCwgZmFsc2UpOyAvLyBDbGlja2luZyBhIHJlcGx5IGNsZWFycyBtYW51YWwgb3ZlcnJpZGVcbiAgICAgICAgICAgICAgICBpc1Jldmlld0NvbmZpcm1lZCA9IGZhbHNlO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgcmVmcmVzaERhdGEoKTtcbiAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgfVxuICAgICAgICAvLyBTZWxlY3Rpb24gb2YgUHJvZmlsZSBUd2VldCBmcm9tIFNuYXBzaG90XG4gICAgICAgIGNvbnN0IHByb2ZpbGVUd2VldFJvdyA9IHRhcmdldC5jbG9zZXN0KCcudGMtcHJvZmlsZS10d2VldC1yb3cnKTtcbiAgICAgICAgaWYgKHByb2ZpbGVUd2VldFJvdz8uZGF0YXNldC5pZCAmJiBzZWxlY3RlZFRhYklkICE9PSBudWxsKSB7XG4gICAgICAgICAgICBjb25zdCB0aWQgPSBwcm9maWxlVHdlZXRSb3cuZGF0YXNldC5pZDtcbiAgICAgICAgICAgIGNvbnN0IGN1cnJlbnRTZWxlY3RlZCA9IHNlbGVjdGVkUHJvZmlsZVR3ZWV0SWRzLmdldChzZWxlY3RlZFRhYklkKTtcbiAgICAgICAgICAgIGlmIChjdXJyZW50U2VsZWN0ZWQgPT09IHRpZCkge1xuICAgICAgICAgICAgICAgIC8vIFRvZ2dsZSBvZmZcbiAgICAgICAgICAgICAgICBzZWxlY3RlZFByb2ZpbGVUd2VldElkcy5zZXQoc2VsZWN0ZWRUYWJJZCwgbnVsbCk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBlbHNlIHtcbiAgICAgICAgICAgICAgICAvLyBTZWxlY3QgbmV3XG4gICAgICAgICAgICAgICAgc2VsZWN0ZWRQcm9maWxlVHdlZXRJZHMuc2V0KHNlbGVjdGVkVGFiSWQsIHRpZCk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICByZWZyZXNoRGF0YSgpO1xuICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICB9XG4gICAgICAgIC8vIFJldmlldyBPbmx5IEJ1dHRvblxuICAgICAgICBjb25zdCByZXZpZXdCdG4gPSB0YXJnZXQuY2xvc2VzdCgnI2J0bi1yZXZpZXctb25seScpO1xuICAgICAgICBpZiAocmV2aWV3QnRuICYmIHNlbGVjdGVkVGFiSWQgIT09IG51bGwgJiYgbGFzdFBhZ2VDb250ZXh0KSB7XG4gICAgICAgICAgICBjb25zdCBpbnB1dEVsID0gZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoJ21hbnVhbC10YXJnZXQtaWQnKTtcbiAgICAgICAgICAgIGNvbnN0IGlucHV0VmFsID0gaW5wdXRFbD8udmFsdWU/LnRyaW0oKTtcbiAgICAgICAgICAgIC8vIFJlLWRlcml2ZSB0aGUgdGFyZ2V0IGp1c3QgbGlrZSByZW5kZXJSZXBseURyYWZ0VUlcbiAgICAgICAgICAgIGNvbnN0IGludGVudCA9IGdldEN1cnJlbnRSZXBseUludGVudChzZWxlY3RlZFRhYklkLCBsYXN0UGFnZUNvbnRleHQsIGlucHV0VmFsIHx8ICcnKTtcbiAgICAgICAgICAgIGlzUmV2aWV3Q29uZmlybWVkID0gdHJ1ZTtcbiAgICAgICAgICAgIGxhc3RSZXZpZXdOb3RlID0ge1xuICAgICAgICAgICAgICAgIHRhcmdldElkOiBpbnRlbnQudGFyZ2V0SWQsXG4gICAgICAgICAgICAgICAgdGFyZ2V0VHlwZTogaW50ZW50LnRhcmdldFR5cGUsXG4gICAgICAgICAgICAgICAgZHJhZnRUZXh0OiByZXBseURyYWZ0VGV4dCxcbiAgICAgICAgICAgICAgICB0aW1lc3RhbXA6IERhdGUubm93KCksXG4gICAgICAgICAgICAgICAgcmV2aWV3Q29uZmlybWVkOiB0cnVlXG4gICAgICAgICAgICB9O1xuICAgICAgICAgICAgcmVmcmVzaERhdGEoKTtcbiAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgfVxuICAgIH0pO1xuICAgIC8vIEhhbmRsZSBpbnB1dCBldmVudCBzcGVjaWZpY2FsbHkgZm9yIG1hbnVhbCBvdmVycmlkZSBkZXRlY3Rpb25cbiAgICBkb2N1bWVudC5hZGRFdmVudExpc3RlbmVyKCdpbnB1dCcsIChlKSA9PiB7XG4gICAgICAgIGNvbnN0IHRhcmdldCA9IGUudGFyZ2V0O1xuICAgICAgICBpZiAodGFyZ2V0LmlkID09PSAnbWFudWFsLXRhcmdldC1pZCcgJiYgc2VsZWN0ZWRUYWJJZCAhPT0gbnVsbCkge1xuICAgICAgICAgICAgbWFudWFsT3ZlcnJpZGVzLnNldChzZWxlY3RlZFRhYklkLCB0cnVlKTtcbiAgICAgICAgICAgIGlzUmV2aWV3Q29uZmlybWVkID0gZmFsc2U7XG4gICAgICAgIH1cbiAgICAgICAgaWYgKHRhcmdldC5pZCA9PT0gJ3JlcGx5LWRyYWZ0LXRleHQnKSB7XG4gICAgICAgICAgICByZXBseURyYWZ0VGV4dCA9IHRhcmdldC52YWx1ZTtcbiAgICAgICAgICAgIGlzUmV2aWV3Q29uZmlybWVkID0gZmFsc2U7XG4gICAgICAgICAgICAvLyBBIHNpbXBsZSB0cmljazogdXBkYXRlIHRoZSBwcmV2aWV3IGRpdiBkaXJlY3RseS5cbiAgICAgICAgICAgIGNvbnN0IHByZXZpZXdFbCA9IGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKCdyZXBseS1pbnRlbnQtcHJldmlldy1jb250YWluZXInKTtcbiAgICAgICAgICAgIGlmIChwcmV2aWV3RWwpIHtcbiAgICAgICAgICAgICAgICByZWZyZXNoRGF0YSgpO1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICAgIGlmICh0YXJnZXQuaWQgPT09ICduYXYtdXJsLWlucHV0JyAmJiBzZWxlY3RlZFRhYklkICE9PSBudWxsKSB7XG4gICAgICAgICAgICBuYXZVcmxEcmFmdHMuc2V0KHNlbGVjdGVkVGFiSWQsIHRhcmdldC52YWx1ZSk7XG4gICAgICAgIH1cbiAgICAgICAgaWYgKHRhcmdldC5pZCA9PT0gJ29wZW4tdHdlZXQtc2NyZWVuLW5hbWUnICYmIHNlbGVjdGVkVGFiSWQgIT09IG51bGwpIHtcbiAgICAgICAgICAgIG9wZW5Ud2VldFNjcmVlbk5hbWVEcmFmdHMuc2V0KHNlbGVjdGVkVGFiSWQsIHRhcmdldC52YWx1ZSk7XG4gICAgICAgIH1cbiAgICAgICAgaWYgKHRhcmdldC5pZCA9PT0gJ29wZW4tdHdlZXQtaWQnICYmIHNlbGVjdGVkVGFiSWQgIT09IG51bGwpIHtcbiAgICAgICAgICAgIG9wZW5Ud2VldElkRHJhZnRzLnNldChzZWxlY3RlZFRhYklkLCB0YXJnZXQudmFsdWUpO1xuICAgICAgICB9XG4gICAgfSk7XG59XG4vLyDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIBcbi8vIEJhY2tncm91bmQg5o6o6YCB55uR5ZCsXG4vLyDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIBcbmNocm9tZS5ydW50aW1lLm9uTWVzc2FnZS5hZGRMaXN0ZW5lcigobWVzc2FnZSkgPT4ge1xuICAgIGlmIChtZXNzYWdlLnR5cGUgIT09ICdERUJVR19VUERBVEVfUFVTSCcpXG4gICAgICAgIHJldHVybjtcbiAgICBpZiAoc2VsZWN0ZWRUYWJJZCA9PT0gbnVsbCB8fCBzZWxlY3RlZFRhYklkID09PSBtZXNzYWdlLnRhYklkKSB7XG4gICAgICAgIHJlZnJlc2hEYXRhKCk7XG4gICAgfVxuICAgIGVsc2Uge1xuICAgICAgICByZWZyZXNoVGFiTGlzdE9ubHkoKTtcbiAgICB9XG59KTtcbi8vIOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgFxuLy8gQnJpZGdlIFBpbmdcbi8vIOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgFxuYXN5bmMgZnVuY3Rpb24gY2hlY2tCcmlkZ2UoKSB7XG4gICAgaWYgKHNlbGVjdGVkVGFiSWQgPT09IG51bGwpIHtcbiAgICAgICAgYnJpZGdlT25saW5lID0gZmFsc2U7XG4gICAgICAgIHJldHVybjtcbiAgICB9XG4gICAgdHJ5IHtcbiAgICAgICAgY29uc3QgcmVzcCA9IGF3YWl0IG5ldyBQcm9taXNlKHIgPT4ge1xuICAgICAgICAgICAgY2hyb21lLnRhYnMuc2VuZE1lc3NhZ2Uoc2VsZWN0ZWRUYWJJZCwgeyB0eXBlOiAnVENfUElORycgfSwgcmVzID0+IHtcbiAgICAgICAgICAgICAgICBpZiAoY2hyb21lLnJ1bnRpbWUubGFzdEVycm9yKVxuICAgICAgICAgICAgICAgICAgICByKHsgb2s6IGZhbHNlIH0pO1xuICAgICAgICAgICAgICAgIGVsc2VcbiAgICAgICAgICAgICAgICAgICAgcihyZXMgfHwgeyBvazogZmFsc2UgfSk7XG4gICAgICAgICAgICB9KTtcbiAgICAgICAgfSk7XG4gICAgICAgIGJyaWRnZU9ubGluZSA9ICEhKHJlc3A/Lm9rKTtcbiAgICB9XG4gICAgY2F0Y2gge1xuICAgICAgICBicmlkZ2VPbmxpbmUgPSBmYWxzZTtcbiAgICB9XG59XG4vLyDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIBcbi8vIOaVsOaNruaLieWPllxuLy8g4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSAXG5hc3luYyBmdW5jdGlvbiByZWZyZXNoVGFiTGlzdE9ubHkoKSB7XG4gICAgdGFiTGlzdCA9IGF3YWl0IHNlbmRNc2coeyB0eXBlOiAnTElTVF9BTExfWF9UQUJTJyB9KSB8fCBbXTtcbiAgICByZW5kZXJUYWJMaXN0KCk7XG4gICAgcmVuZGVyU2lkZWJhckVudigpO1xufVxuYXN5bmMgZnVuY3Rpb24gcmVmcmVzaERhdGEoKSB7XG4gICAgdHJ5IHtcbiAgICAgICAgdGFiTGlzdCA9IGF3YWl0IHNlbmRNc2coeyB0eXBlOiAnTElTVF9BTExfWF9UQUJTJyB9KSB8fCBbXTtcbiAgICAgICAgLy8g6aqM6K+B5b2T5YmN6YCJ5Lit55qEIHRhYiDov5jmmK/lkKblrZjlnKhcbiAgICAgICAgaWYgKHNlbGVjdGVkVGFiSWQgIT09IG51bGwpIHtcbiAgICAgICAgICAgIGNvbnN0IGV4aXN0cyA9IHRhYkxpc3Quc29tZSh0ID0+IHQuaWQgPT09IHNlbGVjdGVkVGFiSWQpO1xuICAgICAgICAgICAgaWYgKCFleGlzdHMpXG4gICAgICAgICAgICAgICAgc2VsZWN0ZWRUYWJJZCA9IG51bGw7XG4gICAgICAgIH1cbiAgICAgICAgLy8g5aaC5p6c5rKh5pyJ6YCJ5Lit5LiU5pyJ5Y+v55SoIHRhYu+8jOm7mOiupOmAieesrOS4gOS4qlxuICAgICAgICBpZiAoc2VsZWN0ZWRUYWJJZCA9PT0gbnVsbCAmJiB0YWJMaXN0Lmxlbmd0aCA+IDApIHtcbiAgICAgICAgICAgIHNlbGVjdGVkVGFiSWQgPSB0YWJMaXN0WzBdLmlkO1xuICAgICAgICB9XG4gICAgICAgIHJlbmRlclRhYkxpc3QoKTtcbiAgICAgICAgaWYgKHNlbGVjdGVkVGFiSWQgIT09IG51bGwpIHtcbiAgICAgICAgICAgIGNvbnN0IGRldGFpbCA9IGF3YWl0IHNlbmRNc2coeyB0eXBlOiAnR0VUX1RBQl9EQVRBJywgdGFiSWQ6IHNlbGVjdGVkVGFiSWQgfSk7XG4gICAgICAgICAgICBjb25zdCBwYWdlQ29udGV4dCA9IGF3YWl0IHNlbmRNc2coeyB0eXBlOiAnR0VUX1BBR0VfQ09OVEVYVCcsIHRhYklkOiBzZWxlY3RlZFRhYklkIH0pO1xuICAgICAgICAgICAgYXdhaXQgY2hlY2tCcmlkZ2UoKTtcbiAgICAgICAgICAgIC8vIC0tLSBGb2N1cyBQcmVzZXJ2YXRpb24gU3RhcnQgLS0tXG4gICAgICAgICAgICBjb25zdCBhY3RpdmVJZCA9IGRvY3VtZW50LmFjdGl2ZUVsZW1lbnQ/LmlkO1xuICAgICAgICAgICAgY29uc3Qgc2VsZWN0aW9uU3RhcnQgPSBkb2N1bWVudC5hY3RpdmVFbGVtZW50Py5zZWxlY3Rpb25TdGFydDtcbiAgICAgICAgICAgIGNvbnN0IHNlbGVjdGlvbkVuZCA9IGRvY3VtZW50LmFjdGl2ZUVsZW1lbnQ/LnNlbGVjdGlvbkVuZDtcbiAgICAgICAgICAgIC8vIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG4gICAgICAgICAgICBsYXN0UGFnZUNvbnRleHQgPSBwYWdlQ29udGV4dDtcbiAgICAgICAgICAgIHJlbmRlckRldGFpbFZpZXcoZGV0YWlsIHx8IHt9LCBwYWdlQ29udGV4dCB8fCB7fSk7XG4gICAgICAgICAgICAvLyAtLS0gRm9jdXMgUHJlc2VydmF0aW9uIEVuZCAtLS1cbiAgICAgICAgICAgIGlmIChhY3RpdmVJZCkge1xuICAgICAgICAgICAgICAgIGNvbnN0IGVsID0gZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoYWN0aXZlSWQpO1xuICAgICAgICAgICAgICAgIGlmIChlbCkge1xuICAgICAgICAgICAgICAgICAgICBlbC5mb2N1cygpO1xuICAgICAgICAgICAgICAgICAgICBpZiAoc2VsZWN0aW9uU3RhcnQgIT09IHVuZGVmaW5lZCAmJiBzZWxlY3Rpb25TdGFydCAhPT0gbnVsbCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgZWwuc2V0U2VsZWN0aW9uUmFuZ2Uoc2VsZWN0aW9uU3RhcnQsIHNlbGVjdGlvbkVuZCB8fCBzZWxlY3Rpb25TdGFydCk7XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICAvLyAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cbiAgICAgICAgfVxuICAgICAgICBlbHNlIHtcbiAgICAgICAgICAgIHJlbmRlckVtcHR5U3RhdGUoKTtcbiAgICAgICAgfVxuICAgICAgICByZW5kZXJTaWRlYmFyRW52KCk7XG4gICAgfVxuICAgIGNhdGNoIChlKSB7XG4gICAgICAgIGNvbnNvbGUuZXJyb3IoJ1tUd2VldENsYXctRGVidWddIHJlZnJlc2hEYXRhIGVycm9yOicsIGUpO1xuICAgIH1cbn1cbmZ1bmN0aW9uIHNlbmRNc2cobXNnKSB7XG4gICAgcmV0dXJuIG5ldyBQcm9taXNlKHJlc29sdmUgPT4ge1xuICAgICAgICBjaHJvbWUucnVudGltZS5zZW5kTWVzc2FnZShtc2csIHJlcyA9PiB7XG4gICAgICAgICAgICBpZiAoY2hyb21lLnJ1bnRpbWUubGFzdEVycm9yKSB7XG4gICAgICAgICAgICAgICAgY29uc29sZS53YXJuKCdbVHdlZXRDbGF3LURlYnVnXSBzZW5kTWVzc2FnZSBlcnJvcjonLCBjaHJvbWUucnVudGltZS5sYXN0RXJyb3IubWVzc2FnZSk7XG4gICAgICAgICAgICAgICAgcmVzb2x2ZShudWxsKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGVsc2Uge1xuICAgICAgICAgICAgICAgIHJlc29sdmUocmVzKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfSk7XG4gICAgfSk7XG59XG4vLyDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIBcbi8vIOS+p+i+ueagj++8mlRhYiDliJfooahcbi8vIOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgFxuZnVuY3Rpb24gcmVuZGVyVGFiTGlzdCgpIHtcbiAgICBjb25zdCBjb250YWluZXIgPSBkb2N1bWVudC5nZXRFbGVtZW50QnlJZCgndGFiLWxpc3QnKTtcbiAgICBpZiAoIWNvbnRhaW5lcilcbiAgICAgICAgcmV0dXJuO1xuICAgIC8vIEFkZCBDcmVhdGUgVGFiIGJ1dHRvbiBhdCB0aGUgdG9wXG4gICAgbGV0IGh0bWwgPSBgXG4gICAgPGRpdiBjbGFzcz1cIm1iLTMgcHgtMVwiPlxuICAgICAgICA8YnV0dG9uIGlkPVwiYnRuLWNyZWF0ZS10YWJcIiBjbGFzcz1cImJ0biBidG4tcHJpbWFyeSBidG4tc20gdy0xMDBcIiBzdHlsZT1cImZvbnQtc2l6ZToxMXB4O1wiPisgT3BlbiB4LmNvbTwvYnV0dG9uPlxuICAgIDwvZGl2PmA7XG4gICAgaWYgKHRhYkxpc3QubGVuZ3RoID09PSAwKSB7XG4gICAgICAgIGh0bWwgKz0gYDxkaXYgY2xhc3M9XCJ0ZXh0LW11dGVkIHNtYWxsIHAtMlwiPk5vIFggdGFicyBvcGVuLjwvZGl2PmA7XG4gICAgICAgIGNvbnRhaW5lci5pbm5lckhUTUwgPSBodG1sO1xuICAgICAgICByZXR1cm47XG4gICAgfVxuICAgIGh0bWwgKz0gdGFiTGlzdC5tYXAodCA9PiB7XG4gICAgICAgIGNvbnN0IGlzU2VsZWN0ZWQgPSB0LmlkID09PSBzZWxlY3RlZFRhYklkO1xuICAgICAgICAvLyDkvJjlhYjnlKjotKblj7cgaGFuZGxl77yM5ZCm5YiZ5LuOIFVSTCDmj5Dlj5bmnInmhI/kuYnnmoTot6/lvoTmoIfor4ZcbiAgICAgICAgY29uc3QgaWRlbnRpdHkgPSB0LmFjY291bnQ/LmhhbmRsZSB8fCB1cmxMYWJlbCh0LnVybCk7XG4gICAgICAgIGNvbnN0IHJLaW5kID0gcGFyc2VSb3V0ZUtpbmQodC51cmwpO1xuICAgICAgICByZXR1cm4gYFxuICAgICAgICA8ZGl2IGNsYXNzPVwidGFiLWl0ZW0gJHtpc1NlbGVjdGVkID8gJ2FjdGl2ZScgOiAnJ31cIiBkYXRhLWlkPVwiJHt0LmlkfVwiPlxuICAgICAgICAgICAgPGRpdiBjbGFzcz1cImQtZmxleCBqdXN0aWZ5LWNvbnRlbnQtYmV0d2VlbiBhbGlnbi1pdGVtcy1jZW50ZXIgbWItMVwiPlxuICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzPVwiZnctYm9sZCBzbWFsbCAke2lzU2VsZWN0ZWQgPyAndGV4dC13aGl0ZScgOiAndGV4dC1pbmZvJ31cIj4ke2lkZW50aXR5fTwvc3Bhbj5cbiAgICAgICAgICAgICAgICA8c3BhbiBjbGFzcz1cInN0YXR1cy1iYWRnZSAke3QuYWN0aXZlID8gJ2JnLXN1Y2Nlc3Mtc3VidGxlJyA6ICdiZy1zZWNvbmRhcnknfVwiPiR7dC5hY3RpdmUgPyAnQUNUSVZFJyA6ICdJRExFJ308L3NwYW4+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJ0ZXh0LXRydW5jYXRlXCIgc3R5bGU9XCJvcGFjaXR5Oi42O2ZvbnQtc2l6ZToxMHB4O1wiPlRBQiAke3QuaWR9IMK3ICR7cktpbmQudG9VcHBlckNhc2UoKX08L2Rpdj5cbiAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJkLWZsZXggZ2FwLTEgbXQtMlwiPlxuICAgICAgICAgICAgICAgIDxidXR0b24gY2xhc3M9XCJidG4gYnRuLW91dGxpbmUtaW5mbyBidG4teHMgYnRuLXRhYi1mb2N1c1wiIGRhdGEtaWQ9XCIke3QuaWR9XCIgc3R5bGU9XCJmb250LXNpemU6OXB4OyBwYWRkaW5nOjFweCA2cHg7XCI+Rm9jdXM8L2J1dHRvbj5cbiAgICAgICAgICAgICAgICA8YnV0dG9uIGNsYXNzPVwiYnRuIGJ0bi1vdXRsaW5lLWRhbmdlciBidG4teHMgYnRuLXRhYi1jbG9zZVwiIGRhdGEtaWQ9XCIke3QuaWR9XCIgc3R5bGU9XCJmb250LXNpemU6OXB4OyBwYWRkaW5nOjFweCA2cHg7XCI+Q2xvc2U8L2J1dHRvbj5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICA8L2Rpdj5gO1xuICAgIH0pLmpvaW4oJycpO1xuICAgIGNvbnRhaW5lci5pbm5lckhUTUwgPSBodG1sO1xufVxuLy8g4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSAXG4vLyDkvqfovrnmoI/vvJrmiafooYznjq/looNcbi8vIOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgFxuZnVuY3Rpb24gcmVuZGVyU2lkZWJhckVudigpIHtcbiAgICBjb25zdCBlbCA9IGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKCdzaWRlYmFyLWVudicpO1xuICAgIGlmICghZWwpXG4gICAgICAgIHJldHVybjtcbiAgICBsZXQgaHRtbCA9IGBcbiAgICAgICAgPGRpdiBjbGFzcz1cInN5cy1zdGF0XCI+PHNwYW4+V3JpdGUgUG9saWN5PC9zcGFuPjxzcGFuIGNsYXNzPVwidmFsIHRleHQtc3VjY2Vzc1wiPkNvbnRlbnQgU2NyaXB0IOKckzwvc3Bhbj48L2Rpdj5cbiAgICAgICAgPGRpdiBjbGFzcz1cInN5cy1zdGF0XCI+PHNwYW4+RXhlYyBCcmlkZ2U8L3NwYW4+XG4gICAgICAgICAgICA8c3BhbiBjbGFzcz1cInZhbCAke2JyaWRnZU9ubGluZSA/ICd0ZXh0LXN1Y2Nlc3MnIDogJ3RleHQtZGFuZ2VyJ31cIj4ke2JyaWRnZU9ubGluZSA/ICdPTkxJTkUg4pyTJyA6ICdPRkZMSU5FIOKclyd9PC9zcGFuPlxuICAgICAgICA8L2Rpdj5cbiAgICAgICAgPGRpdiBjbGFzcz1cInN5cy1zdGF0XCI+PHNwYW4+SW5qZWN0IFJvbGU8L3NwYW4+PHNwYW4gY2xhc3M9XCJ2YWwgdGV4dC13YXJuaW5nXCI+UGFzc2l2ZSBTZW5zb3I8L3NwYW4+PC9kaXY+XG4gICAgICAgIDxkaXYgY2xhc3M9XCJzeXMtc3RhdFwiPjxzcGFuPkluamVjdCBXcml0ZXM8L3NwYW4+PHNwYW4gY2xhc3M9XCJ2YWwgdGV4dC1zdWNjZXNzXCI+Tm9uZSDinJM8L3NwYW4+PC9kaXY+YDtcbiAgICBpZiAobGFzdFJldmlld05vdGUpIHtcbiAgICAgICAgY29uc3QgdGltZVN0ciA9IG5ldyBEYXRlKGxhc3RSZXZpZXdOb3RlLnRpbWVzdGFtcCkudG9Mb2NhbGVUaW1lU3RyaW5nKCk7XG4gICAgICAgIGh0bWwgKz0gYFxuICAgICAgICAgICAgPGRpdiBjbGFzcz1cIm10LTMgcHQtMiBib3JkZXItdG9wIGJvcmRlci1zZWNvbmRhcnlcIiBzdHlsZT1cImZvbnQtc2l6ZTo5cHg7IGxpbmUtaGVpZ2h0OjEuMlwiPlxuICAgICAgICAgICAgICAgIDxkaXYgc3R5bGU9XCJjb2xvcjojYTBhZWMwOyB0ZXh0LXRyYW5zZm9ybTp1cHBlcmNhc2U7IGZvbnQtd2VpZ2h0OjcwMDsgbWFyZ2luLWJvdHRvbToycHhcIj5MYXN0IFJldmlldyBOb3RlPC9kaXY+XG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzcz1cInRleHQtaW5mb1wiPiR7bGFzdFJldmlld05vdGUudGFyZ2V0VHlwZS50b1VwcGVyQ2FzZSgpfSAoJHtsYXN0UmV2aWV3Tm90ZS50YXJnZXRJZH0pPC9kaXY+XG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzcz1cInRleHQtdHJ1bmNhdGVcIiBzdHlsZT1cIm9wYWNpdHk6MC44XCI+VGV4dDogJHtsYXN0UmV2aWV3Tm90ZS5kcmFmdFRleHQgfHwgJ+KAlCd9PC9kaXY+XG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzcz1cInRleHQtbXV0ZWRcIiBzdHlsZT1cImZvbnQtc2l6ZTo4cHhcIj5hdCAke3RpbWVTdHJ9PC9kaXY+XG4gICAgICAgICAgICA8L2Rpdj5gO1xuICAgIH1cbiAgICBlbC5pbm5lckhUTUwgPSBodG1sO1xufVxuLy8g4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSAXG4vLyDnqbrnirbmgIFcbi8vIOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgFxuZnVuY3Rpb24gcmVuZGVyRW1wdHlTdGF0ZSgpIHtcbiAgICBjb25zdCBjID0gZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoJ3RhYi1kYXRhLXZpZXcnKTtcbiAgICBpZiAoYylcbiAgICAgICAgYy5pbm5lckhUTUwgPSBgXG4gICAgICAgIDxkaXYgY2xhc3M9XCJ0ZXh0LWNlbnRlciBtdC01IHRleHQtbXV0ZWRcIj5cbiAgICAgICAgICAgIDxoND5ObyBYIHRhYiBzZWxlY3RlZDwvaDQ+XG4gICAgICAgICAgICA8cCBjbGFzcz1cInNtYWxsXCI+T3BlbiB4LmNvbSBhbmQgc2VsZWN0IGEgdGFiIG9uIHRoZSBsZWZ0PC9wPlxuICAgICAgICA8L2Rpdj5gO1xufVxuLy8g4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSAXG4vLyDlt6Xlhbflh73mlbBcbi8vIOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgFxuLyoqXG4gKiDku44gWC9Ud2l0dGVyIHRhYiBVUkwg5o+Q5Y+W566A55+t5Y+v6K+75qCH6K+G44CCXG4gKiDkvovvvJpodHRwczovL3guY29tL2hvbWUgICAgICAgICAg4oaSIFwieC5jb20vaG9tZVwiXG4gKiAgICAgaHR0cHM6Ly94LmNvbS9jb2Rlci9zdGF0dXMg4oaSIFwieC5jb20vY29kZXJcIlxuICogICAgIGh0dHBzOi8vdHdpdHRlci5jb20v4oCmICAgICAg4oaSIFwidHdpdHRlci5jb20v4oCmXCJcbiAqL1xuZnVuY3Rpb24gdXJsTGFiZWwodXJsKSB7XG4gICAgaWYgKCF1cmwpXG4gICAgICAgIHJldHVybiAnWCBUYWInO1xuICAgIHRyeSB7XG4gICAgICAgIGNvbnN0IHUgPSBuZXcgVVJMKHVybCk7XG4gICAgICAgIGNvbnN0IHBhcnRzID0gdS5wYXRobmFtZS5zcGxpdCgnLycpLmZpbHRlcihCb29sZWFuKTsgLy8gWydob21lJ10gb3IgWyd1c2VyJywnc3RhdHVzJywnaWQnXVxuICAgICAgICBjb25zdCBzbHVnID0gcGFydHMubGVuZ3RoID4gMCA/IGAvJHtwYXJ0c1swXX1gIDogJyc7XG4gICAgICAgIHJldHVybiB1Lmhvc3RuYW1lLnJlcGxhY2UoJ3d3dy4nLCAnJykgKyBzbHVnO1xuICAgIH1cbiAgICBjYXRjaCB7XG4gICAgICAgIHJldHVybiAnWCBUYWInO1xuICAgIH1cbn1cbmZ1bmN0aW9uIGZtdFRpbWUodHMpIHtcbiAgICBpZiAoIXRzKVxuICAgICAgICByZXR1cm4gJ+KAlCc7XG4gICAgY29uc3Qgc2VjID0gTWF0aC5yb3VuZCgoRGF0ZS5ub3coKSAtIHRzKSAvIDEwMDApO1xuICAgIGlmIChzZWMgPCA1KVxuICAgICAgICByZXR1cm4gJ2p1c3Qgbm93JztcbiAgICBpZiAoc2VjIDwgNjApXG4gICAgICAgIHJldHVybiBgJHtzZWN9cyBhZ29gO1xuICAgIGlmIChzZWMgPCAzNjAwKVxuICAgICAgICByZXR1cm4gYCR7TWF0aC5mbG9vcihzZWMgLyA2MCl9bSBhZ29gO1xuICAgIHJldHVybiBuZXcgRGF0ZSh0cykudG9Mb2NhbGVUaW1lU3RyaW5nKCk7XG59XG5mdW5jdGlvbiBiYWRnZShvaywgdCA9ICdBQ1RJVkUnLCBmID0gJ09GRkxJTkUnKSB7XG4gICAgcmV0dXJuIG9rXG4gICAgICAgID8gYDxzcGFuIGNsYXNzPVwiYmFkZ2UgYmctc3VjY2Vzc1wiPiR7dH08L3NwYW4+YFxuICAgICAgICA6IGA8c3BhbiBjbGFzcz1cImJhZGdlIGJnLWRhbmdlclwiPiR7Zn08L3NwYW4+YDtcbn1cbmZ1bmN0aW9uIHRydW5jYXRlKHMsIG4gPSAxMjApIHtcbiAgICBpZiAoIXMpXG4gICAgICAgIHJldHVybiAn4oCUJztcbiAgICByZXR1cm4gcy5sZW5ndGggPiBuID8gcy5zbGljZSgwLCBuKSArICfigKYnIDogcztcbn1cbmZ1bmN0aW9uIG5GbXQobnVtKSB7XG4gICAgaWYgKG51bSA9PT0gbnVsbCB8fCBudW0gPT09IHVuZGVmaW5lZClcbiAgICAgICAgcmV0dXJuICfigJQnO1xuICAgIGlmICh0eXBlb2YgbnVtID09PSAnc3RyaW5nJylcbiAgICAgICAgcmV0dXJuIG51bTtcbiAgICBpZiAobnVtID49IDEwMDAwMDApXG4gICAgICAgIHJldHVybiAobnVtIC8gMTAwMDAwMCkudG9GaXhlZCgxKSArICdNJztcbiAgICBpZiAobnVtID49IDEwMDApXG4gICAgICAgIHJldHVybiAobnVtIC8gMTAwMCkudG9GaXhlZCgxKSArICdrJztcbiAgICByZXR1cm4gbnVtLnRvU3RyaW5nKCk7XG59XG5mdW5jdGlvbiBzYWZlSnNvbihvYmosIGluZGVudCA9IDIpIHtcbiAgICB0cnkge1xuICAgICAgICByZXR1cm4gSlNPTi5zdHJpbmdpZnkob2JqLCBudWxsLCBpbmRlbnQpO1xuICAgIH1cbiAgICBjYXRjaCB7XG4gICAgICAgIHJldHVybiBTdHJpbmcob2JqKTtcbiAgICB9XG59XG5mdW5jdGlvbiByZXFTdW1tYXJ5KG9iaikge1xuICAgIGlmICghb2JqKVxuICAgICAgICByZXR1cm4gJ+KAlCc7XG4gICAgaWYgKHR5cGVvZiBvYmogPT09ICdzdHJpbmcnKVxuICAgICAgICByZXR1cm4gdHJ1bmNhdGUob2JqLCA4MCk7XG4gICAgY29uc3Qga2V5cyA9IE9iamVjdC5rZXlzKG9iaikuc2xpY2UoMCwgNCkuam9pbignLCAnKTtcbiAgICByZXR1cm4gYHske2tleXN9JHtPYmplY3Qua2V5cyhvYmopLmxlbmd0aCA+IDQgPyAn4oCmJyA6ICcnfX1gO1xufVxuLy8g4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSAXG4vLyBTY2VuZSBDYXJkIOa4suafk1xuLy8g4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSAXG5mdW5jdGlvbiByZW5kZXJTY2VuZUNhcmQoY29udGV4dCkge1xuICAgIGlmICghY29udGV4dClcbiAgICAgICAgcmV0dXJuICcnO1xuICAgIGNvbnN0IHNjZW5lTmFtZSA9IChjb250ZXh0LnNjZW5lIHx8ICdVTktOT1dOJykudG9VcHBlckNhc2UoKS5yZXBsYWNlKC9fL2csICcgJyk7XG4gICAgY29uc3Qgcm91dGVOYW1lID0gKGNvbnRleHQucm91dGVLaW5kIHx8ICdOT05FJykudG9VcHBlckNhc2UoKTtcbiAgICAvLyDlpoLmnpzkuI3mmK8gWCDpobXpnaLvvIznroDljJbmmL7npLpcbiAgICBpZiAoY29udGV4dC5zY2VuZSA9PT0gJ25vdF94Jykge1xuICAgICAgICByZXR1cm4gYFxuICAgICAgICAgICAgPGRpdiBjbGFzcz1cImNhcmQgbWItMyBib3JkZXItc2Vjb25kYXJ5XCI+XG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzcz1cImNhcmQtYm9keSBweS0yIHRleHQtY2VudGVyIHRleHQtbXV0ZWQgc21hbGxcIj5cbiAgICAgICAgICAgICAgICAgICAgQ3VycmVudCB0YWIgaXMgbm90IG9uIFggd29ya3NwYWNlLlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgPC9kaXY+YDtcbiAgICB9XG4gICAgcmV0dXJuIGBcbiAgICAgICAgPGRpdiBjbGFzcz1cImNhcmQgbWItM1wiPlxuICAgICAgICAgICAgPGRpdiBjbGFzcz1cImNhcmQtaGVhZGVyIGQtZmxleCBqdXN0aWZ5LWNvbnRlbnQtYmV0d2VlbiBhbGlnbi1pdGVtcy1jZW50ZXJcIj5cbiAgICAgICAgICAgICAgICA8c3BhbiBjbGFzcz1cInRleHQtaW5mbyBmdy1ib2xkXCI+U0NFTkU6ICR7c2NlbmVOYW1lfTwvc3Bhbj5cbiAgICAgICAgICAgICAgICA8c3BhbiBjbGFzcz1cImJhZGdlIGJnLWRhcmsgdGV4dC1pbmZvIGJvcmRlciBib3JkZXItaW5mb1wiIHN0eWxlPVwiZm9udC1zaXplOjEwcHhcIj5ST1VURTogJHtyb3V0ZU5hbWV9PC9zcGFuPlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICA8ZGl2IGNsYXNzPVwiY2FyZC1ib2R5IHB5LTFcIj5cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzPVwic3lzLXN0YXRcIj48c3Bhbj5VUkw8L3NwYW4+PHNwYW4gY2xhc3M9XCJ2YWwgdGV4dC10cnVuY2F0ZVwiIHN0eWxlPVwibWF4LXdpZHRoOjI2MHB4OyBmb250LXNpemU6MTBweDsgb3BhY2l0eTowLjdcIj4ke2NvbnRleHQuY3VycmVudFVybCB8fCAn4oCUJ308L3NwYW4+PC9kaXY+XG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzcz1cIm10LTJcIiBzdHlsZT1cImZvbnQtc2l6ZToxMHB4OyBjb2xvcjojY2JkNWUwOyB0ZXh0LXRyYW5zZm9ybTp1cHBlcmNhc2U7IGZvbnQtd2VpZ2h0OjcwMDsgbGV0dGVyLXNwYWNpbmc6MC41cHhcIj5DYXBhYmlsaXRpZXM8L2Rpdj5cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzPVwiZC1mbGV4IGZsZXgtd3JhcCBnYXAtMSBtdC0xIG1iLTJcIj5cbiAgICAgICAgICAgICAgICAgICAgJHsoY29udGV4dC5hdmFpbGFibGVBY3Rpb25zIHx8IFtdKS5tYXAoKGEpID0+IGA8c3BhbiBjbGFzcz1cImJhZGdlIGJnLWluZm8gdGV4dC1kYXJrXCIgc3R5bGU9XCJmb250LXNpemU6OXB4OyBvcGFjaXR5OjAuOTsgZm9udC13ZWlnaHQ6NjAwXCI+JHthfTwvc3Bhbj5gKS5qb2luKCcnKX1cbiAgICAgICAgICAgICAgICAgICAgJHsoY29udGV4dC5hdmFpbGFibGVBY3Rpb25zIHx8IFtdKS5sZW5ndGggPT09IDAgPyAnPHNwYW4gY2xhc3M9XCJ0ZXh0LW11dGVkIHNtYWxsXCI+Tm9uZTwvc3Bhbj4nIDogJyd9XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgPC9kaXY+YDtcbn1cbmZ1bmN0aW9uIHJlbmRlck1pc21hdGNoV2FybmluZyh0aWQsIHBhZ2VDb250ZXh0KSB7XG4gICAgY29uc3QgbGFzdFJlcXVlc3QgPSBsYXN0T3BlblR3ZWV0UmVxdWVzdHMuZ2V0KHRpZCk7XG4gICAgaWYgKCFsYXN0UmVxdWVzdClcbiAgICAgICAgcmV0dXJuICcnO1xuICAgIC8vIElmIHdlJ3ZlIG5hdmlnYXRlZCBhd2F5IGZyb20gdHdlZXRfZGV0YWlsLCBjbGVhciB0aGUgcmVxdWVzdFxuICAgIGlmIChwYWdlQ29udGV4dC5zY2VuZSAhPT0gJ3R3ZWV0X2RldGFpbCcpIHtcbiAgICAgICAgbGFzdE9wZW5Ud2VldFJlcXVlc3RzLmRlbGV0ZSh0aWQpO1xuICAgICAgICByZXR1cm4gJyc7XG4gICAgfVxuICAgIGNvbnN0IGN1cnJlbnRFbnRpdHkgPSBwYWdlQ29udGV4dC5jdXJyZW50RW50aXR5O1xuICAgIGNvbnN0IGN1cnJlbnRIYW5kbGUgPSBjdXJyZW50RW50aXR5Py5hdXRob3JIYW5kbGU7XG4gICAgY29uc3QgY3VycmVudElkID0gY3VycmVudEVudGl0eT8uZW50aXR5SWQ7XG4gICAgLy8gSWYgd2UgaGF2ZSBhbiBlbnRpdHkgSUQgYW5kIGl0IGRvZXNuJ3QgbWF0Y2ggdGhlIHJlcXVlc3RlZCBvbmUsIFxuICAgIC8vIGl0IG1lYW5zIHRoZSB1c2VyIGhhcyBuYXZpZ2F0ZWQgYXdheSBmcm9tIHRoZSByZXF1ZXN0ZWQgdHdlZXQuXG4gICAgaWYgKGN1cnJlbnRJZCAmJiBjdXJyZW50SWQgIT09IGxhc3RSZXF1ZXN0LnR3ZWV0SWQpIHtcbiAgICAgICAgbGFzdE9wZW5Ud2VldFJlcXVlc3RzLmRlbGV0ZSh0aWQpO1xuICAgICAgICByZXR1cm4gJyc7XG4gICAgfVxuICAgIGlmICghY3VycmVudEhhbmRsZSlcbiAgICAgICAgcmV0dXJuICcnO1xuICAgIGNvbnN0IGNsZWFuUmVxdWVzdGVkID0gbGFzdFJlcXVlc3Quc2NyZWVuTmFtZS5yZXBsYWNlKCdAJywgJycpLnRvTG93ZXJDYXNlKCk7XG4gICAgY29uc3QgY2xlYW5BY3R1YWwgPSBjdXJyZW50SGFuZGxlLnJlcGxhY2UoJ0AnLCAnJykudG9Mb3dlckNhc2UoKTtcbiAgICBpZiAoY2xlYW5SZXF1ZXN0ZWQgIT09IGNsZWFuQWN0dWFsKSB7XG4gICAgICAgIHJldHVybiBgXG4gICAgICAgICAgICA8ZGl2IGNsYXNzPVwiYWxlcnQgYWxlcnQtd2FybmluZyBweS0yIHB4LTMgbWItMyBib3JkZXItd2FybmluZ1wiIHN0eWxlPVwiZm9udC1zaXplOiAxMXB4OyBiYWNrZ3JvdW5kOiByZ2JhKDI1NSwgMTkzLCA3LCAwLjEpO1wiPlxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJmdy1ib2xkIG1iLTFcIj7imqAgQVVUSE9SIE1JU01BVENIIFdBUk5JTkc8L2Rpdj5cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzPVwiZC1mbGV4IGZsZXgtY29sdW1uIGdhcC0xXCI+XG4gICAgICAgICAgICAgICAgICAgIDxkaXY+UmVxdWVzdGVkOiA8c3BhbiBjbGFzcz1cInRleHQtaW5mb1wiPkAke2xhc3RSZXF1ZXN0LnNjcmVlbk5hbWUucmVwbGFjZSgnQCcsICcnKX08L3NwYW4+PC9kaXY+XG4gICAgICAgICAgICAgICAgICAgIDxkaXY+UmVzb2x2ZWQ6IDxzcGFuIGNsYXNzPVwidGV4dC13YXJuaW5nXCI+QCR7Y3VycmVudEhhbmRsZS5yZXBsYWNlKCdAJywgJycpfTwvc3Bhbj48L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzcz1cIm10LTEgb3BhY2l0eS03NVwiPk5hdmlnYXRlZCBzdWNjZXNzZnVsbHksIGJ1dCBhdXRob3IgZG9lcyBub3QgbWF0Y2ggcmVxdWVzdGVkIHNjcmVlbk5hbWUuPC9kaXY+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICA8L2Rpdj5gO1xuICAgIH1cbiAgICByZXR1cm4gJyc7XG59XG4vLyDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIBcbi8vIEVudGl0eSBDYXJkIOa4suafkyAoTkVXKVxuLy8g4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSAXG4vLyDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIBcbi8vIEVudGl0eSBDYXJkIOa4suafkyAoTkVXKVxuLy8g4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSAXG5mdW5jdGlvbiByZW5kZXJFbnRpdHlDYXJkKGVudGl0eSwgc2NlbmUpIHtcbiAgICBpZiAoc2NlbmUgIT09ICd0d2VldF9kZXRhaWwnICYmIHNjZW5lICE9PSAncHJvZmlsZScpIHtcbiAgICAgICAgcmV0dXJuIGBcbiAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJjYXJkIG1iLTMgb3BhY2l0eS03NVwiPlxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJjYXJkLWhlYWRlciBkLWZsZXgganVzdGlmeS1jb250ZW50LWJldHdlZW4gYWxpZ24taXRlbXMtY2VudGVyXCI+XG4gICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzPVwidGV4dC1tdXRlZCBmdy1ib2xkXCI+Q1VSUkVOVCBFTlRJVFk8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzPVwidGV4dC1tdXRlZFwiIHN0eWxlPVwiZm9udC1zaXplOjEwcHhcIj5OL0EgRk9SIFRISVMgU0NFTkU8L3NwYW4+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzcz1cImNhcmQtYm9keSBweS0zIHRleHQtY2VudGVyIHRleHQtbXV0ZWQgaXRhbGljXCIgc3R5bGU9XCJmb250LXNpemU6MTFweFwiPlxuICAgICAgICAgICAgICAgICAgICBFbnRpdHkgc2VsZWN0aW9uIGlzIGFjdGl2ZSBvbmx5IGluIDxzdHJvbmc+VHdlZXQgRGV0YWlsPC9zdHJvbmc+IG9yIDxzdHJvbmc+UHJvZmlsZTwvc3Ryb25nPiB2aWV3cy5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIDwvZGl2PmA7XG4gICAgfVxuICAgIGlmICghZW50aXR5KSB7XG4gICAgICAgIHJldHVybiBgXG4gICAgICAgICAgICA8ZGl2IGNsYXNzPVwiY2FyZCBtYi0zIGJvcmRlci13YXJuaW5nXCI+XG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzcz1cImNhcmQtaGVhZGVyIHRleHQtd2FybmluZyBmdy1ib2xkXCI+Q1VSUkVOVCBFTlRJVFk6IFBFTkRJTkc8L2Rpdj5cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzPVwiY2FyZC1ib2R5IHB5LTMgdGV4dC1jZW50ZXIgdGV4dC1tdXRlZCBpdGFsaWNcIiBzdHlsZT1cImZvbnQtc2l6ZToxMXB4XCI+XG4gICAgICAgICAgICAgICAgICAgIElkZW50aWZ5aW5nIGVudGl0eSBkZXRhaWxzLi4uIFNjcm9sbCBvciBpbnRlcmFjdCB3aXRoIHRoZSBwYWdlLlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgPC9kaXY+YDtcbiAgICB9XG4gICAgaWYgKGVudGl0eS5lbnRpdHlUeXBlICE9PSAndHdlZXQnKVxuICAgICAgICByZXR1cm4gJyc7XG4gICAgY29uc3QgaXNVcmxPbmx5ID0gZW50aXR5LnNvdXJjZSA9PT0gJ3VybF9vbmx5JztcbiAgICBjb25zdCBzb3VyY2VMYWJlbCA9IGlzVXJsT25seSA/ICc8c3BhbiBjbGFzcz1cInRleHQtd2FybmluZ1wiIHN0eWxlPVwiZm9udC1zaXplOjEwcHhcIj5FTlRJVFkgUEFSVElBTExZIFJFU09MVkVEIEZST00gVVJMIE9OTFk8L3NwYW4+JyA6ICc8c3BhbiBjbGFzcz1cInRleHQtc3VjY2Vzc1wiIHN0eWxlPVwiZm9udC1zaXplOjEwcHhcIj5FTlRJVFkgUkVTT0xWRUQgKE1FUkdFRCk8L3NwYW4+JztcbiAgICByZXR1cm4gYFxuICAgICAgICA8ZGl2IGNsYXNzPVwiY2FyZCBtYi0zXCI+XG4gICAgICAgICAgICA8ZGl2IGNsYXNzPVwiY2FyZC1oZWFkZXIgZC1mbGV4IGp1c3RpZnktY29udGVudC1iZXR3ZWVuIGFsaWduLWl0ZW1zLWNlbnRlclwiPlxuICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzPVwidGV4dC1wcmltYXJ5IGZ3LWJvbGRcIj5DVVJSRU5UIEVOVElUWTogVFdFRVQ8L3NwYW4+XG4gICAgICAgICAgICAgICAgJHtzb3VyY2VMYWJlbH1cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgPGRpdiBjbGFzcz1cImNhcmQtYm9keSBweS0yXCI+XG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzcz1cInJvd1wiPlxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzPVwiY29sLTggYm9yZGVyLXJpZ2h0XCI+XG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzPVwic3lzLXN0YXRcIj48c3Bhbj5Ud2VldCBJRDwvc3Bhbj48c3BhbiBjbGFzcz1cInZhbCB0ZXh0LXdhcm5pbmdcIj4ke2VudGl0eS5lbnRpdHlJZH08L3NwYW4+PC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzPVwic3lzLXN0YXRcIj48c3Bhbj5BdXRob3I8L3NwYW4+PHNwYW4gY2xhc3M9XCJ2YWwgdGV4dC1pbmZvXCI+JHtlbnRpdHkuYXV0aG9ySGFuZGxlIHx8ICfigJQnfSAke2VudGl0eS5hdXRob3JOYW1lID8gYDxzbWFsbCBjbGFzcz1cInRleHQtbXV0ZWRcIj4oJHtlbnRpdHkuYXV0aG9yTmFtZX0pPC9zbWFsbD5gIDogJyd9PC9zcGFuPjwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzcz1cInN5cy1zdGF0XCI+PHNwYW4+QXV0aG9yIElEPC9zcGFuPjxzcGFuIGNsYXNzPVwidmFsXCIgc3R5bGU9XCJmb250LXNpemU6MTBweDsgb3BhY2l0eTowLjdcIj4ke2VudGl0eS5hdXRob3JJZCB8fCAn4oCUJ308L3NwYW4+PC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzPVwic3lzLXN0YXRcIj48c3Bhbj5DcmVhdGVkIEF0PC9zcGFuPjxzcGFuIGNsYXNzPVwidmFsXCIgc3R5bGU9XCJmb250LXNpemU6MTBweFwiPiR7ZW50aXR5LmNyZWF0ZWRBdCB8fCAn4oCUJ308L3NwYW4+PC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzPVwic3lzLXN0YXRcIj48c3Bhbj5Pd25lcnNoaXA8L3NwYW4+PHNwYW4gY2xhc3M9XCJ2YWwgJHtlbnRpdHkuaXNPd25lZEJ5QWN0aXZlQWNjb3VudCA/ICd0ZXh0LXN1Y2Nlc3MnIDogJ3RleHQtbXV0ZWQnfVwiPiR7ZW50aXR5LmlzT3duZWRCeUFjdGl2ZUFjY291bnQgPyAnT1dORUQgQlkgQUNUSVZFIEFDQ09VTlQnIDogJ09USEVSUyd9PC9zcGFuPjwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzcz1cIm10LTJcIiBzdHlsZT1cImZvbnQtc2l6ZToxMHB4OyBjb2xvcjojY2JkNWUwOyB0ZXh0LXRyYW5zZm9ybTp1cHBlcmNhc2U7IGZvbnQtd2VpZ2h0OjcwMFwiPkNvbnRlbnQgU25hcHNob3Q8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJwLTIgbXQtMSBiZy1kYXJrIHJvdW5kZWQgdGV4dC1saWdodFwiIHN0eWxlPVwiZm9udC1zaXplOjExcHg7IG1heC1oZWlnaHQ6IDgwcHg7IG92ZXJmbG93LXk6IGF1dG87XCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgJHtlbnRpdHkudGV4dCB8fCAnPHNwYW4gY2xhc3M9XCJ0ZXh0LW11dGVkIGl0YWxpY1wiPk5vIGNvbnRlbnQgY2FwdHVyZWQuPC9zcGFuPid9XG4gICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJjb2wtNFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzcz1cIm10LTFcIiBzdHlsZT1cImZvbnQtc2l6ZToxMHB4OyBjb2xvcjojY2JkNWUwOyB0ZXh0LXRyYW5zZm9ybTp1cHBlcmNhc2U7IGZvbnQtd2VpZ2h0OjcwMFwiPk1ldHJpY3M8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJzeXMtc3RhdCBtdC0yXCI+PHNwYW4+TGlrZTwvc3Bhbj48c3BhbiBjbGFzcz1cInZhbFwiPiR7ZW50aXR5Lmxpa2VDb3VudCA/PyAn4oCUJ308L3NwYW4+PC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzPVwic3lzLXN0YXRcIj48c3Bhbj5SZXBseTwvc3Bhbj48c3BhbiBjbGFzcz1cInZhbFwiPiR7ZW50aXR5LnJlcGx5Q291bnQgPz8gJ+KAlCd9PC9zcGFuPjwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzcz1cInN5cy1zdGF0XCI+PHNwYW4+UmVwb3N0PC9zcGFuPjxzcGFuIGNsYXNzPVwidmFsXCI+JHtlbnRpdHkucmV0d2VldENvdW50ID8/ICfigJQnfTwvc3Bhbj48L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJzeXMtc3RhdFwiPjxzcGFuPkJvb2ttYXJrPC9zcGFuPjxzcGFuIGNsYXNzPVwidmFsXCI+JHtlbnRpdHkuYm9va21hcmtDb3VudCA/PyAn4oCUJ308L3NwYW4+PC9kaXY+XG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICR7aXNVcmxPbmx5ID8gYFxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJtdC0yIHRleHQtY2VudGVyXCI+XG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJhbGVydCBhbGVydC13YXJuaW5nIHB5LTEgcHgtMiBtLTBcIiBzdHlsZT1cImZvbnQtc2l6ZToxMHB4XCI+XG4gICAgICAgICAgICAgICAgICAgICAgICBQYXJ0aWFsIGRhdGEuIE9wZW4gdGhpcyB0d2VldCBvbiBYIHRvIGNhcHR1cmUgZnVsbCBkZXRhaWxzLlxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICA8L2Rpdj5gIDogJyd9XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgPC9kaXY+YDtcbn1cbi8vIOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgFxuLy8gUmVwbGllcyBTbmFwc2hvdCDmuLLmn5MgKE5FVylcbi8vIOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgFxuZnVuY3Rpb24gcmVuZGVyUmVwbGllc1NuYXBzaG90KHJlcGxpZXMsIHNjZW5lKSB7XG4gICAgaWYgKHNjZW5lICE9PSAndHdlZXRfZGV0YWlsJylcbiAgICAgICAgcmV0dXJuICcnO1xuICAgIC8vIOepuueKtuaAge+8muS9v+eUqOS4juS4iuaWuSBTZWN0aW9uIOS4gOiHtOeahOagh+ivhuminOiJslxuICAgIGlmICghcmVwbGllcyB8fCByZXBsaWVzLmxlbmd0aCA9PT0gMCkge1xuICAgICAgICByZXR1cm4gYFxuICAgICAgICAgICAgPGRpdiBjbGFzcz1cImNhcmQgbWItMyBib3JkZXItc2Vjb25kYXJ5XCI+XG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzcz1cImNhcmQtaGVhZGVyIHRleHQtaW5mbyBmdy1ib2xkXCI+UkVQTElFUyBTTkFQU0hPVDwvZGl2PlxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJjYXJkLWJvZHkgcHktMyB0ZXh0LWNlbnRlciB0ZXh0LXNlY29uZGFyeSBpdGFsaWNcIiBzdHlsZT1cImZvbnQtc2l6ZToxMXB4OyBvcGFjaXR5OiAwLjZcIj5cbiAgICAgICAgICAgICAgICAgICAgTm8gYWN0aXZlIHJlcGxpZXMgY2FwdHVyZWQgeWV0LlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgPC9kaXY+YDtcbiAgICB9XG4gICAgY29uc3QgY291bnQgPSByZXBsaWVzLmxlbmd0aDtcbiAgICBjb25zdCBkaXNwbGF5TGlzdCA9IHJlcGxpZXMuc2xpY2UoMCwgNSk7XG4gICAgY29uc3Qgc2VsZWN0ZWRJZCA9IHNlbGVjdGVkVGFiSWQgIT09IG51bGwgPyBzZWxlY3RlZFJlcGx5SWRzLmdldChzZWxlY3RlZFRhYklkKSA6IG51bGw7XG4gICAgLy8g5pyJ5pWw5o2u54q25oCB77ya5L2/55So6bKc6Imz55qE57u/6Imy5by66LCD5o2V6I635oiQ5YqfXG4gICAgcmV0dXJuIGBcbiAgICAgICAgPGRpdiBjbGFzcz1cImNhcmQgbWItMyBib3JkZXItc3VjY2Vzc1wiIHN0eWxlPVwiYm9yZGVyLXdpZHRoOiAxcHhcIj5cbiAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJjYXJkLWhlYWRlciBkLWZsZXgganVzdGlmeS1jb250ZW50LWJldHdlZW4gYWxpZ24taXRlbXMtY2VudGVyXCIgc3R5bGU9XCJiYWNrZ3JvdW5kOiByZ2JhKDI1LCAxMzUsIDg0LCAwLjA1KVwiPlxuICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzPVwidGV4dC1zdWNjZXNzIGZ3LWJvbGRcIj5SRVBMSUVTIFNOQVBTSE9UPC9zcGFuPlxuICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzPVwiYmFkZ2UgYmctZGFyayB0ZXh0LXN1Y2Nlc3MgYm9yZGVyIGJvcmRlci1zdWNjZXNzXCIgc3R5bGU9XCJmb250LXNpemU6MTBweDsgYm94LXNoYWRvdzogMCAwIDVweCByZ2JhKDI1LDEzNSw4NCwwLjMpXCI+JHtjb3VudH0gQ0FQVFVSRUQ8L3NwYW4+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJjYXJkLWJvZHkgcC0wXCI+XG4gICAgICAgICAgICAgICAgPHRhYmxlIGNsYXNzPVwidGFibGUgdGFibGUtZGFyayB0YWJsZS1ob3ZlciBtYi0wXCIgc3R5bGU9XCJmb250LXNpemU6MTFweFwiPlxuICAgICAgICAgICAgICAgICAgICA8dGJvZHk+XG4gICAgICAgICAgICAgICAgICAgICAgICAke2Rpc3BsYXlMaXN0Lm1hcChyID0+IHtcbiAgICAgICAgY29uc3QgaXNTZWxlY3RlZCA9IHIudHdlZXRJZCA9PT0gc2VsZWN0ZWRJZDtcbiAgICAgICAgcmV0dXJuIGBcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dHIgY2xhc3M9XCJ0Yy1yZXBseS1yb3cgJHtpc1NlbGVjdGVkID8gJ3RhYmxlLXByaW1hcnkgc2hhZG93LXNtJyA6ICcnfVwiIFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBkYXRhLWlkPVwiJHtyLnR3ZWV0SWR9XCIgXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHN0eWxlPVwiY3Vyc29yOiBwb2ludGVyOyB0cmFuc2l0aW9uOiBhbGwgMC4yczsgJHtpc1NlbGVjdGVkID8gJ2JhY2tncm91bmQ6IHJnYmEoMTMsIDExMCwgMjUzLCAwLjIpICFpbXBvcnRhbnQ7IGJvcmRlci1sZWZ0OiAzcHggc29saWQgIzBkNmVmZDsnIDogJyd9XCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0ZCBjbGFzcz1cInBzLTMgcHktMlwiIHN0eWxlPVwid2lkdGg6IDI1JVwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzcz1cImZ3LWJvbGQgdGV4dC1pbmZvIHRleHQtdHJ1bmNhdGVcIj4ke3IuYXV0aG9ySGFuZGxlfTwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBzdHlsZT1cImZvbnQtc2l6ZTo5cHg7IGNvbG9yOiAjODg5OUE2XCI+JHtmbXRUaW1lKG5ldyBEYXRlKHIuY3JlYXRlZEF0KS5nZXRUaW1lKCkpfTwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgJHtyLmlzQnlBY3RpdmVBY2NvdW50ID8gJzxzcGFuIGNsYXNzPVwiYmFkZ2UgYmctc3VjY2VzcyB0ZXh0LXdoaXRlIG1zLTFcIiBzdHlsZT1cImZvbnQtc2l6ZTo4cHg7IHBhZGRpbmc6IDFweCA0cHg7IGJvcmRlci1yYWRpdXM6IDRweDsgdmVydGljYWwtYWxpZ246IG1pZGRsZVwiPllPVTwvc3Bhbj4nIDogJyd9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvdGQ+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0ZCBjbGFzcz1cInB5LTJcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJ0ZXh0LWxpZ2h0LWVtcGhhc2lzIGZ3LW1lZGl1bVwiIHN0eWxlPVwiZGlzcGxheTogLXdlYmtpdC1ib3g7IC13ZWJraXQtbGluZS1jbGFtcDogMjsgLXdlYmtpdC1ib3gtb3JpZW50OiB2ZXJ0aWNhbDsgb3ZlcmZsb3c6IGhpZGRlbjsgbGluZS1oZWlnaHQ6IDEuM1wiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICR7dHJ1bmNhdGUoci50ZXh0LCAxMDApfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzPVwibXQtMSBkLWZsZXggZ2FwLTJcIiBzdHlsZT1cImZvbnQtc2l6ZTo5cHg7IG9wYWNpdHk6MC44NVwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzPVwidGV4dC1zZWNvbmRhcnlcIj5MaWtlOiAke3IubGlrZUNvdW50ID8/IDB9PC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzPVwidGV4dC1zZWNvbmRhcnlcIj5SVDogJHtyLnJlcG9zdENvdW50ID8/IDB9PC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzPVwidGV4dC1zZWNvbmRhcnlcIj5SZXBseTogJHtyLnJlcGx5Q291bnQgPz8gMH08L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC90ZD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3RyPlxuICAgICAgICAgICAgICAgICAgICAgICAgYDtcbiAgICB9KS5qb2luKCcnKX1cbiAgICAgICAgICAgICAgICAgICAgPC90Ym9keT5cbiAgICAgICAgICAgICAgICA8L3RhYmxlPlxuICAgICAgICAgICAgICAgICR7Y291bnQgPiA1ID8gYDxkaXYgY2xhc3M9XCJ0ZXh0LWNlbnRlciBweS0xIHRleHQtc2Vjb25kYXJ5IHNtYWxsIGJvcmRlci10b3AgYmctZGFya1wiIHN0eWxlPVwiZm9udC1zaXplOjlweDsgb3BhY2l0eTogMC42XCI+T25seSBzaG93aW5nIGZpcnN0IDUgcmVwbGllcy48L2Rpdj5gIDogJyd9XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgPC9kaXY+YDtcbn1cbi8vIOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgFxuLy8gUHJvZmlsZSBUd2VldHMgU25hcHNob3Qg5riy5p+TIChORVcpXG4vLyDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIBcbmZ1bmN0aW9uIHJlbmRlclByb2ZpbGVUd2VldHNTbmFwc2hvdCh0d2VldHMsIHNjZW5lLCBzZWxlY3RlZElkKSB7XG4gICAgaWYgKHNjZW5lICE9PSAncHJvZmlsZScpXG4gICAgICAgIHJldHVybiAnJztcbiAgICBpZiAoIXR3ZWV0cyB8fCB0d2VldHMubGVuZ3RoID09PSAwKSB7XG4gICAgICAgIHJldHVybiBgXG4gICAgICAgICAgICA8ZGl2IGNsYXNzPVwiY2FyZCBtYi0zIGJvcmRlci1zZWNvbmRhcnlcIj5cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzPVwiY2FyZC1oZWFkZXIgdGV4dC1pbmZvIGZ3LWJvbGRcIj5QUk9GSUxFIFRXRUVUUyBTTkFQU0hPVDwvZGl2PlxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJjYXJkLWJvZHkgcHktMyB0ZXh0LWNlbnRlciB0ZXh0LXNlY29uZGFyeSBpdGFsaWNcIiBzdHlsZT1cImZvbnQtc2l6ZToxMXB4OyBvcGFjaXR5OiAwLjZcIj5cbiAgICAgICAgICAgICAgICAgICAgTm8gcHJvZmlsZSB0d2VldHMgY2FwdHVyZWQgeWV0LiA8YnI+XG4gICAgICAgICAgICAgICAgICAgIDxzbWFsbD5TY3JvbGwgdGhlIHByb2ZpbGUgcGFnZSB0byB0cmlnZ2VyIGV4dHJhY3Rpb24uPC9zbWFsbD5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIDwvZGl2PmA7XG4gICAgfVxuICAgIGNvbnN0IGNvdW50ID0gdHdlZXRzLmxlbmd0aDtcbiAgICBjb25zdCBkaXNwbGF5TGlzdCA9IHR3ZWV0cy5zbGljZSgwLCA1KTtcbiAgICByZXR1cm4gYFxuICAgICAgICA8ZGl2IGNsYXNzPVwiY2FyZCBtYi0zIGJvcmRlci1zdWNjZXNzXCIgc3R5bGU9XCJib3JkZXItd2lkdGg6IDFweFwiPlxuICAgICAgICAgICAgPGRpdiBjbGFzcz1cImNhcmQtaGVhZGVyIGQtZmxleCBqdXN0aWZ5LWNvbnRlbnQtYmV0d2VlbiBhbGlnbi1pdGVtcy1jZW50ZXJcIiBzdHlsZT1cImJhY2tncm91bmQ6IHJnYmEoMjUsIDEzNSwgODQsIDAuMDUpXCI+XG4gICAgICAgICAgICAgICAgPHNwYW4gY2xhc3M9XCJ0ZXh0LXN1Y2Nlc3MgZnctYm9sZFwiPlBST0ZJTEUgVFdFRVRTIFNOQVBTSE9UPC9zcGFuPlxuICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzPVwiYmFkZ2UgYmctZGFyayB0ZXh0LXN1Y2Nlc3MgYm9yZGVyIGJvcmRlci1zdWNjZXNzXCIgc3R5bGU9XCJmb250LXNpemU6MTBweFwiPiR7Y291bnR9IENBUFRVUkVEPC9zcGFuPlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICA8ZGl2IGNsYXNzPVwiY2FyZC1ib2R5IHAtMFwiPlxuICAgICAgICAgICAgICAgIDx0YWJsZSBjbGFzcz1cInRhYmxlIHRhYmxlLWRhcmsgdGFibGUtaG92ZXIgbWItMFwiIHN0eWxlPVwiZm9udC1zaXplOjExcHhcIj5cbiAgICAgICAgICAgICAgICAgICAgPHRib2R5PlxuICAgICAgICAgICAgICAgICAgICAgICAgJHtkaXNwbGF5TGlzdC5tYXAodCA9PiB7XG4gICAgICAgIGNvbnN0IGlzU2VsZWN0ZWQgPSB0LnR3ZWV0SWQgPT09IHNlbGVjdGVkSWQ7XG4gICAgICAgIHJldHVybiBgXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRyIGNsYXNzPVwidGMtcHJvZmlsZS10d2VldC1yb3cgJHtpc1NlbGVjdGVkID8gJ3RhYmxlLXByaW1hcnkgc2hhZG93LXNtJyA6ICcnfVwiIFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBkYXRhLWlkPVwiJHt0LnR3ZWV0SWR9XCIgXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHN0eWxlPVwiY3Vyc29yOiBwb2ludGVyOyB0cmFuc2l0aW9uOiBhbGwgMC4yczsgJHtpc1NlbGVjdGVkID8gJ2JhY2tncm91bmQ6IHJnYmEoMTMsIDExMCwgMjUzLCAwLjIpICFpbXBvcnRhbnQ7IGJvcmRlci1sZWZ0OiAzcHggc29saWQgIzBkNmVmZDsnIDogJyd9XCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0ZCBjbGFzcz1cInBzLTMgcHktMlwiIHN0eWxlPVwid2lkdGg6IDI1JVwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzcz1cImZ3LWJvbGQgdGV4dC1pbmZvIHRleHQtdHJ1bmNhdGVcIj4ke3QuYXV0aG9ySGFuZGxlfTwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBzdHlsZT1cImZvbnQtc2l6ZTo5cHg7IGNvbG9yOiAjODg5OUE2XCI+JHt0LmNyZWF0ZWRBdCA/IGZtdFRpbWUobmV3IERhdGUodC5jcmVhdGVkQXQpLmdldFRpbWUoKSkgOiAn4oCUJ308L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICR7dC5pc093bmVkQnlBY3RpdmVBY2NvdW50ID8gJzxzcGFuIGNsYXNzPVwiYmFkZ2UgYmctd2FybmluZyB0ZXh0LWRhcmsgbXMtMVwiIHN0eWxlPVwiZm9udC1zaXplOjhweDsgcGFkZGluZzogMXB4IDRweDsgYm9yZGVyLXJhZGl1czogNHB4OyB2ZXJ0aWNhbC1hbGlnbjogbWlkZGxlXCI+T1dORUQ8L3NwYW4+JyA6ICcnfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3RkPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGQgY2xhc3M9XCJweS0yXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzPVwidGV4dC1saWdodC1lbXBoYXNpc1wiIHN0eWxlPVwiZGlzcGxheTogLXdlYmtpdC1ib3g7IC13ZWJraXQtbGluZS1jbGFtcDogMjsgLXdlYmtpdC1ib3gtb3JpZW50OiB2ZXJ0aWNhbDsgb3ZlcmZsb3c6IGhpZGRlbjsgbGluZS1oZWlnaHQ6IDEuM1wiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICR7dHJ1bmNhdGUodC50ZXh0LCAxMDApfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzPVwibXQtMSBkLWZsZXggZ2FwLTJcIiBzdHlsZT1cImZvbnQtc2l6ZTo5cHg7IG9wYWNpdHk6MC44NVwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzPVwidGV4dC1zZWNvbmRhcnlcIj5MaWtlczogJHtuRm10KHQubGlrZUNvdW50KX08L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3M9XCJ0ZXh0LXNlY29uZGFyeVwiPlJUczogJHtuRm10KHQucmVwb3N0Q291bnQpfTwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzcz1cInRleHQtc2Vjb25kYXJ5XCI+UmVwbGllczogJHtuRm10KHQucmVwbHlDb3VudCl9PC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvdGQ+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC90cj5cbiAgICAgICAgICAgICAgICAgICAgICAgIGA7XG4gICAgfSkuam9pbignJyl9XG4gICAgICAgICAgICAgICAgICAgIDwvdGJvZHk+XG4gICAgICAgICAgICAgICAgPC90YWJsZT5cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzPVwiY2FyZC1mb290ZXIgcHktMSBkLWZsZXgganVzdGlmeS1jb250ZW50LWJldHdlZW4gYWxpZ24taXRlbXMtY2VudGVyIGJnLWRhcmtcIiBzdHlsZT1cImZvbnQtc2l6ZTo5cHg7IG9wYWNpdHk6IDAuOFwiPlxuICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzcz1cInRleHQtc2Vjb25kYXJ5XCI+JHtjb3VudCA+IDUgPyAnT25seSBzaG93aW5nIGZpcnN0IDUgdHdlZXRzLicgOiAnJ308L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICR7c2VsZWN0ZWRJZCA/IGA8c3BhbiBjbGFzcz1cInRleHQtaW5mbyBmdy1ib2xkXCI+U2VsZWN0ZWQ6ICR7c2VsZWN0ZWRJZH08L3NwYW4+YCA6ICc8c3BhbiBjbGFzcz1cInRleHQtbXV0ZWRcIj5ObyB0d2VldCBzZWxlY3RlZDwvc3Bhbj4nfVxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgIDwvZGl2PmA7XG59XG4vLyDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIBcbi8vIFNlbGVjdGVkIFJlcGx5IERldGFpbCDmuLLmn5MgKE5FVylcbi8vIOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgFxuZnVuY3Rpb24gcmVuZGVyU2VsZWN0ZWRSZXBseUNhcmQocmVwbGllcywgc2NlbmUpIHtcbiAgICBpZiAoc2NlbmUgIT09ICd0d2VldF9kZXRhaWwnIHx8IHNlbGVjdGVkVGFiSWQgPT09IG51bGwpXG4gICAgICAgIHJldHVybiAnJztcbiAgICBjb25zdCBzZWxlY3RlZElkID0gc2VsZWN0ZWRSZXBseUlkcy5nZXQoc2VsZWN0ZWRUYWJJZCk7XG4gICAgaWYgKCFzZWxlY3RlZElkKVxuICAgICAgICByZXR1cm4gJyc7XG4gICAgY29uc3Qgc2VsZWN0ZWRSZXBseSA9IChyZXBsaWVzIHx8IFtdKS5maW5kKHIgPT4gci50d2VldElkID09PSBzZWxlY3RlZElkKTtcbiAgICBpZiAoIXNlbGVjdGVkUmVwbHkpXG4gICAgICAgIHJldHVybiAnJztcbiAgICByZXR1cm4gYFxuICAgICAgICA8ZGl2IGNsYXNzPVwiY2FyZCBtYi0zIGJvcmRlci1wcmltYXJ5XCIgc3R5bGU9XCJib3JkZXItd2lkdGg6IDFweFwiPlxuICAgICAgICAgICAgPGRpdiBjbGFzcz1cImNhcmQtaGVhZGVyIGQtZmxleCBqdXN0aWZ5LWNvbnRlbnQtYmV0d2VlbiBhbGlnbi1pdGVtcy1jZW50ZXJcIiBzdHlsZT1cImJhY2tncm91bmQ6IHJnYmEoMTMsIDExMCwgMjUzLCAwLjA1KVwiPlxuICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzPVwidGV4dC1wcmltYXJ5IGZ3LWJvbGRcIj5TRUxFQ1RFRCBSRVBMWSBERVRBSUw8L3NwYW4+XG4gICAgICAgICAgICAgICAgPHNwYW4gY2xhc3M9XCJiYWRnZSBiZy1kYXJrIHRleHQtcHJpbWFyeSBib3JkZXIgYm9yZGVyLXByaW1hcnlcIiBzdHlsZT1cImZvbnQtc2l6ZToxMHB4XCI+UkVBRCBPTkxZPC9zcGFuPlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICA8ZGl2IGNsYXNzPVwiY2FyZC1ib2R5IHB5LTJcIj5cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzPVwicm93XCI+XG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJjb2wtOCBib3JkZXItcmlnaHRcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJzeXMtc3RhdFwiPjxzcGFuPlJlcGx5IElEPC9zcGFuPjxzcGFuIGNsYXNzPVwidmFsIHRleHQtd2FybmluZ1wiPiR7c2VsZWN0ZWRSZXBseS50d2VldElkfTwvc3Bhbj48L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJzeXMtc3RhdFwiPjxzcGFuPkF1dGhvcjwvc3Bhbj48c3BhbiBjbGFzcz1cInZhbCB0ZXh0LWluZm9cIj4ke3NlbGVjdGVkUmVwbHkuYXV0aG9ySGFuZGxlIHx8ICfigJQnfSAke3NlbGVjdGVkUmVwbHkuYXV0aG9yTmFtZSA/IGA8c21hbGwgY2xhc3M9XCJ0ZXh0LW11dGVkXCI+KCR7c2VsZWN0ZWRSZXBseS5hdXRob3JOYW1lfSk8L3NtYWxsPmAgOiAnJ308L3NwYW4+PC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzPVwic3lzLXN0YXRcIj48c3Bhbj5BdXRob3IgSUQ8L3NwYW4+PHNwYW4gY2xhc3M9XCJ2YWxcIiBzdHlsZT1cImZvbnQtc2l6ZToxMHB4OyBvcGFjaXR5OjAuN1wiPiR7c2VsZWN0ZWRSZXBseS5hdXRob3JJZCB8fCAn4oCUJ308L3NwYW4+PC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzPVwic3lzLXN0YXRcIj48c3Bhbj5DcmVhdGVkIEF0PC9zcGFuPjxzcGFuIGNsYXNzPVwidmFsXCIgc3R5bGU9XCJmb250LXNpemU6MTBweFwiPiR7c2VsZWN0ZWRSZXBseS5jcmVhdGVkQXQgfHwgJ+KAlCd9PC9zcGFuPjwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzcz1cInN5cy1zdGF0XCI+PHNwYW4+T3duZXJzaGlwPC9zcGFuPjxzcGFuIGNsYXNzPVwidmFsICR7c2VsZWN0ZWRSZXBseS5pc0J5QWN0aXZlQWNjb3VudCA/ICd0ZXh0LXN1Y2Nlc3MnIDogJ3RleHQtbXV0ZWQnfVwiPiR7c2VsZWN0ZWRSZXBseS5pc0J5QWN0aXZlQWNjb3VudCA/ICdZT1UnIDogJ09USEVSUyd9PC9zcGFuPjwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzcz1cIm10LTJcIiBzdHlsZT1cImZvbnQtc2l6ZToxMHB4OyBjb2xvcjojY2JkNWUwOyB0ZXh0LXRyYW5zZm9ybTp1cHBlcmNhc2U7IGZvbnQtd2VpZ2h0OjcwMFwiPkNvbnRlbnQgU25hcHNob3Q8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJwLTIgbXQtMSBiZy1kYXJrIHJvdW5kZWQgdGV4dC1saWdodFwiIHN0eWxlPVwiZm9udC1zaXplOjExcHg7IG1heC1oZWlnaHQ6IDgwcHg7IG92ZXJmbG93LXk6IGF1dG87XCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgJHtzZWxlY3RlZFJlcGx5LnRleHQgfHwgJzxzcGFuIGNsYXNzPVwidGV4dC1tdXRlZCBpdGFsaWNcIj5ObyBjb250ZW50IGNhcHR1cmVkLjwvc3Bhbj4nfVxuICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzPVwiY29sLTRcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJtdC0xXCIgc3R5bGU9XCJmb250LXNpemU6MTBweDsgY29sb3I6I2NiZDVlMDsgdGV4dC10cmFuc2Zvcm06dXBwZXJjYXNlOyBmb250LXdlaWdodDo3MDBcIj5NZXRyaWNzPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzPVwic3lzLXN0YXQgbXQtMlwiPjxzcGFuPkxpa2U8L3NwYW4+PHNwYW4gY2xhc3M9XCJ2YWxcIj4ke3NlbGVjdGVkUmVwbHkubGlrZUNvdW50ID8/ICfigJQnfTwvc3Bhbj48L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJzeXMtc3RhdFwiPjxzcGFuPlJlcGx5PC9zcGFuPjxzcGFuIGNsYXNzPVwidmFsXCI+JHtzZWxlY3RlZFJlcGx5LnJlcGx5Q291bnQgPz8gJ+KAlCd9PC9zcGFuPjwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzcz1cInN5cy1zdGF0XCI+PHNwYW4+UmVwb3N0PC9zcGFuPjxzcGFuIGNsYXNzPVwidmFsXCI+JHtzZWxlY3RlZFJlcGx5LnJlcG9zdENvdW50ID8/ICfigJQnfTwvc3Bhbj48L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgPC9kaXY+YDtcbn1cbi8vIOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgFxuLy8gU2VsZWN0ZWQgUHJvZmlsZSBUd2VldCBEZXRhaWwg5riy5p+TIChORVcpXG4vLyDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIBcbmZ1bmN0aW9uIHJlbmRlclNlbGVjdGVkUHJvZmlsZVR3ZWV0Q2FyZCh0d2VldHMsIHNjZW5lKSB7XG4gICAgaWYgKHNjZW5lICE9PSAncHJvZmlsZScgfHwgc2VsZWN0ZWRUYWJJZCA9PT0gbnVsbClcbiAgICAgICAgcmV0dXJuICcnO1xuICAgIGNvbnN0IHNlbGVjdGVkSWQgPSBzZWxlY3RlZFByb2ZpbGVUd2VldElkcy5nZXQoc2VsZWN0ZWRUYWJJZCk7XG4gICAgaWYgKCFzZWxlY3RlZElkKVxuICAgICAgICByZXR1cm4gJyc7XG4gICAgY29uc3Qgc2VsZWN0ZWRUd2VldCA9ICh0d2VldHMgfHwgW10pLmZpbmQodCA9PiB0LnR3ZWV0SWQgPT09IHNlbGVjdGVkSWQpO1xuICAgIGlmICghc2VsZWN0ZWRUd2VldClcbiAgICAgICAgcmV0dXJuICcnO1xuICAgIHJldHVybiBgXG4gICAgICAgIDxkaXYgY2xhc3M9XCJjYXJkIG1iLTMgYm9yZGVyLXByaW1hcnlcIiBzdHlsZT1cImJvcmRlci13aWR0aDogMXB4XCI+XG4gICAgICAgICAgICA8ZGl2IGNsYXNzPVwiY2FyZC1oZWFkZXIgZC1mbGV4IGp1c3RpZnktY29udGVudC1iZXR3ZWVuIGFsaWduLWl0ZW1zLWNlbnRlclwiIHN0eWxlPVwiYmFja2dyb3VuZDogcmdiYSgxMywgMTEwLCAyNTMsIDAuMDUpXCI+XG4gICAgICAgICAgICAgICAgPHNwYW4gY2xhc3M9XCJ0ZXh0LXByaW1hcnkgZnctYm9sZFwiPlNFTEVDVEVEIFBST0ZJTEUgVFdFRVQgREVUQUlMPC9zcGFuPlxuICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzPVwiYmFkZ2UgYmctZGFyayB0ZXh0LXByaW1hcnkgYm9yZGVyIGJvcmRlci1wcmltYXJ5XCIgc3R5bGU9XCJmb250LXNpemU6MTBweFwiPlJFQUQgT05MWTwvc3Bhbj5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgPGRpdiBjbGFzcz1cImNhcmQtYm9keSBweS0yXCI+XG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzcz1cInJvd1wiPlxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzPVwiY29sLTggYm9yZGVyLXJpZ2h0XCI+XG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzPVwic3lzLXN0YXRcIj48c3Bhbj5Ud2VldCBJRDwvc3Bhbj48c3BhbiBjbGFzcz1cInZhbCB0ZXh0LXdhcm5pbmdcIj4ke3NlbGVjdGVkVHdlZXQudHdlZXRJZH08L3NwYW4+PC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzPVwic3lzLXN0YXRcIj48c3Bhbj5BdXRob3I8L3NwYW4+PHNwYW4gY2xhc3M9XCJ2YWwgdGV4dC1pbmZvXCI+JHtzZWxlY3RlZFR3ZWV0LmF1dGhvckhhbmRsZSB8fCAn4oCUJ30gJHtzZWxlY3RlZFR3ZWV0LmF1dGhvck5hbWUgPyBgPHNtYWxsIGNsYXNzPVwidGV4dC1tdXRlZFwiPigke3NlbGVjdGVkVHdlZXQuYXV0aG9yTmFtZX0pPC9zbWFsbD5gIDogJyd9PC9zcGFuPjwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzcz1cInN5cy1zdGF0XCI+PHNwYW4+Q3JlYXRlZCBBdDwvc3Bhbj48c3BhbiBjbGFzcz1cInZhbFwiIHN0eWxlPVwiZm9udC1zaXplOjEwcHhcIj4ke3NlbGVjdGVkVHdlZXQuY3JlYXRlZEF0IHx8ICfigJQnfTwvc3Bhbj48L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJzeXMtc3RhdFwiPjxzcGFuPk93bmVyc2hpcDwvc3Bhbj48c3BhbiBjbGFzcz1cInZhbCAke3NlbGVjdGVkVHdlZXQuaXNPd25lZEJ5QWN0aXZlQWNjb3VudCA/ICd0ZXh0LXN1Y2Nlc3MnIDogJ3RleHQtbXV0ZWQnfVwiPiR7c2VsZWN0ZWRUd2VldC5pc093bmVkQnlBY3RpdmVBY2NvdW50ID8gJ09XTkVEJyA6ICdPVEhFUlMnfTwvc3Bhbj48L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJtdC0yXCIgc3R5bGU9XCJmb250LXNpemU6MTBweDsgY29sb3I6I2NiZDVlMDsgdGV4dC10cmFuc2Zvcm06dXBwZXJjYXNlOyBmb250LXdlaWdodDo3MDBcIj5Db250ZW50IFNuYXBzaG90PC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzPVwicC0yIG10LTEgYmctZGFyayByb3VuZGVkIHRleHQtbGlnaHRcIiBzdHlsZT1cImZvbnQtc2l6ZToxMXB4OyBtYXgtaGVpZ2h0OiA4MHB4OyBvdmVyZmxvdy15OiBhdXRvO1wiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICR7c2VsZWN0ZWRUd2VldC50ZXh0IHx8ICc8c3BhbiBjbGFzcz1cInRleHQtbXV0ZWQgaXRhbGljXCI+Tm8gY29udGVudCBjYXB0dXJlZC48L3NwYW4+J31cbiAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzcz1cImNvbC00XCI+XG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzPVwibXQtMVwiIHN0eWxlPVwiZm9udC1zaXplOjEwcHg7IGNvbG9yOiNjYmQ1ZTA7IHRleHQtdHJhbnNmb3JtOnVwcGVyY2FzZTsgZm9udC13ZWlnaHQ6NzAwXCI+TWV0cmljczwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzcz1cInN5cy1zdGF0IG10LTJcIj48c3Bhbj5MaWtlPC9zcGFuPjxzcGFuIGNsYXNzPVwidmFsXCI+JHtuRm10KHNlbGVjdGVkVHdlZXQubGlrZUNvdW50KX08L3NwYW4+PC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzPVwic3lzLXN0YXRcIj48c3Bhbj5SZXBseTwvc3Bhbj48c3BhbiBjbGFzcz1cInZhbFwiPiR7bkZtdChzZWxlY3RlZFR3ZWV0LnJlcGx5Q291bnQpfTwvc3Bhbj48L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJzeXMtc3RhdFwiPjxzcGFuPlJlcG9zdDwvc3Bhbj48c3BhbiBjbGFzcz1cInZhbFwiPiR7bkZtdChzZWxlY3RlZFR3ZWV0LnJlcG9zdENvdW50KX08L3NwYW4+PC9kaXY+XG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgIDwvZGl2PmA7XG59XG4vKipcbiAqIENhbmRpZGF0ZSBJbnRlbnQgLyBFeGVjdXRpb24gQ2FuZGlkYXRlIENhcmQgZm9yIFNlbGVjdGVkIFByb2ZpbGUgVHdlZXRcbiAqIChSZWFkLW9ubHksIGluZm9ybXMgdGhlIG9wZXJhdG9yIHRoaXMgdHdlZXQgaXMgYSBjYW5kaWRhdGUgZm9yIGZ1dHVyZSBhY3Rpb25zKVxuICovXG5mdW5jdGlvbiByZW5kZXJQcm9maWxlVHdlZXRDYW5kaWRhdGVJbnRlbnRDYXJkKHR3ZWV0cywgc2NlbmUpIHtcbiAgICBpZiAoc2NlbmUgIT09ICdwcm9maWxlJyB8fCBzZWxlY3RlZFRhYklkID09PSBudWxsKVxuICAgICAgICByZXR1cm4gJyc7XG4gICAgY29uc3Qgc2VsZWN0ZWRJZCA9IHNlbGVjdGVkUHJvZmlsZVR3ZWV0SWRzLmdldChzZWxlY3RlZFRhYklkKTtcbiAgICBpZiAoIXNlbGVjdGVkSWQpXG4gICAgICAgIHJldHVybiAnJztcbiAgICBjb25zdCBzZWxlY3RlZFR3ZWV0ID0gKHR3ZWV0cyB8fCBbXSkuZmluZCh0ID0+IHQudHdlZXRJZCA9PT0gc2VsZWN0ZWRJZCk7XG4gICAgaWYgKCFzZWxlY3RlZFR3ZWV0KVxuICAgICAgICByZXR1cm4gJyc7XG4gICAgcmV0dXJuIGBcbiAgICAgICAgPGRpdiBjbGFzcz1cIm1iLTMgcC0yIGJvcmRlci1zdGFydCBib3JkZXItM1wiIHN0eWxlPVwiYmFja2dyb3VuZDogcmdiYSg0NSw1NSw3MiwwLjIpOyBib3JkZXItY29sb3I6ICM0YTU1Njg7IGJvcmRlci1yYWRpdXM6IDAgNHB4IDRweCAwXCI+XG4gICAgICAgICAgICA8ZGl2IGNsYXNzPVwiZC1mbGV4IGp1c3RpZnktY29udGVudC1iZXR3ZWVuIGFsaWduLWl0ZW1zLWNlbnRlclwiPlxuICAgICAgICAgICAgICAgIDxkaXYgc3R5bGU9XCJmb250LXNpemU6IDExcHg7XCI+XG4gICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzPVwidGV4dC1tdXRlZCBmdy1ib2xkXCI+Q2FuZGlkYXRlIFR5cGU6PC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzcz1cIm1zLTEgZnctYm9sZCB0ZXh0LXdoaXRlXCI+UFJPRklMRSBUV0VFVDwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3M9XCJtcy0xIHRleHQtaW5mb1wiIHN0eWxlPVwiZm9udC1zaXplOiAxMHB4XCI+QCR7KHNlbGVjdGVkVHdlZXQuYXV0aG9ySGFuZGxlIHx8ICcnKS5yZXBsYWNlKCdAJywgJycpfTwvc3Bhbj5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICA8c3BhbiBjbGFzcz1cImJhZGdlIGJnLWRhcmsgdGV4dC1tdXRlZCBib3JkZXIgYm9yZGVyLXNlY29uZGFyeVwiIHN0eWxlPVwiZm9udC1zaXplOjhweFwiPlJFQUQgT05MWSBDQU5ESURBVEU8L3NwYW4+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJtdC0xIGQtZmxleCBqdXN0aWZ5LWNvbnRlbnQtYmV0d2VlbiBhbGlnbi1pdGVtcy1jZW50ZXJcIj5cbiAgICAgICAgICAgICAgICA8c3BhbiBjbGFzcz1cImZvbnQtbW9ub3NwYWNlIHRleHQtd2FybmluZ1wiIHN0eWxlPVwiZm9udC1zaXplOiAxMHB4OyBvcGFjaXR5OiAwLjlcIj4ke3NlbGVjdGVkVHdlZXQudHdlZXRJZH08L3NwYW4+XG4gICAgICAgICAgICAgICAgPHNwYW4gY2xhc3M9XCJ0ZXh0LW11dGVkXCIgc3R5bGU9XCJmb250LXNpemU6IDlweDsgZm9udC1zdHlsZTogaXRhbGljXCI+Tm90IHlldCBib3VuZCB0byBhY3Rpb24gdGFyZ2V0PC9zcGFuPlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICA8ZGl2IGNsYXNzPVwibXQtMVwiIHN0eWxlPVwiZm9udC1zaXplOiA5cHg7IGNvbG9yOiAjYTBhZWMwXCI+XG4gICAgICAgICAgICAgICAgT3duZXJzaGlwOiAke3NlbGVjdGVkVHdlZXQuaXNPd25lZEJ5QWN0aXZlQWNjb3VudCA/ICdPV05FRCcgOiAnT1RIRVJTJ31cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICA8L2Rpdj5gO1xufVxuLy8g4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSAXG4vLyBFeGVjdXRpb24gSW50ZW50IOa4suafkyAoTkVXKVxuLy8g4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSAXG5mdW5jdGlvbiByZW5kZXJFeGVjdXRpb25JbnRlbnQodGlkLCBwYWdlQ29udGV4dCwgY3VycmVudElucHV0VmFsdWUpIHtcbiAgICBjb25zdCB7IHRhcmdldFR5cGUsIHRhcmdldElkLCBhdXRob3JIYW5kbGUgfSA9IGdldEN1cnJlbnRSZXBseUludGVudCh0aWQsIHBhZ2VDb250ZXh0LCBjdXJyZW50SW5wdXRWYWx1ZSk7XG4gICAgbGV0IHNvdXJjZUxhYmVsID0gJ05PTkUnO1xuICAgIGxldCBiYWRnZUNsYXNzID0gJ2JnLXNlY29uZGFyeSc7XG4gICAgbGV0IGJvcmRlckNvbG9yID0gJyNjYmQ1ZTAnO1xuICAgIGlmICh0YXJnZXRUeXBlID09PSAnbWFudWFsIHRhcmdldCcpIHtcbiAgICAgICAgc291cmNlTGFiZWwgPSAnTUFOVUFMIE9WRVJSSURFJztcbiAgICAgICAgYmFkZ2VDbGFzcyA9ICdiZy13YXJuaW5nIHRleHQtZGFyayc7XG4gICAgICAgIGJvcmRlckNvbG9yID0gJyNmZmMxMDcnO1xuICAgIH1cbiAgICBlbHNlIGlmICh0YXJnZXRUeXBlID09PSAnc2VsZWN0ZWQgcmVwbHknKSB7XG4gICAgICAgIHNvdXJjZUxhYmVsID0gJ0FVVE86IFNFTEVDVEVEIFJFUExZJztcbiAgICAgICAgYmFkZ2VDbGFzcyA9ICdiZy1wcmltYXJ5JztcbiAgICAgICAgYm9yZGVyQ29sb3IgPSAnIzBkNmVmZCc7XG4gICAgfVxuICAgIGVsc2UgaWYgKHRhcmdldFR5cGUgPT09ICdjdXJyZW50IHR3ZWV0Jykge1xuICAgICAgICBzb3VyY2VMYWJlbCA9ICdBVVRPOiBDVVJSRU5UIEVOVElUWSc7XG4gICAgICAgIGJhZGdlQ2xhc3MgPSAnYmctc3VjY2Vzcyc7XG4gICAgICAgIGJvcmRlckNvbG9yID0gJyMxOTg3NTQnO1xuICAgIH1cbiAgICBpZiAodGFyZ2V0VHlwZSA9PT0gJ05PTkUnKSB7XG4gICAgICAgIHJldHVybiBgXG4gICAgICAgICAgICA8ZGl2IGNsYXNzPVwibWItMiBwLTIgYm9yZGVyLXN0YXJ0IGJvcmRlci0zXCIgc3R5bGU9XCJiYWNrZ3JvdW5kOiByZ2JhKDQ1LDU1LDcyLDAuMik7IGJvcmRlci1jb2xvcjogIzRhNTU2ODsgYm9yZGVyLXJhZGl1czogMCA0cHggNHB4IDBcIj5cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzPVwiZC1mbGV4IGp1c3RpZnktY29udGVudC1iZXR3ZWVuIGFsaWduLWl0ZW1zLWNlbnRlclwiPlxuICAgICAgICAgICAgICAgICAgICA8ZGl2IHN0eWxlPVwiZm9udC1zaXplOiAxMXB4O1wiPlxuICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3M9XCJ0ZXh0LW11dGVkIGZ3LWJvbGRcIj5JTlRFTlQ6PC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3M9XCJtcy0xIHRleHQtbXV0ZWQgaXRhbGljXCI+Tk8gVEFSR0VUPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3M9XCJiYWRnZSBiZy1kYXJrIHRleHQtbXV0ZWQgYm9yZGVyIGJvcmRlci1zZWNvbmRhcnlcIiBzdHlsZT1cImZvbnQtc2l6ZTo4cHhcIj5OT05FPC9zcGFuPlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgPC9kaXY+YDtcbiAgICB9XG4gICAgcmV0dXJuIGBcbiAgICAgICAgPGRpdiBjbGFzcz1cIm1iLTIgcC0yIGJvcmRlci1zdGFydCBib3JkZXItM1wiIHN0eWxlPVwiYmFja2dyb3VuZDogcmdiYSg0NSw1NSw3MiwwLjIpOyBib3JkZXItY29sb3I6ICR7Ym9yZGVyQ29sb3J9OyBib3JkZXItcmFkaXVzOiAwIDRweCA0cHggMFwiPlxuICAgICAgICAgICAgPGRpdiBjbGFzcz1cImQtZmxleCBqdXN0aWZ5LWNvbnRlbnQtYmV0d2VlbiBhbGlnbi1pdGVtcy1jZW50ZXJcIj5cbiAgICAgICAgICAgICAgICA8ZGl2IHN0eWxlPVwiZm9udC1zaXplOiAxMXB4O1wiPlxuICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzcz1cInRleHQtbXV0ZWQgZnctYm9sZFwiPklOVEVOVDo8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzPVwibXMtMSBmdy1ib2xkIHRleHQtd2hpdGVcIj4ke3RhcmdldFR5cGUudG9VcHBlckNhc2UoKX08L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICR7YXV0aG9ySGFuZGxlID8gYDxzcGFuIGNsYXNzPVwibXMtMSB0ZXh0LWluZm9cIiBzdHlsZT1cImZvbnQtc2l6ZTogMTBweFwiPkAke2F1dGhvckhhbmRsZS5yZXBsYWNlKCdAJywgJycpfTwvc3Bhbj5gIDogJyd9XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgPHNwYW4gY2xhc3M9XCJiYWRnZSAke2JhZGdlQ2xhc3N9XCIgc3R5bGU9XCJmb250LXNpemU6OHB4OyBmb250LXdlaWdodDogbm9ybWFsXCI+JHtzb3VyY2VMYWJlbH08L3NwYW4+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJtdC0xIGZvbnQtbW9ub3NwYWNlIHRleHQtd2FybmluZ1wiIHN0eWxlPVwiZm9udC1zaXplOiAxMHB4OyBvcGFjaXR5OiAwLjlcIj4ke3RhcmdldElkIHx8ICdFTVBUWSd9PC9kaXY+XG4gICAgICAgIDwvZGl2PmA7XG59XG4vLyDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIBcbi8vIFJlcGx5IERyYWZ0IFVJIOa4suafkyAoTkVXKVxuLy8g4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSAXG5mdW5jdGlvbiByZW5kZXJSZXBseURyYWZ0VUkodGlkLCBwYWdlQ29udGV4dCwgY3VycmVudElucHV0VmFsdWUsIGlzTG9nZ2VkT3V0KSB7XG4gICAgY29uc3QgeyB0YXJnZXRUeXBlLCB0YXJnZXRJZCwgYXV0aG9ySGFuZGxlIH0gPSBnZXRDdXJyZW50UmVwbHlJbnRlbnQodGlkLCBwYWdlQ29udGV4dCwgY3VycmVudElucHV0VmFsdWUpO1xuICAgIGlmICh0YXJnZXRUeXBlID09PSAnTk9ORScpXG4gICAgICAgIHJldHVybiAnJztcbiAgICBjb25zdCBoYXNUYXJnZXQgPSAhIXRhcmdldElkO1xuICAgIGNvbnN0IGhhc1RleHQgPSAhIXJlcGx5RHJhZnRUZXh0LnRyaW0oKTtcbiAgICBsZXQgY3VycmVudFN0YXRlID0gQVBQUk9WQUxfU1RBVEUuRFJBRlRfRU1QVFk7XG4gICAgaWYgKGlzTG9nZ2VkT3V0KSB7XG4gICAgICAgIGN1cnJlbnRTdGF0ZSA9IEFQUFJPVkFMX1NUQVRFLkxPQ0tFRF9MT0dHRURfT1VUO1xuICAgIH1cbiAgICBlbHNlIGlmICghaGFzVGV4dCkge1xuICAgICAgICBjdXJyZW50U3RhdGUgPSBBUFBST1ZBTF9TVEFURS5EUkFGVF9FTVBUWTtcbiAgICB9XG4gICAgZWxzZSBpZiAoIWhhc1RhcmdldCkge1xuICAgICAgICBjdXJyZW50U3RhdGUgPSBBUFBST1ZBTF9TVEFURS5EUkFGVF9OT1RfUkVBRFk7XG4gICAgfVxuICAgIGVsc2Uge1xuICAgICAgICBjdXJyZW50U3RhdGUgPSBBUFBST1ZBTF9TVEFURS5SRUFEWV9GT1JfUkVWSUVXO1xuICAgIH1cbiAgICBsZXQgc3RhdHVzSHRtbCA9ICcnO1xuICAgIGxldCBzdGF0dXNMYWJlbCA9ICcnO1xuICAgIGxldCBzdGF0dXNDb2xvciA9ICd0ZXh0LW11dGVkJztcbiAgICBsZXQgc2hvd1Jldmlld0J0biA9IGZhbHNlO1xuICAgIGxldCByZXZpZXdDb25maXJtZWRIdG1sID0gJyc7XG4gICAgc3dpdGNoIChjdXJyZW50U3RhdGUpIHtcbiAgICAgICAgY2FzZSBBUFBST1ZBTF9TVEFURS5MT0NLRURfTE9HR0VEX09VVDpcbiAgICAgICAgICAgIHN0YXR1c0xhYmVsID0gJ0xPQ0tFRCAoTE9HR0VEIE9VVCknO1xuICAgICAgICAgICAgc3RhdHVzQ29sb3IgPSAndGV4dC1kYW5nZXInO1xuICAgICAgICAgICAgc3RhdHVzSHRtbCA9ICc8c3BhbiBjbGFzcz1cInRleHQtZGFuZ2VyXCIgc3R5bGU9XCJmb250LXNpemU6MTBweFwiPlBsZWFzZSBsb2cgaW4gdG8gWCB0byBjb250aW51ZS48L3NwYW4+JztcbiAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICBjYXNlIEFQUFJPVkFMX1NUQVRFLkRSQUZUX0VNUFRZOlxuICAgICAgICAgICAgc3RhdHVzTGFiZWwgPSAnRFJBRlQgRU1QVFknO1xuICAgICAgICAgICAgc3RhdHVzSHRtbCA9ICc8c3BhbiBjbGFzcz1cInRleHQtbXV0ZWRcIiBzdHlsZT1cImZvbnQtc2l6ZToxMHB4XCI+V2FpdGluZyBmb3IgZHJhZnQgY29udGVudC4uLjwvc3Bhbj4nO1xuICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgIGNhc2UgQVBQUk9WQUxfU1RBVEUuRFJBRlRfTk9UX1JFQURZOlxuICAgICAgICAgICAgc3RhdHVzTGFiZWwgPSAnRFJBRlQgTk9UIFJFQURZJztcbiAgICAgICAgICAgIHN0YXR1c0NvbG9yID0gJ3RleHQtd2FybmluZyc7XG4gICAgICAgICAgICBzdGF0dXNIdG1sID0gJzxzcGFuIGNsYXNzPVwidGV4dC13YXJuaW5nXCIgc3R5bGU9XCJmb250LXNpemU6MTBweFwiPkhhcyBkcmFmdCBidXQgbm8gdmFsaWQgdGFyZ2V0IGRldGVjdGVkLjwvc3Bhbj4nO1xuICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgIGNhc2UgQVBQUk9WQUxfU1RBVEUuUkVBRFlfRk9SX1JFVklFVzpcbiAgICAgICAgICAgIHN0YXR1c0xhYmVsID0gJ1JFQURZIEZPUiBIVU1BTiBSRVZJRVcnO1xuICAgICAgICAgICAgc3RhdHVzQ29sb3IgPSAndGV4dC1pbmZvJztcbiAgICAgICAgICAgIHN0YXR1c0h0bWwgPSAnPHNwYW4gY2xhc3M9XCJ0ZXh0LWluZm9cIiBzdHlsZT1cImZvbnQtc2l6ZToxMHB4XCI+Q29udGVudCBhbmQgdGFyZ2V0IGFyZSByZWFkeSBmb3IgcmV2aWV3Ljwvc3Bhbj4nO1xuICAgICAgICAgICAgc2hvd1Jldmlld0J0biA9IHRydWU7XG4gICAgICAgICAgICBpZiAoaXNSZXZpZXdDb25maXJtZWQpIHtcbiAgICAgICAgICAgICAgICByZXZpZXdDb25maXJtZWRIdG1sID0gYFxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJtdC0yIHRleHQtY2VudGVyIHAtMiByb3VuZGVkXCIgc3R5bGU9XCJiYWNrZ3JvdW5kOiByZ2JhKDI1LCAxMzUsIDg0LCAwLjIpOyBib3JkZXI6IDFweCBzb2xpZCByZ2JhKDI1LCAxMzUsIDg0LCAwLjQpXCI+XG4gICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzPVwidGV4dC1zdWNjZXNzIGZ3LWJvbGRcIiBzdHlsZT1cImZvbnQtc2l6ZToxMXB4XCI+UkVBRFk6IFJFVklFVyBDT05GSVJNRUQgKFNUSUxMIE5PVCBTRU5UKTwvc3Bhbj5cbiAgICAgICAgICAgICAgICA8L2Rpdj5gO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgYnJlYWs7XG4gICAgfVxuICAgIHJldHVybiBgXG4gICAgICAgIDxkaXYgaWQ9XCJyZXBseS1pbnRlbnQtcHJldmlldy1jb250YWluZXJcIj5cbiAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJtdC00XCI+XG4gICAgICAgICAgICAgICAgPGRpdiBzdHlsZT1cImZvbnQtc2l6ZToxMHB4OyBjb2xvcjojY2JkNWUwOyB0ZXh0LXRyYW5zZm9ybTp1cHBlcmNhc2U7IGZvbnQtd2VpZ2h0OjcwMDsgbWFyZ2luLWJvdHRvbTo2cHhcIj5SZXBseSBEcmFmdDwvZGl2PlxuICAgICAgICAgICAgICAgIDx0ZXh0YXJlYSBpZD1cInJlcGx5LWRyYWZ0LXRleHRcIiBjbGFzcz1cImZvcm0tY29udHJvbCBmb3JtLWNvbnRyb2wtc20gYmctYmxhY2sgdGV4dC1saWdodCBib3JkZXItc2Vjb25kYXJ5XCIgcm93cz1cIjJcIiBwbGFjZWhvbGRlcj1cIldyaXRlIHlvdXIgcmVwbHkgZHJhZnQgaGVyZS4uLlwiIHN0eWxlPVwiZm9udC1zaXplOjExcHg7XCI+JHtyZXBseURyYWZ0VGV4dH08L3RleHRhcmVhPlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICBcbiAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJtdC0zIHAtMlwiIHN0eWxlPVwiYmFja2dyb3VuZDogcmdiYSgwLDAsMCwwLjIpOyBib3JkZXI6IDFweCBzb2xpZCAjMmQzNzQ4OyBib3JkZXItcmFkaXVzOiA2cHg7XCI+XG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzcz1cImQtZmxleCBqdXN0aWZ5LWNvbnRlbnQtYmV0d2VlbiBhbGlnbi1pdGVtcy1jZW50ZXIgbWItMlwiPlxuICAgICAgICAgICAgICAgICAgICA8ZGl2IHN0eWxlPVwiZm9udC1zaXplOjEwcHg7IGNvbG9yOiNjYmQ1ZTA7IHRleHQtdHJhbnNmb3JtOnVwcGVyY2FzZTsgZm9udC13ZWlnaHQ6NzAwXCI+UmVwbHkgSW50ZW50IFByZXZpZXc8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3M9XCJiYWRnZSBiZy1kYXJrIGJvcmRlciAke3N0YXR1c0NvbG9yLnJlcGxhY2UoJ3RleHQtJywgJ2JvcmRlci0nKX1cIiBzdHlsZT1cImZvbnQtc2l6ZTo4cHg7ICR7c3RhdHVzQ29sb3IucmVwbGFjZSgndGV4dC0nLCAnY29sb3I6Jyl9XCI+JHtzdGF0dXNMYWJlbH08L3NwYW4+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzcz1cInN5cy1zdGF0XCI+PHNwYW4+VGFyZ2V0PC9zcGFuPjxzcGFuIGNsYXNzPVwidmFsIHRleHQtaW5mb1wiIHN0eWxlPVwiZm9udC1zaXplOjEwcHhcIj4ke3RhcmdldFR5cGUudG9VcHBlckNhc2UoKX0gJHthdXRob3JIYW5kbGUgPyBgKEAke2F1dGhvckhhbmRsZS5yZXBsYWNlKCdAJywgJycpfSlgIDogJyd9PC9zcGFuPjwvZGl2PlxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJzeXMtc3RhdFwiPjxzcGFuPklEPC9zcGFuPjxzcGFuIGNsYXNzPVwidmFsIHRleHQtd2FybmluZ1wiIHN0eWxlPVwiZm9udC1zaXplOjEwcHhcIj4ke3RhcmdldElkIHx8ICfigJQnfTwvc3Bhbj48L2Rpdj5cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzPVwic3lzLXN0YXRcIj48c3Bhbj5EcmFmdDwvc3Bhbj48c3BhbiBjbGFzcz1cInZhbCB0ZXh0LXRydW5jYXRlXCIgc3R5bGU9XCJtYXgtd2lkdGg6IDE1MHB4OyBmb250LXNpemU6MTBweFwiPiR7cmVwbHlEcmFmdFRleHQgfHwgJ+KAlCd9PC9zcGFuPjwvZGl2PlxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJtdC0xIHRleHQtY2VudGVyXCI+XG4gICAgICAgICAgICAgICAgICAgICR7c3RhdHVzSHRtbH1cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAke3Jldmlld0NvbmZpcm1lZEh0bWx9XG4gICAgICAgICAgICAgICAgJHtzaG93UmV2aWV3QnRuICYmICFpc1Jldmlld0NvbmZpcm1lZCA/IGBcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzPVwibXQtMiBwdC0yIGJvcmRlci10b3AgYm9yZGVyLXNlY29uZGFyeVwiPlxuICAgICAgICAgICAgICAgICAgICA8YnV0dG9uIGlkPVwiYnRuLXJldmlldy1vbmx5XCIgY2xhc3M9XCJidG4gYnRuLWluZm8gYnRuLXNtIHctMTAwIHB5LTFcIiBzdHlsZT1cImZvbnQtc2l6ZToxMXB4OyBmb250LXdlaWdodDpib2xkXCI+UmV2aWV3IE9ubHkgKExvY2FsIENvbmZpcm1hdGlvbik8L2J1dHRvbj5cbiAgICAgICAgICAgICAgICA8L2Rpdj5gIDogJyd9XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgPC9kaXY+XG4gICAgYDtcbn1cbi8vIOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgFxuLy8gRSDljLrvvJpTZXNzaW9uIC8gSWRlbnRpdHkg5riy5p+TXG4vLyDmnIkgYWNjb3VudCDihpIg5bGV56S65q2j5byP6Lqr5Lu9XG4vLyDml6AgYWNjb3VudCDkvYbmnIkgZmVhdHVyZWRUd2VldCDihpIg5bGV56S6XCLlt7Lop4Llr5/liLDnmoTmjqjmlofkvZzogIVcIuS9nOS4uuWPguiAg1xuLy8g6YO95rKh5pyJIOKGkiDmj5DnpLrnlKjmiLfmk43kvZxcbi8vIOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgFxuZnVuY3Rpb24gcmVuZGVySWRlbnRpdHlQYW5lbChhY2NvdW50LCBmZWF0dXJlZFR3ZWV0LCBkYXRhSWQsIHNjZW5lKSB7XG4gICAgaWYgKGFjY291bnQpIHtcbiAgICAgICAgcmV0dXJuIGBcbiAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJzeXMtc3RhdFwiPjxzcGFuPkhhbmRsZTwvc3Bhbj48c3BhbiBjbGFzcz1cInZhbCB0ZXh0LWluZm9cIj4ke2FjY291bnQuaGFuZGxlfTwvc3Bhbj48L2Rpdj5cbiAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJzeXMtc3RhdFwiPjxzcGFuPlVzZXIgSUQ8L3NwYW4+PHNwYW4gY2xhc3M9XCJ2YWxcIiBzdHlsZT1cImZvbnQtc2l6ZToxMXB4XCI+JHthY2NvdW50LnVzZXJJZH08L3NwYW4+PC9kaXY+XG4gICAgICAgICAgICA8ZGl2IGNsYXNzPVwic3lzLXN0YXRcIj48c3Bhbj5EaXNwbGF5IE5hbWU8L3NwYW4+PHNwYW4gY2xhc3M9XCJ2YWxcIj4ke2FjY291bnQuZGlzcGxheU5hbWUgfHwgJ+KAlCd9PC9zcGFuPjwvZGl2PlxuICAgICAgICAgICAgPGRpdiBjbGFzcz1cInN5cy1zdGF0XCI+PHNwYW4+VmVyaWZpZWQ8L3NwYW4+JHtiYWRnZSghIWFjY291bnQudmVyaWZpZWQsICdZRVMnLCAnTk8nKX08L2Rpdj5gO1xuICAgIH1cbiAgICBpZiAoc2NlbmUgPT09ICdpZGVudGl0eV9yZXNvbHZpbmcnKSB7XG4gICAgICAgIHJldHVybiBgXG4gICAgICAgICAgICA8ZGl2IGNsYXNzPVwidGV4dC1pbmZvIHNtYWxsIG1iLTIgZC1mbGV4IGFsaWduLWl0ZW1zLWNlbnRlclwiIHN0eWxlPVwiZm9udC1zaXplOjExcHhcIj5cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzPVwic3Bpbm5lci1ib3JkZXIgc3Bpbm5lci1ib3JkZXItc20gbWUtMlwiIHJvbGU9XCJzdGF0dXNcIiBzdHlsZT1cIndpZHRoOjEwcHg7IGhlaWdodDoxMHB4XCI+PC9kaXY+XG4gICAgICAgICAgICAgICAgUmVzb2x2aW5nIGlkZW50aXR5Li4uPGJyPlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICA8ZGl2IGNsYXNzPVwidGV4dC1tdXRlZFwiIHN0eWxlPVwiZm9udC1zaXplOjEwcHhcIj5cbiAgICAgICAgICAgICAgICBXYWl0aW5nIGZvciA8Y29kZT5WaWV3ZXI8L2NvZGU+IGNhcHR1cmUuIDxicj5cbiAgICAgICAgICAgICAgICA8c3BhbiBjbGFzcz1cInRleHQtd2FybmluZ1wiPlNjcm9sbCB0aGUgcGFnZSBvciB0cnkgcmVmcmVzaGluZyBpZiBzdHVjay48L3NwYW4+XG4gICAgICAgICAgICA8L2Rpdj5gO1xuICAgIH1cbiAgICAvLyDkv53lupXmmL7npLrvvJrlpoLmnpzmiJHku6zmnIkgVUlE77yI5p2l6IeqIENvb2tpZe+8ie+8jOWNs+S9v+ayoeaLv+WIsCBIYW5kbGUg5Lmf5bGV56S65a6DXG4gICAgY29uc3QgdWlkSHRtbCA9IGFjY291bnQ/LnVzZXJJZCA/IGA8ZGl2IGNsYXNzPVwic3lzLXN0YXRcIj48c3Bhbj5WZXJpZmllZCBVSUQ8L3NwYW4+PHNwYW4gY2xhc3M9XCJ2YWwgdGV4dC1zdWNjZXNzXCI+JHthY2NvdW50LnVzZXJJZH08L3NwYW4+PC9kaXY+YCA6ICcnO1xuICAgIC8vIOayoeaciei6q+S7vSDihpIg5YWI57uZ5o+Q56S677yM5YaN5bGV56S65o6o5paH5L2c6ICF5Y+C6ICDXG4gICAgY29uc3QgaGludCA9IGBcbiAgICAgICAgPGRpdiBjbGFzcz1cInRleHQtd2FybmluZyBzbWFsbCBtYi0yXCIgc3R5bGU9XCJmb250LXNpemU6MTFweFwiPlxuICAgICAgICAgICAg4pqgIElkZW50aXR5IG5vdCBmdWxseSBjYXB0dXJlZC48YnI+XG4gICAgICAgICAgICA8c3BhbiBjbGFzcz1cInRleHQtbXV0ZWRcIj5OZWVkIDxjb2RlPlZpZXdlcjwvY29kZT4gb3IgPGNvZGU+c2V0dGluZ3MuanNvbjwvY29kZT4gaW50ZXJjZXB0Ljwvc3Bhbj5cbiAgICAgICAgPC9kaXY+XG4gICAgICAgICR7dWlkSHRtbH1cbiAgICAgICAgPGRpdiBjbGFzcz1cIm10LTIgdGV4dC1jZW50ZXJcIj48YnV0dG9uIGNsYXNzPVwiYnRuIGJ0bi1kYXJrIGJ0bi1zbVwiIHN0eWxlPVwiZm9udC1zaXplOjlweFwiIG9uY2xpY2s9XCJsb2NhdGlvbi5yZWxvYWQoKVwiPlJFRlJFU0ggREVCVUcgUEFORUw8L2J1dHRvbj48L2Rpdj5gO1xuICAgIGlmICghZmVhdHVyZWRUd2VldClcbiAgICAgICAgcmV0dXJuIGhpbnQ7XG4gICAgLy8g5pyJ5o6o5paH5L2G5peg6Lqr5Lu977ya5bGV56S6XCLlt7Lop4Llr5/liLDnmoTmjqjmlofkvZzogIVcIlxuICAgIHJldHVybiBoaW50ICsgYFxuICAgICAgICA8aHIgY2xhc3M9XCJib3JkZXItc2Vjb25kYXJ5IG15LTJcIj5cbiAgICAgICAgPGRpdiBzdHlsZT1cImZvbnQtc2l6ZToxMHB4O2NvbG9yOiM4ODk5QTY7bWFyZ2luLWJvdHRvbTo2cHhcIj5PQlNFUlZFRCBUV0VFVCBBVVRIT1IgKHJlZmVyZW5jZSk8L2Rpdj5cbiAgICAgICAgPGRpdiBjbGFzcz1cInN5cy1zdGF0XCI+PHNwYW4+QXV0aG9yIEhhbmRsZTwvc3Bhbj48c3BhbiBjbGFzcz1cInZhbCB0ZXh0LXNlY29uZGFyeVwiPiR7ZmVhdHVyZWRUd2VldC5hdXRob3JIYW5kbGUgfHwgJ+KAlCd9PC9zcGFuPjwvZGl2PlxuICAgICAgICA8ZGl2IGNsYXNzPVwic3lzLXN0YXRcIj48c3Bhbj5BdXRob3IgTmFtZTwvc3Bhbj48c3BhbiBjbGFzcz1cInZhbCB0ZXh0LXNlY29uZGFyeVwiPiR7ZmVhdHVyZWRUd2VldC5hdXRob3JOYW1lIHx8ICfigJQnfTwvc3Bhbj48L2Rpdj5cbiAgICAgICAgPGRpdiBjbGFzcz1cInN5cy1zdGF0XCI+PHNwYW4+QXV0aG9yIElEPC9zcGFuPjxzcGFuIGNsYXNzPVwidmFsIHRleHQtc2Vjb25kYXJ5XCIgc3R5bGU9XCJmb250LXNpemU6MTBweFwiPiR7ZmVhdHVyZWRUd2VldC5hdXRob3JJZCB8fCAn4oCUJ308L3NwYW4+PC9kaXY+YDtcbn1cbi8vIOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgFxuLy8g5Li75riy5p+T77yaQS9CL0MvRC9FL0Yg5YWt5Yy6XG4vLyDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIBcbmZ1bmN0aW9uIHJlbmRlckRldGFpbFZpZXcoZGF0YSwgcGFnZUNvbnRleHQpIHtcbiAgICBjb25zdCBjb250YWluZXIgPSBkb2N1bWVudC5nZXRFbGVtZW50QnlJZCgndGFiLWRhdGEtdmlldycpO1xuICAgIGlmICghY29udGFpbmVyKVxuICAgICAgICByZXR1cm47XG4gICAgY29uc3QgaGl0cyA9IChkYXRhLmFwaUhpdHMgfHwgW10pO1xuICAgIGNvbnN0IGhvb2tTdCA9IGRhdGEuaG9va1N0YXR1cyB8fCB7IGZldGNoOiBmYWxzZSwgeGhyOiBmYWxzZSB9O1xuICAgIGNvbnN0IHN0YXRzID0gZGF0YS5zdGF0cyB8fCB7fTtcbiAgICBjb25zdCBhbGxPcHMgPSAoZGF0YS5hbGxXYXRjaGVkT3BzIHx8IFtdKTtcbiAgICBjb25zdCBhY2NvdW50ID0gZGF0YS5hY2NvdW50IHx8IG51bGw7XG4gICAgY29uc3QgbWFpblR3ZWV0ID0gZGF0YS5mZWF0dXJlZFR3ZWV0IHx8IG51bGw7XG4gICAgY29uc3QgbGFzdEhpdCA9IGhpdHMubGVuZ3RoID4gMCA/IGhpdHNbMF0udGltZXN0YW1wIDogbnVsbDtcbiAgICBjb25zdCB0YWJNZXRhID0gdGFiTGlzdC5maW5kKHQgPT4gdC5pZCA9PT0gc2VsZWN0ZWRUYWJJZCkgfHwge307XG4gICAgY29uc3QgaXNYUGFnZSA9IC9eaHR0cHM/OlxcL1xcLyh0d2l0dGVyXFwuY29tfHhcXC5jb20pLy50ZXN0KHRhYk1ldGEudXJsIHx8ICcnKTtcbiAgICAvLyDkv53lrZggaGl0cyDkvpsgTW9kYWwg5byV55SoXG4gICAgY3VycmVudEhpdHMgPSBoaXRzO1xuICAgIC8vIOKUgOKUgCBEIOWMuu+8muWNoeeJh+a4suafk++8iOaXoOW1jOWll+a7muWKqO+8jERldGFpbHMg5oyJ6ZKu5by5IE1vZGFs77yJXG4gICAgZnVuY3Rpb24gcmVuZGVySGl0Q2FyZChoLCBpKSB7XG4gICAgICAgIGxldCBhcGlQYXRoID0gJ+KAlCc7XG4gICAgICAgIHRyeSB7XG4gICAgICAgICAgICBhcGlQYXRoID0gaC5hcGlVcmwgPyBuZXcgVVJMKGguYXBpVXJsKS5wYXRobmFtZS5zcGxpdCgnLycpLnNsaWNlKC0yKS5qb2luKCcvJykgOiAn4oCUJztcbiAgICAgICAgfVxuICAgICAgICBjYXRjaCB7XG4gICAgICAgICAgICBhcGlQYXRoID0gaC5vcDtcbiAgICAgICAgfVxuICAgICAgICBjb25zdCBwYXJhbVN1bW1hcnkgPSByZXFTdW1tYXJ5KGgucmVxdWVzdEJvZHkpO1xuICAgICAgICBjb25zdCBpc0lkID0gWydBdXRoZW50aWNhdGVkVXNlclF1ZXJ5JywgJ1ZpZXdlcicsICdBY2NvdW50U2V0dGluZ3MnLCAnc2V0dGluZ3MuanNvbicsICdWZXJpZnlDcmVkZW50aWFscyddLmluY2x1ZGVzKGgub3ApO1xuICAgICAgICByZXR1cm4gYFxuICAgICAgICA8ZGl2IGNsYXNzPVwiaGl0LWNhcmQgJHtpc0lkID8gJ2hpdC1jYXJkLWlkJyA6ICcnfVwiPlxuICAgICAgICAgICAgPGRpdiBjbGFzcz1cImhpdC1jYXJkLXRvcFwiPlxuICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzPVwibWV0aG9kXCI+JHtoLm1ldGhvZCB8fCAnR0VUJ308L3NwYW4+XG4gICAgICAgICAgICAgICAgPHNwYW4gY2xhc3M9XCJoaXQtY2FyZC1vcFwiIHRpdGxlPVwiJHtoLm9wfVwiPiR7aC5vcH08L3NwYW4+XG4gICAgICAgICAgICAgICAgJHtpc0lkID8gJzxzcGFuIGNsYXNzPVwiYmFkZ2UgYmctd2FybmluZyB0ZXh0LWRhcmtcIiBzdHlsZT1cImZvbnQtc2l6ZTo5cHhcIj5JREVOVElUWTwvc3Bhbj4nIDogJyd9XG4gICAgICAgICAgICAgICAgPHNwYW4gY2xhc3M9XCJoaXQtdGltZSBtcy1hdXRvXCI+JHtuZXcgRGF0ZShoLnRpbWVzdGFtcCkudG9Mb2NhbGVUaW1lU3RyaW5nKCl9PC9zcGFuPlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICA8ZGl2IGNsYXNzPVwiaGl0LWNhcmQtcGF0aFwiIHRpdGxlPVwiJHtoLmFwaVVybCB8fCAnJ31cIj4ke2FwaVBhdGh9PC9kaXY+XG4gICAgICAgICAgICA8ZGl2IGNsYXNzPVwiaGl0LWNhcmQtcGFyYW1zXCI+JHtwYXJhbVN1bW1hcnkgIT09ICfigJQnID8gcGFyYW1TdW1tYXJ5IDogJzxzcGFuIGNsYXNzPVwidGV4dC1tdXRlZFwiPm5vIHBhcmFtczwvc3Bhbj4nfTwvZGl2PlxuICAgICAgICAgICAgPGRpdiBjbGFzcz1cImhpdC1jYXJkLWZvb3RlclwiPlxuICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzPVwidGV4dC1zdWNjZXNzXCIgc3R5bGU9XCJmb250LXNpemU6MTBweFwiPuKXjyAyMDA8L3NwYW4+XG4gICAgICAgICAgICAgICAgPGJ1dHRvbiBjbGFzcz1cImJ0bi1oaXQtZGV0YWlsXCIgZGF0YS1oaXQtaW5kZXg9XCIke2l9XCI+RGV0YWlscyDigLo8L2J1dHRvbj5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICA8L2Rpdj5gO1xuICAgIH1cbiAgICBjb25zdCBpc0xvZ2dlZE91dCA9IHBhZ2VDb250ZXh0Py5zY2VuZSA9PT0gJ2xvZ2luX3JlcXVpcmVkJztcbiAgICBjb25zdCBoYXNUYXJnZXQgPSAhIW1haW5Ud2VldD8uaWQ7XG4gICAgY29uc3QgY2FuV3JpdGUgPSAhaXNMb2dnZWRPdXQgJiYgKHBhZ2VDb250ZXh0Py5zY2VuZSAhPT0gJ2lkZW50aXR5X3Jlc29sdmluZycpO1xuICAgIC8vIOKUgOKUgCBUYXJnZXQgSUQgQmluZGluZyBMb2dpYyDilIDilIBcbiAgICBjb25zdCB0aWQgPSBzZWxlY3RlZFRhYklkO1xuICAgIGNvbnN0IGN1ckVudGl0eUlkID0gcGFnZUNvbnRleHQuY3VycmVudEVudGl0eT8uZW50aXR5SWQgfHwgJyc7XG4gICAgY29uc3QgaXNUd2VldERldGFpbCA9IHBhZ2VDb250ZXh0LnNjZW5lID09PSAndHdlZXRfZGV0YWlsJztcbiAgICBsZXQgaXNNYW51YWwgPSBtYW51YWxPdmVycmlkZXMuZ2V0KHRpZCkgfHwgZmFsc2U7XG4gICAgbGV0IGxhc3RGaWxsZWQgPSBsYXN0RmlsbGVkSWRzLmdldCh0aWQpIHx8ICcnO1xuICAgIGxldCBzZWxlY3RlZFJlcGx5SWQgPSBzZWxlY3RlZFJlcGx5SWRzLmdldCh0aWQpIHx8IG51bGw7XG4gICAgLy8gQXV0by1maWxsIHRyaWdnZXI6IHN3aXRjaGVkIHRvIGEgZGlmZmVyZW50IHR3ZWV0IGRldGFpbFxuICAgIGlmIChpc1R3ZWV0RGV0YWlsICYmIGN1ckVudGl0eUlkICYmIGN1ckVudGl0eUlkICE9PSBsYXN0RmlsbGVkKSB7XG4gICAgICAgIGlzTWFudWFsID0gZmFsc2U7XG4gICAgICAgIGxhc3RGaWxsZWQgPSBjdXJFbnRpdHlJZDtcbiAgICAgICAgc2VsZWN0ZWRSZXBseUlkID0gbnVsbDsgLy8gQ2xlYXIgcmVwbHkgc2VsZWN0aW9uIHdoZW4gc3dpdGNoaW5nIG1haW4gdHdlZXRcbiAgICAgICAgbWFudWFsT3ZlcnJpZGVzLnNldCh0aWQsIGZhbHNlKTtcbiAgICAgICAgbGFzdEZpbGxlZElkcy5zZXQodGlkLCBjdXJFbnRpdHlJZCk7XG4gICAgICAgIHNlbGVjdGVkUmVwbHlJZHMuc2V0KHRpZCwgbnVsbCk7XG4gICAgfVxuICAgIC8vIEF1dG8tY2xlYXIgdHJpZ2dlcjogbGVhdmluZyB0d2VldF9kZXRhaWwgd2hlbiBpdCB3YXMgcHJldmlvdXNseSBhdXRvLWZpbGxlZFxuICAgIGlmICghaXNUd2VldERldGFpbCAmJiAhaXNNYW51YWwgJiYgbGFzdEZpbGxlZCAhPT0gJycpIHtcbiAgICAgICAgbGFzdEZpbGxlZCA9ICcnO1xuICAgICAgICBsYXN0RmlsbGVkSWRzLnNldCh0aWQsICcnKTtcbiAgICAgICAgc2VsZWN0ZWRSZXBseUlkcy5zZXQodGlkLCBudWxsKTtcbiAgICB9XG4gICAgLy8gU2VsZWN0aW9uIG9mIFByb2ZpbGUgVHdlZXQgY2xlYXJpbmdcbiAgICBpZiAocGFnZUNvbnRleHQuc2NlbmUgIT09ICdwcm9maWxlJyAmJiBzZWxlY3RlZFByb2ZpbGVUd2VldElkcy5nZXQodGlkKSkge1xuICAgICAgICBzZWxlY3RlZFByb2ZpbGVUd2VldElkcy5zZXQodGlkLCBudWxsKTtcbiAgICB9XG4gICAgLy8gRGV0ZXJtaW5lIHZhbHVlIHRvIHNob3cgaW4gaW5wdXRcbiAgICBjb25zdCBleGlzdGluZ0lucHV0ID0gZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoJ21hbnVhbC10YXJnZXQtaWQnKTtcbiAgICBsZXQgZGlzcGxheVRhcmdldElkID0gJyc7XG4gICAgbGV0IHNvdXJjZUxhYmVsSHRtbCA9ICcnO1xuICAgIGlmIChpc01hbnVhbCkge1xuICAgICAgICBkaXNwbGF5VGFyZ2V0SWQgPSBleGlzdGluZ0lucHV0ID8gZXhpc3RpbmdJbnB1dC52YWx1ZSA6ICcnO1xuICAgICAgICBzb3VyY2VMYWJlbEh0bWwgPSBgPHNwYW4gY2xhc3M9XCJiYWRnZSBiZy13YXJuaW5nLXN1YnRsZSB0ZXh0LXdhcm5pbmcgYm9yZGVyIGJvcmRlci13YXJuaW5nIG1zLTJcIiBzdHlsZT1cImZvbnQtc2l6ZTo5cHg7IGZvbnQtd2VpZ2h0Om5vcm1hbFwiPk1BTlVBTCBPVkVSUklERTwvc3Bhbj5gO1xuICAgIH1cbiAgICBlbHNlIGlmIChpc1R3ZWV0RGV0YWlsICYmIHNlbGVjdGVkUmVwbHlJZCkge1xuICAgICAgICBkaXNwbGF5VGFyZ2V0SWQgPSBzZWxlY3RlZFJlcGx5SWQ7XG4gICAgICAgIHNvdXJjZUxhYmVsSHRtbCA9IGA8c3BhbiBjbGFzcz1cImJhZGdlIGJnLXByaW1hcnkgdGV4dC13aGl0ZSBib3JkZXIgYm9yZGVyLXByaW1hcnkgbXMtMlwiIHN0eWxlPVwiZm9udC1zaXplOjlweDsgZm9udC13ZWlnaHQ6bm9ybWFsXCI+QVVUTzogU0VMRUNURUQgUkVQTFk8L3NwYW4+YDtcbiAgICB9XG4gICAgZWxzZSBpZiAoaXNUd2VldERldGFpbCAmJiBsYXN0RmlsbGVkKSB7XG4gICAgICAgIGRpc3BsYXlUYXJnZXRJZCA9IGxhc3RGaWxsZWQ7XG4gICAgICAgIHNvdXJjZUxhYmVsSHRtbCA9IGA8c3BhbiBjbGFzcz1cImJhZGdlIGJnLXN1Y2Nlc3Mtc3VidGxlIHRleHQtc3VjY2VzcyBib3JkZXIgYm9yZGVyLXN1Y2Nlc3MgbXMtMlwiIHN0eWxlPVwiZm9udC1zaXplOjlweDsgZm9udC13ZWlnaHQ6bm9ybWFsXCI+QVVUTzogQ1VSUkVOVCBFTlRJVFk8L3NwYW4+YDtcbiAgICB9XG4gICAgY29udGFpbmVyLmlubmVySFRNTCA9IGBcbjwhLS0g4pWQ4pWQ4pWQIFJPVyAwOiBTY2VuZSAmIEVudGl0eSBDYXJkIChORVcpIOKVkOKVkOKVkCAtLT5cbjxkaXYgY2xhc3M9XCJyb3cgbWItMVwiPlxuICAgIDxkaXYgY2xhc3M9XCJjb2wtMTJcIj5cbiAgICAgICAgJHtyZW5kZXJTY2VuZUNhcmQocGFnZUNvbnRleHQpfVxuICAgICAgICAke3JlbmRlck1pc21hdGNoV2FybmluZyh0aWQsIHBhZ2VDb250ZXh0KX1cbiAgICAgICAgJHtyZW5kZXJFbnRpdHlDYXJkKHBhZ2VDb250ZXh0LmN1cnJlbnRFbnRpdHksIHBhZ2VDb250ZXh0LnNjZW5lKX1cbiAgICAgICAgJHtyZW5kZXJQcm9maWxlVHdlZXRzU25hcHNob3QocGFnZUNvbnRleHQucHJvZmlsZVR3ZWV0c1NuYXBzaG90IHx8IFtdLCBwYWdlQ29udGV4dC5zY2VuZSwgc2VsZWN0ZWRQcm9maWxlVHdlZXRJZHMuZ2V0KHRpZCkgfHwgbnVsbCl9XG4gICAgICAgICR7cmVuZGVyU2VsZWN0ZWRQcm9maWxlVHdlZXRDYXJkKHBhZ2VDb250ZXh0LnByb2ZpbGVUd2VldHNTbmFwc2hvdCB8fCBbXSwgcGFnZUNvbnRleHQuc2NlbmUpfVxuICAgICAgICAke3JlbmRlclByb2ZpbGVUd2VldENhbmRpZGF0ZUludGVudENhcmQocGFnZUNvbnRleHQucHJvZmlsZVR3ZWV0c1NuYXBzaG90IHx8IFtdLCBwYWdlQ29udGV4dC5zY2VuZSl9XG4gICAgICAgICR7cmVuZGVyUmVwbGllc1NuYXBzaG90KHBhZ2VDb250ZXh0LnJlcGxpZXNTbmFwc2hvdCB8fCBbXSwgcGFnZUNvbnRleHQuc2NlbmUpfVxuICAgICAgICAke3JlbmRlclNlbGVjdGVkUmVwbHlDYXJkKHBhZ2VDb250ZXh0LnJlcGxpZXNTbmFwc2hvdCB8fCBbXSwgcGFnZUNvbnRleHQuc2NlbmUpfVxuICAgIDwvZGl2PlxuPC9kaXY+XG5cbjwhLS0g4pWQ4pWQ4pWQIFJPVyAxOiBUYWIgSW5mbyDCtyBIb29rIFN0YXR1cyDilZDilZDilZAgLS0+XG5cbjwhLS0g4pWQ4pWQ4pWQIFJPVyAxOiBUYWIgSW5mbyDCtyBIb29rIFN0YXR1cyDilZDilZDilZAgLS0+XG48ZGl2IGNsYXNzPVwicm93IG1iLTNcIj5cbiAgICA8ZGl2IGNsYXNzPVwiY29sLTZcIj5cbiAgICAgICAgPGRpdiBjbGFzcz1cImNhcmQgaC0xMDBcIj5cbiAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJjYXJkLWhlYWRlciB0ZXh0LWluZm9cIj5BIMK3IEN1cnJlbnQgVGFiPC9kaXY+XG4gICAgICAgICAgICA8ZGl2IGNsYXNzPVwiY2FyZC1ib2R5IHB5LTJcIj5cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzPVwic3lzLXN0YXRcIj48c3BhbiBjbGFzcz1cInRleHQtbXV0ZWRcIj5UYWIgSUQ8L3NwYW4+PHNwYW4gY2xhc3M9XCJ2YWxcIj4ke2RhdGEuaWQgPz8gJ+KAlCd9PC9zcGFuPjwvZGl2PlxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJzeXMtc3RhdFwiPjxzcGFuIGNsYXNzPVwidGV4dC1tdXRlZFwiPkFjdGl2ZTwvc3Bhbj4ke2JhZGdlKCEhdGFiTWV0YS5hY3RpdmUsICdZRVMnLCAnTk8nKX08L2Rpdj5cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzPVwic3lzLXN0YXRcIj48c3BhbiBjbGFzcz1cInRleHQtbXV0ZWRcIj5YIC8gVHdpdHRlcjwvc3Bhbj4ke2JhZGdlKGlzWFBhZ2UsICdZRVMnLCAnTk8nKX08L2Rpdj5cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzPVwic3lzLXN0YXRcIj48c3BhbiBjbGFzcz1cInRleHQtbXV0ZWRcIj5MYXN0IE9wPC9zcGFuPjxzcGFuIGNsYXNzPVwidmFsIHRleHQtd2FybmluZ1wiIHN0eWxlPVwiZm9udC1zaXplOjExcHhcIj4ke2RhdGEubGFzdE9wIHx8ICfigJQnfTwvc3Bhbj48L2Rpdj5cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzPVwibXQtMlwiIHN0eWxlPVwiZm9udC1zaXplOjEwcHg7Y29sb3I6I2NiZDVlMFwiPlVSTDwvZGl2PlxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJ0ZXh0LWxpZ2h0IHRleHQtdHJ1bmNhdGVcIiBzdHlsZT1cImZvbnQtc2l6ZToxMHB4XCI+JHt0YWJNZXRhLnVybCB8fCBkYXRhLnVybCB8fCAn4oCUJ308L2Rpdj5cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzPVwibXQtMlwiIHN0eWxlPVwiZm9udC1zaXplOjEwcHg7Y29sb3I6I2NiZDVlMFwiPk5BVklHQVRFIFRBQjwvZGl2PlxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJkLWZsZXggZ2FwLTEgbXQtMVwiPlxuICAgICAgICAgICAgICAgICAgICA8aW5wdXQgdHlwZT1cInRleHRcIiBpZD1cIm5hdi11cmwtaW5wdXRcIiBjbGFzcz1cImZvcm0tY29udHJvbCBmb3JtLWNvbnRyb2wtc20gYmctZGFyayB0ZXh0LWxpZ2h0IGJvcmRlci1zZWNvbmRhcnlcIiBwbGFjZWhvbGRlcj1cImh0dHBzOi8veC5jb20vLi4uXCIgc3R5bGU9XCJmb250LXNpemU6MTBweDtcIiB2YWx1ZT1cIiR7bmF2VXJsRHJhZnRzLmdldCh0aWQpIHx8IHRhYk1ldGEudXJsIHx8IGRhdGEudXJsIHx8ICcnfVwiPlxuICAgICAgICAgICAgICAgICAgICA8YnV0dG9uIGNsYXNzPVwiYnRuIGJ0bi1vdXRsaW5lLWluZm8gYnRuLXhzIGJ0bi10YWItbmF2aWdhdGVcIiBkYXRhLWlkPVwiJHtkYXRhLmlkfVwiIHN0eWxlPVwiZm9udC1zaXplOjEwcHg7IHBhZGRpbmc6IDJweCA4cHg7XCI+R088L2J1dHRvbj5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzPVwibXQtMlwiIHN0eWxlPVwiZm9udC1zaXplOjEwcHg7Y29sb3I6I2NiZDVlMFwiPk9QRU4gVFdFRVQgKFNlbWFudGljKTwvZGl2PlxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJkLWZsZXggZ2FwLTEgbXQtMVwiPlxuICAgICAgICAgICAgICAgICAgICA8aW5wdXQgdHlwZT1cInRleHRcIiBpZD1cIm9wZW4tdHdlZXQtc2NyZWVuLW5hbWVcIiBjbGFzcz1cImZvcm0tY29udHJvbCBmb3JtLWNvbnRyb2wtc20gYmctZGFyayB0ZXh0LWxpZ2h0IGJvcmRlci1zZWNvbmRhcnlcIiBwbGFjZWhvbGRlcj1cInNjcmVlbk5hbWVcIiBzdHlsZT1cImZvbnQtc2l6ZToxMHB4OyBmbGV4OiAxO1wiIHZhbHVlPVwiJHtvcGVuVHdlZXRTY3JlZW5OYW1lRHJhZnRzLmdldCh0aWQpIHx8ICcnfVwiPlxuICAgICAgICAgICAgICAgICAgICA8aW5wdXQgdHlwZT1cInRleHRcIiBpZD1cIm9wZW4tdHdlZXQtaWRcIiBjbGFzcz1cImZvcm0tY29udHJvbCBmb3JtLWNvbnRyb2wtc20gYmctZGFyayB0ZXh0LWxpZ2h0IGJvcmRlci1zZWNvbmRhcnlcIiBwbGFjZWhvbGRlcj1cInR3ZWV0SWRcIiBzdHlsZT1cImZvbnQtc2l6ZToxMHB4OyBmbGV4OiAyO1wiIHZhbHVlPVwiJHtvcGVuVHdlZXRJZERyYWZ0cy5nZXQodGlkKSB8fCAnJ31cIj5cbiAgICAgICAgICAgICAgICAgICAgPGJ1dHRvbiBjbGFzcz1cImJ0biBidG4tb3V0bGluZS1pbmZvIGJ0bi14cyBidG4tdGFiLW9wZW4tdHdlZXRcIiBkYXRhLWlkPVwiJHtkYXRhLmlkfVwiIHN0eWxlPVwiZm9udC1zaXplOjEwcHg7IHBhZGRpbmc6IDJweCA4cHg7XCI+T1BFTjwvYnV0dG9uPlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgIDwvZGl2PlxuICAgIDwvZGl2PlxuICAgIDxkaXYgY2xhc3M9XCJjb2wtNlwiPlxuICAgICAgICA8ZGl2IGNsYXNzPVwiY2FyZCBoLTEwMFwiPlxuICAgICAgICAgICAgPGRpdiBjbGFzcz1cImNhcmQtaGVhZGVyIHRleHQtd2FybmluZ1wiPkIgwrcgSW5qZWN0ICZhbXA7IEhvb2sgU3RhdHVzPC9kaXY+XG4gICAgICAgICAgICA8ZGl2IGNsYXNzPVwiY2FyZC1ib2R5IHB5LTJcIj5cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzPVwic3lzLXN0YXRcIj48c3BhbiBjbGFzcz1cInRleHQtbXV0ZWRcIj5JbmplY3QgQWN0aXZlPC9zcGFuPiR7YmFkZ2UoaG9va1N0LmZldGNoIHx8IGhvb2tTdC54aHIsICdZRVMnLCAnVU5LTk9XTicpfTwvZGl2PlxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJzeXMtc3RhdFwiPjxzcGFuIGNsYXNzPVwidGV4dC1tdXRlZFwiPkZldGNoIEhvb2s8L3NwYW4+JHtiYWRnZShob29rU3QuZmV0Y2gpfTwvZGl2PlxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJzeXMtc3RhdFwiPjxzcGFuIGNsYXNzPVwidGV4dC1tdXRlZFwiPlhIUiBIb29rPC9zcGFuPiR7YmFkZ2UoaG9va1N0Lnhocil9PC9kaXY+XG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzcz1cInN5cy1zdGF0XCI+PHNwYW4gY2xhc3M9XCJ0ZXh0LW11dGVkXCI+TGFzdCBBUEkgSGl0PC9zcGFuPjxzcGFuIGNsYXNzPVwidmFsXCI+JHtmbXRUaW1lKGxhc3RIaXQpfTwvc3Bhbj48L2Rpdj5cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzPVwic3lzLXN0YXRcIj48c3BhbiBjbGFzcz1cInRleHQtbXV0ZWRcIj5MYXN0IEJHIFN5bmM8L3NwYW4+PHNwYW4gY2xhc3M9XCJ2YWxcIj4ke2ZtdFRpbWUoZGF0YS5sYXN0QmdTeW5jKX08L3NwYW4+PC9kaXY+XG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzcz1cInN5cy1zdGF0XCI+PHNwYW4gY2xhc3M9XCJ0ZXh0LW11dGVkXCI+QW5vbWFseTwvc3Bhbj48c3BhbiBjbGFzcz1cInZhbCB0ZXh0LXN1Y2Nlc3NcIj5Ob25lPC9zcGFuPjwvZGl2PlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgIDwvZGl2PlxuICAgIDwvZGl2PlxuPC9kaXY+XG5cbjwhLS0g4pWQ4pWQ4pWQIFJPVyAyOiBJZGVudGl0eSDCtyBXcml0ZSBFbnYg4pWQ4pWQ4pWQIC0tPlxuPGRpdiBjbGFzcz1cInJvdyBtYi0zXCI+XG4gICAgPGRpdiBjbGFzcz1cImNvbC02XCI+XG4gICAgICAgIDxkaXYgY2xhc3M9XCJjYXJkIGgtMTAwXCI+XG4gICAgICAgICAgICA8ZGl2IGNsYXNzPVwiY2FyZC1oZWFkZXIgdGV4dC1zdWNjZXNzXCI+RSDCtyBTZXNzaW9uIC8gSWRlbnRpdHk8L2Rpdj5cbiAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJjYXJkLWJvZHkgcHktMlwiPlxuICAgICAgICAgICAgICAgICR7cmVuZGVySWRlbnRpdHlQYW5lbChhY2NvdW50LCBtYWluVHdlZXQsIGRhdGEuaWQsIHBhZ2VDb250ZXh0Py5zY2VuZSl9XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgPC9kaXY+XG4gICAgPC9kaXY+XG4gICAgPGRpdiBjbGFzcz1cImNvbC02XCI+XG4gICAgICAgIDxkaXYgY2xhc3M9XCJjYXJkIGgtMTAwICR7aXNMb2dnZWRPdXQgPyAnYm9yZGVyLWRhbmdlciBvcGFjaXR5LTc1JyA6ICcnfVwiPlxuICAgICAgICAgICAgPGRpdiBjbGFzcz1cImNhcmQtaGVhZGVyIHRleHQtZGFuZ2VyIGQtZmxleCBqdXN0aWZ5LWNvbnRlbnQtYmV0d2VlblwiPlxuICAgICAgICAgICAgICAgIDxzcGFuPkYgwrcgV3JpdGUgRXhlY3V0aW9uIEVudjwvc3Bhbj5cbiAgICAgICAgICAgICAgICAke2lzTG9nZ2VkT3V0ID8gJzxzcGFuIGNsYXNzPVwiYmFkZ2UgYmctZGFuZ2VyXCI+TE9HR0VEIE9VVDwvc3Bhbj4nIDogJyd9XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJjYXJkLWJvZHkgcHktMlwiPlxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJzeXMtc3RhdFwiPjxzcGFuIGNsYXNzPVwidGV4dC1tdXRlZFwiPldyaXRlIEVudjwvc3Bhbj48c3BhbiBjbGFzcz1cInZhbCAke2lzTG9nZ2VkT3V0ID8gJ3RleHQtZGFuZ2VyJyA6ICd0ZXh0LXN1Y2Nlc3MnfVwiPiR7aXNMb2dnZWRPdXQgPyAnTE9DS0VEJyA6ICdDb250ZW50IFNjcmlwdCDinJMnfTwvc3Bhbj48L2Rpdj5cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzPVwic3lzLXN0YXRcIj48c3BhbiBjbGFzcz1cInRleHQtbXV0ZWRcIj5Db250ZW50IEJyaWRnZTwvc3Bhbj4ke2JhZGdlKCFpc0xvZ2dlZE91dCAmJiBicmlkZ2VPbmxpbmUsICdPTkxJTkUnLCAnT0ZGTElORScpfTwvZGl2PlxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJzeXMtc3RhdFwiPjxzcGFuIGNsYXNzPVwidGV4dC1tdXRlZFwiPkluamVjdCBXcml0ZXM8L3NwYW4+PHNwYW4gY2xhc3M9XCJ2YWwgJHtpc0xvZ2dlZE91dCA/ICd0ZXh0LW11dGVkJyA6ICd0ZXh0LXN1Y2Nlc3MnfVwiPiR7aXNMb2dnZWRPdXQgPyAnRGlzYWJsZWQnIDogJ05vbmUg4pyTJ308L3NwYW4+PC9kaXY+XG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzcz1cInN5cy1zdGF0XCI+PHNwYW4gY2xhc3M9XCJ0ZXh0LW11dGVkXCI+QW5vbWFseTwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3M9XCJ2YWwgJHtpc0xvZ2dlZE91dCA/ICd0ZXh0LXdhcm5pbmcnIDogKGJyaWRnZU9ubGluZSA/ICd0ZXh0LXN1Y2Nlc3MnIDogJ3RleHQtZGFuZ2VyJyl9XCI+JHtpc0xvZ2dlZE91dCA/ICdTZXNzaW9uIEludmFsaWQnIDogKGJyaWRnZU9ubGluZSA/ICdOb25lJyA6ICfimqAgQnJpZGdlIG9mZmxpbmUnKX08L3NwYW4+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgJHshaXNMb2dnZWRPdXQgJiYgbWFpblR3ZWV0ID8gYFxuICAgICAgICAgICAgICAgIDxociBjbGFzcz1cIm15LTIgYm9yZGVyLXNlY29uZGFyeVwiPlxuICAgICAgICAgICAgICAgIDxkaXYgc3R5bGU9XCJjb2xvcjojODg5OUE2O2ZvbnQtc2l6ZToxMHB4O21hcmdpbi1ib3R0b206NnB4XCI+TEFTVCBDQVBUVVJFRCBDT05URU5UPC9kaXY+XG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzcz1cInRleHQtbXV0ZWQgbWItMVwiIHN0eWxlPVwiZm9udC1zaXplOjEwcHhcIj5cbiAgICAgICAgICAgICAgICAgICAgPHN0cm9uZyBjbGFzcz1cInRleHQtbGlnaHRcIj4ke21haW5Ud2VldC5hdXRob3JOYW1lIHx8ICcnfTwvc3Ryb25nPlxuICAgICAgICAgICAgICAgICAgICA8c3Bhbj4gQCR7bWFpblR3ZWV0LmF1dGhvckhhbmRsZT8ucmVwbGFjZSgnQCcsICcnKSB8fCAnJ308L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgIDxicj48c3BhbiBzdHlsZT1cIm9wYWNpdHk6LjZcIj5Ud2VldCBJRDogJHttYWluVHdlZXQuaWR9ICB8ICBVc2VyIElEOiAke21haW5Ud2VldC5hdXRob3JJZCB8fCAnJ308L3NwYW4+XG4gICAgICAgICAgICAgICAgPC9kaXY+YCA6IChpc0xvZ2dlZE91dCA/ICcnIDogKHBhZ2VDb250ZXh0Py5zY2VuZSA9PT0gJ2lkZW50aXR5X3Jlc29sdmluZycgPyAnPGRpdiBjbGFzcz1cInRleHQtaW5mbyBzbWFsbCBtdC0yXCI+V2FpdGluZyBmb3IgaWRlbnRpdHkuLi48L2Rpdj4nIDogJzxkaXYgY2xhc3M9XCJ0ZXh0LW11dGVkIHNtYWxsIG10LTJcIj5ObyB0d2VldCBjYXB0dXJlZCB5ZXQuPC9kaXY+JykpfVxuICAgICAgICAgICAgICAgIFxuICAgICAgICAgICAgICAgIDxociBjbGFzcz1cIm15LTMgYm9yZGVyLXNlY29uZGFyeVwiPlxuICAgICAgICAgICAgICAgICR7cmVuZGVyRXhlY3V0aW9uSW50ZW50KGRhdGEuaWQsIHBhZ2VDb250ZXh0LCBkaXNwbGF5VGFyZ2V0SWQpfVxuICAgICAgICAgICAgICAgIDxkaXYgc3R5bGU9XCJjb2xvcjojY2JkNWUwO2ZvbnQtc2l6ZToxMHB4O21hcmdpbi1ib3R0b206NnB4XCI+XG4gICAgICAgICAgICAgICAgICAgIEVYRUNVVEUgQUNUSU9OIChUYXJnZXQgSUQpXG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzcz1cImQtZmxleCBnYXAtMiBhbGlnbi1pdGVtcy1jZW50ZXIgbWItMlwiPlxuICAgICAgICAgICAgICAgICAgICA8aW5wdXQgdHlwZT1cInRleHRcIiBpZD1cIm1hbnVhbC10YXJnZXQtaWRcIiBjbGFzcz1cImZvcm0tY29udHJvbCBmb3JtLWNvbnRyb2wtc20gYmctZGFyayB0ZXh0LWxpZ2h0IGJvcmRlci1zZWNvbmRhcnlcIiBwbGFjZWhvbGRlcj1cIkVudGVyIHRhcmdldCBUd2VldCBJRCBvciBVc2VyIElELi4uXCIgc3R5bGU9XCJmb250LXNpemU6MTFweDtcIiB2YWx1ZT1cIiR7ZGlzcGxheVRhcmdldElkfVwiICR7IWNhbldyaXRlID8gJ2Rpc2FibGVkJyA6ICcnfT5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzPVwiZC1mbGV4IGdhcC0xIGZsZXgtd3JhcFwiPlxuICAgICAgICAgICAgICAgICAgICA8YnV0dG9uIGNsYXNzPVwiYnRuIGJ0bi1vdXRsaW5lLXByaW1hcnkgYnRuLW1hbnVhbC1hY3Rpb24gYnRuLXNtXCIgZGF0YS10YWJpZD1cIiR7ZGF0YS5pZH1cIiBkYXRhLWFjdGlvbj1cImxpa2VcIiAkeyFjYW5Xcml0ZSA/ICdkaXNhYmxlZCcgOiAnJ30+TElLRTwvYnV0dG9uPlxuICAgICAgICAgICAgICAgICAgICA8YnV0dG9uIGNsYXNzPVwiYnRuIGJ0bi1vdXRsaW5lLXN1Y2Nlc3MgYnRuLW1hbnVhbC1hY3Rpb24gYnRuLXNtXCIgZGF0YS10YWJpZD1cIiR7ZGF0YS5pZH1cIiBkYXRhLWFjdGlvbj1cInJldHdlZXRcIiAkeyFjYW5Xcml0ZSA/ICdkaXNhYmxlZCcgOiAnJ30+UlQ8L2J1dHRvbj5cbiAgICAgICAgICAgICAgICAgICAgPGJ1dHRvbiBjbGFzcz1cImJ0biBidG4tb3V0bGluZS13YXJuaW5nIGJ0bi1tYW51YWwtYWN0aW9uIGJ0bi1zbVwiIGRhdGEtdGFiaWQ9XCIke2RhdGEuaWR9XCIgZGF0YS1hY3Rpb249XCJib29rbWFya1wiICR7IWNhbldyaXRlID8gJ2Rpc2FibGVkJyA6ICcnfT5TQVZFPC9idXR0b24+XG4gICAgICAgICAgICAgICAgICAgIDxidXR0b24gY2xhc3M9XCJidG4gYnRuLW91dGxpbmUtaW5mbyBidG4tbWFudWFsLWFjdGlvbiBidG4tc21cIiBkYXRhLXRhYmlkPVwiJHtkYXRhLmlkfVwiIGRhdGEtYWN0aW9uPVwiZm9sbG93XCIgJHshY2FuV3JpdGUgPyAnZGlzYWJsZWQnIDogJyd9PkZPTExPVzwvYnV0dG9uPlxuICAgICAgICAgICAgICAgICAgICA8YnV0dG9uIGNsYXNzPVwiYnRuIGJ0bi1vdXRsaW5lLXNlY29uZGFyeSBidG4tbWFudWFsLWFjdGlvbiBidG4tc21cIiBkYXRhLXRhYmlkPVwiJHtkYXRhLmlkfVwiIGRhdGEtYWN0aW9uPVwidW5mb2xsb3dcIiAkeyFjYW5Xcml0ZSA/ICdkaXNhYmxlZCcgOiAnJ30+VU5GT0xMT1c8L2J1dHRvbj5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAke3JlbmRlclJlcGx5RHJhZnRVSShkYXRhLmlkLCBwYWdlQ29udGV4dCwgZGlzcGxheVRhcmdldElkLCBpc0xvZ2dlZE91dCl9XG4gICAgICAgICAgICAgICAgJHtpc0xvZ2dlZE91dCA/ICc8ZGl2IGNsYXNzPVwibXQtMiB0ZXh0LWRhbmdlclwiIHN0eWxlPVwiZm9udC1zaXplOjEwcHhcIj7imqAgQWN0aW9ucyBsb2NrZWQgdW50aWwgWCBzZXNzaW9uIGlzIHJlc3RvcmVkLjwvZGl2PicgOiAoIWhhc1RhcmdldCAmJiAhaXNMb2dnZWRPdXQgPyAnPGRpdiBjbGFzcz1cIm10LTEgdGV4dC1tdXRlZFwiIHN0eWxlPVwiZm9udC1zaXplOjlweFwiPlBpY2sgYSB0d2VldCBvbiBYIHRvIGVuYWJsZSBhY3Rpb25zLjwvZGl2PicgOiAnJyl9XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgPC9kaXY+XG4gICAgPC9kaXY+XG48L2Rpdj5cblxuPCEtLSDilZDilZDilZAgUk9XIDM6IEFQSSBIaXQgTWF0cml4IOKVkOKVkOKVkCAtLT5cbjxkaXYgY2xhc3M9XCJyb3cgbWItM1wiPlxuICAgIDxkaXYgY2xhc3M9XCJjb2wtMTJcIj5cbiAgICAgICAgPGRpdiBjbGFzcz1cImNhcmRcIj5cbiAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJjYXJkLWhlYWRlciB0ZXh0LXByaW1hcnlcIj5DIMK3IFdhdGNoZWQgQVBJIEhpdCBNYXRyaXggKCR7YWxsT3BzLmxlbmd0aH0gb3BzKTwvZGl2PlxuICAgICAgICAgICAgPGRpdiBzdHlsZT1cIm92ZXJmbG93OmF1dG9cIj5cbiAgICAgICAgICAgICAgICA8dGFibGUgY2xhc3M9XCJ0YWJsZSB0YWJsZS1kYXJrIHRhYmxlLWhvdmVyIG1iLTBcIiBzdHlsZT1cImZvbnQtc2l6ZToxMXB4XCI+XG4gICAgICAgICAgICAgICAgICAgIDx0aGVhZD48dHI+XG4gICAgICAgICAgICAgICAgICAgICAgICA8dGggY2xhc3M9XCJwcy0zXCI+T3BlcmF0aW9uPC90aD5cbiAgICAgICAgICAgICAgICAgICAgICAgIDx0aD5TdGF0dXM8L3RoPlxuICAgICAgICAgICAgICAgICAgICAgICAgPHRoPkhpdHM8L3RoPlxuICAgICAgICAgICAgICAgICAgICAgICAgPHRoPkxhc3QgSGl0PC90aD5cbiAgICAgICAgICAgICAgICAgICAgICAgIDx0aD5DYWNoZTwvdGg+XG4gICAgICAgICAgICAgICAgICAgICAgICA8dGggY2xhc3M9XCJwZS0zXCI+UmVxdWVzdCBTdW1tYXJ5PC90aD5cbiAgICAgICAgICAgICAgICAgICAgPC90cj48L3RoZWFkPlxuICAgICAgICAgICAgICAgICAgICA8dGJvZHk+XG4gICAgICAgICAgICAgICAgICAgICR7YWxsT3BzLm1hcChvcCA9PiB7XG4gICAgICAgIGNvbnN0IHMgPSBzdGF0c1tvcF07XG4gICAgICAgIGNvbnN0IGNhY2hlZCA9ICEhZGF0YS5kYXRhPy5bb3BdO1xuICAgICAgICBjb25zdCBsYXN0SGl0Um93ID0gaGl0cy5maW5kKChoKSA9PiBoLm9wID09PSBvcCk7XG4gICAgICAgIHJldHVybiBgPHRyPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0ZCBjbGFzcz1cInBzLTMgZnctYm9sZFwiPiR7b3B9PC90ZD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGQ+JHtzID8gJzxzcGFuIGNsYXNzPVwidGV4dC1zdWNjZXNzXCI+4pePIEhJVDwvc3Bhbj4nIDogJzxzcGFuIGNsYXNzPVwidGV4dC1tdXRlZFwiPuKXiyDigJQ8L3NwYW4+J308L3RkPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0ZD4ke3M/LmNvdW50IHx8IDB9PC90ZD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGQ+JHtzID8gZm10VGltZShzLmxhc3RIaXQpIDogJ+KAlCd9PC90ZD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGQ+JHtjYWNoZWQgPyAnPHNwYW4gY2xhc3M9XCJ0ZXh0LWluZm9cIj7inJM8L3NwYW4+JyA6ICc8c3BhbiBjbGFzcz1cInRleHQtbXV0ZWRcIj7igJQ8L3NwYW4+J308L3RkPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0ZCBjbGFzcz1cInBlLTMgdGV4dC1tdXRlZFwiIHN0eWxlPVwiZm9udC1zaXplOjEwcHg7bWF4LXdpZHRoOjIyMHB4O292ZXJmbG93OmhpZGRlbjt0ZXh0LW92ZXJmbG93OmVsbGlwc2lzO3doaXRlLXNwYWNlOm5vd3JhcFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAke2xhc3RIaXRSb3cgPyByZXFTdW1tYXJ5KGxhc3RIaXRSb3cucmVxdWVzdEJvZHkpIDogJ+KAlCd9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC90ZD5cbiAgICAgICAgICAgICAgICAgICAgICAgIDwvdHI+YDtcbiAgICB9KS5qb2luKCcnKX1cbiAgICAgICAgICAgICAgICAgICAgPC90Ym9keT5cbiAgICAgICAgICAgICAgICA8L3RhYmxlPlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgIDwvZGl2PlxuICAgIDwvZGl2PlxuPC9kaXY+XG5cbjwhLS0g4pWQ4pWQ4pWQIFJPVyA0OiBSYXcgSW50ZXJjZXB0IEdyaWQg4pWQ4pWQ4pWQIC0tPlxuPGRpdiBjbGFzcz1cInJvd1wiPlxuICAgIDxkaXYgY2xhc3M9XCJjb2wtMTJcIj5cbiAgICAgICAgPGRpdiBjbGFzcz1cImNhcmRcIj5cbiAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJjYXJkLWhlYWRlciB0ZXh0LXNlY29uZGFyeSBkLWZsZXggYWxpZ24taXRlbXMtY2VudGVyXCI+XG4gICAgICAgICAgICAgICAgPHNwYW4+RCDCtyBSYXcgSW50ZXJjZXB0IFN0cmVhbTwvc3Bhbj5cbiAgICAgICAgICAgICAgICA8c3BhbiBjbGFzcz1cImJhZGdlIGJnLXNlY29uZGFyeSBtcy0yXCI+JHtoaXRzLmxlbmd0aH08L3NwYW4+XG4gICAgICAgICAgICAgICAgPHNwYW4gc3R5bGU9XCJmb250LXNpemU6MTBweDtjb2xvcjojY2JkNWUwO21hcmdpbi1sZWZ0OjhweFwiPkNsaWNrIERldGFpbHMgdG8gaW5zcGVjdDwvc3Bhbj5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgPGRpdiBjbGFzcz1cInAtM1wiPlxuICAgICAgICAgICAgICAgICR7aGl0cy5sZW5ndGggPT09IDBcbiAgICAgICAgPyBgPGRpdiBjbGFzcz1cInRleHQtbXV0ZWQgc21hbGxcIj5ObyBpbnRlcmNlcHRzIHlldCDigJQgb3BlbiBvciBzY3JvbGwgeC5jb20gdG8gdHJpZ2dlci48L2Rpdj5gXG4gICAgICAgIDogYDxkaXYgY2xhc3M9XCJoaXQtZ3JpZFwiPiR7aGl0cy5tYXAoKGgsIGkpID0+IHJlbmRlckhpdENhcmQoaCwgaSkpLmpvaW4oJycpfTwvZGl2PmB9XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgPC9kaXY+XG4gICAgPC9kaXY+XG48L2Rpdj5gO1xufVxuLy8g4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSAXG4vLyDlhpnmk43kvZzmiafooYzkuI4gVG9hc3Qg6YGu572pXG4vLyDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIBcbmZ1bmN0aW9uIHNob3dUb2FzdChtZXNzYWdlLCBpc0Vycm9yID0gZmFsc2UsIGF1dG9DbG9zZVRpbWUgPSAwKSB7XG4gICAgbGV0IHQgPSBkb2N1bWVudC5nZXRFbGVtZW50QnlJZCgndGMtdG9hc3QnKTtcbiAgICBpZiAoIXQpIHtcbiAgICAgICAgdCA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ2RpdicpO1xuICAgICAgICB0LmlkID0gJ3RjLXRvYXN0JztcbiAgICAgICAgZG9jdW1lbnQuYm9keS5hcHBlbmRDaGlsZCh0KTtcbiAgICB9XG4gICAgdC5pbm5lckhUTUwgPSBgXG4gICAgPGRpdiBzdHlsZT1cInBvc2l0aW9uOmZpeGVkO2luc2V0OjA7YmFja2dyb3VuZDpyZ2JhKDAsMCwwLC42KTt6LWluZGV4OjEwMDAwO2Rpc3BsYXk6ZmxleDthbGlnbi1pdGVtczpjZW50ZXI7anVzdGlmeS1jb250ZW50OmNlbnRlcjtiYWNrZHJvcC1maWx0ZXI6Ymx1cigycHgpXCI+XG4gICAgICAgIDxkaXYgc3R5bGU9XCJiYWNrZ3JvdW5kOiMxYTIwMmM7Ym9yZGVyOjJweCBzb2xpZCAke2lzRXJyb3IgPyAnI2Y1NjU2NScgOiAnIzRhZGU4MCd9O2JvcmRlci1yYWRpdXM6MTJweDtwYWRkaW5nOjI0cHggNDBweDt0ZXh0LWFsaWduOmNlbnRlcjtib3gtc2hhZG93OjAgMTBweCAzMHB4IHJnYmEoMCwwLDAsLjUpXCI+XG4gICAgICAgICAgICA8aDQgc3R5bGU9XCJjb2xvcjoke2lzRXJyb3IgPyAnI2Y1NjU2NScgOiAnIzRhZGU4MCd9O21hcmdpbjowO1wiPiR7bWVzc2FnZX08L2g0PlxuICAgICAgICA8L2Rpdj5cbiAgICA8L2Rpdj5gO1xuICAgIGlmIChhdXRvQ2xvc2VUaW1lID4gMCkge1xuICAgICAgICBzZXRUaW1lb3V0KCgpID0+IHsgaWYgKHQpXG4gICAgICAgICAgICB0LnJlbW92ZSgpOyB9LCBhdXRvQ2xvc2VUaW1lKTtcbiAgICB9XG59XG5hc3luYyBmdW5jdGlvbiBkb0FjdGlvbih0YWJJZCwgdGFyZ2V0SWQsIGFjdGlvbiwgYnRuKSB7XG4gICAgYnRuLmRpc2FibGVkID0gdHJ1ZTtcbiAgICBjb25zdCBvcmlnID0gYnRuLmlubmVyVGV4dDtcbiAgICBidG4uaW5uZXJUZXh0ID0gJ+KApic7XG4gICAgc2hvd1RvYXN0KGBFWEVDVVRJTkc6ICR7YWN0aW9uLnRvVXBwZXJDYXNlKCl9Li4uYCwgZmFsc2UpO1xuICAgIC8vIOWboOS4uiBGb2xsb3cg5b6A5b6A6ZyA6KaBIHVzZXJJZO+8jOWcqOatpOaIkeS7rOm7mOiupOS9v+eUqCB0YXJnZXRJZFxuICAgIC8vIOWmguaenOeUqOaIt+Whq+mUmeS6huexu+Wei+aIluiAhei+k+WFpeahhuS4uuepuu+8jOS8muWcqOW6leWxguaKm+WHuumUmeivr+OAglxuICAgIGNvbnN0IHJlc3AgPSBhd2FpdCBzZW5kTXNnKHsgdHlwZTogJ0VYRUNfUFJPWFlfQUNUSU9OJywgdGFiSWQsIHR3ZWV0SWQ6IHRhcmdldElkLCB1c2VySWQ6IHRhcmdldElkLCBhY3Rpb24gfSk7XG4gICAgYnRuLmRpc2FibGVkID0gZmFsc2U7XG4gICAgYnRuLmlubmVyVGV4dCA9IG9yaWc7XG4gICAgaWYgKHJlc3A/Lm9rKSB7XG4gICAgICAgIHNob3dUb2FzdChg4pyFICR7YWN0aW9uLnRvVXBwZXJDYXNlKCl9IFNVQ0NFU1MhYCwgZmFsc2UsIDIwMDApO1xuICAgIH1cbiAgICBlbHNlIHtcbiAgICAgICAgc2hvd1RvYXN0KGDinYwgJHthY3Rpb24udG9VcHBlckNhc2UoKX0gRkFJTEVEXFxuXFxuPHNwYW4gc3R5bGU9XCJmb250LXNpemU6MTJweDtjb2xvcjojY2JkNWUwO2Rpc3BsYXk6YmxvY2s7bWFyZ2luLXRvcDoxMHB4XCI+JHtyZXNwPy5lcnJvcj8ubWVzc2FnZSB8fCAnVW5rbm93biBlcnJvcid9PC9zcGFuPmAsIHRydWUsIDQwMDApO1xuICAgICAgICBjb25zb2xlLmVycm9yKCdbVHdlZXRDbGF3LURlYnVnXSBBY3Rpb24gZmFpbGVkOicsIHJlc3ApO1xuICAgIH1cbn1cbi8vIOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgFxuLy8g5Yid5aeL5YyWXG4vLyDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIBcbnNldHVwRGVsZWdhdGlvbigpO1xucmVmcmVzaERhdGEoKTtcbmNvbnNvbGUubG9nKCdbVHdlZXRDbGF3LURlYnVnXSB2NS40IGxvYWRlZC4nKTtcbiJdLCJuYW1lcyI6W10sInNvdXJjZVJvb3QiOiIifQ==