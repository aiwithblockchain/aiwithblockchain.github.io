/******/ (() => { // webpackBootstrap
/******/ 	"use strict";
/******/ 	var __webpack_modules__ = ({

/***/ "./src/capture/consts.ts"
/*!*******************************!*\
  !*** ./src/capture/consts.ts ***!
  \*******************************/
(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   MsgType: () => (/* binding */ MsgType),
/* harmony export */   __DBK_bearer_token: () => (/* binding */ __DBK_bearer_token),
/* harmony export */   __DBK_dynamic_features: () => (/* binding */ __DBK_dynamic_features),
/* harmony export */   __DBK_query_id_map: () => (/* binding */ __DBK_query_id_map),
/* harmony export */   defaultQueryKeyMap: () => (/* binding */ defaultQueryKeyMap),
/* harmony export */   isGuestHandle: () => (/* binding */ isGuestHandle),
/* harmony export */   watchedOps: () => (/* binding */ watchedOps)
/* harmony export */ });
const __DBK_query_id_map = 'tc_query_id_map';
const __DBK_bearer_token = 'tc_bearer_token';
const __DBK_dynamic_features = 'tc_dynamic_features';
var MsgType;
(function (MsgType) {
    MsgType["PING"] = "PING";
    MsgType["EXECUTE_ACTION"] = "EXECUTE_ACTION";
})(MsgType || (MsgType = {}));
const watchedOps = [
    'UserTweets',
    'HomeTimeline',
    'HomeLatestTimeline',
    'TweetDetail',
    'UserByScreenName',
    'ProfileSpotlightsQuery',
    'AccountSettings',
    'AuthenticatedUserQuery',
    'Viewer',
    'VerifyCredentials',
    'CreateFriendship',
    'DestroyFriendship',
    'CreateBookmark',
    'DeleteBookmark',
    'Followers',
    'Following',
    'SearchTimeline',
    'FavoriteTweet',
    'UnfavoriteTweet',
    'CreateRetweet',
    'DeleteRetweet',
    'ListLatestTweetsTimeline',
    'TimelineHome',
    'AccountUserQuery',
    'UserByRestId',
    'CreateTweet', // 新增：发推文（含回复）
    'DeleteTweet', // 新增：删除推文
    'DeleteRetweet' // 新增：取消转发
];
const defaultQueryKeyMap = {
    'UserByScreenName': 'ck5KkZ8t5cOmoLssopN99Q',
    'UserTweets': 'E8Wq-_jFSaU7hxVcuOPR9g',
    'HomeLatestTimeline': 'SFxmNKWfN9ySJcXG_tjX8g',
    'HomeTimeline': 'DXmgQYmIft1oLP6vMkJixw',
    'TweetDetail': 'iFEr5AcP121Og4wx9Yqo3w',
    'SearchTimeline': '4fpceYZ6-YQCx_JSl_Cn_A',
    'CreateBookmark': 'aoDbu3RHznuiSkQ9aNM67Q',
    'DeleteBookmark': 'Wlmlj2-xzyS1GN3a6cj-mQ',
    'Following': 'SaWqzw0TFAWMx1nXWjXoaQ',
    'Followers': 'i6PPdIMm1MO7CpAqjau7sw',
    'FavoriteTweet': 'lI07N6Otwv1PhnEgXILM7A',
    'UnfavoriteTweet': 'ZYKSe-w7KEslx3JhSIk5LA',
    'CreateRetweet': 'mbRO74GrOvSfRcJnlMapnQ',
    'CreateFriendship': '66v9_S_vThhArew_99v9_v9',
    'DestroyFriendship': 'Opv7_p8AunMhJvD8X8c9rw',
    'UserByRestId': 'LJYI_VvTFAZf7PAdT0eWmA',
    'CreateTweet': 'zkcFc6F-RKRgWN8HUkJfZg', // 新增：已确认（2025-05）
    'DeleteTweet': 'nxpZCY2K-I6QoFHAHeojFQ', // 新增：已确认（2025-05）
    'DeleteRetweet': 'ZyZigVsNiFO6v1dEks1eWg' // 新增：已确认（2025-05）
};
/**
 * 识别 X 游客账号（Guest Token）
 *
 * X 的 guest token handle 特征：
 *   - 恰好 15 个字符
 *   - 全部是小写字母 + 数字（无大写字母、无下划线）
 *   - 含有至少一个数字
 *
 * 真实用户 handle 可以包含大写字母或下划线，不会被误判。
 * 例如误判案例：1DU1Gf7oElR2h28 → 含大写 → 不是 guest ✓
 */
function isGuestHandle(h) {
    if (!h)
        return false;
    const clean = h.startsWith('@') ? h.substring(1) : h;
    // Guest handles are random 15-char strings (e.g., 'xyz1234abc5678z' or '123456789012345')
    // Real users like 'web3bridgeninja' (15 chars, lowercase, 1 digit) are common false positives.
    if (clean.length !== 15 || !/^[a-z0-9]+$/.test(clean))
        return false;
    const digits = (clean.match(/\d/g) || []).length;
    const hasVowels = /[aeiou]/.test(clean);
    // Heuristics:
    // 1. All numeric is definitely a guest token
    if (/^\d+$/.test(clean))
        return true;
    // 2. Alphanumeric with high digit count (>= 3) and no vowels is very likely a guest
    if (digits >= 2 && !hasVowels)
        return true;
    // 3. Very high digit count (>= 5) is also a red flag even with vowels
    if (digits >= 5)
        return true;
    return false;
}


/***/ }

/******/ 	});
/************************************************************************/
/******/ 	// The module cache
/******/ 	var __webpack_module_cache__ = {};
/******/ 	
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/ 		// Check if module is in cache
/******/ 		var cachedModule = __webpack_module_cache__[moduleId];
/******/ 		if (cachedModule !== undefined) {
/******/ 			return cachedModule.exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = __webpack_module_cache__[moduleId] = {
/******/ 			// no module.id needed
/******/ 			// no module.loaded needed
/******/ 			exports: {}
/******/ 		};
/******/ 	
/******/ 		// Execute the module function
/******/ 		if (!(moduleId in __webpack_modules__)) {
/******/ 			delete __webpack_module_cache__[moduleId];
/******/ 			var e = new Error("Cannot find module '" + moduleId + "'");
/******/ 			e.code = 'MODULE_NOT_FOUND';
/******/ 			throw e;
/******/ 		}
/******/ 		__webpack_modules__[moduleId](module, module.exports, __webpack_require__);
/******/ 	
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/ 	
/************************************************************************/
/******/ 	/* webpack/runtime/define property getters */
/******/ 	(() => {
/******/ 		// define getter functions for harmony exports
/******/ 		__webpack_require__.d = (exports, definition) => {
/******/ 			for(var key in definition) {
/******/ 				if(__webpack_require__.o(definition, key) && !__webpack_require__.o(exports, key)) {
/******/ 					Object.defineProperty(exports, key, { enumerable: true, get: definition[key] });
/******/ 				}
/******/ 			}
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/hasOwnProperty shorthand */
/******/ 	(() => {
/******/ 		__webpack_require__.o = (obj, prop) => (Object.prototype.hasOwnProperty.call(obj, prop))
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/make namespace object */
/******/ 	(() => {
/******/ 		// define __esModule on exports
/******/ 		__webpack_require__.r = (exports) => {
/******/ 			if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 				Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 			}
/******/ 			Object.defineProperty(exports, '__esModule', { value: true });
/******/ 		};
/******/ 	})();
/******/ 	
/************************************************************************/
var __webpack_exports__ = {};
// This entry needs to be wrapped in an IIFE because it needs to be isolated against other modules in the chunk.
(() => {
/*!**********************************!*\
  !*** ./src/capture/injection.ts ***!
  \**********************************/
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _consts__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./consts */ "./src/capture/consts.ts");

/**
 * TweetClaw Injected Sensor (v4.8 - URL + Bearer Fix)
 *
 * 关键修正：
 *  - postSignal 现在传 apiUrl（被拦截的真实 API 端点），不再传页面 URL
 *  - 从 fetch 请求头中提取 bearer token 一并发出，供 background 存储
 */
(function () {
    const TAG = '🛡️ [TweetClaw-Page]';
    let lastHitTime = 0;
    let lastSendTime = 0;
    let hookAnomalies = [];
    console.log(`${TAG} System initializing...`);
    function isIdentityOp(url) {
        const lowerUrl = url.toLowerCase();
        if (lowerUrl.includes('authenticateduserquery'))
            return 'AuthenticatedUserQuery';
        if (lowerUrl.includes('viewer'))
            return 'Viewer';
        if (lowerUrl.includes('accountuserquery'))
            return 'AccountUserQuery';
        if (lowerUrl.includes('accountsettings'))
            return 'AccountSettings';
        if (lowerUrl.includes('/account/settings.json'))
            return 'settings.json';
        if (lowerUrl.includes('/account/verify_credentials.json'))
            return 'VerifyCredentials';
        return null;
    }
    function isTargetUrl(url) {
        const idOp = isIdentityOp(url);
        if (idOp)
            return idOp;
        const lowerUrl = url.toLowerCase();
        for (const op of _consts__WEBPACK_IMPORTED_MODULE_0__.watchedOps) {
            const lowerOp = op.toLowerCase();
            // 匹配 /OpName 或 =OpName
            if (lowerUrl.includes(`/${lowerOp}`) || lowerUrl.includes(`=${lowerOp}`))
                return op;
        }
        return null;
    }
    /**
     * @param type   operationName (e.g. 'HomeTimeline')
     * @param apiUrl 被拦截的真实 API 端点（含 queryId 的 graphql URL 或 REST URL）
     * @param data   响应体 JSON
     */
    function postSignal(type, apiUrl, data, method = 'POST', requestBody, bearerToken) {
        lastHitTime = Date.now();
        try {
            const biteSize = new TextEncoder().encode(JSON.stringify(data)).length;
            console.log(`%c${TAG} 📡 Intercepted: %c${type}%c (${biteSize} bytes)`, 'color: #718096', 'color: #1DA1F2; font-weight: bold', 'color: #718096');
        }
        catch (e) { }
        const isId = ['AuthenticatedUserQuery', 'Viewer', 'AccountSettings', 'settings.json', 'VerifyCredentials'].includes(type);
        if (isId) {
            try {
                const screen_name = data.data?.viewer?.user_results?.result?.legacy?.screen_name ||
                    data.data?.authenticated_user_info?.screen_name ||
                    data.screen_name;
                if (screen_name) {
                    const guest = (0,_consts__WEBPACK_IMPORTED_MODULE_0__.isGuestHandle)(screen_name);
                    const color = guest ? '#FFAD1F' : '#1DA1F2';
                    const prefix = guest ? '⚠️ [Guest Detect]' : '✅ [Account Detect]';
                    console.log(`%c${TAG} ${prefix} @${screen_name} via ${type}`, `color: ${color}; font-weight: bold;`);
                }
            }
            catch (e) { }
        }
        // Extract features from request body for per-operation caching
        let features = null;
        try {
            if (requestBody && typeof requestBody === 'object' && requestBody.features) {
                features = requestBody.features;
            }
        }
        catch (e) { }
        lastSendTime = Date.now();
        window.postMessage({
            source: 'tweetclaw-injection',
            type: 'SIGNAL_CAPTURED',
            op: type,
            apiUrl, // ← 真实 API 端点 URL（含 queryId）
            pageUrl: window.location.href, // ← 当前页面 URL
            method,
            requestBody,
            bearerToken: bearerToken || null,
            features: features, // ← 提取的 features（如果有）
            data
        }, '*');
    }
    /** 从 fetch RequestInit headers 中提取 Authorization Bearer */
    function extractBearer(initArg) {
        try {
            const hdrs = initArg?.headers;
            if (!hdrs)
                return null;
            let auth = null;
            if (hdrs instanceof Headers) {
                auth = hdrs.get('authorization');
            }
            else if (typeof hdrs === 'object') {
                auth = hdrs['authorization'] || hdrs['Authorization'] || null;
            }
            return (auth && auth.startsWith('Bearer ')) ? auth : null;
        }
        catch {
            return null;
        }
    }
    function patchFetch() {
        if (window.__tc_fetch_patched)
            return;
        const orgFetch = window.fetch;
        if (!orgFetch) {
            hookAnomalies.push('Native fetch missing');
            return;
        }
        window.fetch = async function (...args) {
            const reqArg = args[0];
            const initArg = args[1];
            const url = typeof reqArg === 'string'
                ? reqArg
                : (reqArg instanceof Request ? reqArg.url : String(reqArg));
            const method = initArg?.method || 'GET';
            const body = initArg?.body;
            const targetOp = isTargetUrl(url);
            if (!targetOp) {
                // 如果是 graphql 且包含 operation，但没匹配上，打个日志参考
                if (url.includes('/graphql/')) {
                    console.debug(`${TAG} Ignored GQL: ${url}`);
                }
                return orgFetch.apply(this, args);
            }
            const bearer = extractBearer(initArg);
            try {
                const response = await orgFetch.apply(this, args);
                const clone = response.clone();
                clone.json().then(json => {
                    let parsedBody = body;
                    try {
                        if (typeof body === 'string')
                            parsedBody = JSON.parse(body);
                    }
                    catch (e) { }
                    postSignal(targetOp, url, json, method, parsedBody, bearer);
                }).catch(err => {
                    console.warn(`${TAG} JSON Parse Fail [${targetOp}]:`, err);
                });
                return response;
            }
            catch (e) {
                console.error(`${TAG} Fetch Error [${targetOp}]:`, e);
                throw e;
            }
        };
        window.__tc_fetch_patched = true;
        window.__tc_original_fetch = orgFetch;
    }
    function patchXHR() {
        if (window.__tc_xhr_patched)
            return;
        const OrgXHR = window.XMLHttpRequest;
        if (!OrgXHR) {
            hookAnomalies.push('Native XMLHttpRequest missing');
            return;
        }
        class TCXHRInterceptor extends OrgXHR {
            constructor() {
                super(...arguments);
                this._tc_url = '';
                this._tc_op = null;
                this._tc_method = 'GET';
            }
            open(m, u, ...rest) {
                this._tc_url = u;
                this._tc_method = m;
                this._tc_op = isTargetUrl(u);
                return super.open.apply(this, [m, u, ...rest]);
            }
            send(b) {
                const op = this._tc_op;
                const url = this._tc_url;
                const method = this._tc_method;
                if (op && url) {
                    this.addEventListener('load', () => {
                        try {
                            if (this.responseText) {
                                let parsedBody = b;
                                try {
                                    if (typeof b === 'string')
                                        parsedBody = JSON.parse(b);
                                }
                                catch (e) { }
                                // XHR: bearer not easily captured from headers here; pass null
                                postSignal(op, url, JSON.parse(this.responseText), method, parsedBody, null);
                            }
                        }
                        catch (e) { }
                    });
                }
                return super.send(b);
            }
        }
        window.XMLHttpRequest = TCXHRInterceptor;
        window.__tc_xhr_patched = true;
        window.__tc_original_xhr = OrgXHR;
    }
    function printHealthLog() {
        const isFetchActive = !!window.__tc_fetch_patched;
        const isXHRActive = !!window.__tc_xhr_patched;
        const now = Date.now();
        const hitAgo = lastHitTime ? `${Math.round((now - lastHitTime) / 1000)}s ago` : 'Never';
        const sendAgo = lastSendTime ? `${Math.round((now - lastSendTime) / 1000)}s ago` : 'Never';
        console.groupCollapsed(`%c${TAG} System Pulse - ${new Date().toLocaleTimeString()}`, 'color: #1DA1F2');
        console.log(`Inject Status: %cALIVE`, 'color: #48BB78; font-weight: bold');
        console.log(`Fetch Hook:    %c${isFetchActive ? 'ACTIVE' : 'OFFLINE'}`, isFetchActive ? 'color: #48BB78' : 'color: #F56565');
        console.log(`XHR Hook:      %c${isXHRActive ? 'ACTIVE' : 'OFFLINE'}`, isXHRActive ? 'color: #48BB78' : 'color: #F56565');
        console.log(`Last API Hit:   ${hitAgo}`);
        console.log(`Last BG Send:   ${sendAgo}`);
        if (hookAnomalies.length > 0) {
            console.error(`Anomalies:     ${hookAnomalies.join(', ')}`);
        }
        else {
            console.log(`Anomalies:     %cNONE`, 'color: #48BB78');
        }
        console.groupEnd();
    }
    patchFetch();
    patchXHR();
    setInterval(printHealthLog, 10000);
    // Watchdog: report hook status + self-heal
    setInterval(() => {
        const f = window.fetch && window.__tc_fetch_patched;
        const x = window.__tc_xhr_patched;
        window.postMessage({
            source: 'tweetclaw-injection',
            type: 'HOOK_STATUS_REPORT',
            status: { fetch: !!f, xhr: !!x }
        }, '*');
        if (!f || window.fetch === window.__tc_original_fetch)
            patchFetch();
        if (!x || window.XMLHttpRequest === window.__tc_original_xhr)
            patchXHR();
    }, 2000);
    printHealthLog();
})();

})();

/******/ })()
;
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoianMvaW5qZWN0aW9uLmpzIiwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBQU87QUFDQTtBQUNBO0FBQ0E7QUFDUDtBQUNBO0FBQ0E7QUFDQSxDQUFDLDBCQUEwQjtBQUNwQjtBQUNQO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDTztBQUNQO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ087QUFDUDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7Ozs7Ozs7VUMzRkE7VUFDQTs7VUFFQTtVQUNBO1VBQ0E7VUFDQTtVQUNBO1VBQ0E7VUFDQTtVQUNBO1VBQ0E7VUFDQTtVQUNBO1VBQ0E7VUFDQTs7VUFFQTtVQUNBO1VBQ0E7VUFDQTtVQUNBO1VBQ0E7VUFDQTtVQUNBOztVQUVBO1VBQ0E7VUFDQTs7Ozs7V0M1QkE7V0FDQTtXQUNBO1dBQ0E7V0FDQSx5Q0FBeUMsd0NBQXdDO1dBQ2pGO1dBQ0E7V0FDQSxFOzs7OztXQ1BBLHdGOzs7OztXQ0FBO1dBQ0E7V0FDQTtXQUNBLHVEQUF1RCxpQkFBaUI7V0FDeEU7V0FDQSxnREFBZ0QsYUFBYTtXQUM3RCxFOzs7Ozs7Ozs7Ozs7QUNOcUQ7QUFDckQ7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsbUJBQW1CLEtBQUs7QUFDeEI7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EseUJBQXlCLCtDQUFVO0FBQ25DO0FBQ0E7QUFDQSxzQ0FBc0MsUUFBUSw0QkFBNEIsUUFBUTtBQUNsRjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLDZCQUE2QixLQUFLLG9CQUFvQixLQUFLLE1BQU0sVUFBVSw0Q0FBNEM7QUFDdkg7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0Esa0NBQWtDLHNEQUFhO0FBQy9DO0FBQ0E7QUFDQSxxQ0FBcUMsS0FBSyxFQUFFLFFBQVEsR0FBRyxhQUFhLE1BQU0sS0FBSyxhQUFhLFFBQVEsa0JBQWtCO0FBQ3RIO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLFNBQVM7QUFDVDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLHFDQUFxQyxLQUFLLGVBQWUsSUFBSTtBQUM3RDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxpQkFBaUI7QUFDakIsb0NBQW9DLEtBQUssbUJBQW1CLFNBQVM7QUFDckUsaUJBQWlCO0FBQ2pCO0FBQ0E7QUFDQTtBQUNBLGlDQUFpQyxLQUFLLGVBQWUsU0FBUztBQUM5RDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0Esc0ZBQXNGO0FBQ3RGO0FBQ0E7QUFDQTtBQUNBO0FBQ0EscUJBQXFCO0FBQ3JCO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLHdDQUF3Qyx1Q0FBdUM7QUFDL0UsMENBQTBDLHdDQUF3QztBQUNsRixvQ0FBb0MsS0FBSyxpQkFBaUIsZ0NBQWdDO0FBQzFGLCtEQUErRDtBQUMvRCx3Q0FBd0MscUNBQXFDO0FBQzdFLHdDQUF3QyxtQ0FBbUM7QUFDM0UsdUNBQXVDLE9BQU87QUFDOUMsdUNBQXVDLFFBQVE7QUFDL0M7QUFDQSw0Q0FBNEMseUJBQXlCO0FBQ3JFO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0Esc0JBQXNCO0FBQ3RCLFNBQVM7QUFDVDtBQUNBO0FBQ0E7QUFDQTtBQUNBLEtBQUs7QUFDTDtBQUNBLENBQUMiLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9Ud2VldENsYXcvLi9zcmMvY2FwdHVyZS9jb25zdHMudHMiLCJ3ZWJwYWNrOi8vVHdlZXRDbGF3L3dlYnBhY2svYm9vdHN0cmFwIiwid2VicGFjazovL1R3ZWV0Q2xhdy93ZWJwYWNrL3J1bnRpbWUvZGVmaW5lIHByb3BlcnR5IGdldHRlcnMiLCJ3ZWJwYWNrOi8vVHdlZXRDbGF3L3dlYnBhY2svcnVudGltZS9oYXNPd25Qcm9wZXJ0eSBzaG9ydGhhbmQiLCJ3ZWJwYWNrOi8vVHdlZXRDbGF3L3dlYnBhY2svcnVudGltZS9tYWtlIG5hbWVzcGFjZSBvYmplY3QiLCJ3ZWJwYWNrOi8vVHdlZXRDbGF3Ly4vc3JjL2NhcHR1cmUvaW5qZWN0aW9uLnRzIl0sInNvdXJjZXNDb250ZW50IjpbImV4cG9ydCBjb25zdCBfX0RCS19xdWVyeV9pZF9tYXAgPSAndGNfcXVlcnlfaWRfbWFwJztcbmV4cG9ydCBjb25zdCBfX0RCS19iZWFyZXJfdG9rZW4gPSAndGNfYmVhcmVyX3Rva2VuJztcbmV4cG9ydCBjb25zdCBfX0RCS19keW5hbWljX2ZlYXR1cmVzID0gJ3RjX2R5bmFtaWNfZmVhdHVyZXMnO1xuZXhwb3J0IHZhciBNc2dUeXBlO1xuKGZ1bmN0aW9uIChNc2dUeXBlKSB7XG4gICAgTXNnVHlwZVtcIlBJTkdcIl0gPSBcIlBJTkdcIjtcbiAgICBNc2dUeXBlW1wiRVhFQ1VURV9BQ1RJT05cIl0gPSBcIkVYRUNVVEVfQUNUSU9OXCI7XG59KShNc2dUeXBlIHx8IChNc2dUeXBlID0ge30pKTtcbmV4cG9ydCBjb25zdCB3YXRjaGVkT3BzID0gW1xuICAgICdVc2VyVHdlZXRzJyxcbiAgICAnSG9tZVRpbWVsaW5lJyxcbiAgICAnSG9tZUxhdGVzdFRpbWVsaW5lJyxcbiAgICAnVHdlZXREZXRhaWwnLFxuICAgICdVc2VyQnlTY3JlZW5OYW1lJyxcbiAgICAnUHJvZmlsZVNwb3RsaWdodHNRdWVyeScsXG4gICAgJ0FjY291bnRTZXR0aW5ncycsXG4gICAgJ0F1dGhlbnRpY2F0ZWRVc2VyUXVlcnknLFxuICAgICdWaWV3ZXInLFxuICAgICdWZXJpZnlDcmVkZW50aWFscycsXG4gICAgJ0NyZWF0ZUZyaWVuZHNoaXAnLFxuICAgICdEZXN0cm95RnJpZW5kc2hpcCcsXG4gICAgJ0NyZWF0ZUJvb2ttYXJrJyxcbiAgICAnRGVsZXRlQm9va21hcmsnLFxuICAgICdGb2xsb3dlcnMnLFxuICAgICdGb2xsb3dpbmcnLFxuICAgICdTZWFyY2hUaW1lbGluZScsXG4gICAgJ0Zhdm9yaXRlVHdlZXQnLFxuICAgICdVbmZhdm9yaXRlVHdlZXQnLFxuICAgICdDcmVhdGVSZXR3ZWV0JyxcbiAgICAnRGVsZXRlUmV0d2VldCcsXG4gICAgJ0xpc3RMYXRlc3RUd2VldHNUaW1lbGluZScsXG4gICAgJ1RpbWVsaW5lSG9tZScsXG4gICAgJ0FjY291bnRVc2VyUXVlcnknLFxuICAgICdVc2VyQnlSZXN0SWQnLFxuICAgICdDcmVhdGVUd2VldCcsIC8vIOaWsOWinu+8muWPkeaOqOaWh++8iOWQq+WbnuWkje+8iVxuICAgICdEZWxldGVUd2VldCcsIC8vIOaWsOWinu+8muWIoOmZpOaOqOaWh1xuICAgICdEZWxldGVSZXR3ZWV0JyAvLyDmlrDlop7vvJrlj5bmtojovazlj5Fcbl07XG5leHBvcnQgY29uc3QgZGVmYXVsdFF1ZXJ5S2V5TWFwID0ge1xuICAgICdVc2VyQnlTY3JlZW5OYW1lJzogJ2NrNUtrWjh0NWNPbW9Mc3NvcE45OVEnLFxuICAgICdVc2VyVHdlZXRzJzogJ0U4V3EtX2pGU2FVN2h4VmN1T1BSOWcnLFxuICAgICdIb21lTGF0ZXN0VGltZWxpbmUnOiAnU0Z4bU5LV2ZOOXlTSmNYR190alg4ZycsXG4gICAgJ0hvbWVUaW1lbGluZSc6ICdEWG1nUVltSWZ0MW9MUDZ2TWtKaXh3JyxcbiAgICAnVHdlZXREZXRhaWwnOiAnaUZFcjVBY1AxMjFPZzR3eDlZcW8zdycsXG4gICAgJ1NlYXJjaFRpbWVsaW5lJzogJzRmcGNlWVo2LVlRQ3hfSlNsX0NuX0EnLFxuICAgICdDcmVhdGVCb29rbWFyayc6ICdhb0RidTNSSHpudWlTa1E5YU5NNjdRJyxcbiAgICAnRGVsZXRlQm9va21hcmsnOiAnV2xtbGoyLXh6eVMxR04zYTZjai1tUScsXG4gICAgJ0ZvbGxvd2luZyc6ICdTYVdxencwVEZBV014MW5YV2pYb2FRJyxcbiAgICAnRm9sbG93ZXJzJzogJ2k2UFBkSU1tMU1PN0NwQXFqYXU3c3cnLFxuICAgICdGYXZvcml0ZVR3ZWV0JzogJ2xJMDdONk90d3YxUGhuRWdYSUxNN0EnLFxuICAgICdVbmZhdm9yaXRlVHdlZXQnOiAnWllLU2UtdzdLRXNseDNKaFNJazVMQScsXG4gICAgJ0NyZWF0ZVJldHdlZXQnOiAnbWJSTzc0R3JPdlNmUmNKbmxNYXBuUScsXG4gICAgJ0NyZWF0ZUZyaWVuZHNoaXAnOiAnNjZ2OV9TX3ZUaGhBcmV3Xzk5djlfdjknLFxuICAgICdEZXN0cm95RnJpZW5kc2hpcCc6ICdPcHY3X3A4QXVuTWhKdkQ4WDhjOXJ3JyxcbiAgICAnVXNlckJ5UmVzdElkJzogJ0xKWUlfVnZURkFaZjdQQWRUMGVXbUEnLFxuICAgICdDcmVhdGVUd2VldCc6ICd6a2NGYzZGLVJLUmdXTjhIVWtKZlpnJywgLy8g5paw5aKe77ya5bey56Gu6K6k77yIMjAyNS0wNe+8iVxuICAgICdEZWxldGVUd2VldCc6ICdueHBaQ1kySy1JNlFvRkhBSGVvakZRJywgLy8g5paw5aKe77ya5bey56Gu6K6k77yIMjAyNS0wNe+8iVxuICAgICdEZWxldGVSZXR3ZWV0JzogJ1p5WmlnVnNOaUZPNnYxZEVrczFlV2cnIC8vIOaWsOWinu+8muW3suehruiupO+8iDIwMjUtMDXvvIlcbn07XG4vKipcbiAqIOivhuWIqyBYIOa4uOWuoui0puWPt++8iEd1ZXN0IFRva2Vu77yJXG4gKlxuICogWCDnmoQgZ3Vlc3QgdG9rZW4gaGFuZGxlIOeJueW+ge+8mlxuICogICAtIOaBsOWlvSAxNSDkuKrlrZfnrKZcbiAqICAgLSDlhajpg6jmmK/lsI/lhpnlrZfmr40gKyDmlbDlrZfvvIjml6DlpKflhpnlrZfmr43jgIHml6DkuIvliJLnur/vvIlcbiAqICAgLSDlkKvmnInoh7PlsJHkuIDkuKrmlbDlrZdcbiAqXG4gKiDnnJ/lrp7nlKjmiLcgaGFuZGxlIOWPr+S7peWMheWQq+Wkp+WGmeWtl+avjeaIluS4i+WIkue6v++8jOS4jeS8muiiq+ivr+WIpOOAglxuICog5L6L5aaC6K+v5Yik5qGI5L6L77yaMURVMUdmN29FbFIyaDI4IOKGkiDlkKvlpKflhpkg4oaSIOS4jeaYryBndWVzdCDinJNcbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIGlzR3Vlc3RIYW5kbGUoaCkge1xuICAgIGlmICghaClcbiAgICAgICAgcmV0dXJuIGZhbHNlO1xuICAgIGNvbnN0IGNsZWFuID0gaC5zdGFydHNXaXRoKCdAJykgPyBoLnN1YnN0cmluZygxKSA6IGg7XG4gICAgLy8gR3Vlc3QgaGFuZGxlcyBhcmUgcmFuZG9tIDE1LWNoYXIgc3RyaW5ncyAoZS5nLiwgJ3h5ejEyMzRhYmM1Njc4eicgb3IgJzEyMzQ1Njc4OTAxMjM0NScpXG4gICAgLy8gUmVhbCB1c2VycyBsaWtlICd3ZWIzYnJpZGdlbmluamEnICgxNSBjaGFycywgbG93ZXJjYXNlLCAxIGRpZ2l0KSBhcmUgY29tbW9uIGZhbHNlIHBvc2l0aXZlcy5cbiAgICBpZiAoY2xlYW4ubGVuZ3RoICE9PSAxNSB8fCAhL15bYS16MC05XSskLy50ZXN0KGNsZWFuKSlcbiAgICAgICAgcmV0dXJuIGZhbHNlO1xuICAgIGNvbnN0IGRpZ2l0cyA9IChjbGVhbi5tYXRjaCgvXFxkL2cpIHx8IFtdKS5sZW5ndGg7XG4gICAgY29uc3QgaGFzVm93ZWxzID0gL1thZWlvdV0vLnRlc3QoY2xlYW4pO1xuICAgIC8vIEhldXJpc3RpY3M6XG4gICAgLy8gMS4gQWxsIG51bWVyaWMgaXMgZGVmaW5pdGVseSBhIGd1ZXN0IHRva2VuXG4gICAgaWYgKC9eXFxkKyQvLnRlc3QoY2xlYW4pKVxuICAgICAgICByZXR1cm4gdHJ1ZTtcbiAgICAvLyAyLiBBbHBoYW51bWVyaWMgd2l0aCBoaWdoIGRpZ2l0IGNvdW50ICg+PSAzKSBhbmQgbm8gdm93ZWxzIGlzIHZlcnkgbGlrZWx5IGEgZ3Vlc3RcbiAgICBpZiAoZGlnaXRzID49IDIgJiYgIWhhc1Zvd2VscylcbiAgICAgICAgcmV0dXJuIHRydWU7XG4gICAgLy8gMy4gVmVyeSBoaWdoIGRpZ2l0IGNvdW50ICg+PSA1KSBpcyBhbHNvIGEgcmVkIGZsYWcgZXZlbiB3aXRoIHZvd2Vsc1xuICAgIGlmIChkaWdpdHMgPj0gNSlcbiAgICAgICAgcmV0dXJuIHRydWU7XG4gICAgcmV0dXJuIGZhbHNlO1xufVxuIiwiLy8gVGhlIG1vZHVsZSBjYWNoZVxudmFyIF9fd2VicGFja19tb2R1bGVfY2FjaGVfXyA9IHt9O1xuXG4vLyBUaGUgcmVxdWlyZSBmdW5jdGlvblxuZnVuY3Rpb24gX193ZWJwYWNrX3JlcXVpcmVfXyhtb2R1bGVJZCkge1xuXHQvLyBDaGVjayBpZiBtb2R1bGUgaXMgaW4gY2FjaGVcblx0dmFyIGNhY2hlZE1vZHVsZSA9IF9fd2VicGFja19tb2R1bGVfY2FjaGVfX1ttb2R1bGVJZF07XG5cdGlmIChjYWNoZWRNb2R1bGUgIT09IHVuZGVmaW5lZCkge1xuXHRcdHJldHVybiBjYWNoZWRNb2R1bGUuZXhwb3J0cztcblx0fVxuXHQvLyBDcmVhdGUgYSBuZXcgbW9kdWxlIChhbmQgcHV0IGl0IGludG8gdGhlIGNhY2hlKVxuXHR2YXIgbW9kdWxlID0gX193ZWJwYWNrX21vZHVsZV9jYWNoZV9fW21vZHVsZUlkXSA9IHtcblx0XHQvLyBubyBtb2R1bGUuaWQgbmVlZGVkXG5cdFx0Ly8gbm8gbW9kdWxlLmxvYWRlZCBuZWVkZWRcblx0XHRleHBvcnRzOiB7fVxuXHR9O1xuXG5cdC8vIEV4ZWN1dGUgdGhlIG1vZHVsZSBmdW5jdGlvblxuXHRpZiAoIShtb2R1bGVJZCBpbiBfX3dlYnBhY2tfbW9kdWxlc19fKSkge1xuXHRcdGRlbGV0ZSBfX3dlYnBhY2tfbW9kdWxlX2NhY2hlX19bbW9kdWxlSWRdO1xuXHRcdHZhciBlID0gbmV3IEVycm9yKFwiQ2Fubm90IGZpbmQgbW9kdWxlICdcIiArIG1vZHVsZUlkICsgXCInXCIpO1xuXHRcdGUuY29kZSA9ICdNT0RVTEVfTk9UX0ZPVU5EJztcblx0XHR0aHJvdyBlO1xuXHR9XG5cdF9fd2VicGFja19tb2R1bGVzX19bbW9kdWxlSWRdKG1vZHVsZSwgbW9kdWxlLmV4cG9ydHMsIF9fd2VicGFja19yZXF1aXJlX18pO1xuXG5cdC8vIFJldHVybiB0aGUgZXhwb3J0cyBvZiB0aGUgbW9kdWxlXG5cdHJldHVybiBtb2R1bGUuZXhwb3J0cztcbn1cblxuIiwiLy8gZGVmaW5lIGdldHRlciBmdW5jdGlvbnMgZm9yIGhhcm1vbnkgZXhwb3J0c1xuX193ZWJwYWNrX3JlcXVpcmVfXy5kID0gKGV4cG9ydHMsIGRlZmluaXRpb24pID0+IHtcblx0Zm9yKHZhciBrZXkgaW4gZGVmaW5pdGlvbikge1xuXHRcdGlmKF9fd2VicGFja19yZXF1aXJlX18ubyhkZWZpbml0aW9uLCBrZXkpICYmICFfX3dlYnBhY2tfcmVxdWlyZV9fLm8oZXhwb3J0cywga2V5KSkge1xuXHRcdFx0T2JqZWN0LmRlZmluZVByb3BlcnR5KGV4cG9ydHMsIGtleSwgeyBlbnVtZXJhYmxlOiB0cnVlLCBnZXQ6IGRlZmluaXRpb25ba2V5XSB9KTtcblx0XHR9XG5cdH1cbn07IiwiX193ZWJwYWNrX3JlcXVpcmVfXy5vID0gKG9iaiwgcHJvcCkgPT4gKE9iamVjdC5wcm90b3R5cGUuaGFzT3duUHJvcGVydHkuY2FsbChvYmosIHByb3ApKSIsIi8vIGRlZmluZSBfX2VzTW9kdWxlIG9uIGV4cG9ydHNcbl9fd2VicGFja19yZXF1aXJlX18uciA9IChleHBvcnRzKSA9PiB7XG5cdGlmKHR5cGVvZiBTeW1ib2wgIT09ICd1bmRlZmluZWQnICYmIFN5bWJvbC50b1N0cmluZ1RhZykge1xuXHRcdE9iamVjdC5kZWZpbmVQcm9wZXJ0eShleHBvcnRzLCBTeW1ib2wudG9TdHJpbmdUYWcsIHsgdmFsdWU6ICdNb2R1bGUnIH0pO1xuXHR9XG5cdE9iamVjdC5kZWZpbmVQcm9wZXJ0eShleHBvcnRzLCAnX19lc01vZHVsZScsIHsgdmFsdWU6IHRydWUgfSk7XG59OyIsImltcG9ydCB7IHdhdGNoZWRPcHMsIGlzR3Vlc3RIYW5kbGUgfSBmcm9tICcuL2NvbnN0cyc7XG4vKipcbiAqIFR3ZWV0Q2xhdyBJbmplY3RlZCBTZW5zb3IgKHY0LjggLSBVUkwgKyBCZWFyZXIgRml4KVxuICpcbiAqIOWFs+mUruS/ruato++8mlxuICogIC0gcG9zdFNpZ25hbCDnjrDlnKjkvKAgYXBpVXJs77yI6KKr5oum5oiq55qE55yf5a6eIEFQSSDnq6/ngrnvvInvvIzkuI3lho3kvKDpobXpnaIgVVJMXG4gKiAgLSDku44gZmV0Y2gg6K+35rGC5aS05Lit5o+Q5Y+WIGJlYXJlciB0b2tlbiDkuIDlubblj5Hlh7rvvIzkvpsgYmFja2dyb3VuZCDlrZjlgqhcbiAqL1xuKGZ1bmN0aW9uICgpIHtcbiAgICBjb25zdCBUQUcgPSAn8J+boe+4jyBbVHdlZXRDbGF3LVBhZ2VdJztcbiAgICBsZXQgbGFzdEhpdFRpbWUgPSAwO1xuICAgIGxldCBsYXN0U2VuZFRpbWUgPSAwO1xuICAgIGxldCBob29rQW5vbWFsaWVzID0gW107XG4gICAgY29uc29sZS5sb2coYCR7VEFHfSBTeXN0ZW0gaW5pdGlhbGl6aW5nLi4uYCk7XG4gICAgZnVuY3Rpb24gaXNJZGVudGl0eU9wKHVybCkge1xuICAgICAgICBjb25zdCBsb3dlclVybCA9IHVybC50b0xvd2VyQ2FzZSgpO1xuICAgICAgICBpZiAobG93ZXJVcmwuaW5jbHVkZXMoJ2F1dGhlbnRpY2F0ZWR1c2VycXVlcnknKSlcbiAgICAgICAgICAgIHJldHVybiAnQXV0aGVudGljYXRlZFVzZXJRdWVyeSc7XG4gICAgICAgIGlmIChsb3dlclVybC5pbmNsdWRlcygndmlld2VyJykpXG4gICAgICAgICAgICByZXR1cm4gJ1ZpZXdlcic7XG4gICAgICAgIGlmIChsb3dlclVybC5pbmNsdWRlcygnYWNjb3VudHVzZXJxdWVyeScpKVxuICAgICAgICAgICAgcmV0dXJuICdBY2NvdW50VXNlclF1ZXJ5JztcbiAgICAgICAgaWYgKGxvd2VyVXJsLmluY2x1ZGVzKCdhY2NvdW50c2V0dGluZ3MnKSlcbiAgICAgICAgICAgIHJldHVybiAnQWNjb3VudFNldHRpbmdzJztcbiAgICAgICAgaWYgKGxvd2VyVXJsLmluY2x1ZGVzKCcvYWNjb3VudC9zZXR0aW5ncy5qc29uJykpXG4gICAgICAgICAgICByZXR1cm4gJ3NldHRpbmdzLmpzb24nO1xuICAgICAgICBpZiAobG93ZXJVcmwuaW5jbHVkZXMoJy9hY2NvdW50L3ZlcmlmeV9jcmVkZW50aWFscy5qc29uJykpXG4gICAgICAgICAgICByZXR1cm4gJ1ZlcmlmeUNyZWRlbnRpYWxzJztcbiAgICAgICAgcmV0dXJuIG51bGw7XG4gICAgfVxuICAgIGZ1bmN0aW9uIGlzVGFyZ2V0VXJsKHVybCkge1xuICAgICAgICBjb25zdCBpZE9wID0gaXNJZGVudGl0eU9wKHVybCk7XG4gICAgICAgIGlmIChpZE9wKVxuICAgICAgICAgICAgcmV0dXJuIGlkT3A7XG4gICAgICAgIGNvbnN0IGxvd2VyVXJsID0gdXJsLnRvTG93ZXJDYXNlKCk7XG4gICAgICAgIGZvciAoY29uc3Qgb3Agb2Ygd2F0Y2hlZE9wcykge1xuICAgICAgICAgICAgY29uc3QgbG93ZXJPcCA9IG9wLnRvTG93ZXJDYXNlKCk7XG4gICAgICAgICAgICAvLyDljLnphY0gL09wTmFtZSDmiJYgPU9wTmFtZVxuICAgICAgICAgICAgaWYgKGxvd2VyVXJsLmluY2x1ZGVzKGAvJHtsb3dlck9wfWApIHx8IGxvd2VyVXJsLmluY2x1ZGVzKGA9JHtsb3dlck9wfWApKVxuICAgICAgICAgICAgICAgIHJldHVybiBvcDtcbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gbnVsbDtcbiAgICB9XG4gICAgLyoqXG4gICAgICogQHBhcmFtIHR5cGUgICBvcGVyYXRpb25OYW1lIChlLmcuICdIb21lVGltZWxpbmUnKVxuICAgICAqIEBwYXJhbSBhcGlVcmwg6KKr5oum5oiq55qE55yf5a6eIEFQSSDnq6/ngrnvvIjlkKsgcXVlcnlJZCDnmoQgZ3JhcGhxbCBVUkwg5oiWIFJFU1QgVVJM77yJXG4gICAgICogQHBhcmFtIGRhdGEgICDlk43lupTkvZMgSlNPTlxuICAgICAqL1xuICAgIGZ1bmN0aW9uIHBvc3RTaWduYWwodHlwZSwgYXBpVXJsLCBkYXRhLCBtZXRob2QgPSAnUE9TVCcsIHJlcXVlc3RCb2R5LCBiZWFyZXJUb2tlbikge1xuICAgICAgICBsYXN0SGl0VGltZSA9IERhdGUubm93KCk7XG4gICAgICAgIHRyeSB7XG4gICAgICAgICAgICBjb25zdCBiaXRlU2l6ZSA9IG5ldyBUZXh0RW5jb2RlcigpLmVuY29kZShKU09OLnN0cmluZ2lmeShkYXRhKSkubGVuZ3RoO1xuICAgICAgICAgICAgY29uc29sZS5sb2coYCVjJHtUQUd9IPCfk6EgSW50ZXJjZXB0ZWQ6ICVjJHt0eXBlfSVjICgke2JpdGVTaXplfSBieXRlcylgLCAnY29sb3I6ICM3MTgwOTYnLCAnY29sb3I6ICMxREExRjI7IGZvbnQtd2VpZ2h0OiBib2xkJywgJ2NvbG9yOiAjNzE4MDk2Jyk7XG4gICAgICAgIH1cbiAgICAgICAgY2F0Y2ggKGUpIHsgfVxuICAgICAgICBjb25zdCBpc0lkID0gWydBdXRoZW50aWNhdGVkVXNlclF1ZXJ5JywgJ1ZpZXdlcicsICdBY2NvdW50U2V0dGluZ3MnLCAnc2V0dGluZ3MuanNvbicsICdWZXJpZnlDcmVkZW50aWFscyddLmluY2x1ZGVzKHR5cGUpO1xuICAgICAgICBpZiAoaXNJZCkge1xuICAgICAgICAgICAgdHJ5IHtcbiAgICAgICAgICAgICAgICBjb25zdCBzY3JlZW5fbmFtZSA9IGRhdGEuZGF0YT8udmlld2VyPy51c2VyX3Jlc3VsdHM/LnJlc3VsdD8ubGVnYWN5Py5zY3JlZW5fbmFtZSB8fFxuICAgICAgICAgICAgICAgICAgICBkYXRhLmRhdGE/LmF1dGhlbnRpY2F0ZWRfdXNlcl9pbmZvPy5zY3JlZW5fbmFtZSB8fFxuICAgICAgICAgICAgICAgICAgICBkYXRhLnNjcmVlbl9uYW1lO1xuICAgICAgICAgICAgICAgIGlmIChzY3JlZW5fbmFtZSkge1xuICAgICAgICAgICAgICAgICAgICBjb25zdCBndWVzdCA9IGlzR3Vlc3RIYW5kbGUoc2NyZWVuX25hbWUpO1xuICAgICAgICAgICAgICAgICAgICBjb25zdCBjb2xvciA9IGd1ZXN0ID8gJyNGRkFEMUYnIDogJyMxREExRjInO1xuICAgICAgICAgICAgICAgICAgICBjb25zdCBwcmVmaXggPSBndWVzdCA/ICfimqDvuI8gW0d1ZXN0IERldGVjdF0nIDogJ+KchSBbQWNjb3VudCBEZXRlY3RdJztcbiAgICAgICAgICAgICAgICAgICAgY29uc29sZS5sb2coYCVjJHtUQUd9ICR7cHJlZml4fSBAJHtzY3JlZW5fbmFtZX0gdmlhICR7dHlwZX1gLCBgY29sb3I6ICR7Y29sb3J9OyBmb250LXdlaWdodDogYm9sZDtgKTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBjYXRjaCAoZSkgeyB9XG4gICAgICAgIH1cbiAgICAgICAgLy8gRXh0cmFjdCBmZWF0dXJlcyBmcm9tIHJlcXVlc3QgYm9keSBmb3IgcGVyLW9wZXJhdGlvbiBjYWNoaW5nXG4gICAgICAgIGxldCBmZWF0dXJlcyA9IG51bGw7XG4gICAgICAgIHRyeSB7XG4gICAgICAgICAgICBpZiAocmVxdWVzdEJvZHkgJiYgdHlwZW9mIHJlcXVlc3RCb2R5ID09PSAnb2JqZWN0JyAmJiByZXF1ZXN0Qm9keS5mZWF0dXJlcykge1xuICAgICAgICAgICAgICAgIGZlYXR1cmVzID0gcmVxdWVzdEJvZHkuZmVhdHVyZXM7XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgICAgY2F0Y2ggKGUpIHsgfVxuICAgICAgICBsYXN0U2VuZFRpbWUgPSBEYXRlLm5vdygpO1xuICAgICAgICB3aW5kb3cucG9zdE1lc3NhZ2Uoe1xuICAgICAgICAgICAgc291cmNlOiAndHdlZXRjbGF3LWluamVjdGlvbicsXG4gICAgICAgICAgICB0eXBlOiAnU0lHTkFMX0NBUFRVUkVEJyxcbiAgICAgICAgICAgIG9wOiB0eXBlLFxuICAgICAgICAgICAgYXBpVXJsLCAvLyDihpAg55yf5a6eIEFQSSDnq6/ngrkgVVJM77yI5ZCrIHF1ZXJ5SWTvvIlcbiAgICAgICAgICAgIHBhZ2VVcmw6IHdpbmRvdy5sb2NhdGlvbi5ocmVmLCAvLyDihpAg5b2T5YmN6aG16Z2iIFVSTFxuICAgICAgICAgICAgbWV0aG9kLFxuICAgICAgICAgICAgcmVxdWVzdEJvZHksXG4gICAgICAgICAgICBiZWFyZXJUb2tlbjogYmVhcmVyVG9rZW4gfHwgbnVsbCxcbiAgICAgICAgICAgIGZlYXR1cmVzOiBmZWF0dXJlcywgLy8g4oaQIOaPkOWPlueahCBmZWF0dXJlc++8iOWmguaenOacie+8iVxuICAgICAgICAgICAgZGF0YVxuICAgICAgICB9LCAnKicpO1xuICAgIH1cbiAgICAvKiog5LuOIGZldGNoIFJlcXVlc3RJbml0IGhlYWRlcnMg5Lit5o+Q5Y+WIEF1dGhvcml6YXRpb24gQmVhcmVyICovXG4gICAgZnVuY3Rpb24gZXh0cmFjdEJlYXJlcihpbml0QXJnKSB7XG4gICAgICAgIHRyeSB7XG4gICAgICAgICAgICBjb25zdCBoZHJzID0gaW5pdEFyZz8uaGVhZGVycztcbiAgICAgICAgICAgIGlmICghaGRycylcbiAgICAgICAgICAgICAgICByZXR1cm4gbnVsbDtcbiAgICAgICAgICAgIGxldCBhdXRoID0gbnVsbDtcbiAgICAgICAgICAgIGlmIChoZHJzIGluc3RhbmNlb2YgSGVhZGVycykge1xuICAgICAgICAgICAgICAgIGF1dGggPSBoZHJzLmdldCgnYXV0aG9yaXphdGlvbicpO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgZWxzZSBpZiAodHlwZW9mIGhkcnMgPT09ICdvYmplY3QnKSB7XG4gICAgICAgICAgICAgICAgYXV0aCA9IGhkcnNbJ2F1dGhvcml6YXRpb24nXSB8fCBoZHJzWydBdXRob3JpemF0aW9uJ10gfHwgbnVsbDtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIHJldHVybiAoYXV0aCAmJiBhdXRoLnN0YXJ0c1dpdGgoJ0JlYXJlciAnKSkgPyBhdXRoIDogbnVsbDtcbiAgICAgICAgfVxuICAgICAgICBjYXRjaCB7XG4gICAgICAgICAgICByZXR1cm4gbnVsbDtcbiAgICAgICAgfVxuICAgIH1cbiAgICBmdW5jdGlvbiBwYXRjaEZldGNoKCkge1xuICAgICAgICBpZiAod2luZG93Ll9fdGNfZmV0Y2hfcGF0Y2hlZClcbiAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgY29uc3Qgb3JnRmV0Y2ggPSB3aW5kb3cuZmV0Y2g7XG4gICAgICAgIGlmICghb3JnRmV0Y2gpIHtcbiAgICAgICAgICAgIGhvb2tBbm9tYWxpZXMucHVzaCgnTmF0aXZlIGZldGNoIG1pc3NpbmcnKTtcbiAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgfVxuICAgICAgICB3aW5kb3cuZmV0Y2ggPSBhc3luYyBmdW5jdGlvbiAoLi4uYXJncykge1xuICAgICAgICAgICAgY29uc3QgcmVxQXJnID0gYXJnc1swXTtcbiAgICAgICAgICAgIGNvbnN0IGluaXRBcmcgPSBhcmdzWzFdO1xuICAgICAgICAgICAgY29uc3QgdXJsID0gdHlwZW9mIHJlcUFyZyA9PT0gJ3N0cmluZydcbiAgICAgICAgICAgICAgICA/IHJlcUFyZ1xuICAgICAgICAgICAgICAgIDogKHJlcUFyZyBpbnN0YW5jZW9mIFJlcXVlc3QgPyByZXFBcmcudXJsIDogU3RyaW5nKHJlcUFyZykpO1xuICAgICAgICAgICAgY29uc3QgbWV0aG9kID0gaW5pdEFyZz8ubWV0aG9kIHx8ICdHRVQnO1xuICAgICAgICAgICAgY29uc3QgYm9keSA9IGluaXRBcmc/LmJvZHk7XG4gICAgICAgICAgICBjb25zdCB0YXJnZXRPcCA9IGlzVGFyZ2V0VXJsKHVybCk7XG4gICAgICAgICAgICBpZiAoIXRhcmdldE9wKSB7XG4gICAgICAgICAgICAgICAgLy8g5aaC5p6c5pivIGdyYXBocWwg5LiU5YyF5ZCrIG9wZXJhdGlvbu+8jOS9huayoeWMuemFjeS4iu+8jOaJk+S4quaXpeW/l+WPguiAg1xuICAgICAgICAgICAgICAgIGlmICh1cmwuaW5jbHVkZXMoJy9ncmFwaHFsLycpKSB7XG4gICAgICAgICAgICAgICAgICAgIGNvbnNvbGUuZGVidWcoYCR7VEFHfSBJZ25vcmVkIEdRTDogJHt1cmx9YCk7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIHJldHVybiBvcmdGZXRjaC5hcHBseSh0aGlzLCBhcmdzKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGNvbnN0IGJlYXJlciA9IGV4dHJhY3RCZWFyZXIoaW5pdEFyZyk7XG4gICAgICAgICAgICB0cnkge1xuICAgICAgICAgICAgICAgIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgb3JnRmV0Y2guYXBwbHkodGhpcywgYXJncyk7XG4gICAgICAgICAgICAgICAgY29uc3QgY2xvbmUgPSByZXNwb25zZS5jbG9uZSgpO1xuICAgICAgICAgICAgICAgIGNsb25lLmpzb24oKS50aGVuKGpzb24gPT4ge1xuICAgICAgICAgICAgICAgICAgICBsZXQgcGFyc2VkQm9keSA9IGJvZHk7XG4gICAgICAgICAgICAgICAgICAgIHRyeSB7XG4gICAgICAgICAgICAgICAgICAgICAgICBpZiAodHlwZW9mIGJvZHkgPT09ICdzdHJpbmcnKVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHBhcnNlZEJvZHkgPSBKU09OLnBhcnNlKGJvZHkpO1xuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgIGNhdGNoIChlKSB7IH1cbiAgICAgICAgICAgICAgICAgICAgcG9zdFNpZ25hbCh0YXJnZXRPcCwgdXJsLCBqc29uLCBtZXRob2QsIHBhcnNlZEJvZHksIGJlYXJlcik7XG4gICAgICAgICAgICAgICAgfSkuY2F0Y2goZXJyID0+IHtcbiAgICAgICAgICAgICAgICAgICAgY29uc29sZS53YXJuKGAke1RBR30gSlNPTiBQYXJzZSBGYWlsIFske3RhcmdldE9wfV06YCwgZXJyKTtcbiAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgICAgICByZXR1cm4gcmVzcG9uc2U7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBjYXRjaCAoZSkge1xuICAgICAgICAgICAgICAgIGNvbnNvbGUuZXJyb3IoYCR7VEFHfSBGZXRjaCBFcnJvciBbJHt0YXJnZXRPcH1dOmAsIGUpO1xuICAgICAgICAgICAgICAgIHRocm93IGU7XG4gICAgICAgICAgICB9XG4gICAgICAgIH07XG4gICAgICAgIHdpbmRvdy5fX3RjX2ZldGNoX3BhdGNoZWQgPSB0cnVlO1xuICAgICAgICB3aW5kb3cuX190Y19vcmlnaW5hbF9mZXRjaCA9IG9yZ0ZldGNoO1xuICAgIH1cbiAgICBmdW5jdGlvbiBwYXRjaFhIUigpIHtcbiAgICAgICAgaWYgKHdpbmRvdy5fX3RjX3hocl9wYXRjaGVkKVxuICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICBjb25zdCBPcmdYSFIgPSB3aW5kb3cuWE1MSHR0cFJlcXVlc3Q7XG4gICAgICAgIGlmICghT3JnWEhSKSB7XG4gICAgICAgICAgICBob29rQW5vbWFsaWVzLnB1c2goJ05hdGl2ZSBYTUxIdHRwUmVxdWVzdCBtaXNzaW5nJyk7XG4gICAgICAgICAgICByZXR1cm47XG4gICAgICAgIH1cbiAgICAgICAgY2xhc3MgVENYSFJJbnRlcmNlcHRvciBleHRlbmRzIE9yZ1hIUiB7XG4gICAgICAgICAgICBjb25zdHJ1Y3RvcigpIHtcbiAgICAgICAgICAgICAgICBzdXBlciguLi5hcmd1bWVudHMpO1xuICAgICAgICAgICAgICAgIHRoaXMuX3RjX3VybCA9ICcnO1xuICAgICAgICAgICAgICAgIHRoaXMuX3RjX29wID0gbnVsbDtcbiAgICAgICAgICAgICAgICB0aGlzLl90Y19tZXRob2QgPSAnR0VUJztcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIG9wZW4obSwgdSwgLi4ucmVzdCkge1xuICAgICAgICAgICAgICAgIHRoaXMuX3RjX3VybCA9IHU7XG4gICAgICAgICAgICAgICAgdGhpcy5fdGNfbWV0aG9kID0gbTtcbiAgICAgICAgICAgICAgICB0aGlzLl90Y19vcCA9IGlzVGFyZ2V0VXJsKHUpO1xuICAgICAgICAgICAgICAgIHJldHVybiBzdXBlci5vcGVuLmFwcGx5KHRoaXMsIFttLCB1LCAuLi5yZXN0XSk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBzZW5kKGIpIHtcbiAgICAgICAgICAgICAgICBjb25zdCBvcCA9IHRoaXMuX3RjX29wO1xuICAgICAgICAgICAgICAgIGNvbnN0IHVybCA9IHRoaXMuX3RjX3VybDtcbiAgICAgICAgICAgICAgICBjb25zdCBtZXRob2QgPSB0aGlzLl90Y19tZXRob2Q7XG4gICAgICAgICAgICAgICAgaWYgKG9wICYmIHVybCkge1xuICAgICAgICAgICAgICAgICAgICB0aGlzLmFkZEV2ZW50TGlzdGVuZXIoJ2xvYWQnLCAoKSA9PiB7XG4gICAgICAgICAgICAgICAgICAgICAgICB0cnkge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlmICh0aGlzLnJlc3BvbnNlVGV4dCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBsZXQgcGFyc2VkQm9keSA9IGI7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRyeSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZiAodHlwZW9mIGIgPT09ICdzdHJpbmcnKVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHBhcnNlZEJvZHkgPSBKU09OLnBhcnNlKGIpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNhdGNoIChlKSB7IH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLy8gWEhSOiBiZWFyZXIgbm90IGVhc2lseSBjYXB0dXJlZCBmcm9tIGhlYWRlcnMgaGVyZTsgcGFzcyBudWxsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHBvc3RTaWduYWwob3AsIHVybCwgSlNPTi5wYXJzZSh0aGlzLnJlc3BvbnNlVGV4dCksIG1ldGhvZCwgcGFyc2VkQm9keSwgbnVsbCk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgY2F0Y2ggKGUpIHsgfVxuICAgICAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgcmV0dXJuIHN1cGVyLnNlbmQoYik7XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgICAgd2luZG93LlhNTEh0dHBSZXF1ZXN0ID0gVENYSFJJbnRlcmNlcHRvcjtcbiAgICAgICAgd2luZG93Ll9fdGNfeGhyX3BhdGNoZWQgPSB0cnVlO1xuICAgICAgICB3aW5kb3cuX190Y19vcmlnaW5hbF94aHIgPSBPcmdYSFI7XG4gICAgfVxuICAgIGZ1bmN0aW9uIHByaW50SGVhbHRoTG9nKCkge1xuICAgICAgICBjb25zdCBpc0ZldGNoQWN0aXZlID0gISF3aW5kb3cuX190Y19mZXRjaF9wYXRjaGVkO1xuICAgICAgICBjb25zdCBpc1hIUkFjdGl2ZSA9ICEhd2luZG93Ll9fdGNfeGhyX3BhdGNoZWQ7XG4gICAgICAgIGNvbnN0IG5vdyA9IERhdGUubm93KCk7XG4gICAgICAgIGNvbnN0IGhpdEFnbyA9IGxhc3RIaXRUaW1lID8gYCR7TWF0aC5yb3VuZCgobm93IC0gbGFzdEhpdFRpbWUpIC8gMTAwMCl9cyBhZ29gIDogJ05ldmVyJztcbiAgICAgICAgY29uc3Qgc2VuZEFnbyA9IGxhc3RTZW5kVGltZSA/IGAke01hdGgucm91bmQoKG5vdyAtIGxhc3RTZW5kVGltZSkgLyAxMDAwKX1zIGFnb2AgOiAnTmV2ZXInO1xuICAgICAgICBjb25zb2xlLmdyb3VwQ29sbGFwc2VkKGAlYyR7VEFHfSBTeXN0ZW0gUHVsc2UgLSAke25ldyBEYXRlKCkudG9Mb2NhbGVUaW1lU3RyaW5nKCl9YCwgJ2NvbG9yOiAjMURBMUYyJyk7XG4gICAgICAgIGNvbnNvbGUubG9nKGBJbmplY3QgU3RhdHVzOiAlY0FMSVZFYCwgJ2NvbG9yOiAjNDhCQjc4OyBmb250LXdlaWdodDogYm9sZCcpO1xuICAgICAgICBjb25zb2xlLmxvZyhgRmV0Y2ggSG9vazogICAgJWMke2lzRmV0Y2hBY3RpdmUgPyAnQUNUSVZFJyA6ICdPRkZMSU5FJ31gLCBpc0ZldGNoQWN0aXZlID8gJ2NvbG9yOiAjNDhCQjc4JyA6ICdjb2xvcjogI0Y1NjU2NScpO1xuICAgICAgICBjb25zb2xlLmxvZyhgWEhSIEhvb2s6ICAgICAgJWMke2lzWEhSQWN0aXZlID8gJ0FDVElWRScgOiAnT0ZGTElORSd9YCwgaXNYSFJBY3RpdmUgPyAnY29sb3I6ICM0OEJCNzgnIDogJ2NvbG9yOiAjRjU2NTY1Jyk7XG4gICAgICAgIGNvbnNvbGUubG9nKGBMYXN0IEFQSSBIaXQ6ICAgJHtoaXRBZ299YCk7XG4gICAgICAgIGNvbnNvbGUubG9nKGBMYXN0IEJHIFNlbmQ6ICAgJHtzZW5kQWdvfWApO1xuICAgICAgICBpZiAoaG9va0Fub21hbGllcy5sZW5ndGggPiAwKSB7XG4gICAgICAgICAgICBjb25zb2xlLmVycm9yKGBBbm9tYWxpZXM6ICAgICAke2hvb2tBbm9tYWxpZXMuam9pbignLCAnKX1gKTtcbiAgICAgICAgfVxuICAgICAgICBlbHNlIHtcbiAgICAgICAgICAgIGNvbnNvbGUubG9nKGBBbm9tYWxpZXM6ICAgICAlY05PTkVgLCAnY29sb3I6ICM0OEJCNzgnKTtcbiAgICAgICAgfVxuICAgICAgICBjb25zb2xlLmdyb3VwRW5kKCk7XG4gICAgfVxuICAgIHBhdGNoRmV0Y2goKTtcbiAgICBwYXRjaFhIUigpO1xuICAgIHNldEludGVydmFsKHByaW50SGVhbHRoTG9nLCAxMDAwMCk7XG4gICAgLy8gV2F0Y2hkb2c6IHJlcG9ydCBob29rIHN0YXR1cyArIHNlbGYtaGVhbFxuICAgIHNldEludGVydmFsKCgpID0+IHtcbiAgICAgICAgY29uc3QgZiA9IHdpbmRvdy5mZXRjaCAmJiB3aW5kb3cuX190Y19mZXRjaF9wYXRjaGVkO1xuICAgICAgICBjb25zdCB4ID0gd2luZG93Ll9fdGNfeGhyX3BhdGNoZWQ7XG4gICAgICAgIHdpbmRvdy5wb3N0TWVzc2FnZSh7XG4gICAgICAgICAgICBzb3VyY2U6ICd0d2VldGNsYXctaW5qZWN0aW9uJyxcbiAgICAgICAgICAgIHR5cGU6ICdIT09LX1NUQVRVU19SRVBPUlQnLFxuICAgICAgICAgICAgc3RhdHVzOiB7IGZldGNoOiAhIWYsIHhocjogISF4IH1cbiAgICAgICAgfSwgJyonKTtcbiAgICAgICAgaWYgKCFmIHx8IHdpbmRvdy5mZXRjaCA9PT0gd2luZG93Ll9fdGNfb3JpZ2luYWxfZmV0Y2gpXG4gICAgICAgICAgICBwYXRjaEZldGNoKCk7XG4gICAgICAgIGlmICgheCB8fCB3aW5kb3cuWE1MSHR0cFJlcXVlc3QgPT09IHdpbmRvdy5fX3RjX29yaWdpbmFsX3hocilcbiAgICAgICAgICAgIHBhdGNoWEhSKCk7XG4gICAgfSwgMjAwMCk7XG4gICAgcHJpbnRIZWFsdGhMb2coKTtcbn0pKCk7XG4iXSwibmFtZXMiOltdLCJzb3VyY2VSb290IjoiIn0=