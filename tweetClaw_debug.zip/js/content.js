/******/ (() => { // webpackBootstrap
/******/ 	"use strict";
/******/ 	var __webpack_modules__ = ({

/***/ "./src/capture/consts.ts"
/*!*******************************!*\
  !*** ./src/capture/consts.ts ***!
  \*******************************/
(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   MsgType: () => (/* binding */ MsgType),
/* harmony export */   __DBK_bearer_token: () => (/* binding */ __DBK_bearer_token),
/* harmony export */   __DBK_dynamic_features: () => (/* binding */ __DBK_dynamic_features),
/* harmony export */   __DBK_query_id_map: () => (/* binding */ __DBK_query_id_map),
/* harmony export */   defaultQueryKeyMap: () => (/* binding */ defaultQueryKeyMap),
/* harmony export */   isGuestHandle: () => (/* binding */ isGuestHandle),
/* harmony export */   watchedOps: () => (/* binding */ watchedOps)
/* harmony export */ });
const __DBK_query_id_map = 'tc_query_id_map';
const __DBK_bearer_token = 'tc_bearer_token';
const __DBK_dynamic_features = 'tc_dynamic_features';
var MsgType;
(function (MsgType) {
    MsgType["PING"] = "PING";
    MsgType["EXECUTE_ACTION"] = "EXECUTE_ACTION";
})(MsgType || (MsgType = {}));
const watchedOps = [
    'UserTweets',
    'HomeTimeline',
    'HomeLatestTimeline',
    'TweetDetail',
    'UserByScreenName',
    'ProfileSpotlightsQuery',
    'AccountSettings',
    'AuthenticatedUserQuery',
    'Viewer',
    'VerifyCredentials',
    'CreateFriendship',
    'DestroyFriendship',
    'CreateBookmark',
    'DeleteBookmark',
    'Followers',
    'Following',
    'SearchTimeline',
    'FavoriteTweet',
    'UnfavoriteTweet',
    'CreateRetweet',
    'DeleteRetweet',
    'ListLatestTweetsTimeline',
    'TimelineHome',
    'AccountUserQuery',
    'UserByRestId',
    'CreateTweet', // 新增：发推文（含回复）
    'DeleteTweet', // 新增：删除推文
    'DeleteRetweet' // 新增：取消转发
];
const defaultQueryKeyMap = {
    'UserByScreenName': 'ck5KkZ8t5cOmoLssopN99Q',
    'UserTweets': 'E8Wq-_jFSaU7hxVcuOPR9g',
    'HomeLatestTimeline': 'SFxmNKWfN9ySJcXG_tjX8g',
    'HomeTimeline': 'DXmgQYmIft1oLP6vMkJixw',
    'TweetDetail': 'iFEr5AcP121Og4wx9Yqo3w',
    'SearchTimeline': '4fpceYZ6-YQCx_JSl_Cn_A',
    'CreateBookmark': 'aoDbu3RHznuiSkQ9aNM67Q',
    'DeleteBookmark': 'Wlmlj2-xzyS1GN3a6cj-mQ',
    'Following': 'SaWqzw0TFAWMx1nXWjXoaQ',
    'Followers': 'i6PPdIMm1MO7CpAqjau7sw',
    'FavoriteTweet': 'lI07N6Otwv1PhnEgXILM7A',
    'UnfavoriteTweet': 'ZYKSe-w7KEslx3JhSIk5LA',
    'CreateRetweet': 'mbRO74GrOvSfRcJnlMapnQ',
    'CreateFriendship': '66v9_S_vThhArew_99v9_v9',
    'DestroyFriendship': 'Opv7_p8AunMhJvD8X8c9rw',
    'UserByRestId': 'LJYI_VvTFAZf7PAdT0eWmA',
    'CreateTweet': 'zkcFc6F-RKRgWN8HUkJfZg', // 新增：已确认（2025-05）
    'DeleteTweet': 'nxpZCY2K-I6QoFHAHeojFQ', // 新增：已确认（2025-05）
    'DeleteRetweet': 'ZyZigVsNiFO6v1dEks1eWg' // 新增：已确认（2025-05）
};
/**
 * 识别 X 游客账号（Guest Token）
 *
 * X 的 guest token handle 特征：
 *   - 恰好 15 个字符
 *   - 全部是小写字母 + 数字（无大写字母、无下划线）
 *   - 含有至少一个数字
 *
 * 真实用户 handle 可以包含大写字母或下划线，不会被误判。
 * 例如误判案例：1DU1Gf7oElR2h28 → 含大写 → 不是 guest ✓
 */
function isGuestHandle(h) {
    if (!h)
        return false;
    const clean = h.startsWith('@') ? h.substring(1) : h;
    // Guest handles are random 15-char strings (e.g., 'xyz1234abc5678z' or '123456789012345')
    // Real users like 'web3bridgeninja' (15 chars, lowercase, 1 digit) are common false positives.
    if (clean.length !== 15 || !/^[a-z0-9]+$/.test(clean))
        return false;
    const digits = (clean.match(/\d/g) || []).length;
    const hasVowels = /[aeiou]/.test(clean);
    // Heuristics:
    // 1. All numeric is definitely a guest token
    if (/^\d+$/.test(clean))
        return true;
    // 2. Alphanumeric with high digit count (>= 3) and no vowels is very likely a guest
    if (digits >= 2 && !hasVowels)
        return true;
    // 3. Very high digit count (>= 5) is also a red flag even with vowels
    if (digits >= 5)
        return true;
    return false;
}


/***/ },

/***/ "./src/capture/extractor.ts"
/*!**********************************!*\
  !*** ./src/capture/extractor.ts ***!
  \**********************************/
(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   findDeepUser: () => (/* binding */ findDeepUser),
/* harmony export */   findFeaturedTweet: () => (/* binding */ findFeaturedTweet),
/* harmony export */   findProfileTweetsSnapshot: () => (/* binding */ findProfileTweetsSnapshot),
/* harmony export */   findRepliesSnapshot: () => (/* binding */ findRepliesSnapshot),
/* harmony export */   findScreenNameRecursive: () => (/* binding */ findScreenNameRecursive),
/* harmony export */   findTweetById: () => (/* binding */ findTweetById),
/* harmony export */   findViewerSummary: () => (/* binding */ findViewerSummary),
/* harmony export */   getOpName: () => (/* binding */ getOpName),
/* harmony export */   isTrustableIdentityOp: () => (/* binding */ isTrustableIdentityOp)
/* harmony export */ });
/* harmony import */ var _consts__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./consts */ "./src/capture/consts.ts");
/* harmony import */ var _timeline_extractor__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./timeline-extractor */ "./src/capture/timeline-extractor.ts");
/* harmony import */ var _utils_route_parser__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../utils/route-parser */ "./src/utils/route-parser.ts");



// ─────────────────────────────────────────────────────────────────────────────
// 仅受信任的 identity 操作（不接受普通用户主页 fetch 作为身份来源）
// ─────────────────────────────────────────────────────────────────────────────
const TRUSTED_IDENTITY_OPS = new Set([
    'AuthenticatedUserQuery',
    'Viewer',
    'AccountSettings',
    'settings.json',
    'VerifyCredentials'
]);
function isTrustableIdentityOp(op) {
    return TRUSTED_IDENTITY_OPS.has(op);
}
// ─────────────────────────────────────────────────────────────────────────────
// getOpName: 从 API URL 解析 operationName
// ─────────────────────────────────────────────────────────────────────────────
function getOpName(url) {
    if (!url)
        return null;
    // GraphQL: /i/api/graphql/{queryId}/{OperationName}[?...]
    const gqlMatch = url.match(/\/graphql\/[^\/]+\/([^?&/\s]+)/);
    if (gqlMatch)
        return gqlMatch[1];
    // REST 1.1 特殊映射
    if (url.includes('/account/settings.json'))
        return 'settings.json';
    if (url.includes('/account/verify_credentials.json'))
        return 'VerifyCredentials';
    return null;
}
// ─────────────────────────────────────────────────────────────────────────────
// findScreenNameRecursive: 递归搜索 screen_name（非 guest）
// ─────────────────────────────────────────────────────────────────────────────
function findScreenNameRecursive(obj, depth = 0) {
    if (!obj || typeof obj !== 'object' || depth > 6)
        return null;
    if (typeof obj.screen_name === 'string' && !(0,_consts__WEBPACK_IMPORTED_MODULE_0__.isGuestHandle)(obj.screen_name)) {
        return obj.screen_name;
    }
    for (const key of Object.keys(obj)) {
        const val = obj[key];
        if (val && typeof val === 'object') {
            const found = findScreenNameRecursive(val, depth + 1);
            if (found)
                return found;
        }
    }
    return null;
}
function findViewerSummary(data, targetUid) {
    if (!data)
        return null;
    const extract = (obj) => {
        if (!obj || !obj.legacy)
            return null;
        const handle = obj.legacy.screen_name;
        const userId = obj.rest_id;
        if (!handle)
            return null;
        // Safety: If it matches our confirmed UID (from twid cookie), it's the user, not a guest
        const isActuallyViewer = targetUid && userId === targetUid;
        if ((0,_consts__WEBPACK_IMPORTED_MODULE_0__.isGuestHandle)(handle) && !isActuallyViewer)
            return null;
        if (targetUid && userId !== targetUid)
            return null;
        return {
            handle: `@${handle}`,
            userId: userId,
            displayName: obj.legacy.name,
            verified: obj.legacy.verified || false,
            description: obj.legacy.description,
            avatar: obj.legacy.profile_image_url_https,
            followersCount: obj.legacy.followers_count,
            friendsCount: obj.legacy.friends_count,
            statusesCount: obj.legacy.statuses_count,
            createdAt: obj.legacy.created_at,
            raw: obj // 附加原始对象
        };
    };
    // 1. v1.1 REST 扁平结构（settings.json / verify_credentials.json）
    //    settings.json 仅在登录后可见，里面的 handle 只要存在就是真实的
    if (data.screen_name) {
        const userId = data.id_str || data.id?.toString() || '';
        const isActuallyViewer = targetUid && userId === targetUid;
        if ((0,_consts__WEBPACK_IMPORTED_MODULE_0__.isGuestHandle)(data.screen_name) && !isActuallyViewer)
            return null;
        if (targetUid && userId !== targetUid)
            return null; // 确保 UID 匹配
        return {
            handle: `@${data.screen_name}`,
            userId: userId,
            displayName: data.name || data.screen_name || '', // 确保 displayName 不为空
            verified: data.verified || false,
            description: data.description,
            avatar: data.profile_image_url_https,
            followersCount: data.followers_count,
            friendsCount: data.friends_count,
            statusesCount: data.statuses_count,
            createdAt: data.created_at,
            raw: data // 附加原始数据
        };
    }
    const u = findDeepUser(data);
    if (u) {
        console.log('[TweetClaw-Extractor] findDeepUser found valid user object');
        const summary = extract(u);
        if (summary)
            return summary;
    }
    console.warn('[TweetClaw-Extractor] findViewerSummary failed to find any valid user block in data:', {
        hasData: !!data,
        keys: Object.keys(data || {}),
        targetUid
    });
    return null;
}
// ─────────────────────────────────────────────────────────────────────────────
// findFeaturedTweet: 从响应体中提取一条代表性推文（用于 debug / quick action）
// ─────────────────────────────────────────────────────────────────────────────
function findFeaturedTweet(data, pageUrl) {
    try {
        const tweets = (0,_timeline_extractor__WEBPACK_IMPORTED_MODULE_1__.extractTweetsFromTimeline)(data);
        if (tweets.length === 0)
            return null;
        // 如果提供了 pageUrl，尝试匹配 status ID (用于 tweet_detail 场景选中主推文)
        const targetId = pageUrl ? (0,_utils_route_parser__WEBPACK_IMPORTED_MODULE_2__.extractTweetId)(pageUrl) : null;
        let best = targetId ? tweets.find(t => t.tweetId === targetId) : null;
        // 如果没找到匹配的，或者不是详情页，选第一个
        if (!best) {
            best = tweets[0];
        }
        if (!best)
            return null;
        return {
            id: best.tweetId,
            text: best.text || '',
            authorHandle: best.authorHandle || '',
            authorName: best.authorName || '',
            authorId: best.authorId || '',
            createdAt: best.createdAt || '',
            likeCount: best.likeCount ?? 0,
            replyCount: best.replyCount ?? 0,
            repostCount: best.repostCount ?? 0,
            bookmarkCount: best.bookmarkCount ?? 0
        };
    }
    catch (e) {
        console.warn('[TweetClaw-Extractor] Error in findFeaturedTweet', e);
    }
    return null;
}
/**
 * 寻找响应体中特定 ID 的推文
 * 用于当当前 URL 与已缓存的 featuredTweet 不匹配时，重新从原始响应中找回主推文
 */
function findTweetById(data, tweetId) {
    try {
        const tweets = (0,_timeline_extractor__WEBPACK_IMPORTED_MODULE_1__.extractTweetsFromTimeline)(data);
        const match = tweets.find(t => t.tweetId === tweetId);
        if (!match)
            return null;
        return {
            id: match.tweetId,
            text: match.text || '',
            authorHandle: match.authorHandle || '',
            authorName: match.authorName || '',
            authorId: match.authorId || '',
            createdAt: match.createdAt || '',
            likeCount: match.likeCount ?? 0,
            replyCount: match.replyCount ?? 0,
            repostCount: match.repostCount ?? 0,
            bookmarkCount: match.bookmarkCount ?? 0
        };
    }
    catch (e) {
        console.warn('[TweetClaw-Extractor] Error in findTweetById', e);
    }
    return null;
}
/**
 * 从响应体中提取回复列表（快照）
 */
function findRepliesSnapshot(data, pageUrl, activeAccountHandle) {
    try {
        const tweets = (0,_timeline_extractor__WEBPACK_IMPORTED_MODULE_1__.extractTweetsFromTimeline)(data);
        if (tweets.length === 0)
            return [];
        const targetId = pageUrl ? (0,_utils_route_parser__WEBPACK_IMPORTED_MODULE_2__.extractTweetId)(pageUrl) : null;
        // 过滤逻辑：
        // 1. 排除主推文 (targetId)
        // 2. 这里的 tweets 是拍平的列表，TimelineAddEntries 里的顺序通常就是回复顺序
        // 3. 结果中可能包含主推文本身（如果有的话），我们要排除它
        const replies = tweets.filter(t => t.tweetId !== targetId);
        // 去重
        const seen = new Set();
        const unique = [];
        for (const t of replies) {
            if (!seen.has(t.tweetId)) {
                seen.add(t.tweetId);
                unique.push(t);
            }
        }
        return unique.map(t => ({
            tweetId: t.tweetId,
            authorHandle: t.authorHandle,
            authorName: t.authorName,
            authorId: t.authorId,
            text: t.text,
            createdAt: t.createdAt,
            likeCount: t.likeCount,
            replyCount: t.replyCount,
            repostCount: t.repostCount,
            isByActiveAccount: activeAccountHandle ? t.authorHandle === activeAccountHandle : false
        }));
    }
    catch (e) {
        console.warn('[TweetClaw-Extractor] Error in findRepliesSnapshot', e);
    }
    return [];
}
/**
 * 从响应体中提取 Profile 场景下的推文列表（快照）
 */
function findProfileTweetsSnapshot(data, activeAccountHandle) {
    try {
        const tweets = (0,_timeline_extractor__WEBPACK_IMPORTED_MODULE_1__.extractTweetsFromTimeline)(data);
        if (tweets.length === 0)
            return [];
        // 去重
        const seen = new Set();
        const unique = [];
        for (const t of tweets) {
            if (!seen.has(t.tweetId)) {
                seen.add(t.tweetId);
                unique.push(t);
            }
        }
        return unique.map(t => ({
            tweetId: t.tweetId,
            authorHandle: t.authorHandle,
            authorName: t.authorName,
            text: t.text,
            createdAt: t.createdAt,
            likeCount: t.likeCount,
            replyCount: t.replyCount,
            repostCount: t.repostCount,
            isOwnedByActiveAccount: activeAccountHandle ? t.authorHandle === activeAccountHandle : false
        }));
    }
    catch (e) {
        console.warn('[TweetClaw-Extractor] Error in findProfileTweetsSnapshot', e);
    }
    return [];
}
/**
 * 递归在任意深度的 JSON 对象中找到 Twitter User 结果对象。
 * 兼容 UserByScreenName / UserByRestId 等多种响应结构变体。
 */
function findDeepUser(obj, depth = 0) {
    if (!obj || typeof obj !== 'object' || depth > 8)
        return null;
    // 命中条件：是一个有 rest_id 且 __typename 为 User 的对象
    if (obj.__typename === 'User' && obj.rest_id)
        return obj;
    // 优先尝试语义路径
    const priorityKeys = ['result', 'user', 'user_result', 'data'];
    for (const key of priorityKeys) {
        if (obj[key]) {
            const found = findDeepUser(obj[key], depth + 1);
            if (found)
                return found;
        }
    }
    // 兜底：遍历所有 key
    for (const key of Object.keys(obj)) {
        if (priorityKeys.includes(key))
            continue; // 已处理
        const found = findDeepUser(obj[key], depth + 1);
        if (found)
            return found;
    }
    return null;
}


/***/ },

/***/ "./src/capture/timeline-extractor.ts"
/*!*******************************************!*\
  !*** ./src/capture/timeline-extractor.ts ***!
  \*******************************************/
(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   extractTweetsFromTimeline: () => (/* binding */ extractTweetsFromTimeline)
/* harmony export */ });
/**
 * Timeline Extraction Logic
 * Robust version for Author Handle, Interaction Stats, Media, and Quotes.
 */
/**
 * Recursively searches for the 'instructions' array.
 */
function findInstructionsRecursive(obj) {
    if (!obj || typeof obj !== 'object')
        return null;
    if (Array.isArray(obj.instructions))
        return obj.instructions;
    for (const key in obj) {
        if (typeof obj[key] === 'object' && obj[key] !== null) {
            const found = findInstructionsRecursive(obj[key]);
            if (found)
                return found;
        }
    }
    return null;
}
/**
 * Extracts a list of normalized tweets from any Timeline-like GraphQL response.
 * Works for Home, Search, and TweetDetail (Thread).
 */
function extractTweetsFromTimeline(json) {
    const tweets = [];
    try {
        const instructions = findInstructionsRecursive(json) || [];
        for (const instr of instructions) {
            if (instr.type === 'TimelineAddEntries' || instr.type === 'TimelineReplaceEntry') {
                const entries = instr.entries || (instr.entry ? [instr.entry] : []);
                for (const entry of entries) {
                    // Normal Item
                    const result = entry?.content?.itemContent?.tweet_results?.result
                        || entry?.content?.content?.tweet_results?.result;
                    if (result) {
                        const tweet = parseTweetResult(result);
                        if (tweet) {
                            tweets.push(tweet);
                        }
                    }
                    // Module Items (Common in TweetDetail for replies)
                    const items = entry?.content?.items;
                    if (Array.isArray(items)) {
                        for (const item of items) {
                            const itemResult = item.item?.itemContent?.tweet_results?.result;
                            if (itemResult) {
                                const t = parseTweetResult(itemResult);
                                if (t)
                                    tweets.push(t);
                            }
                        }
                    }
                }
            }
        }
    }
    catch (e) {
        console.warn('[TweetClaw-Extractor] Error in extractTweetsFromTimeline', e);
    }
    return tweets;
}
/**
 * Normalizes a single Tweet result from X's GraphQL response.
 * Supports recursion for Quote Tweets (1 level deep).
 */
function parseTweetResult(result, depth = 0) {
    let data = result;
    // Handle nested results
    if (data.tweet)
        data = data.tweet;
    if (data.result)
        data = data.result;
    if (!data || !data.legacy)
        return null;
    // Handle Retweets: Prefer original tweet for text, metrics, and author if available
    let legacy = data.legacy;
    let core = data.core;
    const retweetedResult = data.retweeted_status_result?.result || legacy.retweeted_status_result?.result;
    if (retweetedResult) {
        const rLegacy = retweetedResult.legacy || retweetedResult.tweet?.legacy;
        const rCore = retweetedResult.core || retweetedResult.tweet?.core;
        if (rLegacy)
            legacy = rLegacy;
        if (rCore)
            core = rCore;
    }
    // 1. Author Info
    let authorHandle = 'unknown';
    let authorName = 'unknown';
    const userResult = core?.user_results?.result;
    const userLegacy = userResult?.legacy || userResult?.user?.legacy || userResult?.user_results?.result?.legacy || data.core?.user_results?.result?.legacy;
    if (userLegacy?.screen_name) {
        authorHandle = `@${userLegacy.screen_name}`;
        authorName = userLegacy.name || authorHandle;
    }
    else {
        const foundHandle = findFirstScreenName(data) || findFirstScreenName(core);
        if (foundHandle)
            authorHandle = `@${foundHandle}`;
        const foundName = findFirstAuthorName(data) || findFirstAuthorName(core);
        if (foundName)
            authorName = foundName;
    }
    // 2. Interaction Metrics
    const tweet = {
        tweetId: legacy.id_str || data.rest_id,
        authorHandle,
        authorName,
        authorId: userResult?.rest_id || 'unknown',
        text: legacy.full_text || '',
        createdAt: legacy.created_at || null,
        replyCount: legacy.reply_count ?? data.reply_count ?? null,
        repostCount: legacy.retweet_count ?? legacy.repost_count ?? data.retweet_count ?? null,
        likeCount: legacy.favorite_count ?? data.favorite_count ?? null,
        bookmarkCount: legacy.bookmark_count ?? data.bookmark_count ?? null,
    };
    // 3. Media Extraction (Photos, Videos, GIFs)
    const mediaItems = legacy.extended_entities?.media || legacy.entities?.media || [];
    if (mediaItems.length > 0) {
        tweet.media = mediaItems.map((m) => {
            const item = {
                type: m.type === 'photo' ? 'photo' : (m.type === 'video' ? 'video' : (m.type === 'animated_gif' ? 'animated_gif' : 'unknown')),
                url: m.media_url_https,
                width: m.original_info?.width,
                height: m.original_info?.height,
            };
            if (m.video_info) {
                item.duration_ms = m.video_info.duration_ms;
                if (m.video_info.variants) {
                    item.variant_urls = m.video_info.variants
                        .filter((v) => v.url)
                        .map((v) => v.url);
                }
            }
            return item;
        });
        tweet.media_count = tweet.media?.length || 0;
    }
    // 4. Quote Tweet Expansion (Limit depth to 1)
    if (depth === 0) {
        const quotedResult = data.quoted_status_result || legacy.quoted_status_result;
        if (quotedResult) {
            const quotedTweet = parseTweetResult(quotedResult, 1);
            if (quotedTweet) {
                tweet.quoted_tweet = quotedTweet;
            }
        }
    }
    return tweet;
}
/**
 * Helper to find the first screen_name in a user-related sub-object.
 */
function findFirstScreenName(obj) {
    if (!obj || typeof obj !== 'object')
        return null;
    if (obj.screen_name)
        return obj.screen_name;
    for (const key in obj) {
        if (obj.hasOwnProperty(key)) {
            const found = findFirstScreenName(obj[key]);
            if (found)
                return found;
        }
    }
    return null;
}
/**
 * Helper to find the first 'name' in a user-related sub-object.
 */
function findFirstAuthorName(obj) {
    if (!obj || typeof obj !== 'object')
        return null;
    if (obj.name)
        return obj.name;
    for (const key in obj) {
        if (obj.hasOwnProperty(key)) {
            const found = findFirstAuthorName(obj[key]);
            if (found)
                return found;
        }
    }
    return null;
}


/***/ },

/***/ "./src/shims/linkedom.ts"
/*!*******************************!*\
  !*** ./src/shims/linkedom.ts ***!
  \*******************************/
(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   parseHTML: () => (/* binding */ parseHTML)
/* harmony export */ });
// 仅提供库里会用到的 parseHTML，返回结构跟 linkedom 类似
function parseHTML(html) {
    const parser = new DOMParser();
    const document = parser.parseFromString(html, "text/html");
    return { window: { document } };
}


/***/ },

/***/ "./src/utils/route-parser.ts"
/*!***********************************!*\
  !*** ./src/utils/route-parser.ts ***!
  \***********************************/
(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   extractTweetId: () => (/* binding */ extractTweetId),
/* harmony export */   parseRouteKind: () => (/* binding */ parseRouteKind)
/* harmony export */ });
function parseRouteKind(url) {
    if (!url || !(url.includes('x.com') || url.includes('twitter.com')))
        return 'none';
    try {
        const u = new URL(url);
        const path = u.pathname;
        if (path === '/home' || path === '/')
            return 'home';
        if (path.includes('/search'))
            return 'search';
        if (path.includes('/status/'))
            return 'thread';
        if (path.includes('/notifications'))
            return 'notification';
        return 'profile';
    }
    catch {
        return 'unknown';
    }
}
function extractTweetId(url) {
    if (!url)
        return null;
    try {
        const u = new URL(url);
        const match = u.pathname.match(/\/status\/(\d+)/);
        return match ? match[1] : null;
    }
    catch {
        return null;
    }
}


/***/ },

/***/ "./src/x_api/feature_manager.ts"
/*!**************************************!*\
  !*** ./src/x_api/feature_manager.ts ***!
  \**************************************/
(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   baseFeatures: () => (/* binding */ baseFeatures),
/* harmony export */   buildFeatures: () => (/* binding */ buildFeatures),
/* harmony export */   cacheOperationFeatures: () => (/* binding */ cacheOperationFeatures),
/* harmony export */   extractMissingFeature: () => (/* binding */ extractMissingFeature),
/* harmony export */   getOperationFeatures: () => (/* binding */ getOperationFeatures)
/* harmony export */ });
/* harmony import */ var _capture_consts__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../capture/consts */ "./src/capture/consts.ts");
/**
 * Feature Manager for X GraphQL requests
 * Handles dynamic feature discovery from 400/403/404 errors.
 *
 * Strategy:
 * 1. Each operation has its own feature cache (per-operation features)
 * 2. When a request fails, we capture features from successful browser requests
 * 3. Features are merged: base + global dynamic + per-operation
 */

const __DBK_per_op_features = 'tc_per_op_features';
const baseFeatures = {
    responsive_web_graphql_timeline_navigation_enabled: true,
    responsive_web_graphql_skip_user_profile_image_extensions_enabled: false,
    creator_subscriptions_tweet_preview_api_enabled: true,
    responsive_web_edit_tweet_api_enabled: true,
    graphql_is_translatable_rweb_tweet_is_translatable_enabled: true,
    view_counts_everywhere_api_enabled: true,
    longform_notetweets_consumption_enabled: true,
    responsive_web_twitter_article_tweet_consumption_enabled: true,
    tweet_with_visibility_results_prefer_gql_limited_actions_policy_enabled: true,
    longform_notetweets_rich_text_read_enabled: true,
    longform_notetweets_inline_media_enabled: true,
    rweb_video_screen_enabled: false,
    standardized_nudges_misinfo: true,
    freedom_of_speech_not_reach_fetch_enabled: true,
    responsive_web_enhance_cards_enabled: false,
    articles_preview_enabled: true,
    communities_web_enable_tweet_community_results_fetch: true,
    c9s_tweet_anatomy_moderator_badge_enabled: true
};
async function extractMissingFeature(body) {
    if (!body)
        return null;
    // X normally returns: "cannot be null: some_feature_flag"
    const m = body.match(/cannot be null:\s*([a-zA-Z0-9_]+)/);
    if (!m)
        return null;
    const feature = m[1];
    const data = await chrome.storage.local.get(_capture_consts__WEBPACK_IMPORTED_MODULE_0__.__DBK_dynamic_features);
    const current = (data[_capture_consts__WEBPACK_IMPORTED_MODULE_0__.__DBK_dynamic_features] || {});
    if (!(feature in current)) {
        current[feature] = true;
        await chrome.storage.local.set({ [_capture_consts__WEBPACK_IMPORTED_MODULE_0__.__DBK_dynamic_features]: current });
        console.log("[TweetClaw-Feature] Auto-harvested new feature flag:", feature);
    }
    return feature;
}
/**
 * Build features for a specific operation
 * Priority: base < global dynamic < per-operation
 */
async function buildFeatures(op) {
    const data = await chrome.storage.local.get([_capture_consts__WEBPACK_IMPORTED_MODULE_0__.__DBK_dynamic_features, __DBK_per_op_features]);
    const globalDynamic = (data[_capture_consts__WEBPACK_IMPORTED_MODULE_0__.__DBK_dynamic_features] || {});
    const perOpFeatures = (data[__DBK_per_op_features] || {});
    const opSpecific = op ? (perOpFeatures[op] || {}) : {};
    return { ...baseFeatures, ...globalDynamic, ...opSpecific };
}
/**
 * Cache features for a specific operation (learned from successful browser requests)
 */
async function cacheOperationFeatures(op, features) {
    const data = await chrome.storage.local.get(__DBK_per_op_features);
    const perOpFeatures = (data[__DBK_per_op_features] || {});
    // Merge with existing features for this operation
    perOpFeatures[op] = { ...(perOpFeatures[op] || {}), ...features };
    await chrome.storage.local.set({ [__DBK_per_op_features]: perOpFeatures });
    console.log(`[TweetClaw-Feature] Cached features for ${op}:`, Object.keys(features).length, 'flags');
}
/**
 * Get cached features for a specific operation
 */
async function getOperationFeatures(op) {
    const data = await chrome.storage.local.get(__DBK_per_op_features);
    const perOpFeatures = (data[__DBK_per_op_features] || {});
    return perOpFeatures[op] || null;
}


/***/ },

/***/ "./src/x_api/twitter_api.ts"
/*!**********************************!*\
  !*** ./src/x_api/twitter_api.ts ***!
  \**********************************/
(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   fetchUserByRestId: () => (/* binding */ fetchUserByRestId),
/* harmony export */   fetchUserByScreenName: () => (/* binding */ fetchUserByScreenName),
/* harmony export */   fetchUserByUsername: () => (/* binding */ fetchUserByUsername),
/* harmony export */   performLegacyREST: () => (/* binding */ performLegacyREST),
/* harmony export */   performMutation: () => (/* binding */ performMutation),
/* harmony export */   performQuery: () => (/* binding */ performQuery)
/* harmony export */ });
/* harmony import */ var _capture_consts__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../capture/consts */ "./src/capture/consts.ts");
/* harmony import */ var _feature_manager__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./feature_manager */ "./src/x_api/feature_manager.ts");
/* harmony import */ var _txid__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./txid */ "./src/x_api/txid.ts");



/**
 * Twitter API Client
 * Designed to run in Content Script (for cookies) and Background (for harvesting).
 */
async function getAuthHeader() {
    const res = await chrome.storage.local.get(_capture_consts__WEBPACK_IMPORTED_MODULE_0__.__DBK_bearer_token);
    return res[_capture_consts__WEBPACK_IMPORTED_MODULE_0__.__DBK_bearer_token] || "";
}
async function getCsrfToken() {
    // Content script: read from document.cookie
    // Background: read from chrome.cookies
    if (typeof document !== 'undefined' && document.cookie) {
        const match = document.cookie.match(/(?:^|;\s*)ct0=([^;]+)/);
        if (match)
            return match[1];
    }
    return new Promise((resolve) => {
        chrome.cookies.get({ url: 'https://x.com', name: 'ct0' }, (cookie) => {
            resolve(cookie ? cookie.value : "");
        });
    });
}
async function getUrlWithQueryId(op) {
    const res = await chrome.storage.local.get(_capture_consts__WEBPACK_IMPORTED_MODULE_0__.__DBK_query_id_map);
    const map = (res[_capture_consts__WEBPACK_IMPORTED_MODULE_0__.__DBK_query_id_map] || {});
    const queryId = map[op];
    if (!queryId)
        return null;
    const url = `https://x.com/i/api/graphql/${queryId}/${op}`;
    const path = `/i/api/graphql/${queryId}/${op}`;
    return { url, path };
}
async function performMutation(op, variables, retryCount = 0) {
    const target = await getUrlWithQueryId(op);
    if (!target)
        throw new Error(`Missing harvested queryId for operation: ${op}`);
    const bearer = await getAuthHeader();
    const csrf = await getCsrfToken();
    // TweetCat txid logic
    const txid = await (0,_txid__WEBPACK_IMPORTED_MODULE_2__.getTransactionIdFor)('POST', target.path);
    const headers = {
        'authorization': bearer,
        'x-csrf-token': csrf,
        'x-client-transaction-id': txid,
        'content-type': 'application/json',
        'x-twitter-active-user': 'yes',
        'x-twitter-auth-type': 'OAuth2Session',
        'x-twitter-client-language': 'zh-cn',
        'referer': 'https://x.com/',
        'accept': '*/*'
    };
    // Some operations (like CreateBookmark, DeleteBookmark) don't need features
    const operationsWithoutFeatures = ['CreateBookmark', 'DeleteBookmark'];
    const needsFeatures = !operationsWithoutFeatures.includes(op);
    const payload = {
        variables,
        queryId: target.url.split('/')[6] // Fix: should be index 6, not 5
    };
    // Only add features if needed
    if (needsFeatures) {
        const features = await (0,_feature_manager__WEBPACK_IMPORTED_MODULE_1__.buildFeatures)(op);
        payload.features = features;
        console.log(`[TwitterAPI] ${op} request with features:`, Object.keys(features));
    }
    else {
        console.log(`[TwitterAPI] ${op} request without features`);
    }
    const response = await fetch(target.url, {
        method: 'POST',
        headers,
        body: JSON.stringify(payload),
        credentials: 'include'
    });
    if (!response.ok) {
        const text = await response.text();
        console.error(`[TwitterAPI] ${op} failed (${response.status}):`, text);
        // Try to extract missing feature from error response
        const missingFeature = await (0,_feature_manager__WEBPACK_IMPORTED_MODULE_1__.extractMissingFeature)(text);
        // If we found a missing feature and haven't retried yet, retry with the new feature
        if (missingFeature && retryCount === 0) {
            console.warn(`[TwitterAPI] ${op} missing feature: ${missingFeature}, retrying...`);
            return performMutation(op, variables, retryCount + 1);
        }
        throw new Error(`X API Error ${response.status} for ${op}: ${text}`);
    }
    return await response.json();
}
/**
 * 专门处理推特老旧的 1.1 REST API（如 friendships/create.json）
 * 这些接口不使用 GraphQL，也不需要 queryId。
 */
async function performLegacyREST(path, params) {
    const bearer = await getAuthHeader();
    const csrf = await getCsrfToken();
    const txid = await (0,_txid__WEBPACK_IMPORTED_MODULE_2__.getTransactionIdFor)('POST', path);
    const headers = {
        'authorization': bearer,
        'x-csrf-token': csrf,
        'x-client-transaction-id': txid,
        'content-type': 'application/x-www-form-urlencoded',
        'x-twitter-active-user': 'yes',
        'x-twitter-auth-type': 'OAuth2Session',
        'referer': 'https://x.com/',
        'accept': '*/*'
    };
    const url = `https://x.com${path}`;
    const body = new URLSearchParams(params).toString();
    const response = await fetch(url, {
        method: 'POST',
        headers,
        body,
        credentials: 'include'
    });
    if (!response.ok) {
        const text = await response.text();
        throw new Error(`X Legacy API Error ${response.status} for ${path}: ${text}`);
    }
    return await response.json();
}
/**
 * 使用稳定的 QueryId 抓取用户资料（绕过哈希变动问题）
 * 仅供在 Content Script 环境（由于 Cookie 权限问题）使用
 */
async function fetchUserByScreenName(screenName) {
    const STABLE_HASH = 'ck5KkZ8t5cOmoLssopN99Q';
    const variables = {
        screen_name: screenName,
        withSafetyModeUserFields: true,
    };
    const features = {
        hidden_profile_likes_enabled: true,
        hidden_profile_subscriptions_enabled: true,
        responsive_web_graphql_exclude_directive_enabled: true,
        verified_phone_label_enabled: false,
        subscriptions_verification_info_is_identity_verified_enabled: true,
        subscriptions_verification_info_verified_since_enabled: true,
        highlights_tweets_tab_ui_enabled: true,
        responsive_web_twitter_article_notes_tab_enabled: false,
        creator_subscriptions_tweet_preview_api_enabled: true,
        responsive_web_graphql_skip_user_profile_image_extensions_enabled: false,
        responsive_web_graphql_timeline_navigation_enabled: true,
    };
    const params = new URLSearchParams();
    params.append('variables', JSON.stringify(variables));
    params.append('features', JSON.stringify(features));
    const url = `https://x.com/i/api/graphql/${STABLE_HASH}/UserByScreenName?${params.toString()}`;
    // 优先使用动态 harvested 的 Bearer Token，fallback 到写死的默认值
    const bearerFromStorage = await getAuthHeader();
    const FALLBACK_BEARER = 'Bearer AAAAAAAAAAAAAAAAAAAAANRILgAAAAAAnNwIzUejRCOuH5E6I8xnZz4puTs%3D1Zv7ttfk8LF81IUq16cHjhLTvJu4FA33AGWWjCpTnA';
    const bearer = bearerFromStorage || FALLBACK_BEARER;
    // CSRF Token（仅限内容脚本上下文，document.cookie 可访问）
    const csrfToken = await getCsrfToken();
    console.log(`[TwitterAPI] fetchUserByScreenName: bearer=${bearer ? 'present' : 'MISSING'}, csrf=${csrfToken ? 'present' : 'MISSING'}`);
    const headers = {
        'authorization': bearer,
        'x-csrf-token': csrfToken,
        'content-type': 'application/json',
        'x-twitter-active-user': 'yes',
        'x-twitter-client-language': 'en',
        'referer': 'https://x.com/',
        'accept': '*/*'
    };
    console.log('[TwitterAPI] fetchUserByScreenName: sending fetch...');
    let response;
    try {
        response = await fetch(url, {
            method: 'GET',
            headers,
            credentials: 'include'
        });
    }
    catch (networkErr) {
        console.error('[TwitterAPI] fetchUserByScreenName: network error', networkErr);
        throw networkErr;
    }
    console.log(`[TwitterAPI] fetchUserByScreenName: response status ${response.status}`);
    if (!response.ok) {
        const errText = await response.text();
        console.error(`[TwitterAPI] fetchUserByScreenName: ${response.status}`, errText.slice(0, 200));
        throw new Error(`UserByScreenName failed: ${response.status}`);
    }
    const json = await response.json();
    console.log('[TwitterAPI] fetchUserByScreenName: got JSON, keys=', Object.keys(json));
    return json;
}
async function performQuery(op, variables, retryCount = 0) {
    const target = await getUrlWithQueryId(op);
    if (!target)
        throw new Error(`Missing harvested queryId for operation: ${op}`);
    const bearer = await getAuthHeader();
    const csrf = await getCsrfToken();
    const features = await (0,_feature_manager__WEBPACK_IMPORTED_MODULE_1__.buildFeatures)(op);
    const params = new URLSearchParams();
    params.append('variables', JSON.stringify(variables));
    params.append('features', JSON.stringify(features));
    const url = `${target.url}?${params.toString()}`;
    const headers = {
        'authorization': bearer,
        'x-csrf-token': csrf,
        'content-type': 'application/json',
        'x-twitter-active-user': 'yes',
        'x-twitter-auth-type': 'OAuth2Session',
        'referer': 'https://x.com/',
        'accept': '*/*'
    };
    const response = await fetch(url, {
        method: 'GET',
        headers,
        credentials: 'include'
    });
    if (!response.ok) {
        const text = await response.text();
        await (0,_feature_manager__WEBPACK_IMPORTED_MODULE_1__.extractMissingFeature)(text);
        // For 404 errors, retry once with fresh features
        if (response.status === 404 && retryCount === 0) {
            console.warn(`[TwitterAPI] ${op} query returned 404, retrying with fresh features...`);
            await new Promise(resolve => setTimeout(resolve, 500));
            return performQuery(op, variables, retryCount + 1);
        }
        throw new Error(`X API Error ${response.status} for ${op}: ${text}`);
    }
    const result = await response.json();
    console.log(`[TwitterAPI] GraphQL ${op} Response:`, result);
    return result;
}
/**
 * 根据用户名获取完整的用户 Profile 信息
 */
async function fetchUserByUsername(username) {
    const cleanUsername = username.startsWith('@') ? username.substring(1) : username;
    const data = await performQuery('UserByScreenName', {
        screen_name: cleanUsername,
        withSafetyModeUserFields: true
    });
    // 从复杂的 GraphQL 响应中提取用户对象
    const userResult = data?.data?.user?.result;
    if (!userResult || userResult.__typename === 'UserUnavailable') {
        return null;
    }
    return userResult;
}
/**
 * 根据 User ID 获取完整的用户 Profile 信息 (UserByRestId)
 */
async function fetchUserByRestId(userId) {
    const data = await performQuery('UserByRestId', {
        userId: userId,
        withSafetyModeUserFields: true
    });
    const userResult = data?.data?.user?.result;
    if (!userResult || userResult.__typename === 'UserUnavailable') {
        return null;
    }
    return userResult;
}


/***/ },

/***/ "./src/x_api/txid.ts"
/*!***************************!*\
  !*** ./src/x_api/txid.ts ***!
  \***************************/
(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   getTransactionIdFor: () => (/* binding */ getTransactionIdFor)
/* harmony export */ });
/* harmony import */ var x_client_transaction_id__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! x-client-transaction-id */ "./node_modules/x-client-transaction-id/esm/mod.js");
/**
 * Twitter Transaction ID (txid) generator.
 * Uses x-client-transaction-id library (same as TweetCat).
 */

let cachedDoc = null;
let lastFetched = 0;
async function getXDoc() {
    const now = Date.now();
    if (!cachedDoc || now - lastFetched > 60000) { // 缓存 60s
        const res = await fetch("https://x.com/", { credentials: "omit" });
        const html = await res.text();
        cachedDoc = new DOMParser().parseFromString(html, "text/html");
        lastFetched = now;
    }
    return cachedDoc;
}
async function getTransactionIdFor(method, path) {
    const doc = await getXDoc();
    const tx = await x_client_transaction_id__WEBPACK_IMPORTED_MODULE_0__.ClientTransaction.create(doc);
    return tx.generateTransactionId(method, path);
}


/***/ },

/***/ "./node_modules/x-client-transaction-id/esm/_dnt.polyfills.js"
/*!********************************************************************!*\
  !*** ./node_modules/x-client-transaction-id/esm/_dnt.polyfills.js ***!
  \********************************************************************/
(__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);



/***/ },

/***/ "./node_modules/x-client-transaction-id/esm/cubic.js"
/*!***********************************************************!*\
  !*** ./node_modules/x-client-transaction-id/esm/cubic.js ***!
  \***********************************************************/
(__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/**
 * Cubic Bezier interpolation implementation
 *
 * This class implements cubic bezier curve interpolation
 * used for animation key generation.
 */
class Cubic {
    /**
     * Creates a new Cubic instance
     * @param curves Array of curve control points
     */
    constructor(curves) {
        Object.defineProperty(this, "curves", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        this.curves = curves;
    }
    /**
     * Calculates the interpolated value at a specific time point
     * @param time Normalized time value (0.0 to 1.0)
     * @returns Interpolated value
     */
    getValue(time) {
        let startGradient = 0;
        let endGradient = 0;
        let start = 0.0;
        let mid = 0.0;
        let end = 1.0;
        // Handle values outside the 0-1 range
        if (time <= 0.0) {
            if (this.curves[0] > 0.0) {
                startGradient = this.curves[1] / this.curves[0];
            }
            else if (this.curves[1] === 0.0 && this.curves[2] > 0.0) {
                startGradient = this.curves[3] / this.curves[2];
            }
            return startGradient * time;
        }
        if (time >= 1.0) {
            if (this.curves[2] < 1.0) {
                endGradient = (this.curves[3] - 1.0) / (this.curves[2] - 1.0);
            }
            else if (this.curves[2] === 1.0 && this.curves[0] < 1.0) {
                endGradient = (this.curves[1] - 1.0) / (this.curves[0] - 1.0);
            }
            return 1.0 + endGradient * (time - 1.0);
        }
        // Binary search to find the closest point on the curve
        while (start < end) {
            mid = (start + end) / 2;
            const xEst = this.calculate(this.curves[0], this.curves[2], mid);
            if (Math.abs(time - xEst) < 0.00001) {
                return this.calculate(this.curves[1], this.curves[3], mid);
            }
            if (xEst < time) {
                start = mid;
            }
            else {
                end = mid;
            }
        }
        return this.calculate(this.curves[1], this.curves[3], mid);
    }
    /**
     * Calculates cubic bezier value with given control points
     * @param a First control point
     * @param b Second control point
     * @param m Parametric value (0.0 to 1.0)
     * @returns Calculated cubic bezier value
     * @private
     */
    calculate(a, b, m) {
        return (3.0 * a * (1 - m) * (1 - m) * m + 3.0 * b * (1 - m) * m * m + m * m * m);
    }
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Cubic);


/***/ },

/***/ "./node_modules/x-client-transaction-id/esm/deps/jsr.io/@std/encoding/1.0.10/_common16.js"
/*!************************************************************************************************!*\
  !*** ./node_modules/x-client-transaction-id/esm/deps/jsr.io/@std/encoding/1.0.10/_common16.js ***!
  \************************************************************************************************/
(__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   alphabet: () => (/* binding */ alphabet),
/* harmony export */   calcSizeHex: () => (/* binding */ calcSizeHex),
/* harmony export */   decode: () => (/* binding */ decode),
/* harmony export */   encode: () => (/* binding */ encode),
/* harmony export */   rAlphabet: () => (/* binding */ rAlphabet)
/* harmony export */ });
// Copyright 2018-2025 the Deno authors. MIT license.
const alphabet = new TextEncoder().encode("0123456789abcdef");
const rAlphabet = new Uint8Array(128).fill(16); // alphabet.Hex.length
alphabet.forEach((byte, i) => rAlphabet[byte] = i);
new TextEncoder()
    .encode("ABCDEF")
    .forEach((byte, i) => rAlphabet[byte] = i + 10);
/**
 * Calculate the output size needed to encode a given input size for
 * {@linkcode encodeIntoHex}.
 *
 * @param originalSize The size of the input buffer.
 * @returns The size of the output buffer.
 *
 * @example Basic Usage
 * ```ts
 * import { assertEquals } from "@std/assert";
 * import { calcSizeHex } from "@std/encoding/unstable-hex";
 *
 * assertEquals(calcSizeHex(1), 2);
 * ```
 */
function calcSizeHex(originalSize) {
    return originalSize * 2;
}
function encode(buffer, i, o, alphabet) {
    for (; i < buffer.length; ++i) {
        const x = buffer[i];
        buffer[o++] = alphabet[x >> 4];
        buffer[o++] = alphabet[x & 0xF];
    }
    return o;
}
function decode(buffer, i, o, alphabet) {
    if ((buffer.length - o) % 2 === 1) {
        throw new RangeError(`Cannot decode input as hex: Length (${buffer.length - o}) must be divisible by 2`);
    }
    i += 1;
    for (; i < buffer.length; i += 2) {
        buffer[o++] = (getByte(buffer[i - 1], alphabet) << 4) |
            getByte(buffer[i], alphabet);
    }
    return o;
}
function getByte(char, alphabet) {
    const byte = alphabet[char] ?? 16;
    if (byte === 16) { // alphabet.Hex.length
        throw new TypeError(`Cannot decode input as hex: Invalid character (${String.fromCharCode(char)})`);
    }
    return byte;
}


/***/ },

/***/ "./node_modules/x-client-transaction-id/esm/deps/jsr.io/@std/encoding/1.0.10/_common32.js"
/*!************************************************************************************************!*\
  !*** ./node_modules/x-client-transaction-id/esm/deps/jsr.io/@std/encoding/1.0.10/_common32.js ***!
  \************************************************************************************************/
(__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   alphabet: () => (/* binding */ alphabet),
/* harmony export */   calcSizeBase32: () => (/* binding */ calcSizeBase32),
/* harmony export */   decode: () => (/* binding */ decode),
/* harmony export */   encode: () => (/* binding */ encode),
/* harmony export */   padding: () => (/* binding */ padding),
/* harmony export */   rAlphabet: () => (/* binding */ rAlphabet)
/* harmony export */ });
// Copyright 2018-2025 the Deno authors. MIT license.
const padding = "=".charCodeAt(0);
const alphabet = {
    base32: new TextEncoder().encode("ABCDEFGHIJKLMNOPQRSTUVWXYZ234567"),
    base32hex: new TextEncoder().encode("0123456789ABCDEFGHIJKLMNOPQRSTUV"),
    base32crockford: new TextEncoder().encode("0123456789ABCDEFGHJKMNPQRSTVWXYZ"),
};
const rAlphabet = {
    base32: new Uint8Array(128).fill(32), // alphabet.base32.length
    base32hex: new Uint8Array(128).fill(32),
    base32crockford: new Uint8Array(128).fill(32),
};
alphabet.base32
    .forEach((byte, i) => rAlphabet.base32[byte] = i);
alphabet.base32hex
    .forEach((byte, i) => rAlphabet.base32hex[byte] = i);
alphabet.base32crockford
    .forEach((byte, i) => rAlphabet.base32crockford[byte] = i);
/**
 * Calculate the output size needed to encode a given input size for
 * {@linkcode encodeIntoBase32}.
 *
 * @param rawSize The size of the input buffer.
 * @returns The size of the output buffer.
 *
 * @example Basic Usage
 * ```ts
 * import { assertEquals } from "@std/assert";
 * import { calcSizeBase32 } from "@std/encoding/unstable-base32";
 *
 * assertEquals(calcSizeBase32(1), 8);
 * ```
 */
function calcSizeBase32(rawSize) {
    return ((rawSize + 4) / 5 | 0) * 8;
}
function encode(buffer, i, o, alphabet, padding) {
    i += 4;
    for (; i < buffer.length; i += 5) {
        let x = (buffer[i - 4] << 16) | (buffer[i - 3] << 8) | buffer[i - 2];
        buffer[o++] = alphabet[x >> 19];
        buffer[o++] = alphabet[x >> 14 & 0x1F];
        buffer[o++] = alphabet[x >> 9 & 0x1F];
        buffer[o++] = alphabet[x >> 4 & 0x1F];
        x = (x << 16) | (buffer[i - 1] << 8) | buffer[i];
        buffer[o++] = alphabet[x >> 15 & 0x1F];
        buffer[o++] = alphabet[x >> 10 & 0x1F];
        buffer[o++] = alphabet[x >> 5 & 0x1F];
        buffer[o++] = alphabet[x & 0x1F];
    }
    switch (i) {
        case buffer.length + 3: {
            const x = buffer[i - 4] << 16;
            buffer[o++] = alphabet[x >> 19];
            buffer[o++] = alphabet[x >> 14 & 0x1F];
            buffer[o++] = padding;
            buffer[o++] = padding;
            buffer[o++] = padding;
            buffer[o++] = padding;
            buffer[o++] = padding;
            buffer[o++] = padding;
            break;
        }
        case buffer.length + 2: {
            const x = (buffer[i - 4] << 16) | (buffer[i - 3] << 8);
            buffer[o++] = alphabet[x >> 19];
            buffer[o++] = alphabet[x >> 14 & 0x1F];
            buffer[o++] = alphabet[x >> 9 & 0x1F];
            buffer[o++] = alphabet[x >> 4 & 0x1F];
            buffer[o++] = padding;
            buffer[o++] = padding;
            buffer[o++] = padding;
            buffer[o++] = padding;
            break;
        }
        case buffer.length + 1: {
            let x = (buffer[i - 4] << 16) | (buffer[i - 3] << 8) | buffer[i - 2];
            buffer[o++] = alphabet[x >> 19];
            buffer[o++] = alphabet[x >> 14 & 0x1F];
            buffer[o++] = alphabet[x >> 9 & 0x1F];
            buffer[o++] = alphabet[x >> 4 & 0x1F];
            x <<= 16;
            buffer[o++] = alphabet[x >> 15 & 0x1F];
            buffer[o++] = padding;
            buffer[o++] = padding;
            buffer[o++] = padding;
            break;
        }
        case buffer.length: {
            let x = (buffer[i - 4] << 16) | (buffer[i - 3] << 8) | buffer[i - 2];
            buffer[o++] = alphabet[x >> 19];
            buffer[o++] = alphabet[x >> 14 & 0x1F];
            buffer[o++] = alphabet[x >> 9 & 0x1F];
            buffer[o++] = alphabet[x >> 4 & 0x1F];
            x = (x << 16) | (buffer[i - 1] << 8);
            buffer[o++] = alphabet[x >> 15 & 0x1F];
            buffer[o++] = alphabet[x >> 10 & 0x1F];
            buffer[o++] = alphabet[x >> 5 & 0x1F];
            buffer[o++] = padding;
            break;
        }
    }
    return o;
}
function decode(buffer, i, o, alphabet, padding) {
    for (let x = buffer.length - 6; x < buffer.length; ++x) {
        if (buffer[x] === padding) {
            for (let y = x + 1; y < buffer.length; ++y) {
                if (buffer[y] !== padding) {
                    throw new TypeError(`Cannot decode input as base32: Invalid character (${String.fromCharCode(buffer[y])})`);
                }
            }
            buffer = buffer.subarray(0, x);
            break;
        }
    }
    switch ((buffer.length - o) % 8) {
        case 6:
        case 3:
        case 1:
            throw new RangeError(`Cannot decode input as base32: Length (${buffer.length - o}), excluding padding, must not have a remainder of 1, 3, or 6 when divided by 8`);
    }
    i += 7;
    for (; i < buffer.length; i += 8) {
        let x = (getByte(buffer[i - 7], alphabet) << 19) |
            (getByte(buffer[i - 6], alphabet) << 14) |
            (getByte(buffer[i - 5], alphabet) << 9) |
            (getByte(buffer[i - 4], alphabet) << 4);
        buffer[o++] = x >> 16;
        buffer[o++] = x >> 8 & 0xFF;
        x = (x << 16) |
            (getByte(buffer[i - 3], alphabet) << 15) |
            (getByte(buffer[i - 2], alphabet) << 10) |
            (getByte(buffer[i - 1], alphabet) << 5) |
            getByte(buffer[i], alphabet);
        buffer[o++] = x >> 16 & 0xFF;
        buffer[o++] = x >> 8 & 0xFF;
        buffer[o++] = x & 0xFF;
    }
    switch (i) {
        case buffer.length + 5: {
            const x = (getByte(buffer[i - 7], alphabet) << 19) |
                (getByte(buffer[i - 6], alphabet) << 14);
            buffer[o++] = x >> 16;
            break;
        }
        case buffer.length + 3: {
            const x = (getByte(buffer[i - 7], alphabet) << 19) |
                (getByte(buffer[i - 6], alphabet) << 14) |
                (getByte(buffer[i - 5], alphabet) << 9) |
                (getByte(buffer[i - 4], alphabet) << 4);
            buffer[o++] = x >> 16;
            buffer[o++] = x >> 8 & 0xFF;
            break;
        }
        case buffer.length + 2: {
            let x = (getByte(buffer[i - 7], alphabet) << 19) |
                (getByte(buffer[i - 6], alphabet) << 14) |
                (getByte(buffer[i - 5], alphabet) << 9) |
                (getByte(buffer[i - 4], alphabet) << 4);
            buffer[o++] = x >> 16;
            buffer[o++] = x >> 8 & 0xFF;
            x = (x << 16) |
                (getByte(buffer[i - 3], alphabet) << 15);
            buffer[o++] = x >> 16 & 0xFF;
            break;
        }
        case buffer.length: {
            let x = (getByte(buffer[i - 7], alphabet) << 19) |
                (getByte(buffer[i - 6], alphabet) << 14) |
                (getByte(buffer[i - 5], alphabet) << 9) |
                (getByte(buffer[i - 4], alphabet) << 4);
            buffer[o++] = x >> 16;
            buffer[o++] = x >> 8 & 0xFF;
            x = (x << 16) |
                (getByte(buffer[i - 3], alphabet) << 15) |
                (getByte(buffer[i - 2], alphabet) << 10) |
                (getByte(buffer[i - 1], alphabet) << 5);
            buffer[o++] = x >> 16 & 0xFF;
            buffer[o++] = x >> 8 & 0xFF;
            break;
        }
    }
    return o;
}
function getByte(char, alphabet) {
    const byte = alphabet[char] ?? 32;
    if (byte === 32) { // alphabet.Base32.length
        throw new TypeError(`Cannot decode input as base32: Invalid character (${String.fromCharCode(char)})`);
    }
    return byte;
}


/***/ },

/***/ "./node_modules/x-client-transaction-id/esm/deps/jsr.io/@std/encoding/1.0.10/_common64.js"
/*!************************************************************************************************!*\
  !*** ./node_modules/x-client-transaction-id/esm/deps/jsr.io/@std/encoding/1.0.10/_common64.js ***!
  \************************************************************************************************/
(__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   alphabet: () => (/* binding */ alphabet),
/* harmony export */   calcSizeBase64: () => (/* binding */ calcSizeBase64),
/* harmony export */   decode: () => (/* binding */ decode),
/* harmony export */   encode: () => (/* binding */ encode),
/* harmony export */   padding: () => (/* binding */ padding),
/* harmony export */   rAlphabet: () => (/* binding */ rAlphabet)
/* harmony export */ });
// Copyright 2018-2025 the Deno authors. MIT license.
const padding = "=".charCodeAt(0);
const alphabet = {
    base64: new TextEncoder()
        .encode("ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/"),
    base64url: new TextEncoder()
        .encode("ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789-_"),
};
const rAlphabet = {
    base64: new Uint8Array(128).fill(64), // alphabet.base64.length
    base64url: new Uint8Array(128).fill(64),
};
alphabet.base64
    .forEach((byte, i) => rAlphabet.base64[byte] = i);
alphabet.base64url
    .forEach((byte, i) => rAlphabet.base64url[byte] = i);
/**
 * Calculate the output size needed to encode a given input size for
 * {@linkcode encodeIntoBase64}.
 *
 * @param originalSize The size of the input buffer.
 * @returns The size of the output buffer.
 *
 * @example Basic Usage
 * ```ts
 * import { assertEquals } from "@std/assert";
 * import { calcSizeBase64 } from "@std/encoding/unstable-base64";
 *
 * assertEquals(calcSizeBase64(1), 4);
 * ```
 */
function calcSizeBase64(originalSize) {
    return ((originalSize + 2) / 3 | 0) * 4;
}
function encode(buffer, i, o, alphabet, padding) {
    i += 2;
    for (; i < buffer.length; i += 3) {
        const x = (buffer[i - 2] << 16) | (buffer[i - 1] << 8) | buffer[i];
        buffer[o++] = alphabet[x >> 18];
        buffer[o++] = alphabet[x >> 12 & 0x3F];
        buffer[o++] = alphabet[x >> 6 & 0x3F];
        buffer[o++] = alphabet[x & 0x3F];
    }
    switch (i) {
        case buffer.length + 1: {
            const x = buffer[i - 2] << 16;
            buffer[o++] = alphabet[x >> 18];
            buffer[o++] = alphabet[x >> 12 & 0x3F];
            buffer[o++] = padding;
            buffer[o++] = padding;
            break;
        }
        case buffer.length: {
            const x = (buffer[i - 2] << 16) | (buffer[i - 1] << 8);
            buffer[o++] = alphabet[x >> 18];
            buffer[o++] = alphabet[x >> 12 & 0x3F];
            buffer[o++] = alphabet[x >> 6 & 0x3F];
            buffer[o++] = padding;
            break;
        }
    }
    return o;
}
function decode(buffer, i, o, alphabet, padding) {
    for (let x = buffer.length - 2; x < buffer.length; ++x) {
        if (buffer[x] === padding) {
            for (let y = x + 1; y < buffer.length; ++y) {
                if (buffer[y] !== padding) {
                    throw new TypeError(`Cannot decode input as base64: Invalid character (${String.fromCharCode(buffer[y])})`);
                }
            }
            buffer = buffer.subarray(0, x);
            break;
        }
    }
    if ((buffer.length - o) % 4 === 1) {
        throw new RangeError(`Cannot decode input as base64: Length (${buffer.length - o}), excluding padding, must not have a remainder of 1 when divided by 4`);
    }
    i += 3;
    for (; i < buffer.length; i += 4) {
        const x = (getByte(buffer[i - 3], alphabet) << 18) |
            (getByte(buffer[i - 2], alphabet) << 12) |
            (getByte(buffer[i - 1], alphabet) << 6) |
            getByte(buffer[i], alphabet);
        buffer[o++] = x >> 16;
        buffer[o++] = x >> 8 & 0xFF;
        buffer[o++] = x & 0xFF;
    }
    switch (i) {
        case buffer.length + 1: {
            const x = (getByte(buffer[i - 3], alphabet) << 18) |
                (getByte(buffer[i - 2], alphabet) << 12);
            buffer[o++] = x >> 16;
            break;
        }
        case buffer.length: {
            const x = (getByte(buffer[i - 3], alphabet) << 18) |
                (getByte(buffer[i - 2], alphabet) << 12) |
                (getByte(buffer[i - 1], alphabet) << 6);
            buffer[o++] = x >> 16;
            buffer[o++] = x >> 8 & 0xFF;
            break;
        }
    }
    return o;
}
function getByte(char, alphabet) {
    const byte = alphabet[char] ?? 64;
    if (byte === 64) { // alphabet.Base64.length
        throw new TypeError(`Cannot decode input as base64: Invalid character (${String.fromCharCode(char)})`);
    }
    return byte;
}


/***/ },

/***/ "./node_modules/x-client-transaction-id/esm/deps/jsr.io/@std/encoding/1.0.10/_common_detach.js"
/*!*****************************************************************************************************!*\
  !*** ./node_modules/x-client-transaction-id/esm/deps/jsr.io/@std/encoding/1.0.10/_common_detach.js ***!
  \*****************************************************************************************************/
(__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   detach: () => (/* binding */ detach)
/* harmony export */ });
// Copyright 2018-2025 the Deno authors. MIT license.
function detach(buffer, maxSize) {
    const originalSize = buffer.length;
    if (buffer.byteOffset) {
        const b = new Uint8Array(buffer.buffer);
        b.set(buffer);
        buffer = b.subarray(0, originalSize);
    }
    // deno-lint-ignore no-explicit-any
    buffer = new Uint8Array(buffer.buffer.transfer(maxSize));
    buffer.set(buffer.subarray(0, originalSize), maxSize - originalSize);
    return [buffer, maxSize - originalSize];
}


/***/ },

/***/ "./node_modules/x-client-transaction-id/esm/deps/jsr.io/@std/encoding/1.0.10/_validate_binary_like.js"
/*!************************************************************************************************************!*\
  !*** ./node_modules/x-client-transaction-id/esm/deps/jsr.io/@std/encoding/1.0.10/_validate_binary_like.js ***!
  \************************************************************************************************************/
(__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   validateBinaryLike: () => (/* binding */ validateBinaryLike)
/* harmony export */ });
// Copyright 2018-2025 the Deno authors. MIT license.
const encoder = new TextEncoder();
function getTypeName(value) {
    const type = typeof value;
    if (type !== "object") {
        return type;
    }
    else if (value === null) {
        return "null";
    }
    else {
        return value?.constructor?.name ?? "object";
    }
}
function validateBinaryLike(source) {
    if (typeof source === "string") {
        return encoder.encode(source);
    }
    else if (source instanceof Uint8Array) {
        return source;
    }
    else if (source instanceof ArrayBuffer) {
        return new Uint8Array(source);
    }
    throw new TypeError(`Cannot validate the input as it must be a Uint8Array, a string, or an ArrayBuffer: received a value of the type ${getTypeName(source)}`);
}


/***/ },

/***/ "./node_modules/x-client-transaction-id/esm/deps/jsr.io/@std/encoding/1.0.10/ascii85.js"
/*!**********************************************************************************************!*\
  !*** ./node_modules/x-client-transaction-id/esm/deps/jsr.io/@std/encoding/1.0.10/ascii85.js ***!
  \**********************************************************************************************/
(__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   decodeAscii85: () => (/* binding */ decodeAscii85),
/* harmony export */   encodeAscii85: () => (/* binding */ encodeAscii85)
/* harmony export */ });
/* harmony import */ var _validate_binary_like_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./_validate_binary_like.js */ "./node_modules/x-client-transaction-id/esm/deps/jsr.io/@std/encoding/1.0.10/_validate_binary_like.js");
// Copyright 2018-2025 the Deno authors. MIT license.
// This module is browser compatible.
/**
 * Utilities for working with {@link https://en.wikipedia.org/wiki/Ascii85 | ascii85} encoding.
 *
 * ## Specifying a standard and delimiter
 *
 * By default, all functions are using the most popular Adobe version of ascii85
 * and not adding any delimiter. However, there are three more standards
 * supported - btoa (different delimiter and additional compression of 4 bytes
 * equal to 32), {@link https://rfc.zeromq.org/spec/32/ | Z85} and
 * {@link https://www.rfc-editor.org/rfc/rfc1924.html | RFC 1924}. It's possible to use a
 * different encoding by specifying it in `options` object as a second parameter.
 *
 * Similarly, it's possible to make `encode` add a delimiter (`<~` and `~>` for
 * Adobe, `xbtoa Begin` and `xbtoa End` with newlines between the delimiters and
 * encoded data for btoa. Checksums for btoa are not supported. Delimiters are not
 * supported by other encodings.)
 *
 * @module
 */

const rfc1924 = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz!#$%&()*+-;<=>?@^_`{|}~";
const Z85 = "0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ.-:+=^!/*?&<>()[]{}@%$#";
/**
 * Converts data into an ascii85-encoded string.
 *
 * @param data The data to encode.
 * @param options Options for encoding.
 *
 * @returns The ascii85-encoded string.
 *
 * @example Usage
 * ```ts
 * import { encodeAscii85 } from "@std/encoding/ascii85";
 * import { assertEquals } from "@std/assert";
 *
 * assertEquals(encodeAscii85("Hello world!"), "87cURD]j7BEbo80");
 * ```
 */
function encodeAscii85(data, options = {}) {
    let uint8 = (0,_validate_binary_like_js__WEBPACK_IMPORTED_MODULE_0__.validateBinaryLike)(data);
    const { standard = "Adobe" } = options;
    let output = [];
    let v;
    let n = 0;
    let difference = 0;
    if (uint8.length % 4 !== 0) {
        const tmp = uint8;
        difference = 4 - (tmp.length % 4);
        uint8 = new Uint8Array(tmp.length + difference);
        uint8.set(tmp);
    }
    const view = new DataView(uint8.buffer, uint8.byteOffset, uint8.byteLength);
    for (let i = 0; i < uint8.length; i += 4) {
        v = view.getUint32(i);
        // Adobe and btoa standards compress 4 zeroes to single "z" character
        if ((standard === "Adobe" || standard === "btoa") &&
            v === 0 &&
            i < uint8.length - difference - 3) {
            output[n++] = "z";
            continue;
        }
        // btoa compresses 4 spaces - that is, bytes equal to 32 - into single "y" character
        if (standard === "btoa" && v === 538976288) {
            output[n++] = "y";
            continue;
        }
        for (let j = 4; j >= 0; j--) {
            output[n + j] = String.fromCharCode((v % 85) + 33);
            v = Math.trunc(v / 85);
        }
        n += 5;
    }
    switch (standard) {
        case "Adobe":
            if (options?.delimiter) {
                return `<~${output.slice(0, output.length - difference).join("")}~>`;
            }
            break;
        case "btoa":
            if (options?.delimiter) {
                return `xbtoa Begin\n${output
                    .slice(0, output.length - difference)
                    .join("")}\nxbtoa End`;
            }
            break;
        case "RFC 1924":
            output = output.map((val) => rfc1924[val.charCodeAt(0) - 33]);
            break;
        case "Z85":
            output = output.map((val) => Z85[val.charCodeAt(0) - 33]);
            break;
    }
    return output.slice(0, output.length - difference).join("");
}
/**
 * Decodes a ascii85-encoded string.
 *
 * @param ascii85 The ascii85-encoded string to decode.
 * @param options Options for decoding.
 * @returns The decoded data.
 *
 * @example Usage
 * ```ts
 * import { decodeAscii85 } from "@std/encoding/ascii85";
 * import { assertEquals } from "@std/assert";
 *
 * assertEquals(
 *   decodeAscii85("87cURD]j7BEbo80"),
 *   new TextEncoder().encode("Hello world!"),
 * );
 * ```
 */
function decodeAscii85(ascii85, options = {}) {
    const { standard = "Adobe" } = options;
    // translate all encodings to most basic adobe/btoa one and decompress some special characters ("z" and "y")
    switch (standard) {
        case "Adobe":
            ascii85 = ascii85.replaceAll(/(<~|~>)/g, "").replaceAll("z", "!!!!!");
            break;
        case "btoa":
            ascii85 = ascii85
                .replaceAll(/(xbtoa Begin|xbtoa End|\n)/g, "")
                .replaceAll("z", "!!!!!")
                .replaceAll("y", "+<VdL");
            break;
        case "RFC 1924":
            ascii85 = ascii85.replaceAll(/./g, (match) => String.fromCharCode(rfc1924.indexOf(match) + 33));
            break;
        case "Z85":
            ascii85 = ascii85.replaceAll(/./g, (match) => String.fromCharCode(Z85.indexOf(match) + 33));
            break;
    }
    // remove all invalid characters
    ascii85 = ascii85.replaceAll(/[^!-u]/g, "");
    const len = ascii85.length;
    const output = new Uint8Array(len + 4 - (len % 4));
    const view = new DataView(output.buffer);
    let v = 0;
    let n = 0;
    let max = 0;
    for (let i = 0; i < len;) {
        for (max += 5; i < max; i++) {
            v = v * 85 + (i < len ? ascii85.charCodeAt(i) : 117) - 33;
        }
        view.setUint32(n, v);
        v = 0;
        n += 4;
    }
    return output.slice(0, Math.trunc(len * 0.8));
}


/***/ },

/***/ "./node_modules/x-client-transaction-id/esm/deps/jsr.io/@std/encoding/1.0.10/base32.js"
/*!*********************************************************************************************!*\
  !*** ./node_modules/x-client-transaction-id/esm/deps/jsr.io/@std/encoding/1.0.10/base32.js ***!
  \*********************************************************************************************/
(__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   decodeBase32: () => (/* binding */ decodeBase32),
/* harmony export */   encodeBase32: () => (/* binding */ encodeBase32)
/* harmony export */ });
/* harmony import */ var _common32_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./_common32.js */ "./node_modules/x-client-transaction-id/esm/deps/jsr.io/@std/encoding/1.0.10/_common32.js");
/* harmony import */ var _common_detach_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./_common_detach.js */ "./node_modules/x-client-transaction-id/esm/deps/jsr.io/@std/encoding/1.0.10/_common_detach.js");
// Copyright 2018-2025 the Deno authors. MIT license.
// Copyright (c) 2014 Jameson Little. MIT License.
// This module is browser compatible.
/**
 * Utilities for
 * {@link https://www.rfc-editor.org/rfc/rfc4648.html#section-6 | base32}
 * encoding and decoding.
 *
 * Modified from {@link https://github.com/beatgammit/base64-js}.
 *
 * ```ts
 * import { encodeBase32, decodeBase32 } from "@std/encoding/base32";
 * import { assertEquals } from "@std/assert";
 *
 * assertEquals(encodeBase32("foobar"), "MZXW6YTBOI======");
 *
 * assertEquals(
 *   decodeBase32("MZXW6YTBOI======"),
 *   new TextEncoder().encode("foobar")
 * );
 * ```
 *
 * @module
 */


const padding = "=".charCodeAt(0);
const alphabet = new TextEncoder()
    .encode("ABCDEFGHIJKLMNOPQRSTUVWXYZ234567");
const rAlphabet = new Uint8Array(128).fill(32); //alphabet.length
alphabet.forEach((byte, i) => rAlphabet[byte] = i);
/**
 * Converts data into a base32-encoded string.
 *
 * @see {@link https://www.rfc-editor.org/rfc/rfc4648.html#section-6}
 *
 * @param data The data to encode.
 * @returns The base32-encoded string.
 *
 * @example Usage
 * ```ts
 * import { encodeBase32 } from "@std/encoding/base32";
 * import { assertEquals } from "@std/assert";
 *
 * assertEquals(encodeBase32("6c60c0"), "GZRTMMDDGA======");
 * ```
 */
function encodeBase32(data) {
    if (typeof data === "string") {
        data = new TextEncoder().encode(data);
    }
    else if (data instanceof ArrayBuffer)
        data = new Uint8Array(data).slice();
    else
        data = data.slice();
    const [output, i] = (0,_common_detach_js__WEBPACK_IMPORTED_MODULE_1__.detach)(data, (0,_common32_js__WEBPACK_IMPORTED_MODULE_0__.calcSizeBase32)(data.length));
    (0,_common32_js__WEBPACK_IMPORTED_MODULE_0__.encode)(output, i, 0, alphabet, padding);
    return new TextDecoder().decode(output);
}
/**
 * Decodes a base32-encoded string.
 *
 * @see {@link https://www.rfc-editor.org/rfc/rfc4648.html#section-6}
 *
 * @param b32 The base32-encoded string to decode.
 * @returns The decoded data.
 *
 * @example Usage
 * ```ts
 * import { decodeBase32 } from "@std/encoding/base32";
 * import { assertEquals } from "@std/assert";
 *
 * assertEquals(
 *   decodeBase32("GZRTMMDDGA======"),
 *   new TextEncoder().encode("6c60c0"),
 * );
 * ```
 */
function decodeBase32(b32) {
    const output = new TextEncoder().encode(b32);
    if (output.length % 8) {
        throw new TypeError(`Invalid base32 string: length (${output.length}) must be a multiple of 8`);
    }
    // deno-lint-ignore no-explicit-any
    return new Uint8Array(output.buffer
        .transfer((0,_common32_js__WEBPACK_IMPORTED_MODULE_0__.decode)(output, 0, 0, rAlphabet, padding)));
}


/***/ },

/***/ "./node_modules/x-client-transaction-id/esm/deps/jsr.io/@std/encoding/1.0.10/base58.js"
/*!*********************************************************************************************!*\
  !*** ./node_modules/x-client-transaction-id/esm/deps/jsr.io/@std/encoding/1.0.10/base58.js ***!
  \*********************************************************************************************/
(__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   decodeBase58: () => (/* binding */ decodeBase58),
/* harmony export */   encodeBase58: () => (/* binding */ encodeBase58)
/* harmony export */ });
/* harmony import */ var _validate_binary_like_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./_validate_binary_like.js */ "./node_modules/x-client-transaction-id/esm/deps/jsr.io/@std/encoding/1.0.10/_validate_binary_like.js");
// Copyright 2018-2025 the Deno authors. MIT license.
// This module is browser compatible.
/**
 * Utilities for
 * {@link https://datatracker.ietf.org/doc/html/draft-msporny-base58-03 | base58}
 * encoding and decoding.
 *
 * ```ts
 * import { encodeBase58, decodeBase58 } from "@std/encoding/base58";
 * import { assertEquals } from "@std/assert";
 *
 * const hello = new TextEncoder().encode("Hello World!");
 *
 * assertEquals(encodeBase58(hello), "2NEpo7TZRRrLZSi2U");
 *
 * assertEquals(decodeBase58("2NEpo7TZRRrLZSi2U"), hello);
 * ```
 *
 * @module
 */

// deno-fmt-ignore
const mapBase58 = {
    "1": 0, "2": 1, "3": 2, "4": 3, "5": 4, "6": 5, "7": 6, "8": 7, "9": 8, A: 9,
    B: 10, C: 11, D: 12, E: 13, F: 14, G: 15, H: 16, J: 17, K: 18, L: 19, M: 20,
    N: 21, P: 22, Q: 23, R: 24, S: 25, T: 26, U: 27, V: 28, W: 29, X: 30, Y: 31,
    Z: 32, a: 33, b: 34, c: 35, d: 36, e: 37, f: 38, g: 39, h: 40, i: 41, j: 42,
    k: 43, m: 44, n: 45, o: 46, p: 47, q: 48, r: 49, s: 50, t: 51, u: 52, v: 53,
    w: 54, x: 55, y: 56, z: 57
};
const base58alphabet = "123456789ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz".split("");
/**
 * Converts data into a base58-encoded string.
 *
 * @see {@link https://datatracker.ietf.org/doc/html/draft-msporny-base58-03#section-3}
 *
 * @param data The data to encode.
 * @returns The base58-encoded string.
 *
 * @example Usage
 * ```ts
 * import { encodeBase58 } from "@std/encoding/base58";
 * import { assertEquals } from "@std/assert";
 *
 * assertEquals(encodeBase58("Hello World!"), "2NEpo7TZRRrLZSi2U");
 * ```
 */
function encodeBase58(data) {
    const uint8tData = (0,_validate_binary_like_js__WEBPACK_IMPORTED_MODULE_0__.validateBinaryLike)(data);
    let length = 0;
    let zeroes = 0;
    // Counting leading zeroes
    let index = 0;
    while (uint8tData[index] === 0) {
        zeroes++;
        index++;
    }
    const notZeroUint8Data = uint8tData.slice(index);
    const size = Math.round((uint8tData.length * 138) / 100 + 1);
    const b58Encoding = [];
    notZeroUint8Data.forEach((byte) => {
        let i = 0;
        let carry = byte;
        for (let reverseIterator = size - 1; (carry > 0 || i < length) && reverseIterator !== -1; reverseIterator--, i++) {
            carry += (b58Encoding[reverseIterator] ?? 0) * 256;
            b58Encoding[reverseIterator] = Math.round(carry % 58);
            carry = Math.floor(carry / 58);
        }
        length = i;
    });
    const strResult = Array.from({
        length: b58Encoding.length + zeroes,
    });
    if (zeroes > 0) {
        strResult.fill("1", 0, zeroes);
    }
    b58Encoding.forEach((byteValue) => strResult.push(base58alphabet[byteValue]));
    return strResult.join("");
}
/**
 * Decodes a base58-encoded string.
 *
 * @see {@link https://datatracker.ietf.org/doc/html/draft-msporny-base58-03#section-4}
 *
 * @param b58 The base58-encoded string to decode.
 * @returns The decoded data.
 *
 * @example Usage
 * ```ts
 * import { decodeBase58 } from "@std/encoding/base58";
 * import { assertEquals } from "@std/assert";
 *
 * assertEquals(
 *   decodeBase58("2NEpo7TZRRrLZSi2U"),
 *   new TextEncoder().encode("Hello World!")
 * );
 * ```
 */
function decodeBase58(b58) {
    const splitInput = b58.trim().split("");
    let length = 0;
    let ones = 0;
    // Counting leading ones
    let index = 0;
    while (splitInput[index] === "1") {
        ones++;
        index++;
    }
    const notZeroData = splitInput.slice(index);
    const size = Math.round((b58.length * 733) / 1000 + 1);
    const output = [];
    notZeroData.forEach((char, idx) => {
        let carry = mapBase58[char];
        let i = 0;
        if (carry === undefined) {
            throw new TypeError(`Invalid base58 char at index ${idx} with value ${char}`);
        }
        for (let reverseIterator = size - 1; (carry > 0 || i < length) && reverseIterator !== -1; reverseIterator--, i++) {
            carry += 58 * (output[reverseIterator] ?? 0);
            output[reverseIterator] = Math.round(carry % 256);
            carry = Math.floor(carry / 256);
        }
        length = i;
    });
    const validOutput = output.filter((item) => item !== undefined);
    if (ones > 0) {
        const onesResult = Array.from({ length: ones }).fill(0, 0, ones);
        return new Uint8Array([...onesResult, ...validOutput]);
    }
    return new Uint8Array(validOutput);
}


/***/ },

/***/ "./node_modules/x-client-transaction-id/esm/deps/jsr.io/@std/encoding/1.0.10/base64.js"
/*!*********************************************************************************************!*\
  !*** ./node_modules/x-client-transaction-id/esm/deps/jsr.io/@std/encoding/1.0.10/base64.js ***!
  \*********************************************************************************************/
(__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   decodeBase64: () => (/* binding */ decodeBase64),
/* harmony export */   encodeBase64: () => (/* binding */ encodeBase64)
/* harmony export */ });
/* harmony import */ var _common64_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./_common64.js */ "./node_modules/x-client-transaction-id/esm/deps/jsr.io/@std/encoding/1.0.10/_common64.js");
/* harmony import */ var _common_detach_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./_common_detach.js */ "./node_modules/x-client-transaction-id/esm/deps/jsr.io/@std/encoding/1.0.10/_common_detach.js");
// Copyright 2018-2025 the Deno authors. MIT license.
// This module is browser compatible.
/**
 * Utilities for
 * {@link https://www.rfc-editor.org/rfc/rfc4648.html#section-4 | base64}
 * encoding and decoding.
 *
 * ```ts
 * import {
 *   encodeBase64,
 *   decodeBase64,
 * } from "@std/encoding/base64";
 * import { assertEquals } from "@std/assert";
 *
 * const foobar = new TextEncoder().encode("foobar");
 *
 * assertEquals(encodeBase64(foobar), "Zm9vYmFy");
 * assertEquals(decodeBase64("Zm9vYmFy"), foobar);
 * ```
 *
 * @module
 */


const padding = "=".charCodeAt(0);
const alphabet = new TextEncoder()
    .encode("ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/");
const rAlphabet = new Uint8Array(128).fill(64); // alphabet.length
alphabet.forEach((byte, i) => rAlphabet[byte] = i);
/**
 * Converts data into a base64-encoded string.
 *
 * @see {@link https://www.rfc-editor.org/rfc/rfc4648.html#section-4}
 *
 * @param data The data to encode.
 * @returns The base64-encoded string.
 *
 * @example Usage
 * ```ts
 * import { encodeBase64 } from "@std/encoding/base64";
 * import { assertEquals } from "@std/assert";
 *
 * assertEquals(encodeBase64("foobar"), "Zm9vYmFy");
 * ```
 */
function encodeBase64(data) {
    if (typeof data === "string") {
        data = new TextEncoder().encode(data);
    }
    else if (data instanceof ArrayBuffer)
        data = new Uint8Array(data).slice();
    else
        data = data.slice();
    const [output, i] = (0,_common_detach_js__WEBPACK_IMPORTED_MODULE_1__.detach)(data, (0,_common64_js__WEBPACK_IMPORTED_MODULE_0__.calcSizeBase64)(data.length));
    (0,_common64_js__WEBPACK_IMPORTED_MODULE_0__.encode)(output, i, 0, alphabet, padding);
    return new TextDecoder().decode(output);
}
/**
 * Decodes a base64-encoded string.
 *
 * @see {@link https://www.rfc-editor.org/rfc/rfc4648.html#section-4}
 *
 * @param b64 The base64-encoded string to decode.
 * @returns The decoded data.
 *
 * @example Usage
 * ```ts
 * import { decodeBase64 } from "@std/encoding/base64";
 * import { assertEquals } from "@std/assert";
 *
 * assertEquals(
 *   decodeBase64("Zm9vYmFy"),
 *   new TextEncoder().encode("foobar")
 * );
 * ```
 */
function decodeBase64(b64) {
    const output = new TextEncoder().encode(b64);
    // deno-lint-ignore no-explicit-any
    return new Uint8Array(output.buffer
        .transfer((0,_common64_js__WEBPACK_IMPORTED_MODULE_0__.decode)(output, 0, 0, rAlphabet, padding)));
}


/***/ },

/***/ "./node_modules/x-client-transaction-id/esm/deps/jsr.io/@std/encoding/1.0.10/base64url.js"
/*!************************************************************************************************!*\
  !*** ./node_modules/x-client-transaction-id/esm/deps/jsr.io/@std/encoding/1.0.10/base64url.js ***!
  \************************************************************************************************/
(__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   decodeBase64Url: () => (/* binding */ decodeBase64Url),
/* harmony export */   encodeBase64Url: () => (/* binding */ encodeBase64Url)
/* harmony export */ });
/* harmony import */ var _common64_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./_common64.js */ "./node_modules/x-client-transaction-id/esm/deps/jsr.io/@std/encoding/1.0.10/_common64.js");
/* harmony import */ var _common_detach_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./_common_detach.js */ "./node_modules/x-client-transaction-id/esm/deps/jsr.io/@std/encoding/1.0.10/_common_detach.js");
// Copyright 2018-2025 the Deno authors. MIT license.
// This module is browser compatible.
/**
 * Utilities for
 * {@link https://www.rfc-editor.org/rfc/rfc4648.html#section-5 | base64url}
 * encoding and decoding.
 *
 * @module
 */


const padding = "=".charCodeAt(0);
const alphabet = new TextEncoder()
    .encode("ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789-_");
const rAlphabet = new Uint8Array(128).fill(64); // alphabet.length
alphabet.forEach((byte, i) => rAlphabet[byte] = i);
/**
 * Convert data into a base64url-encoded string.
 *
 * @see {@link https://www.rfc-editor.org/rfc/rfc4648.html#section-5}
 *
 * @param data The data to encode.
 * @returns The base64url-encoded string.
 *
 * @example Usage
 * ```ts
 * import { encodeBase64Url } from "@std/encoding/base64url";
 * import { assertEquals } from "@std/assert";
 *
 * assertEquals(encodeBase64Url("foobar"), "Zm9vYmFy");
 * ```
 */
function encodeBase64Url(data) {
    if (typeof data === "string") {
        data = new TextEncoder().encode(data);
    }
    else if (data instanceof ArrayBuffer)
        data = new Uint8Array(data).slice();
    else
        data = data.slice();
    const [output, i] = (0,_common_detach_js__WEBPACK_IMPORTED_MODULE_1__.detach)(data, (0,_common64_js__WEBPACK_IMPORTED_MODULE_0__.calcSizeBase64)(data.length));
    let o = (0,_common64_js__WEBPACK_IMPORTED_MODULE_0__.encode)(output, i, 0, alphabet, padding);
    o = output.indexOf(padding, o - 2);
    return new TextDecoder().decode(
    // deno-lint-ignore no-explicit-any
    o > 0 ? new Uint8Array(output.buffer.transfer(o)) : output);
}
/**
 * Decodes a given base64url-encoded string.
 *
 * @see {@link https://www.rfc-editor.org/rfc/rfc4648.html#section-5}
 *
 * @param b64url The base64url-encoded string to decode.
 * @returns The decoded data.
 *
 * @example Usage
 * ```ts
 * import { decodeBase64Url } from "@std/encoding/base64url";
 * import { assertEquals } from "@std/assert";
 *
 * assertEquals(
 *   decodeBase64Url("Zm9vYmFy"),
 *   new TextEncoder().encode("foobar")
 * );
 * ```
 */
function decodeBase64Url(b64url) {
    const output = new TextEncoder().encode(b64url);
    // deno-lint-ignore no-explicit-any
    return new Uint8Array(output.buffer
        .transfer((0,_common64_js__WEBPACK_IMPORTED_MODULE_0__.decode)(output, 0, 0, rAlphabet, padding)));
}


/***/ },

/***/ "./node_modules/x-client-transaction-id/esm/deps/jsr.io/@std/encoding/1.0.10/hex.js"
/*!******************************************************************************************!*\
  !*** ./node_modules/x-client-transaction-id/esm/deps/jsr.io/@std/encoding/1.0.10/hex.js ***!
  \******************************************************************************************/
(__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   decodeHex: () => (/* binding */ decodeHex),
/* harmony export */   encodeHex: () => (/* binding */ encodeHex)
/* harmony export */ });
/* harmony import */ var _common16_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./_common16.js */ "./node_modules/x-client-transaction-id/esm/deps/jsr.io/@std/encoding/1.0.10/_common16.js");
/* harmony import */ var _common_detach_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./_common_detach.js */ "./node_modules/x-client-transaction-id/esm/deps/jsr.io/@std/encoding/1.0.10/_common_detach.js");
// Copyright 2009 The Go Authors. All rights reserved.
// https://github.com/golang/go/blob/master/LICENSE
// Copyright 2018-2025 the Deno authors. MIT license.
// This module is browser compatible.
/**
 * Port of the Go
 * {@link https://github.com/golang/go/blob/go1.12.5/src/encoding/hex/hex.go | encoding/hex}
 * library.
 *
 * ```ts
 * import {
 *   decodeHex,
 *   encodeHex,
 * } from "@std/encoding/hex";
 * import { assertEquals } from "@std/assert";
 *
 * assertEquals(encodeHex("abc"), "616263");
 *
 * assertEquals(
 *   decodeHex("616263"),
 *   new TextEncoder().encode("abc"),
 * );
 * ```
 *
 * @module
 */


const alphabet = new TextEncoder()
    .encode("0123456789abcdef");
const rAlphabet = new Uint8Array(128).fill(16); // alphabet.length
alphabet.forEach((byte, i) => rAlphabet[byte] = i);
new TextEncoder()
    .encode("ABCDEF")
    .forEach((byte, i) => rAlphabet[byte] = i + 10);
/**
 * Converts data into a hex-encoded string.
 *
 * @param src The data to encode.
 *
 * @returns The hex-encoded string.
 *
 * @example Usage
 * ```ts
 * import { encodeHex } from "@std/encoding/hex";
 * import { assertEquals } from "@std/assert";
 *
 * assertEquals(encodeHex("abc"), "616263");
 * ```
 */
function encodeHex(src) {
    if (typeof src === "string") {
        src = new TextEncoder().encode(src);
    }
    else if (src instanceof ArrayBuffer)
        src = new Uint8Array(src).slice();
    else
        src = src.slice();
    const [output, i] = (0,_common_detach_js__WEBPACK_IMPORTED_MODULE_1__.detach)(src, (0,_common16_js__WEBPACK_IMPORTED_MODULE_0__.calcSizeHex)(src.length));
    (0,_common16_js__WEBPACK_IMPORTED_MODULE_0__.encode)(output, i, 0, alphabet);
    return new TextDecoder().decode(output);
}
/**
 * Decodes the given hex-encoded string. If the input is malformed, an error is
 * thrown.
 *
 * @param src The hex-encoded string to decode.
 *
 * @returns The decoded data.
 *
 * @example Usage
 * ```ts
 * import { decodeHex } from "@std/encoding/hex";
 * import { assertEquals } from "@std/assert";
 *
 * assertEquals(
 *   decodeHex("616263"),
 *   new TextEncoder().encode("abc"),
 * );
 * ```
 */
function decodeHex(src) {
    const output = new TextEncoder().encode(src);
    // deno-lint-ignore no-explicit-any
    return new Uint8Array(output.buffer
        .transfer((0,_common16_js__WEBPACK_IMPORTED_MODULE_0__.decode)(output, 0, 0, rAlphabet)));
}


/***/ },

/***/ "./node_modules/x-client-transaction-id/esm/deps/jsr.io/@std/encoding/1.0.10/mod.js"
/*!******************************************************************************************!*\
  !*** ./node_modules/x-client-transaction-id/esm/deps/jsr.io/@std/encoding/1.0.10/mod.js ***!
  \******************************************************************************************/
(__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   MaxUint64: () => (/* reexport safe */ _varint_js__WEBPACK_IMPORTED_MODULE_6__.MaxUint64),
/* harmony export */   MaxVarintLen32: () => (/* reexport safe */ _varint_js__WEBPACK_IMPORTED_MODULE_6__.MaxVarintLen32),
/* harmony export */   MaxVarintLen64: () => (/* reexport safe */ _varint_js__WEBPACK_IMPORTED_MODULE_6__.MaxVarintLen64),
/* harmony export */   decodeAscii85: () => (/* reexport safe */ _ascii85_js__WEBPACK_IMPORTED_MODULE_0__.decodeAscii85),
/* harmony export */   decodeBase32: () => (/* reexport safe */ _base32_js__WEBPACK_IMPORTED_MODULE_1__.decodeBase32),
/* harmony export */   decodeBase58: () => (/* reexport safe */ _base58_js__WEBPACK_IMPORTED_MODULE_2__.decodeBase58),
/* harmony export */   decodeBase64: () => (/* reexport safe */ _base64_js__WEBPACK_IMPORTED_MODULE_3__.decodeBase64),
/* harmony export */   decodeBase64Url: () => (/* reexport safe */ _base64url_js__WEBPACK_IMPORTED_MODULE_4__.decodeBase64Url),
/* harmony export */   decodeHex: () => (/* reexport safe */ _hex_js__WEBPACK_IMPORTED_MODULE_5__.decodeHex),
/* harmony export */   decodeVarint: () => (/* reexport safe */ _varint_js__WEBPACK_IMPORTED_MODULE_6__.decodeVarint),
/* harmony export */   decodeVarint32: () => (/* reexport safe */ _varint_js__WEBPACK_IMPORTED_MODULE_6__.decodeVarint32),
/* harmony export */   encodeAscii85: () => (/* reexport safe */ _ascii85_js__WEBPACK_IMPORTED_MODULE_0__.encodeAscii85),
/* harmony export */   encodeBase32: () => (/* reexport safe */ _base32_js__WEBPACK_IMPORTED_MODULE_1__.encodeBase32),
/* harmony export */   encodeBase58: () => (/* reexport safe */ _base58_js__WEBPACK_IMPORTED_MODULE_2__.encodeBase58),
/* harmony export */   encodeBase64: () => (/* reexport safe */ _base64_js__WEBPACK_IMPORTED_MODULE_3__.encodeBase64),
/* harmony export */   encodeBase64Url: () => (/* reexport safe */ _base64url_js__WEBPACK_IMPORTED_MODULE_4__.encodeBase64Url),
/* harmony export */   encodeHex: () => (/* reexport safe */ _hex_js__WEBPACK_IMPORTED_MODULE_5__.encodeHex),
/* harmony export */   encodeVarint: () => (/* reexport safe */ _varint_js__WEBPACK_IMPORTED_MODULE_6__.encodeVarint)
/* harmony export */ });
/* harmony import */ var _ascii85_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./ascii85.js */ "./node_modules/x-client-transaction-id/esm/deps/jsr.io/@std/encoding/1.0.10/ascii85.js");
/* harmony import */ var _base32_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./base32.js */ "./node_modules/x-client-transaction-id/esm/deps/jsr.io/@std/encoding/1.0.10/base32.js");
/* harmony import */ var _base58_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./base58.js */ "./node_modules/x-client-transaction-id/esm/deps/jsr.io/@std/encoding/1.0.10/base58.js");
/* harmony import */ var _base64_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./base64.js */ "./node_modules/x-client-transaction-id/esm/deps/jsr.io/@std/encoding/1.0.10/base64.js");
/* harmony import */ var _base64url_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./base64url.js */ "./node_modules/x-client-transaction-id/esm/deps/jsr.io/@std/encoding/1.0.10/base64url.js");
/* harmony import */ var _hex_js__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./hex.js */ "./node_modules/x-client-transaction-id/esm/deps/jsr.io/@std/encoding/1.0.10/hex.js");
/* harmony import */ var _varint_js__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./varint.js */ "./node_modules/x-client-transaction-id/esm/deps/jsr.io/@std/encoding/1.0.10/varint.js");
// Copyright 2018-2025 the Deno authors. MIT license.
// This module is browser compatible.
/**
 * Utilities for encoding and decoding common formats like hex, base64, and varint.
 *
 * ## Basic Usage
 *
 * ```ts
 * import { encodeBase64, decodeBase64 } from "@std/encoding";
 * import { assertEquals } from "@std/assert";
 *
 * const foobar = new TextEncoder().encode("foobar");
 * assertEquals(encodeBase64(foobar), "Zm9vYmFy");
 * assertEquals(decodeBase64("Zm9vYmFy"), foobar);
 * ```
 *
 * ## Various Encoding Formats
 *
 * ```ts
 * import {
 *   encodeHex,
 *   encodeBase32,
 *   encodeBase58,
 *   encodeBase64,
 *   encodeAscii85,
 *   decodeHex,
 *   decodeBase32,
 *   decodeBase58,
 *   decodeBase64,
 *   decodeAscii85,
 * } from "@std/encoding";
 * import { assertEquals } from "@std/assert";
 *
 * // Many different encodings for different character sets
 * assertEquals(encodeHex("Hello world!"), "48656c6c6f20776f726c6421");
 * assertEquals(encodeBase32("Hello world!"), "JBSWY3DPEB3W64TMMQQQ====");
 * assertEquals(encodeBase58("Hello world!"), "2NEpo7TZRhna7vSvL");
 * assertEquals(encodeBase64("Hello world!"), "SGVsbG8gd29ybGQh");
 * assertEquals(encodeAscii85("Hello world!"), "87cURD]j7BEbo80");
 *
 * // Decoding
 * assertEquals(new TextDecoder().decode(decodeHex("48656c6c6f20776f726c6421")), "Hello world!");
 * assertEquals(new TextDecoder().decode(decodeBase32("JBSWY3DPEB3W64TMMQQQ====")), "Hello world!");
 * assertEquals(new TextDecoder().decode(decodeBase58("2NEpo7TZRhna7vSvL")), "Hello world!");
 * assertEquals(new TextDecoder().decode(decodeBase64("SGVsbG8gd29ybGQh")), "Hello world!");
 * assertEquals(new TextDecoder().decode(decodeAscii85("87cURD]j7BEbo80")), "Hello world!");
 * ```
 *
 * ## URL-Safe Base64
 *
 * ```ts
 * import { encodeBase64, encodeBase64Url } from "@std/encoding";
 * import { assertEquals } from "@std/assert";
 *
 * assertEquals(encodeBase64("ice creams"), "aWNlIGNyZWFtcw=="); // Not url-safe because of `=`
 * assertEquals(encodeBase64Url("ice creams"), "aWNlIGNyZWFtcw"); // URL-safe!
 *
 * // Base64Url replaces + with - and / with _
 * assertEquals(encodeBase64("subjects?"), "c3ViamVjdHM/"); // slash is not URL-safe
 * assertEquals(encodeBase64Url("subjects?"), "c3ViamVjdHM_"); // _ is URL-safe
 * ```
 *
 * ## Binary Data Encoding
 *
 * ```ts
 * import { encodeHex, encodeBase64 } from "@std/encoding";
 * import { assertEquals } from "@std/assert";
 *
 * // Working with binary data
 * const binaryData = new Uint8Array([0xDE, 0xAD, 0xBE, 0xEF]);
 * assertEquals(encodeHex(binaryData), "deadbeef");
 * assertEquals(encodeBase64(binaryData), "3q2+7w==");
 * ```
 *
 * ## Varint Encoding
 *
 * Learn more from the [protobuf Varint encoding docs](https://protobuf.dev/programming-guides/encoding/#varints).
 *
 * ```ts
 * import { encodeVarint, decodeVarint } from "@std/encoding";
 * import { assertEquals } from "@std/assert";
 *
 * // Varint encoding support
 * assertEquals(encodeVarint(9601n), [new Uint8Array([129, 75]), 2]);
 *
 * // Decode a varint
 * const bytes = new Uint8Array([129, 75]);
 * assertEquals(decodeVarint(bytes), [9601n, 2]);
 * ```
 *
 * @module
 */









/***/ },

/***/ "./node_modules/x-client-transaction-id/esm/deps/jsr.io/@std/encoding/1.0.10/varint.js"
/*!*********************************************************************************************!*\
  !*** ./node_modules/x-client-transaction-id/esm/deps/jsr.io/@std/encoding/1.0.10/varint.js ***!
  \*********************************************************************************************/
(__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   MaxUint64: () => (/* binding */ MaxUint64),
/* harmony export */   MaxVarintLen32: () => (/* binding */ MaxVarintLen32),
/* harmony export */   MaxVarintLen64: () => (/* binding */ MaxVarintLen64),
/* harmony export */   decodeVarint: () => (/* binding */ decodeVarint),
/* harmony export */   decodeVarint32: () => (/* binding */ decodeVarint32),
/* harmony export */   encodeVarint: () => (/* binding */ encodeVarint)
/* harmony export */ });
// Copyright 2018-2025 the Deno authors. MIT license.
// Copyright 2020 Keith Cirkel. All rights reserved. MIT license.
// Copyright 2023 Skye "MierenManz". All rights reserved. MIT license.
/**
 * Utilities for {@link https://protobuf.dev/programming-guides/encoding/#varints Varint} encoding
 * of typed integers. Varint encoding represents integers using a variable number of bytes, with
 * smaller values requiring fewer bytes.
 *
 * ```ts
 * import { encodeVarint, decodeVarint } from "@std/encoding/varint";
 * import { assertEquals } from "@std/assert";
 *
 * const buf = new Uint8Array(10);
 * assertEquals(
 *   encodeVarint(42n, buf),
 *   [new Uint8Array([42]), 1]
 * );
 *
 * assertEquals(
 *   decodeVarint(new Uint8Array([42])),
 *   [ 42n, 1 ]
 * );
 * ```
 *
 * @module
 */
/**
 * The maximum value of an unsigned 64-bit integer.
 * Equivalent to `2n**64n - 1n`
 */
const MaxUint64 = 18446744073709551615n;
/**
 * The maximum length, in bytes, of a Varint encoded 64-bit integer.
 */
const MaxVarintLen64 = 10;
/**
 * The maximum length, in bytes, of a Varint encoded 32-bit integer.
 */
const MaxVarintLen32 = 5;
const MSB = 0x80;
const REST = 0x7f;
const SHIFT = 7;
const MSBN = 0x80n;
const SHIFTN = 7n;
// ArrayBuffer and TypedArray's for "pointer casting"
const AB = new ArrayBuffer(8);
const U32_VIEW = new Uint32Array(AB);
const U64_VIEW = new BigUint64Array(AB);
/**
 * Given a non empty `buf`, starting at `offset` (default: 0), begin decoding bytes as
 * Varint encoded bytes, for a maximum of 10 bytes (offset + 10). The returned
 * tuple is of the decoded varint 32-bit number, and the new offset with which
 * to continue decoding other data.
 *
 * If a `bigint` in return is undesired, the `decode32` function will return a
 * `number`, but this should only be used in cases where the varint is
 * _assured_ to be 32-bits. If in doubt, use `decode()`.
 *
 * To know how many bytes the Varint took to encode, simply negate `offset`
 * from the returned new `offset`.
 *
 * @param buf The buffer to decode from.
 * @param offset The offset to start decoding from.
 * @returns A tuple of the decoded varint 64-bit number, and the new offset.
 *
 * @example Usage
 * ```ts
 * import { decodeVarint } from "@std/encoding/varint";
 * import { assertEquals } from "@std/assert";
 *
 * const buf = new Uint8Array([0x8E, 0x02]);
 * assertEquals(decodeVarint(buf), [270n, 2]);
 * ```
 */
function decodeVarint(buf, offset = 0) {
    // Clear the last result from the Two's complement view
    U64_VIEW[0] = 0n;
    // Setup the initiat state of the function
    let intermediate = 0;
    let position = 0;
    let i = offset;
    // If the buffer is empty Throw
    if (buf.length === 0)
        throw new RangeError("Cannot read empty buffer");
    let byte;
    do {
        // Get a single byte from the buffer
        byte = buf[i];
        // 1. Take the lower 7 bits of the byte.
        // 2. Shift the bits into the correct position.
        // 3. Bitwise OR it with the intermediate value
        // QUIRK: in the 5th (and 10th) iteration of this loop it will overflow on the shift.
        // This causes only the lower 4 bits to be shifted into place and removing the upper 3 bits
        intermediate |= (byte & 0b01111111) << position;
        // If position is 28
        // it means that this iteration needs to be written the the two's complement view
        // This only happens once due to the `-4` in this branch
        if (position === 28) {
            // Write to the view
            U32_VIEW[0] = intermediate;
            // set `intermediate` to the remaining 3 bits
            // We only want the remaining three bits because the other 4 have been "consumed" on line 21
            intermediate = (byte & 0b01110000) >>> 4;
            // set `position` to -4 because later 7 will be added, making it 3
            position = -4;
        }
        // Increment the shift position by 7
        position += 7;
        // Increment the iterator by 1
        i++;
        // Keep going while there is a continuation bit
    } while ((byte & 0b10000000) === 0b10000000);
    // subtract the initial offset from `i` to get the bytes read
    const nRead = i - offset;
    // If 10 bytes have been read and intermediate has overflown
    // it means that the varint is malformed
    // If 11 bytes have been read it means that the varint is malformed
    // If `i` is bigger than the buffer it means we overread the buffer and the varint is malformed
    if ((nRead === 10 && intermediate > -1) || nRead === 11 || i > buf.length) {
        throw new RangeError("Cannot decode the varint input: Malformed or overflow varint");
    }
    // Write the intermediate value to the "empty" slot
    // if the first slot is taken. Take the second slot
    U32_VIEW[Number(nRead > 4)] = intermediate;
    return [U64_VIEW[0], i];
}
/**
 * Given a `buf`, starting at `offset` (default: 0), begin decoding bytes as
 * Varint encoded bytes, for a maximum of 5 bytes (offset + 5). The returned
 * tuple is of the decoded varint 32-bit number, and the new offset with which
 * to continue decoding other data.
 *
 * Varints are _not 32-bit by default_ so this should only be used in cases
 * where the varint is _assured_ to be 32-bits. If in doubt, use `decode()`.
 *
 * To know how many bytes the Varint took to encode, simply negate `offset`
 * from the returned new `offset`.
 *
 * @param buf The buffer to decode from.
 * @param offset The offset to start decoding from.
 * @returns A tuple of the decoded varint 32-bit number, and the new offset.
 *
 * @example Usage
 * ```ts
 * import { decodeVarint32 } from "@std/encoding/varint";
 * import { assertEquals } from "@std/assert";
 *
 * const buf = new Uint8Array([0x8E, 0x02]);
 * assertEquals(decodeVarint32(buf), [270, 2]);
 * ```
 */
function decodeVarint32(buf, offset = 0) {
    let shift = 0;
    let decoded = 0;
    for (let i = offset; i <= Math.min(buf.length, offset + MaxVarintLen32); i += 1, shift += SHIFT) {
        const byte = buf[i];
        decoded += (byte & REST) * Math.pow(2, shift);
        if (!(byte & MSB))
            return [decoded, i + 1];
    }
    throw new RangeError("Cannot decode the varint input: Malformed or overflow varint");
}
/**
 * Takes unsigned number `num` and converts it into a Varint encoded
 * `Uint8Array`, returning a tuple consisting of a `Uint8Array` slice of the
 * encoded Varint, and an offset where the Varint encoded bytes end within the
 * `Uint8Array`.
 *
 * If `buf` is not given then a Uint8Array will be created.
 * `offset` defaults to `0`.
 *
 * If passed `buf` then that will be written into, starting at `offset`. The
 * resulting returned `Uint8Array` will be a slice of `buf`. The resulting
 * returned number is effectively `offset + bytesWritten`.
 *
 * @param num The number to encode.
 * @param buf The buffer to write into.
 * @param offset The offset to start writing at.
 * @returns A tuple of the encoded Varint `Uint8Array` and the new offset.
 *
 * @example Usage
 * ```ts
 * import { encodeVarint } from "@std/encoding/varint";
 * import { assertEquals } from "@std/assert";
 *
 * const buf = new Uint8Array(10);
 * assertEquals(encodeVarint(42n, buf), [new Uint8Array([42]), 1]);
 * ```
 */
function encodeVarint(num, buf = new Uint8Array(MaxVarintLen64), offset = 0) {
    num = BigInt(num);
    if (num < 0n) {
        throw new RangeError(`Cannot encode the input into varint as it should be non-negative integer: received ${num}`);
    }
    for (let i = offset; i <= Math.min(buf.length, MaxVarintLen64); i += 1) {
        if (num < MSBN) {
            buf[i] = Number(num);
            i += 1;
            return [buf.slice(offset, i), i];
        }
        buf[i] = Number((num & 0xffn) | MSBN);
        num >>= SHIFTN;
    }
    throw new RangeError(`Cannot encode the input ${num} into varint as it overflows uint64`);
}


/***/ },

/***/ "./node_modules/x-client-transaction-id/esm/errors.js"
/*!************************************************************!*\
  !*** ./node_modules/x-client-transaction-id/esm/errors.js ***!
  \************************************************************/
(__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   AnimationFrameDataError: () => (/* binding */ AnimationFrameDataError),
/* harmony export */   ClientTransactionError: () => (/* binding */ ClientTransactionError),
/* harmony export */   ClientTransactionInitializationError: () => (/* binding */ ClientTransactionInitializationError),
/* harmony export */   ClientTransactionNotInitializedError: () => (/* binding */ ClientTransactionNotInitializedError),
/* harmony export */   HandleXMigrationError: () => (/* binding */ HandleXMigrationError),
/* harmony export */   IndicesNotInitializedError: () => (/* binding */ IndicesNotInitializedError),
/* harmony export */   InterpolationInputError: () => (/* binding */ InterpolationInputError),
/* harmony export */   KeyByteIndicesExtractionError: () => (/* binding */ KeyByteIndicesExtractionError),
/* harmony export */   OnDemandFileFetchError: () => (/* binding */ OnDemandFileFetchError),
/* harmony export */   OnDemandFileUrlResolutionError: () => (/* binding */ OnDemandFileUrlResolutionError),
/* harmony export */   SiteVerificationKeyNotFoundError: () => (/* binding */ SiteVerificationKeyNotFoundError),
/* harmony export */   XHomePageFetchError: () => (/* binding */ XHomePageFetchError),
/* harmony export */   XMigrationFormError: () => (/* binding */ XMigrationFormError),
/* harmony export */   XMigrationRedirectionError: () => (/* binding */ XMigrationRedirectionError)
/* harmony export */ });
/**
 * Custom error types for x-client-transaction-id.
 */
class ClientTransactionError extends Error {
    constructor(message, options = {}) {
        super(message, options.cause ? { cause: options.cause } : undefined);
        Object.defineProperty(this, "code", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        this.name = new.target.name;
        this.code = options.code ?? "CLIENT_TRANSACTION_ERROR";
    }
}
class ClientTransactionInitializationError extends ClientTransactionError {
    constructor(message, options = {}) {
        super(message, {
            code: options.code ?? "CLIENT_TRANSACTION_INITIALIZATION_ERROR",
            cause: options.cause,
        });
    }
}
class OnDemandFileUrlResolutionError extends ClientTransactionInitializationError {
    constructor() {
        super("Unable to resolve the X ondemand chunk URL from the homepage runtime.", { code: "ONDEMAND_FILE_URL_RESOLUTION_ERROR" });
    }
}
class OnDemandFileFetchError extends ClientTransactionInitializationError {
    constructor(url, status, statusText) {
        super(`Unable to fetch the X ondemand chunk from "${url}": ${status} ${statusText}.`, { code: "ONDEMAND_FILE_FETCH_ERROR" });
        Object.defineProperty(this, "url", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        Object.defineProperty(this, "status", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        Object.defineProperty(this, "statusText", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        this.url = url;
        this.status = status;
        this.statusText = statusText;
    }
}
class KeyByteIndicesExtractionError extends ClientTransactionInitializationError {
    constructor() {
        super("Unable to extract key byte indices from the X ondemand chunk.", { code: "KEY_BYTE_INDICES_EXTRACTION_ERROR" });
    }
}
class SiteVerificationKeyNotFoundError extends ClientTransactionInitializationError {
    constructor() {
        super("Unable to find the twitter-site-verification meta tag in the homepage document.", { code: "SITE_VERIFICATION_KEY_NOT_FOUND_ERROR" });
    }
}
class IndicesNotInitializedError extends ClientTransactionError {
    constructor() {
        super("ClientTransaction indices are not initialized. Call initialize() before generating animation data.", { code: "INDICES_NOT_INITIALIZED_ERROR" });
    }
}
class AnimationFrameDataError extends ClientTransactionInitializationError {
    constructor(rowIndex) {
        super(`Unable to build animation data for row ${rowIndex}. The homepage animation markup may have changed.`, { code: "ANIMATION_FRAME_DATA_ERROR" });
        Object.defineProperty(this, "rowIndex", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        this.rowIndex = rowIndex;
    }
}
class ClientTransactionNotInitializedError extends ClientTransactionError {
    constructor() {
        super("ClientTransaction has not been initialized. Call initialize() or use ClientTransaction.create() first.", { code: "CLIENT_TRANSACTION_NOT_INITIALIZED_ERROR" });
    }
}
class HandleXMigrationError extends ClientTransactionError {
    constructor(message, options = {}) {
        super(message, {
            code: options.code ?? "HANDLE_X_MIGRATION_ERROR",
            cause: options.cause,
        });
    }
}
class XHomePageFetchError extends HandleXMigrationError {
    constructor(status, statusText) {
        super(`Unable to fetch the X homepage: ${status} ${statusText}.`, { code: "X_HOMEPAGE_FETCH_ERROR" });
        Object.defineProperty(this, "status", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        Object.defineProperty(this, "statusText", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        this.status = status;
        this.statusText = statusText;
    }
}
class XMigrationRedirectionError extends HandleXMigrationError {
    constructor(status, statusText) {
        super(`Unable to follow the X migration redirect: ${status} ${statusText}.`, { code: "X_MIGRATION_REDIRECTION_ERROR" });
        Object.defineProperty(this, "status", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        Object.defineProperty(this, "statusText", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        this.status = status;
        this.statusText = statusText;
    }
}
class XMigrationFormError extends HandleXMigrationError {
    constructor(status, statusText) {
        super(`Unable to submit the X migration form: ${status} ${statusText}.`, { code: "X_MIGRATION_FORM_ERROR" });
        Object.defineProperty(this, "status", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        Object.defineProperty(this, "statusText", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        this.status = status;
        this.statusText = statusText;
    }
}
class InterpolationInputError extends ClientTransactionError {
    constructor(fromLength, toLength) {
        super(`Interpolation requires arrays of the same length, but received ${fromLength} and ${toLength}.`, { code: "INTERPOLATION_INPUT_ERROR" });
        Object.defineProperty(this, "fromLength", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        Object.defineProperty(this, "toLength", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        this.fromLength = fromLength;
        this.toLength = toLength;
    }
}



/***/ },

/***/ "./node_modules/x-client-transaction-id/esm/interpolate.js"
/*!*****************************************************************!*\
  !*** ./node_modules/x-client-transaction-id/esm/interpolate.js ***!
  \*****************************************************************/
(__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   interpolate: () => (/* binding */ interpolate),
/* harmony export */   interpolateNum: () => (/* binding */ interpolateNum)
/* harmony export */ });
/* harmony import */ var _errors_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./errors.js */ "./node_modules/x-client-transaction-id/esm/errors.js");
/**
 * Interpolation utility functions
 *
 * This module provides functions for interpolating between values,
 * used in the animation key generation process.
 */
/**
 * Interpolates between two arrays of numbers
 * @param fromList Starting values
 * @param toList Ending values
 * @param f Interpolation factor (0.0 to 1.0)
 * @returns Array of interpolated values
 */

function interpolate(fromList, toList, f) {
    if (fromList.length !== toList.length) {
        throw new _errors_js__WEBPACK_IMPORTED_MODULE_0__.InterpolationInputError(fromList.length, toList.length);
    }
    const out = [];
    for (let i = 0; i < fromList.length; i++) {
        out.push(interpolateNum(fromList[i], toList[i], f));
    }
    return out;
}
/**
 * Interpolates between two values (numeric or boolean)
 * @param fromVal Starting value
 * @param toVal Ending value
 * @param f Interpolation factor (0.0 to 1.0)
 * @returns Interpolated value
 */
function interpolateNum(fromVal, toVal, f) {
    if (typeof fromVal === "number" && typeof toVal === "number") {
        return fromVal * (1 - f) + toVal * f;
    }
    if (typeof fromVal === "boolean" && typeof toVal === "boolean") {
        return f < 0.5 ? (fromVal ? 1 : 0) : toVal ? 1 : 0;
    }
    return 0;
}



/***/ },

/***/ "./node_modules/x-client-transaction-id/esm/mod.js"
/*!*********************************************************!*\
  !*** ./node_modules/x-client-transaction-id/esm/mod.js ***!
  \*********************************************************/
(__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   AnimationFrameDataError: () => (/* reexport safe */ _errors_js__WEBPACK_IMPORTED_MODULE_3__.AnimationFrameDataError),
/* harmony export */   ClientTransaction: () => (/* reexport safe */ _transaction_js__WEBPACK_IMPORTED_MODULE_1__["default"]),
/* harmony export */   ClientTransactionError: () => (/* reexport safe */ _errors_js__WEBPACK_IMPORTED_MODULE_3__.ClientTransactionError),
/* harmony export */   ClientTransactionInitializationError: () => (/* reexport safe */ _errors_js__WEBPACK_IMPORTED_MODULE_3__.ClientTransactionInitializationError),
/* harmony export */   ClientTransactionNotInitializedError: () => (/* reexport safe */ _errors_js__WEBPACK_IMPORTED_MODULE_3__.ClientTransactionNotInitializedError),
/* harmony export */   Cubic: () => (/* reexport safe */ _cubic_js__WEBPACK_IMPORTED_MODULE_2__["default"]),
/* harmony export */   HandleXMigrationError: () => (/* reexport safe */ _errors_js__WEBPACK_IMPORTED_MODULE_3__.HandleXMigrationError),
/* harmony export */   IndicesNotInitializedError: () => (/* reexport safe */ _errors_js__WEBPACK_IMPORTED_MODULE_3__.IndicesNotInitializedError),
/* harmony export */   InterpolationInputError: () => (/* reexport safe */ _errors_js__WEBPACK_IMPORTED_MODULE_3__.InterpolationInputError),
/* harmony export */   KeyByteIndicesExtractionError: () => (/* reexport safe */ _errors_js__WEBPACK_IMPORTED_MODULE_3__.KeyByteIndicesExtractionError),
/* harmony export */   OnDemandFileFetchError: () => (/* reexport safe */ _errors_js__WEBPACK_IMPORTED_MODULE_3__.OnDemandFileFetchError),
/* harmony export */   OnDemandFileUrlResolutionError: () => (/* reexport safe */ _errors_js__WEBPACK_IMPORTED_MODULE_3__.OnDemandFileUrlResolutionError),
/* harmony export */   SiteVerificationKeyNotFoundError: () => (/* reexport safe */ _errors_js__WEBPACK_IMPORTED_MODULE_3__.SiteVerificationKeyNotFoundError),
/* harmony export */   XHomePageFetchError: () => (/* reexport safe */ _errors_js__WEBPACK_IMPORTED_MODULE_3__.XHomePageFetchError),
/* harmony export */   XMigrationFormError: () => (/* reexport safe */ _errors_js__WEBPACK_IMPORTED_MODULE_3__.XMigrationFormError),
/* harmony export */   XMigrationRedirectionError: () => (/* reexport safe */ _errors_js__WEBPACK_IMPORTED_MODULE_3__.XMigrationRedirectionError),
/* harmony export */   convertRotationToMatrix: () => (/* reexport safe */ _rotation_js__WEBPACK_IMPORTED_MODULE_5__.convertRotationToMatrix),
/* harmony export */   decodeBase64: () => (/* reexport safe */ _deps_jsr_io_std_encoding_1_0_10_mod_js__WEBPACK_IMPORTED_MODULE_7__.decodeBase64),
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__),
/* harmony export */   encodeBase64: () => (/* reexport safe */ _deps_jsr_io_std_encoding_1_0_10_mod_js__WEBPACK_IMPORTED_MODULE_7__.encodeBase64),
/* harmony export */   floatToHex: () => (/* reexport safe */ _utils_js__WEBPACK_IMPORTED_MODULE_6__.floatToHex),
/* harmony export */   handleXMigration: () => (/* reexport safe */ _utils_js__WEBPACK_IMPORTED_MODULE_6__.handleXMigration),
/* harmony export */   interpolate: () => (/* reexport safe */ _interpolate_js__WEBPACK_IMPORTED_MODULE_4__.interpolate),
/* harmony export */   interpolateNum: () => (/* reexport safe */ _interpolate_js__WEBPACK_IMPORTED_MODULE_4__.interpolateNum),
/* harmony export */   isOdd: () => (/* reexport safe */ _utils_js__WEBPACK_IMPORTED_MODULE_6__.isOdd)
/* harmony export */ });
/* harmony import */ var _dnt_polyfills_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./_dnt.polyfills.js */ "./node_modules/x-client-transaction-id/esm/_dnt.polyfills.js");
/* harmony import */ var _transaction_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./transaction.js */ "./node_modules/x-client-transaction-id/esm/transaction.js");
/* harmony import */ var _cubic_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./cubic.js */ "./node_modules/x-client-transaction-id/esm/cubic.js");
/* harmony import */ var _errors_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./errors.js */ "./node_modules/x-client-transaction-id/esm/errors.js");
/* harmony import */ var _interpolate_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./interpolate.js */ "./node_modules/x-client-transaction-id/esm/interpolate.js");
/* harmony import */ var _rotation_js__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./rotation.js */ "./node_modules/x-client-transaction-id/esm/rotation.js");
/* harmony import */ var _utils_js__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./utils.js */ "./node_modules/x-client-transaction-id/esm/utils.js");
/* harmony import */ var _deps_jsr_io_std_encoding_1_0_10_mod_js__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./deps/jsr.io/@std/encoding/1.0.10/mod.js */ "./node_modules/x-client-transaction-id/esm/deps/jsr.io/@std/encoding/1.0.10/mod.js");
/**
 * @lami/x-client-transaction-id
 *
 * A library for generating client transaction IDs required for
 * authenticated API requests to X (formerly Twitter).
 *
 * This module exports the main ClientTransaction class and utility functions
 * needed to generate valid x-client-transaction-id headers for X API requests.
 *
 * @module
 */









/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (_transaction_js__WEBPACK_IMPORTED_MODULE_1__["default"]);


/***/ },

/***/ "./node_modules/x-client-transaction-id/esm/rotation.js"
/*!**************************************************************!*\
  !*** ./node_modules/x-client-transaction-id/esm/rotation.js ***!
  \**************************************************************/
(__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   convertRotationToMatrix: () => (/* binding */ convertRotationToMatrix),
/* harmony export */   convertRotationToMatrix2: () => (/* binding */ convertRotationToMatrix2)
/* harmony export */ });
/**
 * Rotation utility functions
 *
 * This module provides functions for converting rotation values to matrices,
 * used in the animation key generation process.
 */
/**
 * Converts a rotation angle in degrees to a 2D transformation matrix
 * @param rotation Angle in degrees
 * @returns Array of 4 values representing the transformation matrix [a, b, c, d]
 */
function convertRotationToMatrix(rotation) {
    const rad = (rotation * Math.PI) / 180;
    return [Math.cos(rad), -Math.sin(rad), Math.sin(rad), Math.cos(rad)];
}
/**
 * Alternative implementation for converting rotation to matrix
 * Note: This implementation returns a 6-value matrix in the format [a, b, c, d, tx, ty]
 * @param degrees Angle in degrees
 * @returns Array of 6 values representing the transformation matrix
 * @private
 */
function convertRotationToMatrix2(degrees) {
    // Convert degrees to radians
    const radians = (degrees * Math.PI) / 180;
    // Create matrix:
    // [cos(r), -sin(r), 0]
    // [sin(r), cos(r), 0]
    //
    // Order:
    // [cos(r), sin(r), -sin(r), cos(r), 0, 0]
    const cos = Math.cos(radians);
    const sin = Math.sin(radians);
    return [cos, sin, -sin, cos, 0, 0];
}



/***/ },

/***/ "./node_modules/x-client-transaction-id/esm/transaction.js"
/*!*****************************************************************!*\
  !*** ./node_modules/x-client-transaction-id/esm/transaction.js ***!
  \*****************************************************************/
(__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _cubic_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./cubic.js */ "./node_modules/x-client-transaction-id/esm/cubic.js");
/* harmony import */ var _errors_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./errors.js */ "./node_modules/x-client-transaction-id/esm/errors.js");
/* harmony import */ var _interpolate_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./interpolate.js */ "./node_modules/x-client-transaction-id/esm/interpolate.js");
/* harmony import */ var _rotation_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./rotation.js */ "./node_modules/x-client-transaction-id/esm/rotation.js");
/* harmony import */ var _utils_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./utils.js */ "./node_modules/x-client-transaction-id/esm/utils.js");
/* harmony import */ var _deps_jsr_io_std_encoding_1_0_10_mod_js__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./deps/jsr.io/@std/encoding/1.0.10/mod.js */ "./node_modules/x-client-transaction-id/esm/deps/jsr.io/@std/encoding/1.0.10/mod.js");
/**
 * Client Transaction ID Generator for X (formerly Twitter) API requests
 *
 * This module provides functionality to generate the x-client-transaction-id
 * header value required for authenticated API requests to X.
 */






const ON_DEMAND_CHUNK_NAME = "ondemand.s";
const INDICES_REGEX = /\(\w\[(\d{1,2})\],\s*16\)/g;
const ON_DEMAND_FILE_HASH_REGEX = /(\d+):\s*["']ondemand\.s["'][\s\S]*?\}\[e\]\s*\|\|\s*e\)\s*\+\s*["']\.["']\s*\+\s*\{[\s\S]*?\b\1:\s*["']([a-zA-Z0-9_-]+)["']/s;
function resolveOnDemandFileUrlFromRuntime(runtimeSource) {
    const onDemandFileMatch = ON_DEMAND_FILE_HASH_REGEX.exec(runtimeSource);
    if (!onDemandFileMatch) {
        return null;
    }
    return `https://abs.twimg.com/responsive-web/client-web/${ON_DEMAND_CHUNK_NAME}.${onDemandFileMatch[2]}a.js`;
}
/**
 * Main class responsible for generating client transaction IDs
 * used in authenticated API requests to X
 */
class ClientTransaction {
    /**
     * Creates a new ClientTransaction instance
     * @param homePageDocument DOM Document object from X's homepage
     */
    constructor(homePageDocument) {
        Object.defineProperty(this, "DEFAULT_ROW_INDEX", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: null
        });
        Object.defineProperty(this, "DEFAULT_KEY_BYTES_INDICES", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: null
        });
        Object.defineProperty(this, "homePageDocument", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        Object.defineProperty(this, "key", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: null
        });
        Object.defineProperty(this, "keyBytes", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: null
        });
        Object.defineProperty(this, "animationKey", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: null
        });
        Object.defineProperty(this, "isInitialized", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: false
        });
        this.homePageDocument = homePageDocument;
    }
    /**
     * Initializes the ClientTransaction instance
     * Must be called after constructor and before using other methods
     * @returns Promise that resolves when initialization is complete
     * @throws Error if initialization fails
     */
    async initialize() {
        if (this.isInitialized)
            return;
        // Initialize indices
        [this.DEFAULT_ROW_INDEX, this.DEFAULT_KEY_BYTES_INDICES] = await this
            .getIndices(this.homePageDocument);
        // Get key from document
        this.key = this.getKey(this.homePageDocument);
        // Convert key to byte array
        this.keyBytes = this.getKeyBytes(this.key);
        // Generate animation key
        this.animationKey = this.getAnimationKey(this.keyBytes, this.homePageDocument);
        // Mark initialization as complete
        this.isInitialized = true;
    }
    /**
     * Static factory method that creates and initializes a ClientTransaction instance
     * @param homePageDocument DOM Document object from X's homepage
     * @returns Initialized ClientTransaction instance
     */
    static async create(homePageDocument) {
        const instance = new ClientTransaction(homePageDocument);
        await instance.initialize();
        return instance;
    }
    /**
     * Extracts key byte indices from homepage document
     * @param homePageDocument Optional document to use instead of stored one
     * @returns Tuple of [rowIndex, keyByteIndices]
     * @private
     */
    async getIndices(homePageDocument) {
        const keyByteIndices = [];
        const response = homePageDocument || this.homePageDocument;
        const onDemandFileUrl = this.getOnDemandFileUrl(response);
        const onDemandFileResponse = await fetch(onDemandFileUrl);
        if (!onDemandFileResponse.ok) {
            throw new _errors_js__WEBPACK_IMPORTED_MODULE_1__.OnDemandFileFetchError(onDemandFileUrl, onDemandFileResponse.status, onDemandFileResponse.statusText);
        }
        const responseText = await onDemandFileResponse.text();
        // Extract indices using regex
        let match;
        INDICES_REGEX.lastIndex = 0; // Reset regex index
        while ((match = INDICES_REGEX.exec(responseText)) !== null) {
            keyByteIndices.push(match[1]);
        }
        if (!keyByteIndices.length) {
            throw new _errors_js__WEBPACK_IMPORTED_MODULE_1__.KeyByteIndicesExtractionError();
        }
        // Convert strings to numbers
        const numericIndices = keyByteIndices.map((index) => parseInt(index, 10));
        return [numericIndices[0], numericIndices.slice(1)];
    }
    /**
     * Resolves the current ondemand chunk URL from webpack runtime metadata.
     * @param response Optional document to use instead of stored one
     * @returns Absolute URL for the ondemand chunk file
     * @private
     */
    getOnDemandFileUrl(response) {
        const document = response || this.homePageDocument;
        const runtimeSources = Array.from(document.querySelectorAll("script"))
            .map((script) => script.textContent || "")
            .filter((scriptText) => scriptText.includes(ON_DEMAND_CHUNK_NAME));
        runtimeSources.push(document.documentElement.outerHTML);
        for (const runtimeSource of runtimeSources) {
            const onDemandFileUrl = resolveOnDemandFileUrlFromRuntime(runtimeSource);
            if (onDemandFileUrl) {
                return onDemandFileUrl;
            }
        }
        throw new _errors_js__WEBPACK_IMPORTED_MODULE_1__.OnDemandFileUrlResolutionError();
    }
    /**
     * Extracts verification key from document
     * @param response Optional document to use instead of stored one
     * @returns X site verification key
     * @private
     */
    getKey(response) {
        response = response || this.homePageDocument;
        let content = "";
        // Extract key from meta tag
        const element = response.querySelector("[name='twitter-site-verification']");
        if (element) {
            content = element.getAttribute("content") ?? "";
        }
        if (!content) {
            throw new _errors_js__WEBPACK_IMPORTED_MODULE_1__.SiteVerificationKeyNotFoundError();
        }
        return content;
    }
    /**
     * Converts key string to byte array
     * @param key Base64 encoded key string
     * @returns Array of byte values
     * @private
     */
    getKeyBytes(key) {
        return Array.from((0,_deps_jsr_io_std_encoding_1_0_10_mod_js__WEBPACK_IMPORTED_MODULE_5__.decodeBase64)(key));
    }
    /**
     * Gets animation frames from document
     * @param response Optional document to use instead of stored one
     * @returns Array of frame elements
     * @private
     */
    getFrames(response) {
        response = response || this.homePageDocument;
        return Array.from(response.querySelectorAll("[id^='loading-x-anim']"));
    }
    /**
     * Parses SVG paths to extract coordinate arrays
     * @param keyBytes Key bytes from site verification
     * @param response Optional document to use
     * @param frames Optional frame elements if already fetched
     * @returns 2D array of frame coordinates
     * @private
     */
    get2dArray(keyBytes, response, frames) {
        if (!frames) {
            frames = this.getFrames(response);
        }
        if (!frames || !frames.length) {
            return [[]]; // Return empty 2D array
        }
        // 1. Select frame and navigate DOM to get "d" attribute
        const frame = frames[keyBytes[5] % 4];
        const firstChild = frame.children[0];
        const targetChild = firstChild.children[1];
        const dAttr = targetChild.getAttribute("d");
        if (dAttr === null) {
            return [];
        }
        // 2. Remove first 9 chars and split by "C"
        const items = dAttr.substring(9).split("C");
        // 3. Extract and convert numbers from each segment
        return items.map((item) => {
            // a) Replace non-digits with spaces
            const cleaned = item.replace(/[^\d]+/g, " ").trim();
            // b) Split by whitespace
            const parts = cleaned === "" ? [] : cleaned.split(/\s+/);
            // c) Convert string to integers
            return parts.map((str) => parseInt(str, 10));
        });
    }
    /**
     * Calculates value within specified range
     * @param value Input value (0-255)
     * @param minVal Minimum output value
     * @param maxVal Maximum output value
     * @param rounding Whether to use floor (true) or round (false)
     * @returns Calculated value
     * @private
     */
    solve(value, minVal, maxVal, rounding) {
        const result = (value * (maxVal - minVal)) / 255 + minVal;
        return rounding ? Math.floor(result) : Math.round(result * 100) / 100;
    }
    /**
     * Generates animation key from frame data
     * @param frames Array of frame values
     * @param targetTime Target time for animation
     * @returns Animation key string
     * @private
     */
    animate(frames, targetTime) {
        const fromColor = frames.slice(0, 3).concat(1).map(Number);
        const toColor = frames.slice(3, 6).concat(1).map(Number);
        const fromRotation = [0.0];
        const toRotation = [this.solve(frames[6], 60.0, 360.0, true)];
        const remainingFrames = frames.slice(7);
        const curves = remainingFrames.map((item, counter) => this.solve(item, (0,_utils_js__WEBPACK_IMPORTED_MODULE_4__.isOdd)(counter), 1.0, false));
        const cubic = new _cubic_js__WEBPACK_IMPORTED_MODULE_0__["default"](curves);
        const val = cubic.getValue(targetTime);
        const color = (0,_interpolate_js__WEBPACK_IMPORTED_MODULE_2__.interpolate)(fromColor, toColor, val).map((value) => value > 0 ? value : 0);
        const rotation = (0,_interpolate_js__WEBPACK_IMPORTED_MODULE_2__.interpolate)(fromRotation, toRotation, val);
        const matrix = (0,_rotation_js__WEBPACK_IMPORTED_MODULE_3__.convertRotationToMatrix)(rotation[0]);
        // Convert color and matrix values to hex string
        const strArr = color
            .slice(0, -1)
            .map((value) => Math.round(value).toString(16));
        for (const value of matrix) {
            let rounded = Math.round(value * 100) / 100;
            if (rounded < 0) {
                rounded = -rounded;
            }
            const hexValue = (0,_utils_js__WEBPACK_IMPORTED_MODULE_4__.floatToHex)(rounded);
            strArr.push(hexValue.startsWith(".")
                ? `0${hexValue}`.toLowerCase()
                : hexValue || "0");
        }
        strArr.push("0", "0");
        const animationKey = strArr.join("").replace(/[.-]/g, "");
        return animationKey;
    }
    /**
     * Generates animation key used in transaction ID
     * @param keyBytes Key bytes from site verification
     * @param response Optional document to use
     * @returns Animation key string
     * @private
     */
    getAnimationKey(keyBytes, response) {
        const totalTime = 4096;
        if (this.DEFAULT_ROW_INDEX == null || this.DEFAULT_KEY_BYTES_INDICES == null) {
            throw new _errors_js__WEBPACK_IMPORTED_MODULE_1__.IndicesNotInitializedError();
        }
        const rowIndex = keyBytes[this.DEFAULT_ROW_INDEX] % 16;
        // Generate frame time using key byte indices
        let frameTime = this.DEFAULT_KEY_BYTES_INDICES.reduce((num1, num2) => {
            return num1 * (keyBytes[num2] % 16);
        }, 1);
        frameTime = Math.round(frameTime / 10) * 10;
        const arr = this.get2dArray(keyBytes, response);
        if (!arr || !arr[rowIndex]) {
            throw new _errors_js__WEBPACK_IMPORTED_MODULE_1__.AnimationFrameDataError(rowIndex);
        }
        const frameRow = arr[rowIndex];
        const targetTime = frameTime / totalTime;
        const animationKey = this.animate(frameRow, targetTime);
        return animationKey;
    }
    /**
     * Generates a transaction ID for X API requests
     * @param method HTTP method (GET, POST, etc.)
     * @param path API endpoint path
     * @param response Optional document to use
     * @param key Optional key to use
     * @param animationKey Optional animation key to use
     * @param timeNow Optional timestamp (defaults to current time)
     * @returns Base64 encoded transaction ID
     */
    async generateTransactionId(method, path, response, key, animationKey, timeNow) {
        // Check if instance is initialized
        if (!this.isInitialized) {
            throw new _errors_js__WEBPACK_IMPORTED_MODULE_1__.ClientTransactionNotInitializedError();
        }
        timeNow = timeNow || Math.floor((Date.now() - 1682924400 * 1000) / 1000);
        const timeNowBytes = [
            timeNow & 0xff,
            (timeNow >> 8) & 0xff,
            (timeNow >> 16) & 0xff,
            (timeNow >> 24) & 0xff,
        ];
        key = key || this.key || this.getKey(response);
        const keyBytes = key
            ? this.getKeyBytes(key)
            : this.keyBytes || this.getKeyBytes(key);
        animationKey = animationKey ||
            this.animationKey ||
            this.getAnimationKey(keyBytes, response);
        // Generate hash data
        const data = `${method}!${path}!${timeNow}${ClientTransaction.DEFAULT_KEYWORD}${animationKey}`;
        // Calculate SHA-256 hash
        const encoder = new TextEncoder();
        const dataBuffer = encoder.encode(data);
        const hashBuffer = await crypto.subtle.digest("SHA-256", dataBuffer);
        const hashBytes = Array.from(new Uint8Array(hashBuffer));
        const randomNum = Math.floor(Math.random() * 256);
        const bytesArr = [
            ...keyBytes,
            ...timeNowBytes,
            ...hashBytes.slice(0, 16),
            ClientTransaction.ADDITIONAL_RANDOM_NUMBER,
        ];
        const out = new Uint8Array([
            randomNum,
            ...bytesArr.map((item) => item ^ randomNum),
        ]);
        return (0,_deps_jsr_io_std_encoding_1_0_10_mod_js__WEBPACK_IMPORTED_MODULE_5__.encodeBase64)(out).replace(/=/g, "");
    }
}
Object.defineProperty(ClientTransaction, "ADDITIONAL_RANDOM_NUMBER", {
    enumerable: true,
    configurable: true,
    writable: true,
    value: 3
});
Object.defineProperty(ClientTransaction, "DEFAULT_KEYWORD", {
    enumerable: true,
    configurable: true,
    writable: true,
    value: "obfiowerehiring"
});
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (ClientTransaction);


/***/ },

/***/ "./node_modules/x-client-transaction-id/esm/utils.js"
/*!***********************************************************!*\
  !*** ./node_modules/x-client-transaction-id/esm/utils.js ***!
  \***********************************************************/
(__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   floatToHex: () => (/* binding */ floatToHex),
/* harmony export */   handleXMigration: () => (/* binding */ handleXMigration),
/* harmony export */   isOdd: () => (/* binding */ isOdd)
/* harmony export */ });
/* harmony import */ var linkedom__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! linkedom */ "./src/shims/linkedom.ts");
/* harmony import */ var _errors_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./errors.js */ "./node_modules/x-client-transaction-id/esm/errors.js");
/**
 * Utility functions for X client transaction ID generation
 *
 * This module provides helper functions for handling X domain migration,
 * number conversions, and other utility operations.
 */


/**
 * Handles X.com domain migration process and returns the HTML document
 *
 * This function navigates through X's migration redirects and forms
 * to obtain the final HTML document needed for transaction ID generation.
 *
 * @returns Promise resolving to the Document object from X's homepage
 */
async function handleXMigration() {
    // Set headers to mimic a browser request
    const headers = {
        accept: "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7",
        "accept-language": "ja",
        "cache-control": "no-cache",
        pragma: "no-cache",
        priority: "u=0, i",
        "sec-ch-ua": '"Google Chrome";v="135", "Not-A.Brand";v="8", "Chromium";v="135"',
        "sec-ch-ua-mobile": "?0",
        "sec-ch-ua-platform": '"Windows"',
        "sec-fetch-dest": "document",
        "sec-fetch-mode": "navigate",
        "sec-fetch-site": "none",
        "sec-fetch-user": "?1",
        "upgrade-insecure-requests": "1",
        "user-agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/135.0.0.0 Safari/537.36",
    };
    // Fetch X.com homepage
    const response = await fetch("https://x.com", {
        headers,
    });
    if (!response.ok) {
        throw new _errors_js__WEBPACK_IMPORTED_MODULE_1__.XHomePageFetchError(response.status, response.statusText);
    }
    const htmlText = await response.text();
    // Parse HTML using linkedom
    let dom = (0,linkedom__WEBPACK_IMPORTED_MODULE_0__.parseHTML)(htmlText);
    let document = dom.window.document;
    // Check for migration redirection links
    const migrationRedirectionRegex = new RegExp("(http(?:s)?://(?:www\\.)?(twitter|x){1}\\.com(/x)?/migrate([/?])?tok=[a-zA-Z0-9%\\-_]+)+", "i");
    const metaRefresh = document.querySelector("meta[http-equiv='refresh']");
    const metaContent = metaRefresh
        ? metaRefresh.getAttribute("content") || ""
        : "";
    const migrationRedirectionUrl = migrationRedirectionRegex.exec(metaContent) ||
        migrationRedirectionRegex.exec(htmlText);
    if (migrationRedirectionUrl) {
        // Follow redirection URL
        const redirectResponse = await fetch(migrationRedirectionUrl[0]);
        if (!redirectResponse.ok) {
            throw new _errors_js__WEBPACK_IMPORTED_MODULE_1__.XMigrationRedirectionError(redirectResponse.status, redirectResponse.statusText);
        }
        const redirectHtml = await redirectResponse.text();
        dom = (0,linkedom__WEBPACK_IMPORTED_MODULE_0__.parseHTML)(redirectHtml);
        document = dom.window.document;
    }
    // Handle migration form if present
    const migrationForm = document.querySelector("form[name='f']") ||
        document.querySelector("form[action='https://x.com/x/migrate']");
    if (migrationForm) {
        const url = migrationForm.getAttribute("action") ||
            "https://x.com/x/migrate";
        const method = migrationForm.getAttribute("method") || "POST";
        // Collect form input fields
        const requestPayload = new FormData();
        const inputFields = migrationForm.querySelectorAll("input");
        for (const element of Array.from(inputFields)) {
            const name = element.getAttribute("name");
            const value = element.getAttribute("value");
            if (name && value) {
                requestPayload.append(name, value);
            }
        }
        // Submit form using POST request
        const formResponse = await fetch(url, {
            method: method,
            body: requestPayload,
            headers,
        });
        if (!formResponse.ok) {
            throw new _errors_js__WEBPACK_IMPORTED_MODULE_1__.XMigrationFormError(formResponse.status, formResponse.statusText);
        }
        const formHtml = await formResponse.text();
        dom = (0,linkedom__WEBPACK_IMPORTED_MODULE_0__.parseHTML)(formHtml);
        document = dom.window.document;
    }
    // Return final DOM document
    return document;
}
/**
 * Converts a floating point number to hexadecimal string representation
 *
 * @param x Floating point number to convert
 * @returns Hexadecimal string representation of the number
 */
function floatToHex(x) {
    const result = [];
    let quotient = Math.floor(x);
    let fraction = x - quotient;
    // Convert integer part to hex
    while (quotient > 0) {
        quotient = Math.floor(x / 16);
        const remainder = Math.floor(x - quotient * 16);
        if (remainder > 9) {
            result.unshift(String.fromCharCode(remainder + 55)); // Convert to A-F
        }
        else {
            result.unshift(remainder.toString());
        }
        x = quotient;
    }
    if (fraction === 0) {
        return result.join("");
    }
    // Add decimal point for fractional part
    result.push(".");
    // Convert fractional part to hex
    while (fraction > 0) {
        fraction *= 16;
        const integer = Math.floor(fraction);
        fraction -= integer;
        if (integer > 9) {
            result.push(String.fromCharCode(integer + 55)); // Convert to A-F
        }
        else {
            result.push(integer.toString());
        }
    }
    return result.join("");
}
/**
 * Determines if a number is odd and returns a specific value
 *
 * @param num Number to check
 * @returns -1.0 if odd, 0.0 if even
 */
function isOdd(num) {
    if (num % 2) {
        return -1.0;
    }
    return 0.0;
}



/***/ }

/******/ 	});
/************************************************************************/
/******/ 	// The module cache
/******/ 	var __webpack_module_cache__ = {};
/******/ 	
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/ 		// Check if module is in cache
/******/ 		var cachedModule = __webpack_module_cache__[moduleId];
/******/ 		if (cachedModule !== undefined) {
/******/ 			return cachedModule.exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = __webpack_module_cache__[moduleId] = {
/******/ 			// no module.id needed
/******/ 			// no module.loaded needed
/******/ 			exports: {}
/******/ 		};
/******/ 	
/******/ 		// Execute the module function
/******/ 		if (!(moduleId in __webpack_modules__)) {
/******/ 			delete __webpack_module_cache__[moduleId];
/******/ 			var e = new Error("Cannot find module '" + moduleId + "'");
/******/ 			e.code = 'MODULE_NOT_FOUND';
/******/ 			throw e;
/******/ 		}
/******/ 		__webpack_modules__[moduleId](module, module.exports, __webpack_require__);
/******/ 	
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/ 	
/************************************************************************/
/******/ 	/* webpack/runtime/define property getters */
/******/ 	(() => {
/******/ 		// define getter functions for harmony exports
/******/ 		__webpack_require__.d = (exports, definition) => {
/******/ 			for(var key in definition) {
/******/ 				if(__webpack_require__.o(definition, key) && !__webpack_require__.o(exports, key)) {
/******/ 					Object.defineProperty(exports, key, { enumerable: true, get: definition[key] });
/******/ 				}
/******/ 			}
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/hasOwnProperty shorthand */
/******/ 	(() => {
/******/ 		__webpack_require__.o = (obj, prop) => (Object.prototype.hasOwnProperty.call(obj, prop))
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/make namespace object */
/******/ 	(() => {
/******/ 		// define __esModule on exports
/******/ 		__webpack_require__.r = (exports) => {
/******/ 			if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 				Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 			}
/******/ 			Object.defineProperty(exports, '__esModule', { value: true });
/******/ 		};
/******/ 	})();
/******/ 	
/************************************************************************/
var __webpack_exports__ = {};
// This entry needs to be wrapped in an IIFE because it needs to be isolated against other modules in the chunk.
(() => {
/*!**************************************!*\
  !*** ./src/content/main_entrance.ts ***!
  \**************************************/
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _capture_consts__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../capture/consts */ "./src/capture/consts.ts");
/* harmony import */ var _x_api_twitter_api__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../x_api/twitter_api */ "./src/x_api/twitter_api.ts");
/* harmony import */ var _capture_extractor__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../capture/extractor */ "./src/capture/extractor.ts");



/**
 * main_entrance.ts - Content Script Supervisor
 *
 * 职责：
 *  1. 将 injection.js 注入页面上下文
 *  2. 中继 injection → background 的消息（包括 apiUrl、bearerToken）
 *  3. 执行写操作（mutation）—— 唯一合法的写操作执行环境
 */
(function inject() {
    if (document.getElementById('tc_injection'))
        return;
    const script = document.createElement('script');
    script.id = 'tc_injection';
    script.src = chrome.runtime.getURL('js/injection.js');
    (document.head || document.documentElement).appendChild(script);
    script.onload = () => script.remove();
})();
window.addEventListener('message', (event) => {
    if (event.data?.source !== 'tweetclaw-injection')
        return;
    // ── 直接在 Content Script 层捕获 settings.json，立刻写入 storage ──
    // 修复背景：settings.json 是 REST 接口，响应体没有 id_str 字段。
    // background 里的 findViewerSummary 会因为 userId==='' 与 twid cookie uid 不匹配
    // 而 return null，导致 screenName 从未被写入 chrome.storage.local。
    // 解决方式：绕过 background 链路，在 Content Script 自己直接写。
    if (event.data.type === 'SIGNAL_CAPTURED' && event.data.op === 'settings.json') {
        const d = event.data.data;
        const screenName = d?.screen_name;
        const userId = d?.id_str || (d?.id ? String(d.id) : undefined);
        if (screenName) {
            const toStore = { screenName };
            if (userId)
                toStore.userId = userId;
            chrome.storage.local.set(toStore).then(() => {
                console.log(`[TweetClaw-CS] ✅ screenName cached from settings.json: @${screenName}`);
            }).catch(() => { });
        }
    }
    // ── 捕获并缓存 per-operation features ──
    if (event.data.type === 'SIGNAL_CAPTURED' && event.data.features) {
        const op = event.data.op;
        const features = event.data.features;
        // 导入 cacheOperationFeatures 并缓存
        Promise.resolve(/*! import() */).then(__webpack_require__.bind(__webpack_require__, /*! ../x_api/feature_manager */ "./src/x_api/feature_manager.ts")).then(({ cacheOperationFeatures }) => {
            cacheOperationFeatures(op, features).catch(() => { });
        });
    }
    if (event.data.type === 'SIGNAL_CAPTURED') {
        chrome.runtime.sendMessage({
            type: 'CAPTURED_DATA',
            op: event.data.op,
            apiUrl: event.data.apiUrl, // ← 真实 API 端点 URL
            pageUrl: event.data.pageUrl || window.location.href, // ← 当前页面 URL
            method: event.data.method,
            requestBody: event.data.requestBody,
            bearerToken: event.data.bearerToken || null, // ← bearer token（如已从请求头捕获）
            data: event.data.data
        });
    }
    if (event.data.type === 'HOOK_STATUS_REPORT') {
        chrome.runtime.sendMessage({
            type: 'REPORT_HOOK_STATUS',
            status: event.data.status
        });
    }
});
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    if (message.type === _capture_consts__WEBPACK_IMPORTED_MODULE_0__.MsgType.PING || message.type === 'TC_PING') {
        sendResponse({ ok: true, url: window.location.href, context: 'CONTENT_SCRIPT' });
        return true;
    }
    if (message.type === _capture_consts__WEBPACK_IMPORTED_MODULE_0__.MsgType.EXECUTE_ACTION) {
        let op = '';
        let vars = { tweet_id: message.tweetId };
        switch (message.action) {
            case 'like':
                op = 'FavoriteTweet';
                break;
            case 'retweet':
                op = 'CreateRetweet';
                vars.dark_request = false;
                break;
            case 'bookmark':
                op = 'CreateBookmark';
                break;
            case 'follow':
                op = 'CreateFriendship';
                vars = { user_id: message.userId };
                break;
            case 'unfollow':
                op = 'DestroyFriendship';
                vars = { user_id: message.userId };
                break;
            case 'post_tweet':
                // 发布新推文
                op = 'CreateTweet';
                vars = {
                    tweet_text: message.text || '',
                    media: {
                        media_entities: [],
                        possibly_sensitive: false
                    },
                    semantic_annotation_ids: [],
                    broadcast: true,
                    disallowed_reply_options: null
                };
                break;
            case 'reply_tweet':
                // 回复推文
                op = 'CreateTweet';
                vars = {
                    tweet_text: message.text || '',
                    reply: {
                        in_reply_to_tweet_id: message.tweetId,
                        exclude_reply_user_ids: []
                    },
                    media: {
                        media_entities: [],
                        possibly_sensitive: false
                    },
                    semantic_annotation_ids: [],
                    broadcast: true,
                    disallowed_reply_options: null
                };
                break;
            case 'unlike':
                op = 'UnfavoriteTweet';
                vars = { tweet_id: message.tweetId };
                break;
            case 'unretweet':
                op = 'DeleteRetweet';
                vars = { source_tweet_id: message.tweetId };
                break;
            case 'unbookmark':
                op = 'DeleteBookmark';
                vars = { tweet_id: message.tweetId };
                break;
            case 'delete_tweet':
                op = 'DeleteTweet';
                vars = { tweet_id: message.tweetId };
                break;
        }
        if (op) {
            // 针对 Follow/Unfollow 特殊处理：如果还没抓到 GraphQL Hash，直接走 1.1 REST 降级方案
            if (message.action === 'follow' || message.action === 'unfollow') {
                const path = message.action === 'follow' ? '/i/api/1.1/friendships/create.json' : '/i/api/1.1/friendships/destroy.json';
                // 尝试执行，如果 performMutation 报错说明没哈希，我们就直接走 legacy
                (0,_x_api_twitter_api__WEBPACK_IMPORTED_MODULE_1__.performMutation)(op, vars)
                    .then(res => sendResponse({ ok: true, data: res }))
                    .catch(() => {
                    console.log(`[TweetClaw-CS] 🔄 Fallback to Legacy REST: ${path}`);
                    (0,_x_api_twitter_api__WEBPACK_IMPORTED_MODULE_1__.performLegacyREST)(path, { user_id: message.userId })
                        .then(res => sendResponse({ ok: true, data: res }))
                        .catch(err => sendResponse({ ok: false, error: err.message }));
                });
                return true;
            }
            (0,_x_api_twitter_api__WEBPACK_IMPORTED_MODULE_1__.performMutation)(op, vars)
                .then(res => sendResponse({ ok: true, data: res }))
                .catch(err => sendResponse({ ok: false, error: err.message }));
            return true;
        }
    }
    if (message.type === 'FETCH_SETTINGS_AND_PROFILE') {
        (async () => {
            try {
                // 第一步：从 storage 读 screenName
                const stored = await chrome.storage.local.get(['screenName', 'userId']);
                let screenName = stored.screenName;
                // 第二步：如果 storage 里还没有（injection 还没完成拦截），
                // 监听 postMessage 最多等待 4 秒，等 settings.json 被拦截
                if (!screenName) {
                    console.log('[TweetClaw-CS] screenName not in storage, waiting up to 4s for injection...');
                    screenName = await new Promise((resolve) => {
                        const timer = setTimeout(() => {
                            window.removeEventListener('message', onMsg);
                            resolve(undefined);
                        }, 4000);
                        function onMsg(e) {
                            if (e.data?.source === 'tweetclaw-injection' &&
                                e.data?.type === 'SIGNAL_CAPTURED' &&
                                e.data?.op === 'settings.json' &&
                                e.data?.data?.screen_name) {
                                clearTimeout(timer);
                                window.removeEventListener('message', onMsg);
                                const sn = e.data.data.screen_name;
                                const uid = e.data.data.id_str ||
                                    (e.data.data.id ? String(e.data.data.id) : undefined);
                                const toStore = { screenName: sn };
                                if (uid)
                                    toStore.userId = uid;
                                chrome.storage.local.set(toStore).catch(() => { });
                                resolve(sn);
                            }
                        }
                        window.addEventListener('message', onMsg);
                    });
                }
                if (!screenName)
                    throw new Error('screenName not found in storage');
                console.log(`[TweetClaw-CS] Fetching profile for @${screenName}...`);
                const json = await (0,_x_api_twitter_api__WEBPACK_IMPORTED_MODULE_1__.fetchUserByScreenName)(screenName);
                // 用容错递归解析拿到 user result 对象
                const userResult = (0,_capture_extractor__WEBPACK_IMPORTED_MODULE_2__.findDeepUser)(json);
                if (!userResult)
                    throw new Error('findDeepUser returned null');
                sendResponse({ success: true, raw: userResult });
            }
            catch (e) {
                console.error('[TweetClaw-CS] FETCH_SETTINGS_AND_PROFILE fail:', e);
                sendResponse({ success: false, error: e.message });
            }
        })();
        return true; // 保持异步 sendResponse 通道
    }
    if (message.type === 'FETCH_USER_PROFILE_BY_SCREEN_NAME') {
        (async () => {
            try {
                const cleanName = message.screenName.replace('@', '');
                const json = await (0,_x_api_twitter_api__WEBPACK_IMPORTED_MODULE_1__.fetchUserByScreenName)(cleanName);
                const { findDeepUser } = await Promise.resolve(/*! import() */).then(__webpack_require__.bind(__webpack_require__, /*! ../capture/extractor */ "./src/capture/extractor.ts"));
                const userResult = findDeepUser(json);
                if (!userResult)
                    throw new Error('User not found or unavailable');
                const legacy = userResult?.legacy ?? {};
                const data = {
                    userId: userResult?.rest_id || '',
                    screenName: legacy.screen_name || '',
                    name: legacy.name || '',
                    description: legacy.description || '',
                    followersCount: legacy.followers_count,
                    friendsCount: legacy.friends_count,
                    statusesCount: legacy.statuses_count,
                    verified: userResult?.is_blue_verified || legacy.verified || false,
                    createdAt: legacy.created_at || '',
                    avatar: (legacy.profile_image_url_https || '').replace('_normal', '')
                };
                sendResponse({ success: true, data });
            }
            catch (e) {
                sendResponse({ success: false, error: e.message });
            }
        })();
        return true;
    }
    return false;
});
console.log('[TweetClaw-CS] Active.');

})();

/******/ })()
;
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoianMvY29udGVudC5qcyIsIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQUFPO0FBQ0E7QUFDQTtBQUNBO0FBQ1A7QUFDQTtBQUNBO0FBQ0EsQ0FBQywwQkFBMEI7QUFDcEI7QUFDUDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ087QUFDUDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNPO0FBQ1A7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQzNGeUM7QUFDd0I7QUFDVjtBQUN2RDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNPO0FBQ1A7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNPO0FBQ1A7QUFDQTtBQUNBLGdDQUFnQyxRQUFRLEVBQUUsY0FBYztBQUN4RDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNPO0FBQ1A7QUFDQTtBQUNBLGdEQUFnRCxzREFBYTtBQUM3RDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDTztBQUNQO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxZQUFZLHNEQUFhO0FBQ3pCO0FBQ0E7QUFDQTtBQUNBO0FBQ0Esd0JBQXdCLE9BQU87QUFDL0I7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLFlBQVksc0RBQWE7QUFDekI7QUFDQTtBQUNBLHlCQUF5QjtBQUN6QjtBQUNBLHdCQUF3QixpQkFBaUI7QUFDekM7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0Esb0NBQW9DO0FBQ3BDO0FBQ0EsS0FBSztBQUNMO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDTztBQUNQO0FBQ0EsdUJBQXVCLDhFQUF5QjtBQUNoRDtBQUNBO0FBQ0E7QUFDQSxtQ0FBbUMsbUVBQWM7QUFDakQ7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNPO0FBQ1A7QUFDQSx1QkFBdUIsOEVBQXlCO0FBQ2hEO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNPO0FBQ1A7QUFDQSx1QkFBdUIsOEVBQXlCO0FBQ2hEO0FBQ0E7QUFDQSxtQ0FBbUMsbUVBQWM7QUFDakQ7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxTQUFTO0FBQ1Q7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ087QUFDUDtBQUNBLHVCQUF1Qiw4RUFBeUI7QUFDaEQ7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsU0FBUztBQUNUO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ087QUFDUDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0Esc0JBQXNCO0FBQ3RCO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7Ozs7Ozs7Ozs7Ozs7O0FDN1JBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ087QUFDUDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsMkJBQTJCLHVCQUF1QjtBQUNsRDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsK0JBQStCLFlBQVk7QUFDM0M7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsU0FBUztBQUNUO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7Ozs7Ozs7Ozs7Ozs7O0FDekxBO0FBQ087QUFDUDtBQUNBO0FBQ0EsYUFBYSxVQUFVO0FBQ3ZCOzs7Ozs7Ozs7Ozs7Ozs7O0FDTE87QUFDUDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNPO0FBQ1A7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUMvQkE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQzJEO0FBQzNEO0FBQ087QUFDUDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNPO0FBQ1A7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxnREFBZ0QsbUVBQXNCO0FBQ3RFLDBCQUEwQixtRUFBc0IsT0FBTztBQUN2RDtBQUNBO0FBQ0EseUNBQXlDLENBQUMsbUVBQXNCLFlBQVk7QUFDNUU7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNPO0FBQ1AsaURBQWlELG1FQUFzQjtBQUN2RSxnQ0FBZ0MsbUVBQXNCLE9BQU87QUFDN0QsNERBQTREO0FBQzVELG9EQUFvRDtBQUNwRCxhQUFhO0FBQ2I7QUFDQTtBQUNBO0FBQ0E7QUFDTztBQUNQO0FBQ0EsNERBQTREO0FBQzVEO0FBQ0EsMEJBQTBCLDJCQUEyQjtBQUNyRCxxQ0FBcUMsd0NBQXdDO0FBQzdFLDJEQUEyRCxHQUFHO0FBQzlEO0FBQ0E7QUFDQTtBQUNBO0FBQ087QUFDUDtBQUNBLDREQUE0RDtBQUM1RDtBQUNBOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQzdFMkU7QUFDRjtBQUM1QjtBQUM3QztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsK0NBQStDLCtEQUFrQjtBQUNqRSxlQUFlLCtEQUFrQjtBQUNqQztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsbURBQW1ELFlBQVk7QUFDL0Q7QUFDQTtBQUNBO0FBQ0E7QUFDQSw2QkFBNkIsbUNBQW1DO0FBQ2hFO0FBQ0EsU0FBUztBQUNULEtBQUs7QUFDTDtBQUNBO0FBQ0EsK0NBQStDLCtEQUFrQjtBQUNqRSxxQkFBcUIsK0RBQWtCLE9BQU87QUFDOUM7QUFDQTtBQUNBO0FBQ0EsK0NBQStDLFFBQVEsR0FBRyxHQUFHO0FBQzdELG1DQUFtQyxRQUFRLEdBQUcsR0FBRztBQUNqRCxhQUFhO0FBQ2I7QUFDTztBQUNQO0FBQ0E7QUFDQSxvRUFBb0UsR0FBRztBQUN2RTtBQUNBO0FBQ0E7QUFDQSx1QkFBdUIsMERBQW1CO0FBQzFDO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSwrQkFBK0IsK0RBQWE7QUFDNUM7QUFDQSxvQ0FBb0MsSUFBSTtBQUN4QztBQUNBO0FBQ0Esb0NBQW9DLElBQUk7QUFDeEM7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsS0FBSztBQUNMO0FBQ0E7QUFDQSxzQ0FBc0MsSUFBSSxVQUFVLGdCQUFnQjtBQUNwRTtBQUNBLHFDQUFxQyx1RUFBcUI7QUFDMUQ7QUFDQTtBQUNBLHlDQUF5QyxJQUFJLG1CQUFtQixlQUFlO0FBQy9FO0FBQ0E7QUFDQSx1Q0FBdUMsaUJBQWlCLE1BQU0sR0FBRyxJQUFJLEtBQUs7QUFDMUU7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDTztBQUNQO0FBQ0E7QUFDQSx1QkFBdUIsMERBQW1CO0FBQzFDO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsZ0NBQWdDLEtBQUs7QUFDckM7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsS0FBSztBQUNMO0FBQ0E7QUFDQSw4Q0FBOEMsaUJBQWlCLE1BQU0sS0FBSyxJQUFJLEtBQUs7QUFDbkY7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDTztBQUNQO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLCtDQUErQyxZQUFZLG9CQUFvQixrQkFBa0I7QUFDakc7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsOERBQThELCtCQUErQixTQUFTLGtDQUFrQztBQUN4STtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLFNBQVM7QUFDVDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsdUVBQXVFLGdCQUFnQjtBQUN2RjtBQUNBO0FBQ0EsNkRBQTZELGdCQUFnQjtBQUM3RSxvREFBb0QsZ0JBQWdCO0FBQ3BFO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDTztBQUNQO0FBQ0E7QUFDQSxvRUFBb0UsR0FBRztBQUN2RTtBQUNBO0FBQ0EsMkJBQTJCLCtEQUFhO0FBQ3hDO0FBQ0E7QUFDQTtBQUNBLG1CQUFtQixXQUFXLEdBQUcsa0JBQWtCO0FBQ25EO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsS0FBSztBQUNMO0FBQ0E7QUFDQSxjQUFjLHVFQUFxQjtBQUNuQztBQUNBO0FBQ0EseUNBQXlDLElBQUk7QUFDN0M7QUFDQTtBQUNBO0FBQ0EsdUNBQXVDLGlCQUFpQixNQUFNLEdBQUcsSUFBSSxLQUFLO0FBQzFFO0FBQ0E7QUFDQSx3Q0FBd0MsSUFBSTtBQUM1QztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ087QUFDUDtBQUNBO0FBQ0E7QUFDQTtBQUNBLEtBQUs7QUFDTDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNPO0FBQ1A7QUFDQTtBQUNBO0FBQ0EsS0FBSztBQUNMO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7Ozs7Ozs7Ozs7Ozs7OztBQ2pRQTtBQUNBO0FBQ0E7QUFDQTtBQUM0RDtBQUM1RDtBQUNBO0FBQ0E7QUFDQTtBQUNBLG1EQUFtRDtBQUNuRCxvREFBb0QscUJBQXFCO0FBQ3pFO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNPO0FBQ1A7QUFDQSxxQkFBcUIsc0VBQWlCO0FBQ3RDO0FBQ0E7Ozs7Ozs7Ozs7OztBQ3JCVTs7Ozs7Ozs7Ozs7Ozs7O0FDQVY7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLFNBQVM7QUFDVDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxpRUFBZSxLQUFLLEVBQUM7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUM5RXJCO0FBQ087QUFDQSxnREFBZ0Q7QUFDdkQ7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsSUFBSSx3QkFBd0I7QUFDNUI7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsWUFBWSxlQUFlO0FBQzNCLFlBQVksY0FBYztBQUMxQjtBQUNBO0FBQ0E7QUFDQTtBQUNPO0FBQ1A7QUFDQTtBQUNPO0FBQ1AsV0FBVyxtQkFBbUI7QUFDOUI7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ087QUFDUDtBQUNBLG9FQUFvRSxrQkFBa0I7QUFDdEY7QUFDQTtBQUNBLFdBQVcsbUJBQW1CO0FBQzlCO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsdUJBQXVCO0FBQ3ZCLDhFQUE4RSwwQkFBMEI7QUFDeEc7QUFDQTtBQUNBOzs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQ2xEQTtBQUNPO0FBQ0E7QUFDUDtBQUNBO0FBQ0E7QUFDQTtBQUNPO0FBQ1A7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsSUFBSSwyQkFBMkI7QUFDL0I7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsWUFBWSxlQUFlO0FBQzNCLFlBQVksaUJBQWlCO0FBQzdCO0FBQ0E7QUFDQTtBQUNBO0FBQ087QUFDUDtBQUNBO0FBQ087QUFDUDtBQUNBLFdBQVcsbUJBQW1CO0FBQzlCO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDTztBQUNQLG9DQUFvQyxtQkFBbUI7QUFDdkQ7QUFDQSxnQ0FBZ0MsbUJBQW1CO0FBQ25EO0FBQ0EsNkZBQTZGLCtCQUErQjtBQUM1SDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLDJFQUEyRSxrQkFBa0I7QUFDN0Y7QUFDQTtBQUNBLFdBQVcsbUJBQW1CO0FBQzlCO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLHVCQUF1QjtBQUN2QixpRkFBaUYsMEJBQTBCO0FBQzNHO0FBQ0E7QUFDQTs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUMvTEE7QUFDTztBQUNBO0FBQ1A7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNPO0FBQ1A7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsSUFBSSwyQkFBMkI7QUFDL0I7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsWUFBWSxlQUFlO0FBQzNCLFlBQVksaUJBQWlCO0FBQzdCO0FBQ0E7QUFDQTtBQUNBO0FBQ087QUFDUDtBQUNBO0FBQ087QUFDUDtBQUNBLFdBQVcsbUJBQW1CO0FBQzlCO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDTztBQUNQLG9DQUFvQyxtQkFBbUI7QUFDdkQ7QUFDQSxnQ0FBZ0MsbUJBQW1CO0FBQ25EO0FBQ0EsNkZBQTZGLCtCQUErQjtBQUM1SDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLHVFQUF1RSxrQkFBa0I7QUFDekY7QUFDQTtBQUNBLFdBQVcsbUJBQW1CO0FBQzlCO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsdUJBQXVCO0FBQ3ZCLGlGQUFpRiwwQkFBMEI7QUFDM0c7QUFDQTtBQUNBOzs7Ozs7Ozs7Ozs7Ozs7QUNoSEE7QUFDTztBQUNQO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7Ozs7Ozs7Ozs7Ozs7OztBQ1pBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDTztBQUNQO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLDJJQUEySSxvQkFBb0I7QUFDL0o7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDekJBO0FBQ0E7QUFDQTtBQUNBLCtCQUErQix1REFBdUQ7QUFDdEY7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0Esa0JBQWtCLDZDQUE2QztBQUMvRCxJQUFJLDZEQUE2RDtBQUNqRTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDZ0U7QUFDaEUsMEZBQTBGLFNBQVMsRUFBRTtBQUNyRyw4RkFBOEY7QUFDOUY7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxZQUFZLGdCQUFnQjtBQUM1QixZQUFZLGVBQWU7QUFDM0I7QUFDQTtBQUNBO0FBQ0E7QUFDTyx5Q0FBeUM7QUFDaEQsZ0JBQWdCLDRFQUFrQjtBQUNsQyxZQUFZLHFCQUFxQjtBQUNqQztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0Esb0JBQW9CLGtCQUFrQjtBQUN0QztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLHdCQUF3QixRQUFRO0FBQ2hDO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSw0QkFBNEIscURBQXFEO0FBQ2pGO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsdUNBQXVDO0FBQ3ZDO0FBQ0EsOEJBQThCO0FBQzlCO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxZQUFZLGdCQUFnQjtBQUM1QixZQUFZLGVBQWU7QUFDM0I7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDTyw0Q0FBNEM7QUFDbkQsWUFBWSxxQkFBcUI7QUFDakM7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLG9CQUFvQixRQUFRO0FBQzVCLHVCQUF1QixTQUFTO0FBQ2hDO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQ3ZKQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsSUFBSTtBQUNKO0FBQ0E7QUFDQSxrQkFBa0IsOENBQThDO0FBQ2hFO0FBQ0E7QUFDQSxZQUFZLDZCQUE2QjtBQUN6QyxZQUFZLGVBQWU7QUFDM0I7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNnRTtBQUNuQjtBQUM3QztBQUNBO0FBQ0E7QUFDQSxnREFBZ0Q7QUFDaEQ7QUFDQTtBQUNBO0FBQ0E7QUFDQSxTQUFTO0FBQ1Q7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsWUFBWSxlQUFlO0FBQzNCLFlBQVksZUFBZTtBQUMzQjtBQUNBO0FBQ0E7QUFDQTtBQUNPO0FBQ1A7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSx3QkFBd0IseURBQU0sT0FBTyw0REFBYztBQUNuRCxJQUFJLG9EQUFNO0FBQ1Y7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLFNBQVM7QUFDVDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxZQUFZLGVBQWU7QUFDM0IsWUFBWSxlQUFlO0FBQzNCO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ087QUFDUDtBQUNBO0FBQ0EsOERBQThELGNBQWM7QUFDNUU7QUFDQTtBQUNBO0FBQ0Esa0JBQWtCLG9EQUFNO0FBQ3hCOzs7Ozs7Ozs7Ozs7Ozs7OztBQ3RGQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLElBQUk7QUFDSjtBQUNBO0FBQ0E7QUFDQSxZQUFZLDZCQUE2QjtBQUN6QyxZQUFZLGVBQWU7QUFDM0I7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDZ0U7QUFDaEU7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxTQUFTO0FBQ1Q7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsWUFBWSxlQUFlO0FBQzNCLFlBQVksZUFBZTtBQUMzQjtBQUNBO0FBQ0E7QUFDQTtBQUNPO0FBQ1AsdUJBQXVCLDRFQUFrQjtBQUN6QztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsNkNBQTZDLHFEQUFxRDtBQUNsRztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsS0FBSztBQUNMO0FBQ0E7QUFDQSxLQUFLO0FBQ0w7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsU0FBUztBQUNUO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLFlBQVksZUFBZTtBQUMzQixZQUFZLGVBQWU7QUFDM0I7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDTztBQUNQO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsZ0VBQWdFLEtBQUssYUFBYSxLQUFLO0FBQ3ZGO0FBQ0EsNkNBQTZDLHFEQUFxRDtBQUNsRztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsS0FBSztBQUNMO0FBQ0E7QUFDQSx3Q0FBd0MsY0FBYztBQUN0RDtBQUNBO0FBQ0E7QUFDQTs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDbElBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsSUFBSTtBQUNKO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLEtBQUs7QUFDTCxZQUFZLGVBQWU7QUFDM0I7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ2dFO0FBQ25CO0FBQzdDO0FBQ0E7QUFDQTtBQUNBLGdEQUFnRDtBQUNoRDtBQUNBO0FBQ0E7QUFDQTtBQUNBLFNBQVM7QUFDVDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxZQUFZLGVBQWU7QUFDM0IsWUFBWSxlQUFlO0FBQzNCO0FBQ0E7QUFDQTtBQUNBO0FBQ087QUFDUDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLHdCQUF3Qix5REFBTSxPQUFPLDREQUFjO0FBQ25ELElBQUksb0RBQU07QUFDVjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsU0FBUztBQUNUO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLFlBQVksZUFBZTtBQUMzQixZQUFZLGVBQWU7QUFDM0I7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDTztBQUNQO0FBQ0E7QUFDQTtBQUNBLGtCQUFrQixvREFBTTtBQUN4Qjs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDakZBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsSUFBSTtBQUNKO0FBQ0E7QUFDQTtBQUNBO0FBQ2dFO0FBQ25CO0FBQzdDO0FBQ0E7QUFDQTtBQUNBLGdEQUFnRDtBQUNoRDtBQUNBO0FBQ0E7QUFDQTtBQUNBLFNBQVM7QUFDVDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxZQUFZLGtCQUFrQjtBQUM5QixZQUFZLGVBQWU7QUFDM0I7QUFDQTtBQUNBO0FBQ0E7QUFDTztBQUNQO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0Esd0JBQXdCLHlEQUFNLE9BQU8sNERBQWM7QUFDbkQsWUFBWSxvREFBTTtBQUNsQjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsU0FBUztBQUNUO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLFlBQVksa0JBQWtCO0FBQzlCLFlBQVksZUFBZTtBQUMzQjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNPO0FBQ1A7QUFDQTtBQUNBO0FBQ0Esa0JBQWtCLG9EQUFNO0FBQ3hCOzs7Ozs7Ozs7Ozs7Ozs7Ozs7QUN2RUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsSUFBSTtBQUNKO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLEtBQUs7QUFDTCxZQUFZLGVBQWU7QUFDM0I7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUM2RDtBQUNoQjtBQUM3QztBQUNBO0FBQ0EsZ0RBQWdEO0FBQ2hEO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsWUFBWSxZQUFZO0FBQ3hCLFlBQVksZUFBZTtBQUMzQjtBQUNBO0FBQ0E7QUFDQTtBQUNPO0FBQ1A7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSx3QkFBd0IseURBQU0sTUFBTSx5REFBVztBQUMvQyxJQUFJLG9EQUFNO0FBQ1Y7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsWUFBWSxZQUFZO0FBQ3hCLFlBQVksZUFBZTtBQUMzQjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNPO0FBQ1A7QUFDQTtBQUNBO0FBQ0Esa0JBQWtCLG9EQUFNO0FBQ3hCOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUN0RkE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLFlBQVksNkJBQTZCO0FBQ3pDLFlBQVksZUFBZTtBQUMzQjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsS0FBSztBQUNMLFlBQVksZUFBZTtBQUMzQjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLFlBQVksZ0NBQWdDO0FBQzVDLFlBQVksZUFBZTtBQUMzQjtBQUNBLGlFQUFpRTtBQUNqRSxrRUFBa0U7QUFDbEU7QUFDQTtBQUNBLDREQUE0RDtBQUM1RCwrREFBK0Q7QUFDL0Q7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLFlBQVksMEJBQTBCO0FBQ3RDLFlBQVksZUFBZTtBQUMzQjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxZQUFZLDZCQUE2QjtBQUN6QyxZQUFZLGVBQWU7QUFDM0I7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUM2QjtBQUNEO0FBQ0E7QUFDQTtBQUNHO0FBQ047QUFDRzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUNsRzVCO0FBQ0E7QUFDQTtBQUNBO0FBQ0Esa0JBQWtCLHdFQUF3RTtBQUMxRjtBQUNBO0FBQ0E7QUFDQTtBQUNBLFlBQVksNkJBQTZCO0FBQ3pDLFlBQVksZUFBZTtBQUMzQjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNPO0FBQ1A7QUFDQTtBQUNBO0FBQ087QUFDUDtBQUNBO0FBQ0E7QUFDTztBQUNQO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsWUFBWSxlQUFlO0FBQzNCLFlBQVksZUFBZTtBQUMzQjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ087QUFDUDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxNQUFNO0FBQ047QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLFlBQVksaUJBQWlCO0FBQzdCLFlBQVksZUFBZTtBQUMzQjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ087QUFDUDtBQUNBO0FBQ0EseUJBQXlCLG9EQUFvRDtBQUM3RTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxZQUFZLGVBQWU7QUFDM0IsWUFBWSxlQUFlO0FBQzNCO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDTztBQUNQO0FBQ0E7QUFDQSxtSEFBbUgsSUFBSTtBQUN2SDtBQUNBLHlCQUF5QiwyQ0FBMkM7QUFDcEU7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLG9EQUFvRCxLQUFLO0FBQ3pEOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDNU1BO0FBQ0E7QUFDQTtBQUNBO0FBQ0EscUNBQXFDO0FBQ3JDLHlDQUF5Qyx1QkFBdUI7QUFDaEU7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLFNBQVM7QUFDVDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EscUNBQXFDO0FBQ3JDO0FBQ0E7QUFDQTtBQUNBLFNBQVM7QUFDVDtBQUNBO0FBQ0E7QUFDQTtBQUNBLHlGQUF5Riw0Q0FBNEM7QUFDckk7QUFDQTtBQUNBO0FBQ0E7QUFDQSw0REFBNEQsSUFBSSxLQUFLLFFBQVEsRUFBRSxXQUFXLE1BQU0sbUNBQW1DO0FBQ25JO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxTQUFTO0FBQ1Q7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLFNBQVM7QUFDVDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsU0FBUztBQUNUO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsaUZBQWlGLDJDQUEyQztBQUM1SDtBQUNBO0FBQ0E7QUFDQTtBQUNBLG1HQUFtRywrQ0FBK0M7QUFDbEo7QUFDQTtBQUNBO0FBQ0E7QUFDQSxzSEFBc0gsdUNBQXVDO0FBQzdKO0FBQ0E7QUFDQTtBQUNBO0FBQ0Esd0RBQXdELFNBQVMsc0RBQXNELG9DQUFvQztBQUMzSjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsU0FBUztBQUNUO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSwwSEFBMEgsa0RBQWtEO0FBQzVLO0FBQ0E7QUFDQTtBQUNBLHFDQUFxQztBQUNyQztBQUNBO0FBQ0E7QUFDQSxTQUFTO0FBQ1Q7QUFDQTtBQUNBO0FBQ0E7QUFDQSxpREFBaUQsUUFBUSxFQUFFLFdBQVcsTUFBTSxnQ0FBZ0M7QUFDNUc7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLFNBQVM7QUFDVDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsU0FBUztBQUNUO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLDREQUE0RCxRQUFRLEVBQUUsV0FBVyxNQUFNLHVDQUF1QztBQUM5SDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsU0FBUztBQUNUO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxTQUFTO0FBQ1Q7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0Esd0RBQXdELFFBQVEsRUFBRSxXQUFXLE1BQU0sZ0NBQWdDO0FBQ25IO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxTQUFTO0FBQ1Q7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLFNBQVM7QUFDVDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxnRkFBZ0YsWUFBWSxNQUFNLFNBQVMsTUFBTSxtQ0FBbUM7QUFDcEo7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLFNBQVM7QUFDVDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsU0FBUztBQUNUO0FBQ0E7QUFDQTtBQUNBO0FBQ21aOzs7Ozs7Ozs7Ozs7Ozs7OztBQzNLblo7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDc0Q7QUFDdEQ7QUFDQTtBQUNBLGtCQUFrQiwrREFBdUI7QUFDekM7QUFDQTtBQUNBLG9CQUFvQixxQkFBcUI7QUFDekM7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUN1Qzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUN4Q3ZDO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDNkI7QUFDb0I7QUFDbEI7QUFDdVk7QUFDdlc7QUFDUDtBQUNTO0FBQ3NCO0FBQzZjO0FBQ3BpQixpRUFBZSx1REFBaUIsRUFBQzs7Ozs7Ozs7Ozs7Ozs7OztBQ3BCakM7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUM2RDs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDbkM3RDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDK0I7QUFDbU47QUFDbk07QUFDUztBQUNUO0FBQ3dDO0FBQ3ZGO0FBQ0EsaUNBQWlDLElBQUk7QUFDckMseUVBQXlFLDhDQUE4QztBQUN2SDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsOERBQThELHFCQUFxQixHQUFHLHFCQUFxQjtBQUMzRztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLFNBQVM7QUFDVDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsU0FBUztBQUNUO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxTQUFTO0FBQ1Q7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLFNBQVM7QUFDVDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsU0FBUztBQUNUO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxTQUFTO0FBQ1Q7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLFNBQVM7QUFDVDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxzQkFBc0IsOERBQXNCO0FBQzVDO0FBQ0E7QUFDQTtBQUNBO0FBQ0EscUNBQXFDO0FBQ3JDO0FBQ0E7QUFDQTtBQUNBO0FBQ0Esc0JBQXNCLHFFQUE2QjtBQUNuRDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0Esa0JBQWtCLHNFQUE4QjtBQUNoRDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLHNCQUFzQix3RUFBZ0M7QUFDdEQ7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSwwQkFBMEIscUZBQVk7QUFDdEM7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EseUJBQXlCO0FBQ3pCO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsU0FBUztBQUNUO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLCtFQUErRSxnREFBSztBQUNwRiwwQkFBMEIsaURBQUs7QUFDL0I7QUFDQSxzQkFBc0IsNERBQVc7QUFDakMseUJBQXlCLDREQUFXO0FBQ3BDLHVCQUF1QixxRUFBdUI7QUFDOUM7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsNkJBQTZCLHFEQUFVO0FBQ3ZDO0FBQ0Esc0JBQXNCLFNBQVM7QUFDL0I7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxzQkFBc0Isa0VBQTBCO0FBQ2hEO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxTQUFTO0FBQ1Q7QUFDQTtBQUNBO0FBQ0Esc0JBQXNCLCtEQUF1QjtBQUM3QztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLHNCQUFzQiw0RUFBb0M7QUFDMUQ7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSx3QkFBd0IsT0FBTyxHQUFHLEtBQUssR0FBRyxRQUFRLEVBQUUsa0NBQWtDLEVBQUUsYUFBYTtBQUNyRztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLGVBQWUscUZBQVk7QUFDM0I7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxDQUFDO0FBQ0Q7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLENBQUM7QUFDRCxpRUFBZSxpQkFBaUIsRUFBQzs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQy9XakM7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ3FDO0FBQytEO0FBQ3BHO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxpRUFBaUUsMkNBQTJDLGtDQUFrQyxLQUFLO0FBQ25KO0FBQ0E7QUFDQTtBQUNBO0FBQ0Esc0NBQXNDLHVCQUF1QixrQkFBa0I7QUFDL0U7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxxREFBcUQsT0FBTztBQUM1RDtBQUNBO0FBQ0E7QUFDQTtBQUNBLEtBQUs7QUFDTDtBQUNBLGtCQUFrQiwyREFBbUI7QUFDckM7QUFDQTtBQUNBO0FBQ0EsY0FBYyxtREFBUztBQUN2QjtBQUNBO0FBQ0EsdUZBQXVGLEVBQUU7QUFDekY7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxzQkFBc0Isa0VBQTBCO0FBQ2hEO0FBQ0E7QUFDQSxjQUFjLG1EQUFTO0FBQ3ZCO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLFNBQVM7QUFDVDtBQUNBLHNCQUFzQiwyREFBbUI7QUFDekM7QUFDQTtBQUNBLGNBQWMsbURBQVM7QUFDdkI7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLGlFQUFpRTtBQUNqRTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsNERBQTREO0FBQzVEO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQytDOzs7Ozs7O1VDckovQztVQUNBOztVQUVBO1VBQ0E7VUFDQTtVQUNBO1VBQ0E7VUFDQTtVQUNBO1VBQ0E7VUFDQTtVQUNBO1VBQ0E7VUFDQTtVQUNBOztVQUVBO1VBQ0E7VUFDQTtVQUNBO1VBQ0E7VUFDQTtVQUNBO1VBQ0E7O1VBRUE7VUFDQTtVQUNBOzs7OztXQzVCQTtXQUNBO1dBQ0E7V0FDQTtXQUNBLHlDQUF5Qyx3Q0FBd0M7V0FDakY7V0FDQTtXQUNBLEU7Ozs7O1dDUEEsd0Y7Ozs7O1dDQUE7V0FDQTtXQUNBO1dBQ0EsdURBQXVELGlCQUFpQjtXQUN4RTtXQUNBLGdEQUFnRCxhQUFhO1dBQzdELEU7Ozs7Ozs7Ozs7Ozs7O0FDTjRDO0FBQ3FEO0FBQzdDO0FBQ3BEO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsQ0FBQztBQUNEO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsOEJBQThCO0FBQzlCO0FBQ0E7QUFDQTtBQUNBLHVGQUF1RixXQUFXO0FBQ2xHLGFBQWEsaUJBQWlCO0FBQzlCO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsUUFBUSxzSkFBa0MsU0FBUyx3QkFBd0I7QUFDM0UsZ0VBQWdFO0FBQ2hFLFNBQVM7QUFDVDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsU0FBUztBQUNUO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxTQUFTO0FBQ1Q7QUFDQSxDQUFDO0FBQ0Q7QUFDQSx5QkFBeUIsb0RBQU87QUFDaEMsdUJBQXVCLGdFQUFnRTtBQUN2RjtBQUNBO0FBQ0EseUJBQXlCLG9EQUFPO0FBQ2hDO0FBQ0EscUJBQXFCO0FBQ3JCO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EseUJBQXlCO0FBQ3pCO0FBQ0E7QUFDQTtBQUNBLHlCQUF5QjtBQUN6QjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxxQkFBcUI7QUFDckI7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxxQkFBcUI7QUFDckI7QUFDQTtBQUNBO0FBQ0EscUJBQXFCO0FBQ3JCO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EseUJBQXlCO0FBQ3pCO0FBQ0E7QUFDQTtBQUNBLHlCQUF5QjtBQUN6QjtBQUNBO0FBQ0E7QUFDQSx5QkFBeUI7QUFDekI7QUFDQTtBQUNBO0FBQ0EseUJBQXlCO0FBQ3pCO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsZ0JBQWdCLG1FQUFlO0FBQy9CLGdEQUFnRCxxQkFBcUI7QUFDckU7QUFDQSw4RUFBOEUsS0FBSztBQUNuRixvQkFBb0IscUVBQWlCLFNBQVMseUJBQXlCO0FBQ3ZFLG9EQUFvRCxxQkFBcUI7QUFDekUscURBQXFELCtCQUErQjtBQUNwRixpQkFBaUI7QUFDakI7QUFDQTtBQUNBLFlBQVksbUVBQWU7QUFDM0IsNENBQTRDLHFCQUFxQjtBQUNqRSw2Q0FBNkMsK0JBQStCO0FBQzVFO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSx5QkFBeUI7QUFDekI7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxrREFBa0Q7QUFDbEQ7QUFDQTtBQUNBLGlGQUFpRjtBQUNqRjtBQUNBO0FBQ0E7QUFDQTtBQUNBLHFCQUFxQjtBQUNyQjtBQUNBO0FBQ0E7QUFDQSxvRUFBb0UsV0FBVztBQUMvRSxtQ0FBbUMseUVBQXFCO0FBQ3hEO0FBQ0EsbUNBQW1DLGdFQUFZO0FBQy9DO0FBQ0E7QUFDQSwrQkFBK0IsZ0NBQWdDO0FBQy9EO0FBQ0E7QUFDQTtBQUNBLCtCQUErQixrQ0FBa0M7QUFDakU7QUFDQSxTQUFTO0FBQ1QscUJBQXFCO0FBQ3JCO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxtQ0FBbUMseUVBQXFCO0FBQ3hELHdCQUF3QixlQUFlLFFBQVEsOElBQThCO0FBQzdFO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsK0JBQStCLHFCQUFxQjtBQUNwRDtBQUNBO0FBQ0EsK0JBQStCLGtDQUFrQztBQUNqRTtBQUNBLFNBQVM7QUFDVDtBQUNBO0FBQ0E7QUFDQSxDQUFDO0FBQ0QiLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9Ud2VldENsYXcvLi9zcmMvY2FwdHVyZS9jb25zdHMudHMiLCJ3ZWJwYWNrOi8vVHdlZXRDbGF3Ly4vc3JjL2NhcHR1cmUvZXh0cmFjdG9yLnRzIiwid2VicGFjazovL1R3ZWV0Q2xhdy8uL3NyYy9jYXB0dXJlL3RpbWVsaW5lLWV4dHJhY3Rvci50cyIsIndlYnBhY2s6Ly9Ud2VldENsYXcvLi9zcmMvc2hpbXMvbGlua2Vkb20udHMiLCJ3ZWJwYWNrOi8vVHdlZXRDbGF3Ly4vc3JjL3V0aWxzL3JvdXRlLXBhcnNlci50cyIsIndlYnBhY2s6Ly9Ud2VldENsYXcvLi9zcmMveF9hcGkvZmVhdHVyZV9tYW5hZ2VyLnRzIiwid2VicGFjazovL1R3ZWV0Q2xhdy8uL3NyYy94X2FwaS90d2l0dGVyX2FwaS50cyIsIndlYnBhY2s6Ly9Ud2VldENsYXcvLi9zcmMveF9hcGkvdHhpZC50cyIsIndlYnBhY2s6Ly9Ud2VldENsYXcvLi9ub2RlX21vZHVsZXMveC1jbGllbnQtdHJhbnNhY3Rpb24taWQvZXNtL19kbnQucG9seWZpbGxzLmpzIiwid2VicGFjazovL1R3ZWV0Q2xhdy8uL25vZGVfbW9kdWxlcy94LWNsaWVudC10cmFuc2FjdGlvbi1pZC9lc20vY3ViaWMuanMiLCJ3ZWJwYWNrOi8vVHdlZXRDbGF3Ly4vbm9kZV9tb2R1bGVzL3gtY2xpZW50LXRyYW5zYWN0aW9uLWlkL2VzbS9kZXBzL2pzci5pby9Ac3RkL2VuY29kaW5nLzEuMC4xMC9fY29tbW9uMTYuanMiLCJ3ZWJwYWNrOi8vVHdlZXRDbGF3Ly4vbm9kZV9tb2R1bGVzL3gtY2xpZW50LXRyYW5zYWN0aW9uLWlkL2VzbS9kZXBzL2pzci5pby9Ac3RkL2VuY29kaW5nLzEuMC4xMC9fY29tbW9uMzIuanMiLCJ3ZWJwYWNrOi8vVHdlZXRDbGF3Ly4vbm9kZV9tb2R1bGVzL3gtY2xpZW50LXRyYW5zYWN0aW9uLWlkL2VzbS9kZXBzL2pzci5pby9Ac3RkL2VuY29kaW5nLzEuMC4xMC9fY29tbW9uNjQuanMiLCJ3ZWJwYWNrOi8vVHdlZXRDbGF3Ly4vbm9kZV9tb2R1bGVzL3gtY2xpZW50LXRyYW5zYWN0aW9uLWlkL2VzbS9kZXBzL2pzci5pby9Ac3RkL2VuY29kaW5nLzEuMC4xMC9fY29tbW9uX2RldGFjaC5qcyIsIndlYnBhY2s6Ly9Ud2VldENsYXcvLi9ub2RlX21vZHVsZXMveC1jbGllbnQtdHJhbnNhY3Rpb24taWQvZXNtL2RlcHMvanNyLmlvL0BzdGQvZW5jb2RpbmcvMS4wLjEwL192YWxpZGF0ZV9iaW5hcnlfbGlrZS5qcyIsIndlYnBhY2s6Ly9Ud2VldENsYXcvLi9ub2RlX21vZHVsZXMveC1jbGllbnQtdHJhbnNhY3Rpb24taWQvZXNtL2RlcHMvanNyLmlvL0BzdGQvZW5jb2RpbmcvMS4wLjEwL2FzY2lpODUuanMiLCJ3ZWJwYWNrOi8vVHdlZXRDbGF3Ly4vbm9kZV9tb2R1bGVzL3gtY2xpZW50LXRyYW5zYWN0aW9uLWlkL2VzbS9kZXBzL2pzci5pby9Ac3RkL2VuY29kaW5nLzEuMC4xMC9iYXNlMzIuanMiLCJ3ZWJwYWNrOi8vVHdlZXRDbGF3Ly4vbm9kZV9tb2R1bGVzL3gtY2xpZW50LXRyYW5zYWN0aW9uLWlkL2VzbS9kZXBzL2pzci5pby9Ac3RkL2VuY29kaW5nLzEuMC4xMC9iYXNlNTguanMiLCJ3ZWJwYWNrOi8vVHdlZXRDbGF3Ly4vbm9kZV9tb2R1bGVzL3gtY2xpZW50LXRyYW5zYWN0aW9uLWlkL2VzbS9kZXBzL2pzci5pby9Ac3RkL2VuY29kaW5nLzEuMC4xMC9iYXNlNjQuanMiLCJ3ZWJwYWNrOi8vVHdlZXRDbGF3Ly4vbm9kZV9tb2R1bGVzL3gtY2xpZW50LXRyYW5zYWN0aW9uLWlkL2VzbS9kZXBzL2pzci5pby9Ac3RkL2VuY29kaW5nLzEuMC4xMC9iYXNlNjR1cmwuanMiLCJ3ZWJwYWNrOi8vVHdlZXRDbGF3Ly4vbm9kZV9tb2R1bGVzL3gtY2xpZW50LXRyYW5zYWN0aW9uLWlkL2VzbS9kZXBzL2pzci5pby9Ac3RkL2VuY29kaW5nLzEuMC4xMC9oZXguanMiLCJ3ZWJwYWNrOi8vVHdlZXRDbGF3Ly4vbm9kZV9tb2R1bGVzL3gtY2xpZW50LXRyYW5zYWN0aW9uLWlkL2VzbS9kZXBzL2pzci5pby9Ac3RkL2VuY29kaW5nLzEuMC4xMC9tb2QuanMiLCJ3ZWJwYWNrOi8vVHdlZXRDbGF3Ly4vbm9kZV9tb2R1bGVzL3gtY2xpZW50LXRyYW5zYWN0aW9uLWlkL2VzbS9kZXBzL2pzci5pby9Ac3RkL2VuY29kaW5nLzEuMC4xMC92YXJpbnQuanMiLCJ3ZWJwYWNrOi8vVHdlZXRDbGF3Ly4vbm9kZV9tb2R1bGVzL3gtY2xpZW50LXRyYW5zYWN0aW9uLWlkL2VzbS9lcnJvcnMuanMiLCJ3ZWJwYWNrOi8vVHdlZXRDbGF3Ly4vbm9kZV9tb2R1bGVzL3gtY2xpZW50LXRyYW5zYWN0aW9uLWlkL2VzbS9pbnRlcnBvbGF0ZS5qcyIsIndlYnBhY2s6Ly9Ud2VldENsYXcvLi9ub2RlX21vZHVsZXMveC1jbGllbnQtdHJhbnNhY3Rpb24taWQvZXNtL21vZC5qcyIsIndlYnBhY2s6Ly9Ud2VldENsYXcvLi9ub2RlX21vZHVsZXMveC1jbGllbnQtdHJhbnNhY3Rpb24taWQvZXNtL3JvdGF0aW9uLmpzIiwid2VicGFjazovL1R3ZWV0Q2xhdy8uL25vZGVfbW9kdWxlcy94LWNsaWVudC10cmFuc2FjdGlvbi1pZC9lc20vdHJhbnNhY3Rpb24uanMiLCJ3ZWJwYWNrOi8vVHdlZXRDbGF3Ly4vbm9kZV9tb2R1bGVzL3gtY2xpZW50LXRyYW5zYWN0aW9uLWlkL2VzbS91dGlscy5qcyIsIndlYnBhY2s6Ly9Ud2VldENsYXcvd2VicGFjay9ib290c3RyYXAiLCJ3ZWJwYWNrOi8vVHdlZXRDbGF3L3dlYnBhY2svcnVudGltZS9kZWZpbmUgcHJvcGVydHkgZ2V0dGVycyIsIndlYnBhY2s6Ly9Ud2VldENsYXcvd2VicGFjay9ydW50aW1lL2hhc093blByb3BlcnR5IHNob3J0aGFuZCIsIndlYnBhY2s6Ly9Ud2VldENsYXcvd2VicGFjay9ydW50aW1lL21ha2UgbmFtZXNwYWNlIG9iamVjdCIsIndlYnBhY2s6Ly9Ud2VldENsYXcvLi9zcmMvY29udGVudC9tYWluX2VudHJhbmNlLnRzIl0sInNvdXJjZXNDb250ZW50IjpbImV4cG9ydCBjb25zdCBfX0RCS19xdWVyeV9pZF9tYXAgPSAndGNfcXVlcnlfaWRfbWFwJztcbmV4cG9ydCBjb25zdCBfX0RCS19iZWFyZXJfdG9rZW4gPSAndGNfYmVhcmVyX3Rva2VuJztcbmV4cG9ydCBjb25zdCBfX0RCS19keW5hbWljX2ZlYXR1cmVzID0gJ3RjX2R5bmFtaWNfZmVhdHVyZXMnO1xuZXhwb3J0IHZhciBNc2dUeXBlO1xuKGZ1bmN0aW9uIChNc2dUeXBlKSB7XG4gICAgTXNnVHlwZVtcIlBJTkdcIl0gPSBcIlBJTkdcIjtcbiAgICBNc2dUeXBlW1wiRVhFQ1VURV9BQ1RJT05cIl0gPSBcIkVYRUNVVEVfQUNUSU9OXCI7XG59KShNc2dUeXBlIHx8IChNc2dUeXBlID0ge30pKTtcbmV4cG9ydCBjb25zdCB3YXRjaGVkT3BzID0gW1xuICAgICdVc2VyVHdlZXRzJyxcbiAgICAnSG9tZVRpbWVsaW5lJyxcbiAgICAnSG9tZUxhdGVzdFRpbWVsaW5lJyxcbiAgICAnVHdlZXREZXRhaWwnLFxuICAgICdVc2VyQnlTY3JlZW5OYW1lJyxcbiAgICAnUHJvZmlsZVNwb3RsaWdodHNRdWVyeScsXG4gICAgJ0FjY291bnRTZXR0aW5ncycsXG4gICAgJ0F1dGhlbnRpY2F0ZWRVc2VyUXVlcnknLFxuICAgICdWaWV3ZXInLFxuICAgICdWZXJpZnlDcmVkZW50aWFscycsXG4gICAgJ0NyZWF0ZUZyaWVuZHNoaXAnLFxuICAgICdEZXN0cm95RnJpZW5kc2hpcCcsXG4gICAgJ0NyZWF0ZUJvb2ttYXJrJyxcbiAgICAnRGVsZXRlQm9va21hcmsnLFxuICAgICdGb2xsb3dlcnMnLFxuICAgICdGb2xsb3dpbmcnLFxuICAgICdTZWFyY2hUaW1lbGluZScsXG4gICAgJ0Zhdm9yaXRlVHdlZXQnLFxuICAgICdVbmZhdm9yaXRlVHdlZXQnLFxuICAgICdDcmVhdGVSZXR3ZWV0JyxcbiAgICAnRGVsZXRlUmV0d2VldCcsXG4gICAgJ0xpc3RMYXRlc3RUd2VldHNUaW1lbGluZScsXG4gICAgJ1RpbWVsaW5lSG9tZScsXG4gICAgJ0FjY291bnRVc2VyUXVlcnknLFxuICAgICdVc2VyQnlSZXN0SWQnLFxuICAgICdDcmVhdGVUd2VldCcsIC8vIOaWsOWinu+8muWPkeaOqOaWh++8iOWQq+WbnuWkje+8iVxuICAgICdEZWxldGVUd2VldCcsIC8vIOaWsOWinu+8muWIoOmZpOaOqOaWh1xuICAgICdEZWxldGVSZXR3ZWV0JyAvLyDmlrDlop7vvJrlj5bmtojovazlj5Fcbl07XG5leHBvcnQgY29uc3QgZGVmYXVsdFF1ZXJ5S2V5TWFwID0ge1xuICAgICdVc2VyQnlTY3JlZW5OYW1lJzogJ2NrNUtrWjh0NWNPbW9Mc3NvcE45OVEnLFxuICAgICdVc2VyVHdlZXRzJzogJ0U4V3EtX2pGU2FVN2h4VmN1T1BSOWcnLFxuICAgICdIb21lTGF0ZXN0VGltZWxpbmUnOiAnU0Z4bU5LV2ZOOXlTSmNYR190alg4ZycsXG4gICAgJ0hvbWVUaW1lbGluZSc6ICdEWG1nUVltSWZ0MW9MUDZ2TWtKaXh3JyxcbiAgICAnVHdlZXREZXRhaWwnOiAnaUZFcjVBY1AxMjFPZzR3eDlZcW8zdycsXG4gICAgJ1NlYXJjaFRpbWVsaW5lJzogJzRmcGNlWVo2LVlRQ3hfSlNsX0NuX0EnLFxuICAgICdDcmVhdGVCb29rbWFyayc6ICdhb0RidTNSSHpudWlTa1E5YU5NNjdRJyxcbiAgICAnRGVsZXRlQm9va21hcmsnOiAnV2xtbGoyLXh6eVMxR04zYTZjai1tUScsXG4gICAgJ0ZvbGxvd2luZyc6ICdTYVdxencwVEZBV014MW5YV2pYb2FRJyxcbiAgICAnRm9sbG93ZXJzJzogJ2k2UFBkSU1tMU1PN0NwQXFqYXU3c3cnLFxuICAgICdGYXZvcml0ZVR3ZWV0JzogJ2xJMDdONk90d3YxUGhuRWdYSUxNN0EnLFxuICAgICdVbmZhdm9yaXRlVHdlZXQnOiAnWllLU2UtdzdLRXNseDNKaFNJazVMQScsXG4gICAgJ0NyZWF0ZVJldHdlZXQnOiAnbWJSTzc0R3JPdlNmUmNKbmxNYXBuUScsXG4gICAgJ0NyZWF0ZUZyaWVuZHNoaXAnOiAnNjZ2OV9TX3ZUaGhBcmV3Xzk5djlfdjknLFxuICAgICdEZXN0cm95RnJpZW5kc2hpcCc6ICdPcHY3X3A4QXVuTWhKdkQ4WDhjOXJ3JyxcbiAgICAnVXNlckJ5UmVzdElkJzogJ0xKWUlfVnZURkFaZjdQQWRUMGVXbUEnLFxuICAgICdDcmVhdGVUd2VldCc6ICd6a2NGYzZGLVJLUmdXTjhIVWtKZlpnJywgLy8g5paw5aKe77ya5bey56Gu6K6k77yIMjAyNS0wNe+8iVxuICAgICdEZWxldGVUd2VldCc6ICdueHBaQ1kySy1JNlFvRkhBSGVvakZRJywgLy8g5paw5aKe77ya5bey56Gu6K6k77yIMjAyNS0wNe+8iVxuICAgICdEZWxldGVSZXR3ZWV0JzogJ1p5WmlnVnNOaUZPNnYxZEVrczFlV2cnIC8vIOaWsOWinu+8muW3suehruiupO+8iDIwMjUtMDXvvIlcbn07XG4vKipcbiAqIOivhuWIqyBYIOa4uOWuoui0puWPt++8iEd1ZXN0IFRva2Vu77yJXG4gKlxuICogWCDnmoQgZ3Vlc3QgdG9rZW4gaGFuZGxlIOeJueW+ge+8mlxuICogICAtIOaBsOWlvSAxNSDkuKrlrZfnrKZcbiAqICAgLSDlhajpg6jmmK/lsI/lhpnlrZfmr40gKyDmlbDlrZfvvIjml6DlpKflhpnlrZfmr43jgIHml6DkuIvliJLnur/vvIlcbiAqICAgLSDlkKvmnInoh7PlsJHkuIDkuKrmlbDlrZdcbiAqXG4gKiDnnJ/lrp7nlKjmiLcgaGFuZGxlIOWPr+S7peWMheWQq+Wkp+WGmeWtl+avjeaIluS4i+WIkue6v++8jOS4jeS8muiiq+ivr+WIpOOAglxuICog5L6L5aaC6K+v5Yik5qGI5L6L77yaMURVMUdmN29FbFIyaDI4IOKGkiDlkKvlpKflhpkg4oaSIOS4jeaYryBndWVzdCDinJNcbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIGlzR3Vlc3RIYW5kbGUoaCkge1xuICAgIGlmICghaClcbiAgICAgICAgcmV0dXJuIGZhbHNlO1xuICAgIGNvbnN0IGNsZWFuID0gaC5zdGFydHNXaXRoKCdAJykgPyBoLnN1YnN0cmluZygxKSA6IGg7XG4gICAgLy8gR3Vlc3QgaGFuZGxlcyBhcmUgcmFuZG9tIDE1LWNoYXIgc3RyaW5ncyAoZS5nLiwgJ3h5ejEyMzRhYmM1Njc4eicgb3IgJzEyMzQ1Njc4OTAxMjM0NScpXG4gICAgLy8gUmVhbCB1c2VycyBsaWtlICd3ZWIzYnJpZGdlbmluamEnICgxNSBjaGFycywgbG93ZXJjYXNlLCAxIGRpZ2l0KSBhcmUgY29tbW9uIGZhbHNlIHBvc2l0aXZlcy5cbiAgICBpZiAoY2xlYW4ubGVuZ3RoICE9PSAxNSB8fCAhL15bYS16MC05XSskLy50ZXN0KGNsZWFuKSlcbiAgICAgICAgcmV0dXJuIGZhbHNlO1xuICAgIGNvbnN0IGRpZ2l0cyA9IChjbGVhbi5tYXRjaCgvXFxkL2cpIHx8IFtdKS5sZW5ndGg7XG4gICAgY29uc3QgaGFzVm93ZWxzID0gL1thZWlvdV0vLnRlc3QoY2xlYW4pO1xuICAgIC8vIEhldXJpc3RpY3M6XG4gICAgLy8gMS4gQWxsIG51bWVyaWMgaXMgZGVmaW5pdGVseSBhIGd1ZXN0IHRva2VuXG4gICAgaWYgKC9eXFxkKyQvLnRlc3QoY2xlYW4pKVxuICAgICAgICByZXR1cm4gdHJ1ZTtcbiAgICAvLyAyLiBBbHBoYW51bWVyaWMgd2l0aCBoaWdoIGRpZ2l0IGNvdW50ICg+PSAzKSBhbmQgbm8gdm93ZWxzIGlzIHZlcnkgbGlrZWx5IGEgZ3Vlc3RcbiAgICBpZiAoZGlnaXRzID49IDIgJiYgIWhhc1Zvd2VscylcbiAgICAgICAgcmV0dXJuIHRydWU7XG4gICAgLy8gMy4gVmVyeSBoaWdoIGRpZ2l0IGNvdW50ICg+PSA1KSBpcyBhbHNvIGEgcmVkIGZsYWcgZXZlbiB3aXRoIHZvd2Vsc1xuICAgIGlmIChkaWdpdHMgPj0gNSlcbiAgICAgICAgcmV0dXJuIHRydWU7XG4gICAgcmV0dXJuIGZhbHNlO1xufVxuIiwiaW1wb3J0IHsgaXNHdWVzdEhhbmRsZSB9IGZyb20gJy4vY29uc3RzJztcbmltcG9ydCB7IGV4dHJhY3RUd2VldHNGcm9tVGltZWxpbmUgfSBmcm9tICcuL3RpbWVsaW5lLWV4dHJhY3Rvcic7XG5pbXBvcnQgeyBleHRyYWN0VHdlZXRJZCB9IGZyb20gJy4uL3V0aWxzL3JvdXRlLXBhcnNlcic7XG4vLyDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIBcbi8vIOS7heWPl+S/oeS7u+eahCBpZGVudGl0eSDmk43kvZzvvIjkuI3mjqXlj5fmma7pgJrnlKjmiLfkuLvpobUgZmV0Y2gg5L2c5Li66Lqr5Lu95p2l5rqQ77yJXG4vLyDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIBcbmNvbnN0IFRSVVNURURfSURFTlRJVFlfT1BTID0gbmV3IFNldChbXG4gICAgJ0F1dGhlbnRpY2F0ZWRVc2VyUXVlcnknLFxuICAgICdWaWV3ZXInLFxuICAgICdBY2NvdW50U2V0dGluZ3MnLFxuICAgICdzZXR0aW5ncy5qc29uJyxcbiAgICAnVmVyaWZ5Q3JlZGVudGlhbHMnXG5dKTtcbmV4cG9ydCBmdW5jdGlvbiBpc1RydXN0YWJsZUlkZW50aXR5T3Aob3ApIHtcbiAgICByZXR1cm4gVFJVU1RFRF9JREVOVElUWV9PUFMuaGFzKG9wKTtcbn1cbi8vIOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgFxuLy8gZ2V0T3BOYW1lOiDku44gQVBJIFVSTCDop6PmnpAgb3BlcmF0aW9uTmFtZVxuLy8g4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSAXG5leHBvcnQgZnVuY3Rpb24gZ2V0T3BOYW1lKHVybCkge1xuICAgIGlmICghdXJsKVxuICAgICAgICByZXR1cm4gbnVsbDtcbiAgICAvLyBHcmFwaFFMOiAvaS9hcGkvZ3JhcGhxbC97cXVlcnlJZH0ve09wZXJhdGlvbk5hbWV9Wz8uLi5dXG4gICAgY29uc3QgZ3FsTWF0Y2ggPSB1cmwubWF0Y2goL1xcL2dyYXBocWxcXC9bXlxcL10rXFwvKFtePyYvXFxzXSspLyk7XG4gICAgaWYgKGdxbE1hdGNoKVxuICAgICAgICByZXR1cm4gZ3FsTWF0Y2hbMV07XG4gICAgLy8gUkVTVCAxLjEg54m55q6K5pig5bCEXG4gICAgaWYgKHVybC5pbmNsdWRlcygnL2FjY291bnQvc2V0dGluZ3MuanNvbicpKVxuICAgICAgICByZXR1cm4gJ3NldHRpbmdzLmpzb24nO1xuICAgIGlmICh1cmwuaW5jbHVkZXMoJy9hY2NvdW50L3ZlcmlmeV9jcmVkZW50aWFscy5qc29uJykpXG4gICAgICAgIHJldHVybiAnVmVyaWZ5Q3JlZGVudGlhbHMnO1xuICAgIHJldHVybiBudWxsO1xufVxuLy8g4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSAXG4vLyBmaW5kU2NyZWVuTmFtZVJlY3Vyc2l2ZTog6YCS5b2S5pCc57SiIHNjcmVlbl9uYW1l77yI6Z2eIGd1ZXN077yJXG4vLyDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIBcbmV4cG9ydCBmdW5jdGlvbiBmaW5kU2NyZWVuTmFtZVJlY3Vyc2l2ZShvYmosIGRlcHRoID0gMCkge1xuICAgIGlmICghb2JqIHx8IHR5cGVvZiBvYmogIT09ICdvYmplY3QnIHx8IGRlcHRoID4gNilcbiAgICAgICAgcmV0dXJuIG51bGw7XG4gICAgaWYgKHR5cGVvZiBvYmouc2NyZWVuX25hbWUgPT09ICdzdHJpbmcnICYmICFpc0d1ZXN0SGFuZGxlKG9iai5zY3JlZW5fbmFtZSkpIHtcbiAgICAgICAgcmV0dXJuIG9iai5zY3JlZW5fbmFtZTtcbiAgICB9XG4gICAgZm9yIChjb25zdCBrZXkgb2YgT2JqZWN0LmtleXMob2JqKSkge1xuICAgICAgICBjb25zdCB2YWwgPSBvYmpba2V5XTtcbiAgICAgICAgaWYgKHZhbCAmJiB0eXBlb2YgdmFsID09PSAnb2JqZWN0Jykge1xuICAgICAgICAgICAgY29uc3QgZm91bmQgPSBmaW5kU2NyZWVuTmFtZVJlY3Vyc2l2ZSh2YWwsIGRlcHRoICsgMSk7XG4gICAgICAgICAgICBpZiAoZm91bmQpXG4gICAgICAgICAgICAgICAgcmV0dXJuIGZvdW5kO1xuICAgICAgICB9XG4gICAgfVxuICAgIHJldHVybiBudWxsO1xufVxuZXhwb3J0IGZ1bmN0aW9uIGZpbmRWaWV3ZXJTdW1tYXJ5KGRhdGEsIHRhcmdldFVpZCkge1xuICAgIGlmICghZGF0YSlcbiAgICAgICAgcmV0dXJuIG51bGw7XG4gICAgY29uc3QgZXh0cmFjdCA9IChvYmopID0+IHtcbiAgICAgICAgaWYgKCFvYmogfHwgIW9iai5sZWdhY3kpXG4gICAgICAgICAgICByZXR1cm4gbnVsbDtcbiAgICAgICAgY29uc3QgaGFuZGxlID0gb2JqLmxlZ2FjeS5zY3JlZW5fbmFtZTtcbiAgICAgICAgY29uc3QgdXNlcklkID0gb2JqLnJlc3RfaWQ7XG4gICAgICAgIGlmICghaGFuZGxlKVxuICAgICAgICAgICAgcmV0dXJuIG51bGw7XG4gICAgICAgIC8vIFNhZmV0eTogSWYgaXQgbWF0Y2hlcyBvdXIgY29uZmlybWVkIFVJRCAoZnJvbSB0d2lkIGNvb2tpZSksIGl0J3MgdGhlIHVzZXIsIG5vdCBhIGd1ZXN0XG4gICAgICAgIGNvbnN0IGlzQWN0dWFsbHlWaWV3ZXIgPSB0YXJnZXRVaWQgJiYgdXNlcklkID09PSB0YXJnZXRVaWQ7XG4gICAgICAgIGlmIChpc0d1ZXN0SGFuZGxlKGhhbmRsZSkgJiYgIWlzQWN0dWFsbHlWaWV3ZXIpXG4gICAgICAgICAgICByZXR1cm4gbnVsbDtcbiAgICAgICAgaWYgKHRhcmdldFVpZCAmJiB1c2VySWQgIT09IHRhcmdldFVpZClcbiAgICAgICAgICAgIHJldHVybiBudWxsO1xuICAgICAgICByZXR1cm4ge1xuICAgICAgICAgICAgaGFuZGxlOiBgQCR7aGFuZGxlfWAsXG4gICAgICAgICAgICB1c2VySWQ6IHVzZXJJZCxcbiAgICAgICAgICAgIGRpc3BsYXlOYW1lOiBvYmoubGVnYWN5Lm5hbWUsXG4gICAgICAgICAgICB2ZXJpZmllZDogb2JqLmxlZ2FjeS52ZXJpZmllZCB8fCBmYWxzZSxcbiAgICAgICAgICAgIGRlc2NyaXB0aW9uOiBvYmoubGVnYWN5LmRlc2NyaXB0aW9uLFxuICAgICAgICAgICAgYXZhdGFyOiBvYmoubGVnYWN5LnByb2ZpbGVfaW1hZ2VfdXJsX2h0dHBzLFxuICAgICAgICAgICAgZm9sbG93ZXJzQ291bnQ6IG9iai5sZWdhY3kuZm9sbG93ZXJzX2NvdW50LFxuICAgICAgICAgICAgZnJpZW5kc0NvdW50OiBvYmoubGVnYWN5LmZyaWVuZHNfY291bnQsXG4gICAgICAgICAgICBzdGF0dXNlc0NvdW50OiBvYmoubGVnYWN5LnN0YXR1c2VzX2NvdW50LFxuICAgICAgICAgICAgY3JlYXRlZEF0OiBvYmoubGVnYWN5LmNyZWF0ZWRfYXQsXG4gICAgICAgICAgICByYXc6IG9iaiAvLyDpmYTliqDljp/lp4vlr7nosaFcbiAgICAgICAgfTtcbiAgICB9O1xuICAgIC8vIDEuIHYxLjEgUkVTVCDmiYHlubPnu5PmnoTvvIhzZXR0aW5ncy5qc29uIC8gdmVyaWZ5X2NyZWRlbnRpYWxzLmpzb27vvIlcbiAgICAvLyAgICBzZXR0aW5ncy5qc29uIOS7heWcqOeZu+W9leWQjuWPr+inge+8jOmHjOmdoueahCBoYW5kbGUg5Y+q6KaB5a2Y5Zyo5bCx5piv55yf5a6e55qEXG4gICAgaWYgKGRhdGEuc2NyZWVuX25hbWUpIHtcbiAgICAgICAgY29uc3QgdXNlcklkID0gZGF0YS5pZF9zdHIgfHwgZGF0YS5pZD8udG9TdHJpbmcoKSB8fCAnJztcbiAgICAgICAgY29uc3QgaXNBY3R1YWxseVZpZXdlciA9IHRhcmdldFVpZCAmJiB1c2VySWQgPT09IHRhcmdldFVpZDtcbiAgICAgICAgaWYgKGlzR3Vlc3RIYW5kbGUoZGF0YS5zY3JlZW5fbmFtZSkgJiYgIWlzQWN0dWFsbHlWaWV3ZXIpXG4gICAgICAgICAgICByZXR1cm4gbnVsbDtcbiAgICAgICAgaWYgKHRhcmdldFVpZCAmJiB1c2VySWQgIT09IHRhcmdldFVpZClcbiAgICAgICAgICAgIHJldHVybiBudWxsOyAvLyDnoa7kv50gVUlEIOWMuemFjVxuICAgICAgICByZXR1cm4ge1xuICAgICAgICAgICAgaGFuZGxlOiBgQCR7ZGF0YS5zY3JlZW5fbmFtZX1gLFxuICAgICAgICAgICAgdXNlcklkOiB1c2VySWQsXG4gICAgICAgICAgICBkaXNwbGF5TmFtZTogZGF0YS5uYW1lIHx8IGRhdGEuc2NyZWVuX25hbWUgfHwgJycsIC8vIOehruS/nSBkaXNwbGF5TmFtZSDkuI3kuLrnqbpcbiAgICAgICAgICAgIHZlcmlmaWVkOiBkYXRhLnZlcmlmaWVkIHx8IGZhbHNlLFxuICAgICAgICAgICAgZGVzY3JpcHRpb246IGRhdGEuZGVzY3JpcHRpb24sXG4gICAgICAgICAgICBhdmF0YXI6IGRhdGEucHJvZmlsZV9pbWFnZV91cmxfaHR0cHMsXG4gICAgICAgICAgICBmb2xsb3dlcnNDb3VudDogZGF0YS5mb2xsb3dlcnNfY291bnQsXG4gICAgICAgICAgICBmcmllbmRzQ291bnQ6IGRhdGEuZnJpZW5kc19jb3VudCxcbiAgICAgICAgICAgIHN0YXR1c2VzQ291bnQ6IGRhdGEuc3RhdHVzZXNfY291bnQsXG4gICAgICAgICAgICBjcmVhdGVkQXQ6IGRhdGEuY3JlYXRlZF9hdCxcbiAgICAgICAgICAgIHJhdzogZGF0YSAvLyDpmYTliqDljp/lp4vmlbDmja5cbiAgICAgICAgfTtcbiAgICB9XG4gICAgY29uc3QgdSA9IGZpbmREZWVwVXNlcihkYXRhKTtcbiAgICBpZiAodSkge1xuICAgICAgICBjb25zb2xlLmxvZygnW1R3ZWV0Q2xhdy1FeHRyYWN0b3JdIGZpbmREZWVwVXNlciBmb3VuZCB2YWxpZCB1c2VyIG9iamVjdCcpO1xuICAgICAgICBjb25zdCBzdW1tYXJ5ID0gZXh0cmFjdCh1KTtcbiAgICAgICAgaWYgKHN1bW1hcnkpXG4gICAgICAgICAgICByZXR1cm4gc3VtbWFyeTtcbiAgICB9XG4gICAgY29uc29sZS53YXJuKCdbVHdlZXRDbGF3LUV4dHJhY3Rvcl0gZmluZFZpZXdlclN1bW1hcnkgZmFpbGVkIHRvIGZpbmQgYW55IHZhbGlkIHVzZXIgYmxvY2sgaW4gZGF0YTonLCB7XG4gICAgICAgIGhhc0RhdGE6ICEhZGF0YSxcbiAgICAgICAga2V5czogT2JqZWN0LmtleXMoZGF0YSB8fCB7fSksXG4gICAgICAgIHRhcmdldFVpZFxuICAgIH0pO1xuICAgIHJldHVybiBudWxsO1xufVxuLy8g4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSAXG4vLyBmaW5kRmVhdHVyZWRUd2VldDog5LuO5ZON5bqU5L2T5Lit5o+Q5Y+W5LiA5p2h5Luj6KGo5oCn5o6o5paH77yI55So5LqOIGRlYnVnIC8gcXVpY2sgYWN0aW9u77yJXG4vLyDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIBcbmV4cG9ydCBmdW5jdGlvbiBmaW5kRmVhdHVyZWRUd2VldChkYXRhLCBwYWdlVXJsKSB7XG4gICAgdHJ5IHtcbiAgICAgICAgY29uc3QgdHdlZXRzID0gZXh0cmFjdFR3ZWV0c0Zyb21UaW1lbGluZShkYXRhKTtcbiAgICAgICAgaWYgKHR3ZWV0cy5sZW5ndGggPT09IDApXG4gICAgICAgICAgICByZXR1cm4gbnVsbDtcbiAgICAgICAgLy8g5aaC5p6c5o+Q5L6b5LqGIHBhZ2VVcmzvvIzlsJ3or5XljLnphY0gc3RhdHVzIElEICjnlKjkuo4gdHdlZXRfZGV0YWlsIOWcuuaZr+mAieS4reS4u+aOqOaWhylcbiAgICAgICAgY29uc3QgdGFyZ2V0SWQgPSBwYWdlVXJsID8gZXh0cmFjdFR3ZWV0SWQocGFnZVVybCkgOiBudWxsO1xuICAgICAgICBsZXQgYmVzdCA9IHRhcmdldElkID8gdHdlZXRzLmZpbmQodCA9PiB0LnR3ZWV0SWQgPT09IHRhcmdldElkKSA6IG51bGw7XG4gICAgICAgIC8vIOWmguaenOayoeaJvuWIsOWMuemFjeeahO+8jOaIluiAheS4jeaYr+ivpuaDhemhte+8jOmAieesrOS4gOS4qlxuICAgICAgICBpZiAoIWJlc3QpIHtcbiAgICAgICAgICAgIGJlc3QgPSB0d2VldHNbMF07XG4gICAgICAgIH1cbiAgICAgICAgaWYgKCFiZXN0KVxuICAgICAgICAgICAgcmV0dXJuIG51bGw7XG4gICAgICAgIHJldHVybiB7XG4gICAgICAgICAgICBpZDogYmVzdC50d2VldElkLFxuICAgICAgICAgICAgdGV4dDogYmVzdC50ZXh0IHx8ICcnLFxuICAgICAgICAgICAgYXV0aG9ySGFuZGxlOiBiZXN0LmF1dGhvckhhbmRsZSB8fCAnJyxcbiAgICAgICAgICAgIGF1dGhvck5hbWU6IGJlc3QuYXV0aG9yTmFtZSB8fCAnJyxcbiAgICAgICAgICAgIGF1dGhvcklkOiBiZXN0LmF1dGhvcklkIHx8ICcnLFxuICAgICAgICAgICAgY3JlYXRlZEF0OiBiZXN0LmNyZWF0ZWRBdCB8fCAnJyxcbiAgICAgICAgICAgIGxpa2VDb3VudDogYmVzdC5saWtlQ291bnQgPz8gMCxcbiAgICAgICAgICAgIHJlcGx5Q291bnQ6IGJlc3QucmVwbHlDb3VudCA/PyAwLFxuICAgICAgICAgICAgcmVwb3N0Q291bnQ6IGJlc3QucmVwb3N0Q291bnQgPz8gMCxcbiAgICAgICAgICAgIGJvb2ttYXJrQ291bnQ6IGJlc3QuYm9va21hcmtDb3VudCA/PyAwXG4gICAgICAgIH07XG4gICAgfVxuICAgIGNhdGNoIChlKSB7XG4gICAgICAgIGNvbnNvbGUud2FybignW1R3ZWV0Q2xhdy1FeHRyYWN0b3JdIEVycm9yIGluIGZpbmRGZWF0dXJlZFR3ZWV0JywgZSk7XG4gICAgfVxuICAgIHJldHVybiBudWxsO1xufVxuLyoqXG4gKiDlr7vmib7lk43lupTkvZPkuK3nibnlrpogSUQg55qE5o6o5paHXG4gKiDnlKjkuo7lvZPlvZPliY0gVVJMIOS4juW3sue8k+WtmOeahCBmZWF0dXJlZFR3ZWV0IOS4jeWMuemFjeaXtu+8jOmHjeaWsOS7juWOn+Wni+WTjeW6lOS4reaJvuWbnuS4u+aOqOaWh1xuICovXG5leHBvcnQgZnVuY3Rpb24gZmluZFR3ZWV0QnlJZChkYXRhLCB0d2VldElkKSB7XG4gICAgdHJ5IHtcbiAgICAgICAgY29uc3QgdHdlZXRzID0gZXh0cmFjdFR3ZWV0c0Zyb21UaW1lbGluZShkYXRhKTtcbiAgICAgICAgY29uc3QgbWF0Y2ggPSB0d2VldHMuZmluZCh0ID0+IHQudHdlZXRJZCA9PT0gdHdlZXRJZCk7XG4gICAgICAgIGlmICghbWF0Y2gpXG4gICAgICAgICAgICByZXR1cm4gbnVsbDtcbiAgICAgICAgcmV0dXJuIHtcbiAgICAgICAgICAgIGlkOiBtYXRjaC50d2VldElkLFxuICAgICAgICAgICAgdGV4dDogbWF0Y2gudGV4dCB8fCAnJyxcbiAgICAgICAgICAgIGF1dGhvckhhbmRsZTogbWF0Y2guYXV0aG9ySGFuZGxlIHx8ICcnLFxuICAgICAgICAgICAgYXV0aG9yTmFtZTogbWF0Y2guYXV0aG9yTmFtZSB8fCAnJyxcbiAgICAgICAgICAgIGF1dGhvcklkOiBtYXRjaC5hdXRob3JJZCB8fCAnJyxcbiAgICAgICAgICAgIGNyZWF0ZWRBdDogbWF0Y2guY3JlYXRlZEF0IHx8ICcnLFxuICAgICAgICAgICAgbGlrZUNvdW50OiBtYXRjaC5saWtlQ291bnQgPz8gMCxcbiAgICAgICAgICAgIHJlcGx5Q291bnQ6IG1hdGNoLnJlcGx5Q291bnQgPz8gMCxcbiAgICAgICAgICAgIHJlcG9zdENvdW50OiBtYXRjaC5yZXBvc3RDb3VudCA/PyAwLFxuICAgICAgICAgICAgYm9va21hcmtDb3VudDogbWF0Y2guYm9va21hcmtDb3VudCA/PyAwXG4gICAgICAgIH07XG4gICAgfVxuICAgIGNhdGNoIChlKSB7XG4gICAgICAgIGNvbnNvbGUud2FybignW1R3ZWV0Q2xhdy1FeHRyYWN0b3JdIEVycm9yIGluIGZpbmRUd2VldEJ5SWQnLCBlKTtcbiAgICB9XG4gICAgcmV0dXJuIG51bGw7XG59XG4vKipcbiAqIOS7juWTjeW6lOS9k+S4reaPkOWPluWbnuWkjeWIl+ihqO+8iOW/q+eFp++8iVxuICovXG5leHBvcnQgZnVuY3Rpb24gZmluZFJlcGxpZXNTbmFwc2hvdChkYXRhLCBwYWdlVXJsLCBhY3RpdmVBY2NvdW50SGFuZGxlKSB7XG4gICAgdHJ5IHtcbiAgICAgICAgY29uc3QgdHdlZXRzID0gZXh0cmFjdFR3ZWV0c0Zyb21UaW1lbGluZShkYXRhKTtcbiAgICAgICAgaWYgKHR3ZWV0cy5sZW5ndGggPT09IDApXG4gICAgICAgICAgICByZXR1cm4gW107XG4gICAgICAgIGNvbnN0IHRhcmdldElkID0gcGFnZVVybCA/IGV4dHJhY3RUd2VldElkKHBhZ2VVcmwpIDogbnVsbDtcbiAgICAgICAgLy8g6L+H5ruk6YC76L6R77yaXG4gICAgICAgIC8vIDEuIOaOkumZpOS4u+aOqOaWhyAodGFyZ2V0SWQpXG4gICAgICAgIC8vIDIuIOi/memHjOeahCB0d2VldHMg5piv5ouN5bmz55qE5YiX6KGo77yMVGltZWxpbmVBZGRFbnRyaWVzIOmHjOeahOmhuuW6j+mAmuW4uOWwseaYr+WbnuWkjemhuuW6j1xuICAgICAgICAvLyAzLiDnu5PmnpzkuK3lj6/og73ljIXlkKvkuLvmjqjmlofmnKzouqvvvIjlpoLmnpzmnInnmoTor53vvInvvIzmiJHku6zopoHmjpLpmaTlroNcbiAgICAgICAgY29uc3QgcmVwbGllcyA9IHR3ZWV0cy5maWx0ZXIodCA9PiB0LnR3ZWV0SWQgIT09IHRhcmdldElkKTtcbiAgICAgICAgLy8g5Y676YeNXG4gICAgICAgIGNvbnN0IHNlZW4gPSBuZXcgU2V0KCk7XG4gICAgICAgIGNvbnN0IHVuaXF1ZSA9IFtdO1xuICAgICAgICBmb3IgKGNvbnN0IHQgb2YgcmVwbGllcykge1xuICAgICAgICAgICAgaWYgKCFzZWVuLmhhcyh0LnR3ZWV0SWQpKSB7XG4gICAgICAgICAgICAgICAgc2Vlbi5hZGQodC50d2VldElkKTtcbiAgICAgICAgICAgICAgICB1bmlxdWUucHVzaCh0KTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gdW5pcXVlLm1hcCh0ID0+ICh7XG4gICAgICAgICAgICB0d2VldElkOiB0LnR3ZWV0SWQsXG4gICAgICAgICAgICBhdXRob3JIYW5kbGU6IHQuYXV0aG9ySGFuZGxlLFxuICAgICAgICAgICAgYXV0aG9yTmFtZTogdC5hdXRob3JOYW1lLFxuICAgICAgICAgICAgYXV0aG9ySWQ6IHQuYXV0aG9ySWQsXG4gICAgICAgICAgICB0ZXh0OiB0LnRleHQsXG4gICAgICAgICAgICBjcmVhdGVkQXQ6IHQuY3JlYXRlZEF0LFxuICAgICAgICAgICAgbGlrZUNvdW50OiB0Lmxpa2VDb3VudCxcbiAgICAgICAgICAgIHJlcGx5Q291bnQ6IHQucmVwbHlDb3VudCxcbiAgICAgICAgICAgIHJlcG9zdENvdW50OiB0LnJlcG9zdENvdW50LFxuICAgICAgICAgICAgaXNCeUFjdGl2ZUFjY291bnQ6IGFjdGl2ZUFjY291bnRIYW5kbGUgPyB0LmF1dGhvckhhbmRsZSA9PT0gYWN0aXZlQWNjb3VudEhhbmRsZSA6IGZhbHNlXG4gICAgICAgIH0pKTtcbiAgICB9XG4gICAgY2F0Y2ggKGUpIHtcbiAgICAgICAgY29uc29sZS53YXJuKCdbVHdlZXRDbGF3LUV4dHJhY3Rvcl0gRXJyb3IgaW4gZmluZFJlcGxpZXNTbmFwc2hvdCcsIGUpO1xuICAgIH1cbiAgICByZXR1cm4gW107XG59XG4vKipcbiAqIOS7juWTjeW6lOS9k+S4reaPkOWPliBQcm9maWxlIOWcuuaZr+S4i+eahOaOqOaWh+WIl+ihqO+8iOW/q+eFp++8iVxuICovXG5leHBvcnQgZnVuY3Rpb24gZmluZFByb2ZpbGVUd2VldHNTbmFwc2hvdChkYXRhLCBhY3RpdmVBY2NvdW50SGFuZGxlKSB7XG4gICAgdHJ5IHtcbiAgICAgICAgY29uc3QgdHdlZXRzID0gZXh0cmFjdFR3ZWV0c0Zyb21UaW1lbGluZShkYXRhKTtcbiAgICAgICAgaWYgKHR3ZWV0cy5sZW5ndGggPT09IDApXG4gICAgICAgICAgICByZXR1cm4gW107XG4gICAgICAgIC8vIOWOu+mHjVxuICAgICAgICBjb25zdCBzZWVuID0gbmV3IFNldCgpO1xuICAgICAgICBjb25zdCB1bmlxdWUgPSBbXTtcbiAgICAgICAgZm9yIChjb25zdCB0IG9mIHR3ZWV0cykge1xuICAgICAgICAgICAgaWYgKCFzZWVuLmhhcyh0LnR3ZWV0SWQpKSB7XG4gICAgICAgICAgICAgICAgc2Vlbi5hZGQodC50d2VldElkKTtcbiAgICAgICAgICAgICAgICB1bmlxdWUucHVzaCh0KTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gdW5pcXVlLm1hcCh0ID0+ICh7XG4gICAgICAgICAgICB0d2VldElkOiB0LnR3ZWV0SWQsXG4gICAgICAgICAgICBhdXRob3JIYW5kbGU6IHQuYXV0aG9ySGFuZGxlLFxuICAgICAgICAgICAgYXV0aG9yTmFtZTogdC5hdXRob3JOYW1lLFxuICAgICAgICAgICAgdGV4dDogdC50ZXh0LFxuICAgICAgICAgICAgY3JlYXRlZEF0OiB0LmNyZWF0ZWRBdCxcbiAgICAgICAgICAgIGxpa2VDb3VudDogdC5saWtlQ291bnQsXG4gICAgICAgICAgICByZXBseUNvdW50OiB0LnJlcGx5Q291bnQsXG4gICAgICAgICAgICByZXBvc3RDb3VudDogdC5yZXBvc3RDb3VudCxcbiAgICAgICAgICAgIGlzT3duZWRCeUFjdGl2ZUFjY291bnQ6IGFjdGl2ZUFjY291bnRIYW5kbGUgPyB0LmF1dGhvckhhbmRsZSA9PT0gYWN0aXZlQWNjb3VudEhhbmRsZSA6IGZhbHNlXG4gICAgICAgIH0pKTtcbiAgICB9XG4gICAgY2F0Y2ggKGUpIHtcbiAgICAgICAgY29uc29sZS53YXJuKCdbVHdlZXRDbGF3LUV4dHJhY3Rvcl0gRXJyb3IgaW4gZmluZFByb2ZpbGVUd2VldHNTbmFwc2hvdCcsIGUpO1xuICAgIH1cbiAgICByZXR1cm4gW107XG59XG4vKipcbiAqIOmAkuW9kuWcqOS7u+aEj+a3seW6pueahCBKU09OIOWvueixoeS4reaJvuWIsCBUd2l0dGVyIFVzZXIg57uT5p6c5a+56LGh44CCXG4gKiDlhbzlrrkgVXNlckJ5U2NyZWVuTmFtZSAvIFVzZXJCeVJlc3RJZCDnrYnlpJrnp43lk43lupTnu5PmnoTlj5jkvZPjgIJcbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIGZpbmREZWVwVXNlcihvYmosIGRlcHRoID0gMCkge1xuICAgIGlmICghb2JqIHx8IHR5cGVvZiBvYmogIT09ICdvYmplY3QnIHx8IGRlcHRoID4gOClcbiAgICAgICAgcmV0dXJuIG51bGw7XG4gICAgLy8g5ZG95Lit5p2h5Lu277ya5piv5LiA5Liq5pyJIHJlc3RfaWQg5LiUIF9fdHlwZW5hbWUg5Li6IFVzZXIg55qE5a+56LGhXG4gICAgaWYgKG9iai5fX3R5cGVuYW1lID09PSAnVXNlcicgJiYgb2JqLnJlc3RfaWQpXG4gICAgICAgIHJldHVybiBvYmo7XG4gICAgLy8g5LyY5YWI5bCd6K+V6K+t5LmJ6Lev5b6EXG4gICAgY29uc3QgcHJpb3JpdHlLZXlzID0gWydyZXN1bHQnLCAndXNlcicsICd1c2VyX3Jlc3VsdCcsICdkYXRhJ107XG4gICAgZm9yIChjb25zdCBrZXkgb2YgcHJpb3JpdHlLZXlzKSB7XG4gICAgICAgIGlmIChvYmpba2V5XSkge1xuICAgICAgICAgICAgY29uc3QgZm91bmQgPSBmaW5kRGVlcFVzZXIob2JqW2tleV0sIGRlcHRoICsgMSk7XG4gICAgICAgICAgICBpZiAoZm91bmQpXG4gICAgICAgICAgICAgICAgcmV0dXJuIGZvdW5kO1xuICAgICAgICB9XG4gICAgfVxuICAgIC8vIOWFnOW6le+8mumBjeWOhuaJgOaciSBrZXlcbiAgICBmb3IgKGNvbnN0IGtleSBvZiBPYmplY3Qua2V5cyhvYmopKSB7XG4gICAgICAgIGlmIChwcmlvcml0eUtleXMuaW5jbHVkZXMoa2V5KSlcbiAgICAgICAgICAgIGNvbnRpbnVlOyAvLyDlt7LlpITnkIZcbiAgICAgICAgY29uc3QgZm91bmQgPSBmaW5kRGVlcFVzZXIob2JqW2tleV0sIGRlcHRoICsgMSk7XG4gICAgICAgIGlmIChmb3VuZClcbiAgICAgICAgICAgIHJldHVybiBmb3VuZDtcbiAgICB9XG4gICAgcmV0dXJuIG51bGw7XG59XG4iLCIvKipcbiAqIFRpbWVsaW5lIEV4dHJhY3Rpb24gTG9naWNcbiAqIFJvYnVzdCB2ZXJzaW9uIGZvciBBdXRob3IgSGFuZGxlLCBJbnRlcmFjdGlvbiBTdGF0cywgTWVkaWEsIGFuZCBRdW90ZXMuXG4gKi9cbi8qKlxuICogUmVjdXJzaXZlbHkgc2VhcmNoZXMgZm9yIHRoZSAnaW5zdHJ1Y3Rpb25zJyBhcnJheS5cbiAqL1xuZnVuY3Rpb24gZmluZEluc3RydWN0aW9uc1JlY3Vyc2l2ZShvYmopIHtcbiAgICBpZiAoIW9iaiB8fCB0eXBlb2Ygb2JqICE9PSAnb2JqZWN0JylcbiAgICAgICAgcmV0dXJuIG51bGw7XG4gICAgaWYgKEFycmF5LmlzQXJyYXkob2JqLmluc3RydWN0aW9ucykpXG4gICAgICAgIHJldHVybiBvYmouaW5zdHJ1Y3Rpb25zO1xuICAgIGZvciAoY29uc3Qga2V5IGluIG9iaikge1xuICAgICAgICBpZiAodHlwZW9mIG9ialtrZXldID09PSAnb2JqZWN0JyAmJiBvYmpba2V5XSAhPT0gbnVsbCkge1xuICAgICAgICAgICAgY29uc3QgZm91bmQgPSBmaW5kSW5zdHJ1Y3Rpb25zUmVjdXJzaXZlKG9ialtrZXldKTtcbiAgICAgICAgICAgIGlmIChmb3VuZClcbiAgICAgICAgICAgICAgICByZXR1cm4gZm91bmQ7XG4gICAgICAgIH1cbiAgICB9XG4gICAgcmV0dXJuIG51bGw7XG59XG4vKipcbiAqIEV4dHJhY3RzIGEgbGlzdCBvZiBub3JtYWxpemVkIHR3ZWV0cyBmcm9tIGFueSBUaW1lbGluZS1saWtlIEdyYXBoUUwgcmVzcG9uc2UuXG4gKiBXb3JrcyBmb3IgSG9tZSwgU2VhcmNoLCBhbmQgVHdlZXREZXRhaWwgKFRocmVhZCkuXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBleHRyYWN0VHdlZXRzRnJvbVRpbWVsaW5lKGpzb24pIHtcbiAgICBjb25zdCB0d2VldHMgPSBbXTtcbiAgICB0cnkge1xuICAgICAgICBjb25zdCBpbnN0cnVjdGlvbnMgPSBmaW5kSW5zdHJ1Y3Rpb25zUmVjdXJzaXZlKGpzb24pIHx8IFtdO1xuICAgICAgICBmb3IgKGNvbnN0IGluc3RyIG9mIGluc3RydWN0aW9ucykge1xuICAgICAgICAgICAgaWYgKGluc3RyLnR5cGUgPT09ICdUaW1lbGluZUFkZEVudHJpZXMnIHx8IGluc3RyLnR5cGUgPT09ICdUaW1lbGluZVJlcGxhY2VFbnRyeScpIHtcbiAgICAgICAgICAgICAgICBjb25zdCBlbnRyaWVzID0gaW5zdHIuZW50cmllcyB8fCAoaW5zdHIuZW50cnkgPyBbaW5zdHIuZW50cnldIDogW10pO1xuICAgICAgICAgICAgICAgIGZvciAoY29uc3QgZW50cnkgb2YgZW50cmllcykge1xuICAgICAgICAgICAgICAgICAgICAvLyBOb3JtYWwgSXRlbVxuICAgICAgICAgICAgICAgICAgICBjb25zdCByZXN1bHQgPSBlbnRyeT8uY29udGVudD8uaXRlbUNvbnRlbnQ/LnR3ZWV0X3Jlc3VsdHM/LnJlc3VsdFxuICAgICAgICAgICAgICAgICAgICAgICAgfHwgZW50cnk/LmNvbnRlbnQ/LmNvbnRlbnQ/LnR3ZWV0X3Jlc3VsdHM/LnJlc3VsdDtcbiAgICAgICAgICAgICAgICAgICAgaWYgKHJlc3VsdCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgY29uc3QgdHdlZXQgPSBwYXJzZVR3ZWV0UmVzdWx0KHJlc3VsdCk7XG4gICAgICAgICAgICAgICAgICAgICAgICBpZiAodHdlZXQpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB0d2VldHMucHVzaCh0d2VldCk7XG4gICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgLy8gTW9kdWxlIEl0ZW1zIChDb21tb24gaW4gVHdlZXREZXRhaWwgZm9yIHJlcGxpZXMpXG4gICAgICAgICAgICAgICAgICAgIGNvbnN0IGl0ZW1zID0gZW50cnk/LmNvbnRlbnQ/Lml0ZW1zO1xuICAgICAgICAgICAgICAgICAgICBpZiAoQXJyYXkuaXNBcnJheShpdGVtcykpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIGZvciAoY29uc3QgaXRlbSBvZiBpdGVtcykge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbnN0IGl0ZW1SZXN1bHQgPSBpdGVtLml0ZW0/Lml0ZW1Db250ZW50Py50d2VldF9yZXN1bHRzPy5yZXN1bHQ7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgaWYgKGl0ZW1SZXN1bHQpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY29uc3QgdCA9IHBhcnNlVHdlZXRSZXN1bHQoaXRlbVJlc3VsdCk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlmICh0KVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdHdlZXRzLnB1c2godCk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgfVxuICAgIGNhdGNoIChlKSB7XG4gICAgICAgIGNvbnNvbGUud2FybignW1R3ZWV0Q2xhdy1FeHRyYWN0b3JdIEVycm9yIGluIGV4dHJhY3RUd2VldHNGcm9tVGltZWxpbmUnLCBlKTtcbiAgICB9XG4gICAgcmV0dXJuIHR3ZWV0cztcbn1cbi8qKlxuICogTm9ybWFsaXplcyBhIHNpbmdsZSBUd2VldCByZXN1bHQgZnJvbSBYJ3MgR3JhcGhRTCByZXNwb25zZS5cbiAqIFN1cHBvcnRzIHJlY3Vyc2lvbiBmb3IgUXVvdGUgVHdlZXRzICgxIGxldmVsIGRlZXApLlxuICovXG5mdW5jdGlvbiBwYXJzZVR3ZWV0UmVzdWx0KHJlc3VsdCwgZGVwdGggPSAwKSB7XG4gICAgbGV0IGRhdGEgPSByZXN1bHQ7XG4gICAgLy8gSGFuZGxlIG5lc3RlZCByZXN1bHRzXG4gICAgaWYgKGRhdGEudHdlZXQpXG4gICAgICAgIGRhdGEgPSBkYXRhLnR3ZWV0O1xuICAgIGlmIChkYXRhLnJlc3VsdClcbiAgICAgICAgZGF0YSA9IGRhdGEucmVzdWx0O1xuICAgIGlmICghZGF0YSB8fCAhZGF0YS5sZWdhY3kpXG4gICAgICAgIHJldHVybiBudWxsO1xuICAgIC8vIEhhbmRsZSBSZXR3ZWV0czogUHJlZmVyIG9yaWdpbmFsIHR3ZWV0IGZvciB0ZXh0LCBtZXRyaWNzLCBhbmQgYXV0aG9yIGlmIGF2YWlsYWJsZVxuICAgIGxldCBsZWdhY3kgPSBkYXRhLmxlZ2FjeTtcbiAgICBsZXQgY29yZSA9IGRhdGEuY29yZTtcbiAgICBjb25zdCByZXR3ZWV0ZWRSZXN1bHQgPSBkYXRhLnJldHdlZXRlZF9zdGF0dXNfcmVzdWx0Py5yZXN1bHQgfHwgbGVnYWN5LnJldHdlZXRlZF9zdGF0dXNfcmVzdWx0Py5yZXN1bHQ7XG4gICAgaWYgKHJldHdlZXRlZFJlc3VsdCkge1xuICAgICAgICBjb25zdCByTGVnYWN5ID0gcmV0d2VldGVkUmVzdWx0LmxlZ2FjeSB8fCByZXR3ZWV0ZWRSZXN1bHQudHdlZXQ/LmxlZ2FjeTtcbiAgICAgICAgY29uc3QgckNvcmUgPSByZXR3ZWV0ZWRSZXN1bHQuY29yZSB8fCByZXR3ZWV0ZWRSZXN1bHQudHdlZXQ/LmNvcmU7XG4gICAgICAgIGlmIChyTGVnYWN5KVxuICAgICAgICAgICAgbGVnYWN5ID0gckxlZ2FjeTtcbiAgICAgICAgaWYgKHJDb3JlKVxuICAgICAgICAgICAgY29yZSA9IHJDb3JlO1xuICAgIH1cbiAgICAvLyAxLiBBdXRob3IgSW5mb1xuICAgIGxldCBhdXRob3JIYW5kbGUgPSAndW5rbm93bic7XG4gICAgbGV0IGF1dGhvck5hbWUgPSAndW5rbm93bic7XG4gICAgY29uc3QgdXNlclJlc3VsdCA9IGNvcmU/LnVzZXJfcmVzdWx0cz8ucmVzdWx0O1xuICAgIGNvbnN0IHVzZXJMZWdhY3kgPSB1c2VyUmVzdWx0Py5sZWdhY3kgfHwgdXNlclJlc3VsdD8udXNlcj8ubGVnYWN5IHx8IHVzZXJSZXN1bHQ/LnVzZXJfcmVzdWx0cz8ucmVzdWx0Py5sZWdhY3kgfHwgZGF0YS5jb3JlPy51c2VyX3Jlc3VsdHM/LnJlc3VsdD8ubGVnYWN5O1xuICAgIGlmICh1c2VyTGVnYWN5Py5zY3JlZW5fbmFtZSkge1xuICAgICAgICBhdXRob3JIYW5kbGUgPSBgQCR7dXNlckxlZ2FjeS5zY3JlZW5fbmFtZX1gO1xuICAgICAgICBhdXRob3JOYW1lID0gdXNlckxlZ2FjeS5uYW1lIHx8IGF1dGhvckhhbmRsZTtcbiAgICB9XG4gICAgZWxzZSB7XG4gICAgICAgIGNvbnN0IGZvdW5kSGFuZGxlID0gZmluZEZpcnN0U2NyZWVuTmFtZShkYXRhKSB8fCBmaW5kRmlyc3RTY3JlZW5OYW1lKGNvcmUpO1xuICAgICAgICBpZiAoZm91bmRIYW5kbGUpXG4gICAgICAgICAgICBhdXRob3JIYW5kbGUgPSBgQCR7Zm91bmRIYW5kbGV9YDtcbiAgICAgICAgY29uc3QgZm91bmROYW1lID0gZmluZEZpcnN0QXV0aG9yTmFtZShkYXRhKSB8fCBmaW5kRmlyc3RBdXRob3JOYW1lKGNvcmUpO1xuICAgICAgICBpZiAoZm91bmROYW1lKVxuICAgICAgICAgICAgYXV0aG9yTmFtZSA9IGZvdW5kTmFtZTtcbiAgICB9XG4gICAgLy8gMi4gSW50ZXJhY3Rpb24gTWV0cmljc1xuICAgIGNvbnN0IHR3ZWV0ID0ge1xuICAgICAgICB0d2VldElkOiBsZWdhY3kuaWRfc3RyIHx8IGRhdGEucmVzdF9pZCxcbiAgICAgICAgYXV0aG9ySGFuZGxlLFxuICAgICAgICBhdXRob3JOYW1lLFxuICAgICAgICBhdXRob3JJZDogdXNlclJlc3VsdD8ucmVzdF9pZCB8fCAndW5rbm93bicsXG4gICAgICAgIHRleHQ6IGxlZ2FjeS5mdWxsX3RleHQgfHwgJycsXG4gICAgICAgIGNyZWF0ZWRBdDogbGVnYWN5LmNyZWF0ZWRfYXQgfHwgbnVsbCxcbiAgICAgICAgcmVwbHlDb3VudDogbGVnYWN5LnJlcGx5X2NvdW50ID8/IGRhdGEucmVwbHlfY291bnQgPz8gbnVsbCxcbiAgICAgICAgcmVwb3N0Q291bnQ6IGxlZ2FjeS5yZXR3ZWV0X2NvdW50ID8/IGxlZ2FjeS5yZXBvc3RfY291bnQgPz8gZGF0YS5yZXR3ZWV0X2NvdW50ID8/IG51bGwsXG4gICAgICAgIGxpa2VDb3VudDogbGVnYWN5LmZhdm9yaXRlX2NvdW50ID8/IGRhdGEuZmF2b3JpdGVfY291bnQgPz8gbnVsbCxcbiAgICAgICAgYm9va21hcmtDb3VudDogbGVnYWN5LmJvb2ttYXJrX2NvdW50ID8/IGRhdGEuYm9va21hcmtfY291bnQgPz8gbnVsbCxcbiAgICB9O1xuICAgIC8vIDMuIE1lZGlhIEV4dHJhY3Rpb24gKFBob3RvcywgVmlkZW9zLCBHSUZzKVxuICAgIGNvbnN0IG1lZGlhSXRlbXMgPSBsZWdhY3kuZXh0ZW5kZWRfZW50aXRpZXM/Lm1lZGlhIHx8IGxlZ2FjeS5lbnRpdGllcz8ubWVkaWEgfHwgW107XG4gICAgaWYgKG1lZGlhSXRlbXMubGVuZ3RoID4gMCkge1xuICAgICAgICB0d2VldC5tZWRpYSA9IG1lZGlhSXRlbXMubWFwKChtKSA9PiB7XG4gICAgICAgICAgICBjb25zdCBpdGVtID0ge1xuICAgICAgICAgICAgICAgIHR5cGU6IG0udHlwZSA9PT0gJ3Bob3RvJyA/ICdwaG90bycgOiAobS50eXBlID09PSAndmlkZW8nID8gJ3ZpZGVvJyA6IChtLnR5cGUgPT09ICdhbmltYXRlZF9naWYnID8gJ2FuaW1hdGVkX2dpZicgOiAndW5rbm93bicpKSxcbiAgICAgICAgICAgICAgICB1cmw6IG0ubWVkaWFfdXJsX2h0dHBzLFxuICAgICAgICAgICAgICAgIHdpZHRoOiBtLm9yaWdpbmFsX2luZm8/LndpZHRoLFxuICAgICAgICAgICAgICAgIGhlaWdodDogbS5vcmlnaW5hbF9pbmZvPy5oZWlnaHQsXG4gICAgICAgICAgICB9O1xuICAgICAgICAgICAgaWYgKG0udmlkZW9faW5mbykge1xuICAgICAgICAgICAgICAgIGl0ZW0uZHVyYXRpb25fbXMgPSBtLnZpZGVvX2luZm8uZHVyYXRpb25fbXM7XG4gICAgICAgICAgICAgICAgaWYgKG0udmlkZW9faW5mby52YXJpYW50cykge1xuICAgICAgICAgICAgICAgICAgICBpdGVtLnZhcmlhbnRfdXJscyA9IG0udmlkZW9faW5mby52YXJpYW50c1xuICAgICAgICAgICAgICAgICAgICAgICAgLmZpbHRlcigodikgPT4gdi51cmwpXG4gICAgICAgICAgICAgICAgICAgICAgICAubWFwKCh2KSA9PiB2LnVybCk7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfVxuICAgICAgICAgICAgcmV0dXJuIGl0ZW07XG4gICAgICAgIH0pO1xuICAgICAgICB0d2VldC5tZWRpYV9jb3VudCA9IHR3ZWV0Lm1lZGlhPy5sZW5ndGggfHwgMDtcbiAgICB9XG4gICAgLy8gNC4gUXVvdGUgVHdlZXQgRXhwYW5zaW9uIChMaW1pdCBkZXB0aCB0byAxKVxuICAgIGlmIChkZXB0aCA9PT0gMCkge1xuICAgICAgICBjb25zdCBxdW90ZWRSZXN1bHQgPSBkYXRhLnF1b3RlZF9zdGF0dXNfcmVzdWx0IHx8IGxlZ2FjeS5xdW90ZWRfc3RhdHVzX3Jlc3VsdDtcbiAgICAgICAgaWYgKHF1b3RlZFJlc3VsdCkge1xuICAgICAgICAgICAgY29uc3QgcXVvdGVkVHdlZXQgPSBwYXJzZVR3ZWV0UmVzdWx0KHF1b3RlZFJlc3VsdCwgMSk7XG4gICAgICAgICAgICBpZiAocXVvdGVkVHdlZXQpIHtcbiAgICAgICAgICAgICAgICB0d2VldC5xdW90ZWRfdHdlZXQgPSBxdW90ZWRUd2VldDtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgIH1cbiAgICByZXR1cm4gdHdlZXQ7XG59XG4vKipcbiAqIEhlbHBlciB0byBmaW5kIHRoZSBmaXJzdCBzY3JlZW5fbmFtZSBpbiBhIHVzZXItcmVsYXRlZCBzdWItb2JqZWN0LlxuICovXG5mdW5jdGlvbiBmaW5kRmlyc3RTY3JlZW5OYW1lKG9iaikge1xuICAgIGlmICghb2JqIHx8IHR5cGVvZiBvYmogIT09ICdvYmplY3QnKVxuICAgICAgICByZXR1cm4gbnVsbDtcbiAgICBpZiAob2JqLnNjcmVlbl9uYW1lKVxuICAgICAgICByZXR1cm4gb2JqLnNjcmVlbl9uYW1lO1xuICAgIGZvciAoY29uc3Qga2V5IGluIG9iaikge1xuICAgICAgICBpZiAob2JqLmhhc093blByb3BlcnR5KGtleSkpIHtcbiAgICAgICAgICAgIGNvbnN0IGZvdW5kID0gZmluZEZpcnN0U2NyZWVuTmFtZShvYmpba2V5XSk7XG4gICAgICAgICAgICBpZiAoZm91bmQpXG4gICAgICAgICAgICAgICAgcmV0dXJuIGZvdW5kO1xuICAgICAgICB9XG4gICAgfVxuICAgIHJldHVybiBudWxsO1xufVxuLyoqXG4gKiBIZWxwZXIgdG8gZmluZCB0aGUgZmlyc3QgJ25hbWUnIGluIGEgdXNlci1yZWxhdGVkIHN1Yi1vYmplY3QuXG4gKi9cbmZ1bmN0aW9uIGZpbmRGaXJzdEF1dGhvck5hbWUob2JqKSB7XG4gICAgaWYgKCFvYmogfHwgdHlwZW9mIG9iaiAhPT0gJ29iamVjdCcpXG4gICAgICAgIHJldHVybiBudWxsO1xuICAgIGlmIChvYmoubmFtZSlcbiAgICAgICAgcmV0dXJuIG9iai5uYW1lO1xuICAgIGZvciAoY29uc3Qga2V5IGluIG9iaikge1xuICAgICAgICBpZiAob2JqLmhhc093blByb3BlcnR5KGtleSkpIHtcbiAgICAgICAgICAgIGNvbnN0IGZvdW5kID0gZmluZEZpcnN0QXV0aG9yTmFtZShvYmpba2V5XSk7XG4gICAgICAgICAgICBpZiAoZm91bmQpXG4gICAgICAgICAgICAgICAgcmV0dXJuIGZvdW5kO1xuICAgICAgICB9XG4gICAgfVxuICAgIHJldHVybiBudWxsO1xufVxuIiwiLy8g5LuF5o+Q5L6b5bqT6YeM5Lya55So5Yiw55qEIHBhcnNlSFRNTO+8jOi/lOWbnue7k+aehOi3nyBsaW5rZWRvbSDnsbvkvLxcbmV4cG9ydCBmdW5jdGlvbiBwYXJzZUhUTUwoaHRtbCkge1xuICAgIGNvbnN0IHBhcnNlciA9IG5ldyBET01QYXJzZXIoKTtcbiAgICBjb25zdCBkb2N1bWVudCA9IHBhcnNlci5wYXJzZUZyb21TdHJpbmcoaHRtbCwgXCJ0ZXh0L2h0bWxcIik7XG4gICAgcmV0dXJuIHsgd2luZG93OiB7IGRvY3VtZW50IH0gfTtcbn1cbiIsImV4cG9ydCBmdW5jdGlvbiBwYXJzZVJvdXRlS2luZCh1cmwpIHtcbiAgICBpZiAoIXVybCB8fCAhKHVybC5pbmNsdWRlcygneC5jb20nKSB8fCB1cmwuaW5jbHVkZXMoJ3R3aXR0ZXIuY29tJykpKVxuICAgICAgICByZXR1cm4gJ25vbmUnO1xuICAgIHRyeSB7XG4gICAgICAgIGNvbnN0IHUgPSBuZXcgVVJMKHVybCk7XG4gICAgICAgIGNvbnN0IHBhdGggPSB1LnBhdGhuYW1lO1xuICAgICAgICBpZiAocGF0aCA9PT0gJy9ob21lJyB8fCBwYXRoID09PSAnLycpXG4gICAgICAgICAgICByZXR1cm4gJ2hvbWUnO1xuICAgICAgICBpZiAocGF0aC5pbmNsdWRlcygnL3NlYXJjaCcpKVxuICAgICAgICAgICAgcmV0dXJuICdzZWFyY2gnO1xuICAgICAgICBpZiAocGF0aC5pbmNsdWRlcygnL3N0YXR1cy8nKSlcbiAgICAgICAgICAgIHJldHVybiAndGhyZWFkJztcbiAgICAgICAgaWYgKHBhdGguaW5jbHVkZXMoJy9ub3RpZmljYXRpb25zJykpXG4gICAgICAgICAgICByZXR1cm4gJ25vdGlmaWNhdGlvbic7XG4gICAgICAgIHJldHVybiAncHJvZmlsZSc7XG4gICAgfVxuICAgIGNhdGNoIHtcbiAgICAgICAgcmV0dXJuICd1bmtub3duJztcbiAgICB9XG59XG5leHBvcnQgZnVuY3Rpb24gZXh0cmFjdFR3ZWV0SWQodXJsKSB7XG4gICAgaWYgKCF1cmwpXG4gICAgICAgIHJldHVybiBudWxsO1xuICAgIHRyeSB7XG4gICAgICAgIGNvbnN0IHUgPSBuZXcgVVJMKHVybCk7XG4gICAgICAgIGNvbnN0IG1hdGNoID0gdS5wYXRobmFtZS5tYXRjaCgvXFwvc3RhdHVzXFwvKFxcZCspLyk7XG4gICAgICAgIHJldHVybiBtYXRjaCA/IG1hdGNoWzFdIDogbnVsbDtcbiAgICB9XG4gICAgY2F0Y2gge1xuICAgICAgICByZXR1cm4gbnVsbDtcbiAgICB9XG59XG4iLCIvKipcbiAqIEZlYXR1cmUgTWFuYWdlciBmb3IgWCBHcmFwaFFMIHJlcXVlc3RzXG4gKiBIYW5kbGVzIGR5bmFtaWMgZmVhdHVyZSBkaXNjb3ZlcnkgZnJvbSA0MDAvNDAzLzQwNCBlcnJvcnMuXG4gKlxuICogU3RyYXRlZ3k6XG4gKiAxLiBFYWNoIG9wZXJhdGlvbiBoYXMgaXRzIG93biBmZWF0dXJlIGNhY2hlIChwZXItb3BlcmF0aW9uIGZlYXR1cmVzKVxuICogMi4gV2hlbiBhIHJlcXVlc3QgZmFpbHMsIHdlIGNhcHR1cmUgZmVhdHVyZXMgZnJvbSBzdWNjZXNzZnVsIGJyb3dzZXIgcmVxdWVzdHNcbiAqIDMuIEZlYXR1cmVzIGFyZSBtZXJnZWQ6IGJhc2UgKyBnbG9iYWwgZHluYW1pYyArIHBlci1vcGVyYXRpb25cbiAqL1xuaW1wb3J0IHsgX19EQktfZHluYW1pY19mZWF0dXJlcyB9IGZyb20gJy4uL2NhcHR1cmUvY29uc3RzJztcbmNvbnN0IF9fREJLX3Blcl9vcF9mZWF0dXJlcyA9ICd0Y19wZXJfb3BfZmVhdHVyZXMnO1xuZXhwb3J0IGNvbnN0IGJhc2VGZWF0dXJlcyA9IHtcbiAgICByZXNwb25zaXZlX3dlYl9ncmFwaHFsX3RpbWVsaW5lX25hdmlnYXRpb25fZW5hYmxlZDogdHJ1ZSxcbiAgICByZXNwb25zaXZlX3dlYl9ncmFwaHFsX3NraXBfdXNlcl9wcm9maWxlX2ltYWdlX2V4dGVuc2lvbnNfZW5hYmxlZDogZmFsc2UsXG4gICAgY3JlYXRvcl9zdWJzY3JpcHRpb25zX3R3ZWV0X3ByZXZpZXdfYXBpX2VuYWJsZWQ6IHRydWUsXG4gICAgcmVzcG9uc2l2ZV93ZWJfZWRpdF90d2VldF9hcGlfZW5hYmxlZDogdHJ1ZSxcbiAgICBncmFwaHFsX2lzX3RyYW5zbGF0YWJsZV9yd2ViX3R3ZWV0X2lzX3RyYW5zbGF0YWJsZV9lbmFibGVkOiB0cnVlLFxuICAgIHZpZXdfY291bnRzX2V2ZXJ5d2hlcmVfYXBpX2VuYWJsZWQ6IHRydWUsXG4gICAgbG9uZ2Zvcm1fbm90ZXR3ZWV0c19jb25zdW1wdGlvbl9lbmFibGVkOiB0cnVlLFxuICAgIHJlc3BvbnNpdmVfd2ViX3R3aXR0ZXJfYXJ0aWNsZV90d2VldF9jb25zdW1wdGlvbl9lbmFibGVkOiB0cnVlLFxuICAgIHR3ZWV0X3dpdGhfdmlzaWJpbGl0eV9yZXN1bHRzX3ByZWZlcl9ncWxfbGltaXRlZF9hY3Rpb25zX3BvbGljeV9lbmFibGVkOiB0cnVlLFxuICAgIGxvbmdmb3JtX25vdGV0d2VldHNfcmljaF90ZXh0X3JlYWRfZW5hYmxlZDogdHJ1ZSxcbiAgICBsb25nZm9ybV9ub3RldHdlZXRzX2lubGluZV9tZWRpYV9lbmFibGVkOiB0cnVlLFxuICAgIHJ3ZWJfdmlkZW9fc2NyZWVuX2VuYWJsZWQ6IGZhbHNlLFxuICAgIHN0YW5kYXJkaXplZF9udWRnZXNfbWlzaW5mbzogdHJ1ZSxcbiAgICBmcmVlZG9tX29mX3NwZWVjaF9ub3RfcmVhY2hfZmV0Y2hfZW5hYmxlZDogdHJ1ZSxcbiAgICByZXNwb25zaXZlX3dlYl9lbmhhbmNlX2NhcmRzX2VuYWJsZWQ6IGZhbHNlLFxuICAgIGFydGljbGVzX3ByZXZpZXdfZW5hYmxlZDogdHJ1ZSxcbiAgICBjb21tdW5pdGllc193ZWJfZW5hYmxlX3R3ZWV0X2NvbW11bml0eV9yZXN1bHRzX2ZldGNoOiB0cnVlLFxuICAgIGM5c190d2VldF9hbmF0b215X21vZGVyYXRvcl9iYWRnZV9lbmFibGVkOiB0cnVlXG59O1xuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGV4dHJhY3RNaXNzaW5nRmVhdHVyZShib2R5KSB7XG4gICAgaWYgKCFib2R5KVxuICAgICAgICByZXR1cm4gbnVsbDtcbiAgICAvLyBYIG5vcm1hbGx5IHJldHVybnM6IFwiY2Fubm90IGJlIG51bGw6IHNvbWVfZmVhdHVyZV9mbGFnXCJcbiAgICBjb25zdCBtID0gYm9keS5tYXRjaCgvY2Fubm90IGJlIG51bGw6XFxzKihbYS16QS1aMC05X10rKS8pO1xuICAgIGlmICghbSlcbiAgICAgICAgcmV0dXJuIG51bGw7XG4gICAgY29uc3QgZmVhdHVyZSA9IG1bMV07XG4gICAgY29uc3QgZGF0YSA9IGF3YWl0IGNocm9tZS5zdG9yYWdlLmxvY2FsLmdldChfX0RCS19keW5hbWljX2ZlYXR1cmVzKTtcbiAgICBjb25zdCBjdXJyZW50ID0gKGRhdGFbX19EQktfZHluYW1pY19mZWF0dXJlc10gfHwge30pO1xuICAgIGlmICghKGZlYXR1cmUgaW4gY3VycmVudCkpIHtcbiAgICAgICAgY3VycmVudFtmZWF0dXJlXSA9IHRydWU7XG4gICAgICAgIGF3YWl0IGNocm9tZS5zdG9yYWdlLmxvY2FsLnNldCh7IFtfX0RCS19keW5hbWljX2ZlYXR1cmVzXTogY3VycmVudCB9KTtcbiAgICAgICAgY29uc29sZS5sb2coXCJbVHdlZXRDbGF3LUZlYXR1cmVdIEF1dG8taGFydmVzdGVkIG5ldyBmZWF0dXJlIGZsYWc6XCIsIGZlYXR1cmUpO1xuICAgIH1cbiAgICByZXR1cm4gZmVhdHVyZTtcbn1cbi8qKlxuICogQnVpbGQgZmVhdHVyZXMgZm9yIGEgc3BlY2lmaWMgb3BlcmF0aW9uXG4gKiBQcmlvcml0eTogYmFzZSA8IGdsb2JhbCBkeW5hbWljIDwgcGVyLW9wZXJhdGlvblxuICovXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gYnVpbGRGZWF0dXJlcyhvcCkge1xuICAgIGNvbnN0IGRhdGEgPSBhd2FpdCBjaHJvbWUuc3RvcmFnZS5sb2NhbC5nZXQoW19fREJLX2R5bmFtaWNfZmVhdHVyZXMsIF9fREJLX3Blcl9vcF9mZWF0dXJlc10pO1xuICAgIGNvbnN0IGdsb2JhbER5bmFtaWMgPSAoZGF0YVtfX0RCS19keW5hbWljX2ZlYXR1cmVzXSB8fCB7fSk7XG4gICAgY29uc3QgcGVyT3BGZWF0dXJlcyA9IChkYXRhW19fREJLX3Blcl9vcF9mZWF0dXJlc10gfHwge30pO1xuICAgIGNvbnN0IG9wU3BlY2lmaWMgPSBvcCA/IChwZXJPcEZlYXR1cmVzW29wXSB8fCB7fSkgOiB7fTtcbiAgICByZXR1cm4geyAuLi5iYXNlRmVhdHVyZXMsIC4uLmdsb2JhbER5bmFtaWMsIC4uLm9wU3BlY2lmaWMgfTtcbn1cbi8qKlxuICogQ2FjaGUgZmVhdHVyZXMgZm9yIGEgc3BlY2lmaWMgb3BlcmF0aW9uIChsZWFybmVkIGZyb20gc3VjY2Vzc2Z1bCBicm93c2VyIHJlcXVlc3RzKVxuICovXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gY2FjaGVPcGVyYXRpb25GZWF0dXJlcyhvcCwgZmVhdHVyZXMpIHtcbiAgICBjb25zdCBkYXRhID0gYXdhaXQgY2hyb21lLnN0b3JhZ2UubG9jYWwuZ2V0KF9fREJLX3Blcl9vcF9mZWF0dXJlcyk7XG4gICAgY29uc3QgcGVyT3BGZWF0dXJlcyA9IChkYXRhW19fREJLX3Blcl9vcF9mZWF0dXJlc10gfHwge30pO1xuICAgIC8vIE1lcmdlIHdpdGggZXhpc3RpbmcgZmVhdHVyZXMgZm9yIHRoaXMgb3BlcmF0aW9uXG4gICAgcGVyT3BGZWF0dXJlc1tvcF0gPSB7IC4uLihwZXJPcEZlYXR1cmVzW29wXSB8fCB7fSksIC4uLmZlYXR1cmVzIH07XG4gICAgYXdhaXQgY2hyb21lLnN0b3JhZ2UubG9jYWwuc2V0KHsgW19fREJLX3Blcl9vcF9mZWF0dXJlc106IHBlck9wRmVhdHVyZXMgfSk7XG4gICAgY29uc29sZS5sb2coYFtUd2VldENsYXctRmVhdHVyZV0gQ2FjaGVkIGZlYXR1cmVzIGZvciAke29wfTpgLCBPYmplY3Qua2V5cyhmZWF0dXJlcykubGVuZ3RoLCAnZmxhZ3MnKTtcbn1cbi8qKlxuICogR2V0IGNhY2hlZCBmZWF0dXJlcyBmb3IgYSBzcGVjaWZpYyBvcGVyYXRpb25cbiAqL1xuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGdldE9wZXJhdGlvbkZlYXR1cmVzKG9wKSB7XG4gICAgY29uc3QgZGF0YSA9IGF3YWl0IGNocm9tZS5zdG9yYWdlLmxvY2FsLmdldChfX0RCS19wZXJfb3BfZmVhdHVyZXMpO1xuICAgIGNvbnN0IHBlck9wRmVhdHVyZXMgPSAoZGF0YVtfX0RCS19wZXJfb3BfZmVhdHVyZXNdIHx8IHt9KTtcbiAgICByZXR1cm4gcGVyT3BGZWF0dXJlc1tvcF0gfHwgbnVsbDtcbn1cbiIsImltcG9ydCB7IF9fREJLX3F1ZXJ5X2lkX21hcCwgX19EQktfYmVhcmVyX3Rva2VuIH0gZnJvbSAnLi4vY2FwdHVyZS9jb25zdHMnO1xuaW1wb3J0IHsgYnVpbGRGZWF0dXJlcywgZXh0cmFjdE1pc3NpbmdGZWF0dXJlIH0gZnJvbSAnLi9mZWF0dXJlX21hbmFnZXInO1xuaW1wb3J0IHsgZ2V0VHJhbnNhY3Rpb25JZEZvciB9IGZyb20gJy4vdHhpZCc7XG4vKipcbiAqIFR3aXR0ZXIgQVBJIENsaWVudFxuICogRGVzaWduZWQgdG8gcnVuIGluIENvbnRlbnQgU2NyaXB0IChmb3IgY29va2llcykgYW5kIEJhY2tncm91bmQgKGZvciBoYXJ2ZXN0aW5nKS5cbiAqL1xuYXN5bmMgZnVuY3Rpb24gZ2V0QXV0aEhlYWRlcigpIHtcbiAgICBjb25zdCByZXMgPSBhd2FpdCBjaHJvbWUuc3RvcmFnZS5sb2NhbC5nZXQoX19EQktfYmVhcmVyX3Rva2VuKTtcbiAgICByZXR1cm4gcmVzW19fREJLX2JlYXJlcl90b2tlbl0gfHwgXCJcIjtcbn1cbmFzeW5jIGZ1bmN0aW9uIGdldENzcmZUb2tlbigpIHtcbiAgICAvLyBDb250ZW50IHNjcmlwdDogcmVhZCBmcm9tIGRvY3VtZW50LmNvb2tpZVxuICAgIC8vIEJhY2tncm91bmQ6IHJlYWQgZnJvbSBjaHJvbWUuY29va2llc1xuICAgIGlmICh0eXBlb2YgZG9jdW1lbnQgIT09ICd1bmRlZmluZWQnICYmIGRvY3VtZW50LmNvb2tpZSkge1xuICAgICAgICBjb25zdCBtYXRjaCA9IGRvY3VtZW50LmNvb2tpZS5tYXRjaCgvKD86Xnw7XFxzKiljdDA9KFteO10rKS8pO1xuICAgICAgICBpZiAobWF0Y2gpXG4gICAgICAgICAgICByZXR1cm4gbWF0Y2hbMV07XG4gICAgfVxuICAgIHJldHVybiBuZXcgUHJvbWlzZSgocmVzb2x2ZSkgPT4ge1xuICAgICAgICBjaHJvbWUuY29va2llcy5nZXQoeyB1cmw6ICdodHRwczovL3guY29tJywgbmFtZTogJ2N0MCcgfSwgKGNvb2tpZSkgPT4ge1xuICAgICAgICAgICAgcmVzb2x2ZShjb29raWUgPyBjb29raWUudmFsdWUgOiBcIlwiKTtcbiAgICAgICAgfSk7XG4gICAgfSk7XG59XG5hc3luYyBmdW5jdGlvbiBnZXRVcmxXaXRoUXVlcnlJZChvcCkge1xuICAgIGNvbnN0IHJlcyA9IGF3YWl0IGNocm9tZS5zdG9yYWdlLmxvY2FsLmdldChfX0RCS19xdWVyeV9pZF9tYXApO1xuICAgIGNvbnN0IG1hcCA9IChyZXNbX19EQktfcXVlcnlfaWRfbWFwXSB8fCB7fSk7XG4gICAgY29uc3QgcXVlcnlJZCA9IG1hcFtvcF07XG4gICAgaWYgKCFxdWVyeUlkKVxuICAgICAgICByZXR1cm4gbnVsbDtcbiAgICBjb25zdCB1cmwgPSBgaHR0cHM6Ly94LmNvbS9pL2FwaS9ncmFwaHFsLyR7cXVlcnlJZH0vJHtvcH1gO1xuICAgIGNvbnN0IHBhdGggPSBgL2kvYXBpL2dyYXBocWwvJHtxdWVyeUlkfS8ke29wfWA7XG4gICAgcmV0dXJuIHsgdXJsLCBwYXRoIH07XG59XG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gcGVyZm9ybU11dGF0aW9uKG9wLCB2YXJpYWJsZXMsIHJldHJ5Q291bnQgPSAwKSB7XG4gICAgY29uc3QgdGFyZ2V0ID0gYXdhaXQgZ2V0VXJsV2l0aFF1ZXJ5SWQob3ApO1xuICAgIGlmICghdGFyZ2V0KVxuICAgICAgICB0aHJvdyBuZXcgRXJyb3IoYE1pc3NpbmcgaGFydmVzdGVkIHF1ZXJ5SWQgZm9yIG9wZXJhdGlvbjogJHtvcH1gKTtcbiAgICBjb25zdCBiZWFyZXIgPSBhd2FpdCBnZXRBdXRoSGVhZGVyKCk7XG4gICAgY29uc3QgY3NyZiA9IGF3YWl0IGdldENzcmZUb2tlbigpO1xuICAgIC8vIFR3ZWV0Q2F0IHR4aWQgbG9naWNcbiAgICBjb25zdCB0eGlkID0gYXdhaXQgZ2V0VHJhbnNhY3Rpb25JZEZvcignUE9TVCcsIHRhcmdldC5wYXRoKTtcbiAgICBjb25zdCBoZWFkZXJzID0ge1xuICAgICAgICAnYXV0aG9yaXphdGlvbic6IGJlYXJlcixcbiAgICAgICAgJ3gtY3NyZi10b2tlbic6IGNzcmYsXG4gICAgICAgICd4LWNsaWVudC10cmFuc2FjdGlvbi1pZCc6IHR4aWQsXG4gICAgICAgICdjb250ZW50LXR5cGUnOiAnYXBwbGljYXRpb24vanNvbicsXG4gICAgICAgICd4LXR3aXR0ZXItYWN0aXZlLXVzZXInOiAneWVzJyxcbiAgICAgICAgJ3gtdHdpdHRlci1hdXRoLXR5cGUnOiAnT0F1dGgyU2Vzc2lvbicsXG4gICAgICAgICd4LXR3aXR0ZXItY2xpZW50LWxhbmd1YWdlJzogJ3poLWNuJyxcbiAgICAgICAgJ3JlZmVyZXInOiAnaHR0cHM6Ly94LmNvbS8nLFxuICAgICAgICAnYWNjZXB0JzogJyovKidcbiAgICB9O1xuICAgIC8vIFNvbWUgb3BlcmF0aW9ucyAobGlrZSBDcmVhdGVCb29rbWFyaywgRGVsZXRlQm9va21hcmspIGRvbid0IG5lZWQgZmVhdHVyZXNcbiAgICBjb25zdCBvcGVyYXRpb25zV2l0aG91dEZlYXR1cmVzID0gWydDcmVhdGVCb29rbWFyaycsICdEZWxldGVCb29rbWFyayddO1xuICAgIGNvbnN0IG5lZWRzRmVhdHVyZXMgPSAhb3BlcmF0aW9uc1dpdGhvdXRGZWF0dXJlcy5pbmNsdWRlcyhvcCk7XG4gICAgY29uc3QgcGF5bG9hZCA9IHtcbiAgICAgICAgdmFyaWFibGVzLFxuICAgICAgICBxdWVyeUlkOiB0YXJnZXQudXJsLnNwbGl0KCcvJylbNl0gLy8gRml4OiBzaG91bGQgYmUgaW5kZXggNiwgbm90IDVcbiAgICB9O1xuICAgIC8vIE9ubHkgYWRkIGZlYXR1cmVzIGlmIG5lZWRlZFxuICAgIGlmIChuZWVkc0ZlYXR1cmVzKSB7XG4gICAgICAgIGNvbnN0IGZlYXR1cmVzID0gYXdhaXQgYnVpbGRGZWF0dXJlcyhvcCk7XG4gICAgICAgIHBheWxvYWQuZmVhdHVyZXMgPSBmZWF0dXJlcztcbiAgICAgICAgY29uc29sZS5sb2coYFtUd2l0dGVyQVBJXSAke29wfSByZXF1ZXN0IHdpdGggZmVhdHVyZXM6YCwgT2JqZWN0LmtleXMoZmVhdHVyZXMpKTtcbiAgICB9XG4gICAgZWxzZSB7XG4gICAgICAgIGNvbnNvbGUubG9nKGBbVHdpdHRlckFQSV0gJHtvcH0gcmVxdWVzdCB3aXRob3V0IGZlYXR1cmVzYCk7XG4gICAgfVxuICAgIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgZmV0Y2godGFyZ2V0LnVybCwge1xuICAgICAgICBtZXRob2Q6ICdQT1NUJyxcbiAgICAgICAgaGVhZGVycyxcbiAgICAgICAgYm9keTogSlNPTi5zdHJpbmdpZnkocGF5bG9hZCksXG4gICAgICAgIGNyZWRlbnRpYWxzOiAnaW5jbHVkZSdcbiAgICB9KTtcbiAgICBpZiAoIXJlc3BvbnNlLm9rKSB7XG4gICAgICAgIGNvbnN0IHRleHQgPSBhd2FpdCByZXNwb25zZS50ZXh0KCk7XG4gICAgICAgIGNvbnNvbGUuZXJyb3IoYFtUd2l0dGVyQVBJXSAke29wfSBmYWlsZWQgKCR7cmVzcG9uc2Uuc3RhdHVzfSk6YCwgdGV4dCk7XG4gICAgICAgIC8vIFRyeSB0byBleHRyYWN0IG1pc3NpbmcgZmVhdHVyZSBmcm9tIGVycm9yIHJlc3BvbnNlXG4gICAgICAgIGNvbnN0IG1pc3NpbmdGZWF0dXJlID0gYXdhaXQgZXh0cmFjdE1pc3NpbmdGZWF0dXJlKHRleHQpO1xuICAgICAgICAvLyBJZiB3ZSBmb3VuZCBhIG1pc3NpbmcgZmVhdHVyZSBhbmQgaGF2ZW4ndCByZXRyaWVkIHlldCwgcmV0cnkgd2l0aCB0aGUgbmV3IGZlYXR1cmVcbiAgICAgICAgaWYgKG1pc3NpbmdGZWF0dXJlICYmIHJldHJ5Q291bnQgPT09IDApIHtcbiAgICAgICAgICAgIGNvbnNvbGUud2FybihgW1R3aXR0ZXJBUEldICR7b3B9IG1pc3NpbmcgZmVhdHVyZTogJHttaXNzaW5nRmVhdHVyZX0sIHJldHJ5aW5nLi4uYCk7XG4gICAgICAgICAgICByZXR1cm4gcGVyZm9ybU11dGF0aW9uKG9wLCB2YXJpYWJsZXMsIHJldHJ5Q291bnQgKyAxKTtcbiAgICAgICAgfVxuICAgICAgICB0aHJvdyBuZXcgRXJyb3IoYFggQVBJIEVycm9yICR7cmVzcG9uc2Uuc3RhdHVzfSBmb3IgJHtvcH06ICR7dGV4dH1gKTtcbiAgICB9XG4gICAgcmV0dXJuIGF3YWl0IHJlc3BvbnNlLmpzb24oKTtcbn1cbi8qKlxuICog5LiT6Zeo5aSE55CG5o6o54m56ICB5pen55qEIDEuMSBSRVNUIEFQSe+8iOWmgiBmcmllbmRzaGlwcy9jcmVhdGUuanNvbu+8iVxuICog6L+Z5Lqb5o6l5Y+j5LiN5L2/55SoIEdyYXBoUUzvvIzkuZ/kuI3pnIDopoEgcXVlcnlJZOOAglxuICovXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gcGVyZm9ybUxlZ2FjeVJFU1QocGF0aCwgcGFyYW1zKSB7XG4gICAgY29uc3QgYmVhcmVyID0gYXdhaXQgZ2V0QXV0aEhlYWRlcigpO1xuICAgIGNvbnN0IGNzcmYgPSBhd2FpdCBnZXRDc3JmVG9rZW4oKTtcbiAgICBjb25zdCB0eGlkID0gYXdhaXQgZ2V0VHJhbnNhY3Rpb25JZEZvcignUE9TVCcsIHBhdGgpO1xuICAgIGNvbnN0IGhlYWRlcnMgPSB7XG4gICAgICAgICdhdXRob3JpemF0aW9uJzogYmVhcmVyLFxuICAgICAgICAneC1jc3JmLXRva2VuJzogY3NyZixcbiAgICAgICAgJ3gtY2xpZW50LXRyYW5zYWN0aW9uLWlkJzogdHhpZCxcbiAgICAgICAgJ2NvbnRlbnQtdHlwZSc6ICdhcHBsaWNhdGlvbi94LXd3dy1mb3JtLXVybGVuY29kZWQnLFxuICAgICAgICAneC10d2l0dGVyLWFjdGl2ZS11c2VyJzogJ3llcycsXG4gICAgICAgICd4LXR3aXR0ZXItYXV0aC10eXBlJzogJ09BdXRoMlNlc3Npb24nLFxuICAgICAgICAncmVmZXJlcic6ICdodHRwczovL3guY29tLycsXG4gICAgICAgICdhY2NlcHQnOiAnKi8qJ1xuICAgIH07XG4gICAgY29uc3QgdXJsID0gYGh0dHBzOi8veC5jb20ke3BhdGh9YDtcbiAgICBjb25zdCBib2R5ID0gbmV3IFVSTFNlYXJjaFBhcmFtcyhwYXJhbXMpLnRvU3RyaW5nKCk7XG4gICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBmZXRjaCh1cmwsIHtcbiAgICAgICAgbWV0aG9kOiAnUE9TVCcsXG4gICAgICAgIGhlYWRlcnMsXG4gICAgICAgIGJvZHksXG4gICAgICAgIGNyZWRlbnRpYWxzOiAnaW5jbHVkZSdcbiAgICB9KTtcbiAgICBpZiAoIXJlc3BvbnNlLm9rKSB7XG4gICAgICAgIGNvbnN0IHRleHQgPSBhd2FpdCByZXNwb25zZS50ZXh0KCk7XG4gICAgICAgIHRocm93IG5ldyBFcnJvcihgWCBMZWdhY3kgQVBJIEVycm9yICR7cmVzcG9uc2Uuc3RhdHVzfSBmb3IgJHtwYXRofTogJHt0ZXh0fWApO1xuICAgIH1cbiAgICByZXR1cm4gYXdhaXQgcmVzcG9uc2UuanNvbigpO1xufVxuLyoqXG4gKiDkvb/nlKjnqLPlrprnmoQgUXVlcnlJZCDmipPlj5bnlKjmiLfotYTmlpnvvIjnu5Xov4flk4jluIzlj5jliqjpl67popjvvIlcbiAqIOS7heS+m+WcqCBDb250ZW50IFNjcmlwdCDnjq/looPvvIjnlLHkuo4gQ29va2llIOadg+mZkOmXrumimO+8ieS9v+eUqFxuICovXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZmV0Y2hVc2VyQnlTY3JlZW5OYW1lKHNjcmVlbk5hbWUpIHtcbiAgICBjb25zdCBTVEFCTEVfSEFTSCA9ICdjazVLa1o4dDVjT21vTHNzb3BOOTlRJztcbiAgICBjb25zdCB2YXJpYWJsZXMgPSB7XG4gICAgICAgIHNjcmVlbl9uYW1lOiBzY3JlZW5OYW1lLFxuICAgICAgICB3aXRoU2FmZXR5TW9kZVVzZXJGaWVsZHM6IHRydWUsXG4gICAgfTtcbiAgICBjb25zdCBmZWF0dXJlcyA9IHtcbiAgICAgICAgaGlkZGVuX3Byb2ZpbGVfbGlrZXNfZW5hYmxlZDogdHJ1ZSxcbiAgICAgICAgaGlkZGVuX3Byb2ZpbGVfc3Vic2NyaXB0aW9uc19lbmFibGVkOiB0cnVlLFxuICAgICAgICByZXNwb25zaXZlX3dlYl9ncmFwaHFsX2V4Y2x1ZGVfZGlyZWN0aXZlX2VuYWJsZWQ6IHRydWUsXG4gICAgICAgIHZlcmlmaWVkX3Bob25lX2xhYmVsX2VuYWJsZWQ6IGZhbHNlLFxuICAgICAgICBzdWJzY3JpcHRpb25zX3ZlcmlmaWNhdGlvbl9pbmZvX2lzX2lkZW50aXR5X3ZlcmlmaWVkX2VuYWJsZWQ6IHRydWUsXG4gICAgICAgIHN1YnNjcmlwdGlvbnNfdmVyaWZpY2F0aW9uX2luZm9fdmVyaWZpZWRfc2luY2VfZW5hYmxlZDogdHJ1ZSxcbiAgICAgICAgaGlnaGxpZ2h0c190d2VldHNfdGFiX3VpX2VuYWJsZWQ6IHRydWUsXG4gICAgICAgIHJlc3BvbnNpdmVfd2ViX3R3aXR0ZXJfYXJ0aWNsZV9ub3Rlc190YWJfZW5hYmxlZDogZmFsc2UsXG4gICAgICAgIGNyZWF0b3Jfc3Vic2NyaXB0aW9uc190d2VldF9wcmV2aWV3X2FwaV9lbmFibGVkOiB0cnVlLFxuICAgICAgICByZXNwb25zaXZlX3dlYl9ncmFwaHFsX3NraXBfdXNlcl9wcm9maWxlX2ltYWdlX2V4dGVuc2lvbnNfZW5hYmxlZDogZmFsc2UsXG4gICAgICAgIHJlc3BvbnNpdmVfd2ViX2dyYXBocWxfdGltZWxpbmVfbmF2aWdhdGlvbl9lbmFibGVkOiB0cnVlLFxuICAgIH07XG4gICAgY29uc3QgcGFyYW1zID0gbmV3IFVSTFNlYXJjaFBhcmFtcygpO1xuICAgIHBhcmFtcy5hcHBlbmQoJ3ZhcmlhYmxlcycsIEpTT04uc3RyaW5naWZ5KHZhcmlhYmxlcykpO1xuICAgIHBhcmFtcy5hcHBlbmQoJ2ZlYXR1cmVzJywgSlNPTi5zdHJpbmdpZnkoZmVhdHVyZXMpKTtcbiAgICBjb25zdCB1cmwgPSBgaHR0cHM6Ly94LmNvbS9pL2FwaS9ncmFwaHFsLyR7U1RBQkxFX0hBU0h9L1VzZXJCeVNjcmVlbk5hbWU/JHtwYXJhbXMudG9TdHJpbmcoKX1gO1xuICAgIC8vIOS8mOWFiOS9v+eUqOWKqOaAgSBoYXJ2ZXN0ZWQg55qEIEJlYXJlciBUb2tlbu+8jGZhbGxiYWNrIOWIsOWGmeatu+eahOm7mOiupOWAvFxuICAgIGNvbnN0IGJlYXJlckZyb21TdG9yYWdlID0gYXdhaXQgZ2V0QXV0aEhlYWRlcigpO1xuICAgIGNvbnN0IEZBTExCQUNLX0JFQVJFUiA9ICdCZWFyZXIgQUFBQUFBQUFBQUFBQUFBQUFBQUFBTlJJTGdBQUFBQUFuTndJelVlalJDT3VINUU2STh4blp6NHB1VHMlM0QxWnY3dHRmazhMRjgxSVVxMTZjSGpoTFR2SnU0RkEzM0FHV1dqQ3BUbkEnO1xuICAgIGNvbnN0IGJlYXJlciA9IGJlYXJlckZyb21TdG9yYWdlIHx8IEZBTExCQUNLX0JFQVJFUjtcbiAgICAvLyBDU1JGIFRva2Vu77yI5LuF6ZmQ5YaF5a656ISa5pys5LiK5LiL5paH77yMZG9jdW1lbnQuY29va2llIOWPr+iuv+mXru+8iVxuICAgIGNvbnN0IGNzcmZUb2tlbiA9IGF3YWl0IGdldENzcmZUb2tlbigpO1xuICAgIGNvbnNvbGUubG9nKGBbVHdpdHRlckFQSV0gZmV0Y2hVc2VyQnlTY3JlZW5OYW1lOiBiZWFyZXI9JHtiZWFyZXIgPyAncHJlc2VudCcgOiAnTUlTU0lORyd9LCBjc3JmPSR7Y3NyZlRva2VuID8gJ3ByZXNlbnQnIDogJ01JU1NJTkcnfWApO1xuICAgIGNvbnN0IGhlYWRlcnMgPSB7XG4gICAgICAgICdhdXRob3JpemF0aW9uJzogYmVhcmVyLFxuICAgICAgICAneC1jc3JmLXRva2VuJzogY3NyZlRva2VuLFxuICAgICAgICAnY29udGVudC10eXBlJzogJ2FwcGxpY2F0aW9uL2pzb24nLFxuICAgICAgICAneC10d2l0dGVyLWFjdGl2ZS11c2VyJzogJ3llcycsXG4gICAgICAgICd4LXR3aXR0ZXItY2xpZW50LWxhbmd1YWdlJzogJ2VuJyxcbiAgICAgICAgJ3JlZmVyZXInOiAnaHR0cHM6Ly94LmNvbS8nLFxuICAgICAgICAnYWNjZXB0JzogJyovKidcbiAgICB9O1xuICAgIGNvbnNvbGUubG9nKCdbVHdpdHRlckFQSV0gZmV0Y2hVc2VyQnlTY3JlZW5OYW1lOiBzZW5kaW5nIGZldGNoLi4uJyk7XG4gICAgbGV0IHJlc3BvbnNlO1xuICAgIHRyeSB7XG4gICAgICAgIHJlc3BvbnNlID0gYXdhaXQgZmV0Y2godXJsLCB7XG4gICAgICAgICAgICBtZXRob2Q6ICdHRVQnLFxuICAgICAgICAgICAgaGVhZGVycyxcbiAgICAgICAgICAgIGNyZWRlbnRpYWxzOiAnaW5jbHVkZSdcbiAgICAgICAgfSk7XG4gICAgfVxuICAgIGNhdGNoIChuZXR3b3JrRXJyKSB7XG4gICAgICAgIGNvbnNvbGUuZXJyb3IoJ1tUd2l0dGVyQVBJXSBmZXRjaFVzZXJCeVNjcmVlbk5hbWU6IG5ldHdvcmsgZXJyb3InLCBuZXR3b3JrRXJyKTtcbiAgICAgICAgdGhyb3cgbmV0d29ya0VycjtcbiAgICB9XG4gICAgY29uc29sZS5sb2coYFtUd2l0dGVyQVBJXSBmZXRjaFVzZXJCeVNjcmVlbk5hbWU6IHJlc3BvbnNlIHN0YXR1cyAke3Jlc3BvbnNlLnN0YXR1c31gKTtcbiAgICBpZiAoIXJlc3BvbnNlLm9rKSB7XG4gICAgICAgIGNvbnN0IGVyclRleHQgPSBhd2FpdCByZXNwb25zZS50ZXh0KCk7XG4gICAgICAgIGNvbnNvbGUuZXJyb3IoYFtUd2l0dGVyQVBJXSBmZXRjaFVzZXJCeVNjcmVlbk5hbWU6ICR7cmVzcG9uc2Uuc3RhdHVzfWAsIGVyclRleHQuc2xpY2UoMCwgMjAwKSk7XG4gICAgICAgIHRocm93IG5ldyBFcnJvcihgVXNlckJ5U2NyZWVuTmFtZSBmYWlsZWQ6ICR7cmVzcG9uc2Uuc3RhdHVzfWApO1xuICAgIH1cbiAgICBjb25zdCBqc29uID0gYXdhaXQgcmVzcG9uc2UuanNvbigpO1xuICAgIGNvbnNvbGUubG9nKCdbVHdpdHRlckFQSV0gZmV0Y2hVc2VyQnlTY3JlZW5OYW1lOiBnb3QgSlNPTiwga2V5cz0nLCBPYmplY3Qua2V5cyhqc29uKSk7XG4gICAgcmV0dXJuIGpzb247XG59XG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gcGVyZm9ybVF1ZXJ5KG9wLCB2YXJpYWJsZXMsIHJldHJ5Q291bnQgPSAwKSB7XG4gICAgY29uc3QgdGFyZ2V0ID0gYXdhaXQgZ2V0VXJsV2l0aFF1ZXJ5SWQob3ApO1xuICAgIGlmICghdGFyZ2V0KVxuICAgICAgICB0aHJvdyBuZXcgRXJyb3IoYE1pc3NpbmcgaGFydmVzdGVkIHF1ZXJ5SWQgZm9yIG9wZXJhdGlvbjogJHtvcH1gKTtcbiAgICBjb25zdCBiZWFyZXIgPSBhd2FpdCBnZXRBdXRoSGVhZGVyKCk7XG4gICAgY29uc3QgY3NyZiA9IGF3YWl0IGdldENzcmZUb2tlbigpO1xuICAgIGNvbnN0IGZlYXR1cmVzID0gYXdhaXQgYnVpbGRGZWF0dXJlcyhvcCk7XG4gICAgY29uc3QgcGFyYW1zID0gbmV3IFVSTFNlYXJjaFBhcmFtcygpO1xuICAgIHBhcmFtcy5hcHBlbmQoJ3ZhcmlhYmxlcycsIEpTT04uc3RyaW5naWZ5KHZhcmlhYmxlcykpO1xuICAgIHBhcmFtcy5hcHBlbmQoJ2ZlYXR1cmVzJywgSlNPTi5zdHJpbmdpZnkoZmVhdHVyZXMpKTtcbiAgICBjb25zdCB1cmwgPSBgJHt0YXJnZXQudXJsfT8ke3BhcmFtcy50b1N0cmluZygpfWA7XG4gICAgY29uc3QgaGVhZGVycyA9IHtcbiAgICAgICAgJ2F1dGhvcml6YXRpb24nOiBiZWFyZXIsXG4gICAgICAgICd4LWNzcmYtdG9rZW4nOiBjc3JmLFxuICAgICAgICAnY29udGVudC10eXBlJzogJ2FwcGxpY2F0aW9uL2pzb24nLFxuICAgICAgICAneC10d2l0dGVyLWFjdGl2ZS11c2VyJzogJ3llcycsXG4gICAgICAgICd4LXR3aXR0ZXItYXV0aC10eXBlJzogJ09BdXRoMlNlc3Npb24nLFxuICAgICAgICAncmVmZXJlcic6ICdodHRwczovL3guY29tLycsXG4gICAgICAgICdhY2NlcHQnOiAnKi8qJ1xuICAgIH07XG4gICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBmZXRjaCh1cmwsIHtcbiAgICAgICAgbWV0aG9kOiAnR0VUJyxcbiAgICAgICAgaGVhZGVycyxcbiAgICAgICAgY3JlZGVudGlhbHM6ICdpbmNsdWRlJ1xuICAgIH0pO1xuICAgIGlmICghcmVzcG9uc2Uub2spIHtcbiAgICAgICAgY29uc3QgdGV4dCA9IGF3YWl0IHJlc3BvbnNlLnRleHQoKTtcbiAgICAgICAgYXdhaXQgZXh0cmFjdE1pc3NpbmdGZWF0dXJlKHRleHQpO1xuICAgICAgICAvLyBGb3IgNDA0IGVycm9ycywgcmV0cnkgb25jZSB3aXRoIGZyZXNoIGZlYXR1cmVzXG4gICAgICAgIGlmIChyZXNwb25zZS5zdGF0dXMgPT09IDQwNCAmJiByZXRyeUNvdW50ID09PSAwKSB7XG4gICAgICAgICAgICBjb25zb2xlLndhcm4oYFtUd2l0dGVyQVBJXSAke29wfSBxdWVyeSByZXR1cm5lZCA0MDQsIHJldHJ5aW5nIHdpdGggZnJlc2ggZmVhdHVyZXMuLi5gKTtcbiAgICAgICAgICAgIGF3YWl0IG5ldyBQcm9taXNlKHJlc29sdmUgPT4gc2V0VGltZW91dChyZXNvbHZlLCA1MDApKTtcbiAgICAgICAgICAgIHJldHVybiBwZXJmb3JtUXVlcnkob3AsIHZhcmlhYmxlcywgcmV0cnlDb3VudCArIDEpO1xuICAgICAgICB9XG4gICAgICAgIHRocm93IG5ldyBFcnJvcihgWCBBUEkgRXJyb3IgJHtyZXNwb25zZS5zdGF0dXN9IGZvciAke29wfTogJHt0ZXh0fWApO1xuICAgIH1cbiAgICBjb25zdCByZXN1bHQgPSBhd2FpdCByZXNwb25zZS5qc29uKCk7XG4gICAgY29uc29sZS5sb2coYFtUd2l0dGVyQVBJXSBHcmFwaFFMICR7b3B9IFJlc3BvbnNlOmAsIHJlc3VsdCk7XG4gICAgcmV0dXJuIHJlc3VsdDtcbn1cbi8qKlxuICog5qC55o2u55So5oi35ZCN6I635Y+W5a6M5pW055qE55So5oi3IFByb2ZpbGUg5L+h5oGvXG4gKi9cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBmZXRjaFVzZXJCeVVzZXJuYW1lKHVzZXJuYW1lKSB7XG4gICAgY29uc3QgY2xlYW5Vc2VybmFtZSA9IHVzZXJuYW1lLnN0YXJ0c1dpdGgoJ0AnKSA/IHVzZXJuYW1lLnN1YnN0cmluZygxKSA6IHVzZXJuYW1lO1xuICAgIGNvbnN0IGRhdGEgPSBhd2FpdCBwZXJmb3JtUXVlcnkoJ1VzZXJCeVNjcmVlbk5hbWUnLCB7XG4gICAgICAgIHNjcmVlbl9uYW1lOiBjbGVhblVzZXJuYW1lLFxuICAgICAgICB3aXRoU2FmZXR5TW9kZVVzZXJGaWVsZHM6IHRydWVcbiAgICB9KTtcbiAgICAvLyDku47lpI3mnYLnmoQgR3JhcGhRTCDlk43lupTkuK3mj5Dlj5bnlKjmiLflr7nosaFcbiAgICBjb25zdCB1c2VyUmVzdWx0ID0gZGF0YT8uZGF0YT8udXNlcj8ucmVzdWx0O1xuICAgIGlmICghdXNlclJlc3VsdCB8fCB1c2VyUmVzdWx0Ll9fdHlwZW5hbWUgPT09ICdVc2VyVW5hdmFpbGFibGUnKSB7XG4gICAgICAgIHJldHVybiBudWxsO1xuICAgIH1cbiAgICByZXR1cm4gdXNlclJlc3VsdDtcbn1cbi8qKlxuICog5qC55o2uIFVzZXIgSUQg6I635Y+W5a6M5pW055qE55So5oi3IFByb2ZpbGUg5L+h5oGvIChVc2VyQnlSZXN0SWQpXG4gKi9cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBmZXRjaFVzZXJCeVJlc3RJZCh1c2VySWQpIHtcbiAgICBjb25zdCBkYXRhID0gYXdhaXQgcGVyZm9ybVF1ZXJ5KCdVc2VyQnlSZXN0SWQnLCB7XG4gICAgICAgIHVzZXJJZDogdXNlcklkLFxuICAgICAgICB3aXRoU2FmZXR5TW9kZVVzZXJGaWVsZHM6IHRydWVcbiAgICB9KTtcbiAgICBjb25zdCB1c2VyUmVzdWx0ID0gZGF0YT8uZGF0YT8udXNlcj8ucmVzdWx0O1xuICAgIGlmICghdXNlclJlc3VsdCB8fCB1c2VyUmVzdWx0Ll9fdHlwZW5hbWUgPT09ICdVc2VyVW5hdmFpbGFibGUnKSB7XG4gICAgICAgIHJldHVybiBudWxsO1xuICAgIH1cbiAgICByZXR1cm4gdXNlclJlc3VsdDtcbn1cbiIsIi8qKlxuICogVHdpdHRlciBUcmFuc2FjdGlvbiBJRCAodHhpZCkgZ2VuZXJhdG9yLlxuICogVXNlcyB4LWNsaWVudC10cmFuc2FjdGlvbi1pZCBsaWJyYXJ5IChzYW1lIGFzIFR3ZWV0Q2F0KS5cbiAqL1xuaW1wb3J0IHsgQ2xpZW50VHJhbnNhY3Rpb24gfSBmcm9tIFwieC1jbGllbnQtdHJhbnNhY3Rpb24taWRcIjtcbmxldCBjYWNoZWREb2MgPSBudWxsO1xubGV0IGxhc3RGZXRjaGVkID0gMDtcbmFzeW5jIGZ1bmN0aW9uIGdldFhEb2MoKSB7XG4gICAgY29uc3Qgbm93ID0gRGF0ZS5ub3coKTtcbiAgICBpZiAoIWNhY2hlZERvYyB8fCBub3cgLSBsYXN0RmV0Y2hlZCA+IDYwMDAwKSB7IC8vIOe8k+WtmCA2MHNcbiAgICAgICAgY29uc3QgcmVzID0gYXdhaXQgZmV0Y2goXCJodHRwczovL3guY29tL1wiLCB7IGNyZWRlbnRpYWxzOiBcIm9taXRcIiB9KTtcbiAgICAgICAgY29uc3QgaHRtbCA9IGF3YWl0IHJlcy50ZXh0KCk7XG4gICAgICAgIGNhY2hlZERvYyA9IG5ldyBET01QYXJzZXIoKS5wYXJzZUZyb21TdHJpbmcoaHRtbCwgXCJ0ZXh0L2h0bWxcIik7XG4gICAgICAgIGxhc3RGZXRjaGVkID0gbm93O1xuICAgIH1cbiAgICByZXR1cm4gY2FjaGVkRG9jO1xufVxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGdldFRyYW5zYWN0aW9uSWRGb3IobWV0aG9kLCBwYXRoKSB7XG4gICAgY29uc3QgZG9jID0gYXdhaXQgZ2V0WERvYygpO1xuICAgIGNvbnN0IHR4ID0gYXdhaXQgQ2xpZW50VHJhbnNhY3Rpb24uY3JlYXRlKGRvYyk7XG4gICAgcmV0dXJuIHR4LmdlbmVyYXRlVHJhbnNhY3Rpb25JZChtZXRob2QsIHBhdGgpO1xufVxuIiwiZXhwb3J0IHt9O1xuIiwiLyoqXG4gKiBDdWJpYyBCZXppZXIgaW50ZXJwb2xhdGlvbiBpbXBsZW1lbnRhdGlvblxuICpcbiAqIFRoaXMgY2xhc3MgaW1wbGVtZW50cyBjdWJpYyBiZXppZXIgY3VydmUgaW50ZXJwb2xhdGlvblxuICogdXNlZCBmb3IgYW5pbWF0aW9uIGtleSBnZW5lcmF0aW9uLlxuICovXG5jbGFzcyBDdWJpYyB7XG4gICAgLyoqXG4gICAgICogQ3JlYXRlcyBhIG5ldyBDdWJpYyBpbnN0YW5jZVxuICAgICAqIEBwYXJhbSBjdXJ2ZXMgQXJyYXkgb2YgY3VydmUgY29udHJvbCBwb2ludHNcbiAgICAgKi9cbiAgICBjb25zdHJ1Y3RvcihjdXJ2ZXMpIHtcbiAgICAgICAgT2JqZWN0LmRlZmluZVByb3BlcnR5KHRoaXMsIFwiY3VydmVzXCIsIHtcbiAgICAgICAgICAgIGVudW1lcmFibGU6IHRydWUsXG4gICAgICAgICAgICBjb25maWd1cmFibGU6IHRydWUsXG4gICAgICAgICAgICB3cml0YWJsZTogdHJ1ZSxcbiAgICAgICAgICAgIHZhbHVlOiB2b2lkIDBcbiAgICAgICAgfSk7XG4gICAgICAgIHRoaXMuY3VydmVzID0gY3VydmVzO1xuICAgIH1cbiAgICAvKipcbiAgICAgKiBDYWxjdWxhdGVzIHRoZSBpbnRlcnBvbGF0ZWQgdmFsdWUgYXQgYSBzcGVjaWZpYyB0aW1lIHBvaW50XG4gICAgICogQHBhcmFtIHRpbWUgTm9ybWFsaXplZCB0aW1lIHZhbHVlICgwLjAgdG8gMS4wKVxuICAgICAqIEByZXR1cm5zIEludGVycG9sYXRlZCB2YWx1ZVxuICAgICAqL1xuICAgIGdldFZhbHVlKHRpbWUpIHtcbiAgICAgICAgbGV0IHN0YXJ0R3JhZGllbnQgPSAwO1xuICAgICAgICBsZXQgZW5kR3JhZGllbnQgPSAwO1xuICAgICAgICBsZXQgc3RhcnQgPSAwLjA7XG4gICAgICAgIGxldCBtaWQgPSAwLjA7XG4gICAgICAgIGxldCBlbmQgPSAxLjA7XG4gICAgICAgIC8vIEhhbmRsZSB2YWx1ZXMgb3V0c2lkZSB0aGUgMC0xIHJhbmdlXG4gICAgICAgIGlmICh0aW1lIDw9IDAuMCkge1xuICAgICAgICAgICAgaWYgKHRoaXMuY3VydmVzWzBdID4gMC4wKSB7XG4gICAgICAgICAgICAgICAgc3RhcnRHcmFkaWVudCA9IHRoaXMuY3VydmVzWzFdIC8gdGhpcy5jdXJ2ZXNbMF07XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBlbHNlIGlmICh0aGlzLmN1cnZlc1sxXSA9PT0gMC4wICYmIHRoaXMuY3VydmVzWzJdID4gMC4wKSB7XG4gICAgICAgICAgICAgICAgc3RhcnRHcmFkaWVudCA9IHRoaXMuY3VydmVzWzNdIC8gdGhpcy5jdXJ2ZXNbMl07XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICByZXR1cm4gc3RhcnRHcmFkaWVudCAqIHRpbWU7XG4gICAgICAgIH1cbiAgICAgICAgaWYgKHRpbWUgPj0gMS4wKSB7XG4gICAgICAgICAgICBpZiAodGhpcy5jdXJ2ZXNbMl0gPCAxLjApIHtcbiAgICAgICAgICAgICAgICBlbmRHcmFkaWVudCA9ICh0aGlzLmN1cnZlc1szXSAtIDEuMCkgLyAodGhpcy5jdXJ2ZXNbMl0gLSAxLjApO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgZWxzZSBpZiAodGhpcy5jdXJ2ZXNbMl0gPT09IDEuMCAmJiB0aGlzLmN1cnZlc1swXSA8IDEuMCkge1xuICAgICAgICAgICAgICAgIGVuZEdyYWRpZW50ID0gKHRoaXMuY3VydmVzWzFdIC0gMS4wKSAvICh0aGlzLmN1cnZlc1swXSAtIDEuMCk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICByZXR1cm4gMS4wICsgZW5kR3JhZGllbnQgKiAodGltZSAtIDEuMCk7XG4gICAgICAgIH1cbiAgICAgICAgLy8gQmluYXJ5IHNlYXJjaCB0byBmaW5kIHRoZSBjbG9zZXN0IHBvaW50IG9uIHRoZSBjdXJ2ZVxuICAgICAgICB3aGlsZSAoc3RhcnQgPCBlbmQpIHtcbiAgICAgICAgICAgIG1pZCA9IChzdGFydCArIGVuZCkgLyAyO1xuICAgICAgICAgICAgY29uc3QgeEVzdCA9IHRoaXMuY2FsY3VsYXRlKHRoaXMuY3VydmVzWzBdLCB0aGlzLmN1cnZlc1syXSwgbWlkKTtcbiAgICAgICAgICAgIGlmIChNYXRoLmFicyh0aW1lIC0geEVzdCkgPCAwLjAwMDAxKSB7XG4gICAgICAgICAgICAgICAgcmV0dXJuIHRoaXMuY2FsY3VsYXRlKHRoaXMuY3VydmVzWzFdLCB0aGlzLmN1cnZlc1szXSwgbWlkKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGlmICh4RXN0IDwgdGltZSkge1xuICAgICAgICAgICAgICAgIHN0YXJ0ID0gbWlkO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgZWxzZSB7XG4gICAgICAgICAgICAgICAgZW5kID0gbWlkO1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICAgIHJldHVybiB0aGlzLmNhbGN1bGF0ZSh0aGlzLmN1cnZlc1sxXSwgdGhpcy5jdXJ2ZXNbM10sIG1pZCk7XG4gICAgfVxuICAgIC8qKlxuICAgICAqIENhbGN1bGF0ZXMgY3ViaWMgYmV6aWVyIHZhbHVlIHdpdGggZ2l2ZW4gY29udHJvbCBwb2ludHNcbiAgICAgKiBAcGFyYW0gYSBGaXJzdCBjb250cm9sIHBvaW50XG4gICAgICogQHBhcmFtIGIgU2Vjb25kIGNvbnRyb2wgcG9pbnRcbiAgICAgKiBAcGFyYW0gbSBQYXJhbWV0cmljIHZhbHVlICgwLjAgdG8gMS4wKVxuICAgICAqIEByZXR1cm5zIENhbGN1bGF0ZWQgY3ViaWMgYmV6aWVyIHZhbHVlXG4gICAgICogQHByaXZhdGVcbiAgICAgKi9cbiAgICBjYWxjdWxhdGUoYSwgYiwgbSkge1xuICAgICAgICByZXR1cm4gKDMuMCAqIGEgKiAoMSAtIG0pICogKDEgLSBtKSAqIG0gKyAzLjAgKiBiICogKDEgLSBtKSAqIG0gKiBtICsgbSAqIG0gKiBtKTtcbiAgICB9XG59XG5leHBvcnQgZGVmYXVsdCBDdWJpYztcbiIsIi8vIENvcHlyaWdodCAyMDE4LTIwMjUgdGhlIERlbm8gYXV0aG9ycy4gTUlUIGxpY2Vuc2UuXG5leHBvcnQgY29uc3QgYWxwaGFiZXQgPSBuZXcgVGV4dEVuY29kZXIoKS5lbmNvZGUoXCIwMTIzNDU2Nzg5YWJjZGVmXCIpO1xuZXhwb3J0IGNvbnN0IHJBbHBoYWJldCA9IG5ldyBVaW50OEFycmF5KDEyOCkuZmlsbCgxNik7IC8vIGFscGhhYmV0LkhleC5sZW5ndGhcbmFscGhhYmV0LmZvckVhY2goKGJ5dGUsIGkpID0+IHJBbHBoYWJldFtieXRlXSA9IGkpO1xubmV3IFRleHRFbmNvZGVyKClcbiAgICAuZW5jb2RlKFwiQUJDREVGXCIpXG4gICAgLmZvckVhY2goKGJ5dGUsIGkpID0+IHJBbHBoYWJldFtieXRlXSA9IGkgKyAxMCk7XG4vKipcbiAqIENhbGN1bGF0ZSB0aGUgb3V0cHV0IHNpemUgbmVlZGVkIHRvIGVuY29kZSBhIGdpdmVuIGlucHV0IHNpemUgZm9yXG4gKiB7QGxpbmtjb2RlIGVuY29kZUludG9IZXh9LlxuICpcbiAqIEBwYXJhbSBvcmlnaW5hbFNpemUgVGhlIHNpemUgb2YgdGhlIGlucHV0IGJ1ZmZlci5cbiAqIEByZXR1cm5zIFRoZSBzaXplIG9mIHRoZSBvdXRwdXQgYnVmZmVyLlxuICpcbiAqIEBleGFtcGxlIEJhc2ljIFVzYWdlXG4gKiBgYGB0c1xuICogaW1wb3J0IHsgYXNzZXJ0RXF1YWxzIH0gZnJvbSBcIkBzdGQvYXNzZXJ0XCI7XG4gKiBpbXBvcnQgeyBjYWxjU2l6ZUhleCB9IGZyb20gXCJAc3RkL2VuY29kaW5nL3Vuc3RhYmxlLWhleFwiO1xuICpcbiAqIGFzc2VydEVxdWFscyhjYWxjU2l6ZUhleCgxKSwgMik7XG4gKiBgYGBcbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIGNhbGNTaXplSGV4KG9yaWdpbmFsU2l6ZSkge1xuICAgIHJldHVybiBvcmlnaW5hbFNpemUgKiAyO1xufVxuZXhwb3J0IGZ1bmN0aW9uIGVuY29kZShidWZmZXIsIGksIG8sIGFscGhhYmV0KSB7XG4gICAgZm9yICg7IGkgPCBidWZmZXIubGVuZ3RoOyArK2kpIHtcbiAgICAgICAgY29uc3QgeCA9IGJ1ZmZlcltpXTtcbiAgICAgICAgYnVmZmVyW28rK10gPSBhbHBoYWJldFt4ID4+IDRdO1xuICAgICAgICBidWZmZXJbbysrXSA9IGFscGhhYmV0W3ggJiAweEZdO1xuICAgIH1cbiAgICByZXR1cm4gbztcbn1cbmV4cG9ydCBmdW5jdGlvbiBkZWNvZGUoYnVmZmVyLCBpLCBvLCBhbHBoYWJldCkge1xuICAgIGlmICgoYnVmZmVyLmxlbmd0aCAtIG8pICUgMiA9PT0gMSkge1xuICAgICAgICB0aHJvdyBuZXcgUmFuZ2VFcnJvcihgQ2Fubm90IGRlY29kZSBpbnB1dCBhcyBoZXg6IExlbmd0aCAoJHtidWZmZXIubGVuZ3RoIC0gb30pIG11c3QgYmUgZGl2aXNpYmxlIGJ5IDJgKTtcbiAgICB9XG4gICAgaSArPSAxO1xuICAgIGZvciAoOyBpIDwgYnVmZmVyLmxlbmd0aDsgaSArPSAyKSB7XG4gICAgICAgIGJ1ZmZlcltvKytdID0gKGdldEJ5dGUoYnVmZmVyW2kgLSAxXSwgYWxwaGFiZXQpIDw8IDQpIHxcbiAgICAgICAgICAgIGdldEJ5dGUoYnVmZmVyW2ldLCBhbHBoYWJldCk7XG4gICAgfVxuICAgIHJldHVybiBvO1xufVxuZnVuY3Rpb24gZ2V0Qnl0ZShjaGFyLCBhbHBoYWJldCkge1xuICAgIGNvbnN0IGJ5dGUgPSBhbHBoYWJldFtjaGFyXSA/PyAxNjtcbiAgICBpZiAoYnl0ZSA9PT0gMTYpIHsgLy8gYWxwaGFiZXQuSGV4Lmxlbmd0aFxuICAgICAgICB0aHJvdyBuZXcgVHlwZUVycm9yKGBDYW5ub3QgZGVjb2RlIGlucHV0IGFzIGhleDogSW52YWxpZCBjaGFyYWN0ZXIgKCR7U3RyaW5nLmZyb21DaGFyQ29kZShjaGFyKX0pYCk7XG4gICAgfVxuICAgIHJldHVybiBieXRlO1xufVxuIiwiLy8gQ29weXJpZ2h0IDIwMTgtMjAyNSB0aGUgRGVubyBhdXRob3JzLiBNSVQgbGljZW5zZS5cbmV4cG9ydCBjb25zdCBwYWRkaW5nID0gXCI9XCIuY2hhckNvZGVBdCgwKTtcbmV4cG9ydCBjb25zdCBhbHBoYWJldCA9IHtcbiAgICBiYXNlMzI6IG5ldyBUZXh0RW5jb2RlcigpLmVuY29kZShcIkFCQ0RFRkdISUpLTE1OT1BRUlNUVVZXWFlaMjM0NTY3XCIpLFxuICAgIGJhc2UzMmhleDogbmV3IFRleHRFbmNvZGVyKCkuZW5jb2RlKFwiMDEyMzQ1Njc4OUFCQ0RFRkdISUpLTE1OT1BRUlNUVVZcIiksXG4gICAgYmFzZTMyY3JvY2tmb3JkOiBuZXcgVGV4dEVuY29kZXIoKS5lbmNvZGUoXCIwMTIzNDU2Nzg5QUJDREVGR0hKS01OUFFSU1RWV1hZWlwiKSxcbn07XG5leHBvcnQgY29uc3QgckFscGhhYmV0ID0ge1xuICAgIGJhc2UzMjogbmV3IFVpbnQ4QXJyYXkoMTI4KS5maWxsKDMyKSwgLy8gYWxwaGFiZXQuYmFzZTMyLmxlbmd0aFxuICAgIGJhc2UzMmhleDogbmV3IFVpbnQ4QXJyYXkoMTI4KS5maWxsKDMyKSxcbiAgICBiYXNlMzJjcm9ja2ZvcmQ6IG5ldyBVaW50OEFycmF5KDEyOCkuZmlsbCgzMiksXG59O1xuYWxwaGFiZXQuYmFzZTMyXG4gICAgLmZvckVhY2goKGJ5dGUsIGkpID0+IHJBbHBoYWJldC5iYXNlMzJbYnl0ZV0gPSBpKTtcbmFscGhhYmV0LmJhc2UzMmhleFxuICAgIC5mb3JFYWNoKChieXRlLCBpKSA9PiByQWxwaGFiZXQuYmFzZTMyaGV4W2J5dGVdID0gaSk7XG5hbHBoYWJldC5iYXNlMzJjcm9ja2ZvcmRcbiAgICAuZm9yRWFjaCgoYnl0ZSwgaSkgPT4gckFscGhhYmV0LmJhc2UzMmNyb2NrZm9yZFtieXRlXSA9IGkpO1xuLyoqXG4gKiBDYWxjdWxhdGUgdGhlIG91dHB1dCBzaXplIG5lZWRlZCB0byBlbmNvZGUgYSBnaXZlbiBpbnB1dCBzaXplIGZvclxuICoge0BsaW5rY29kZSBlbmNvZGVJbnRvQmFzZTMyfS5cbiAqXG4gKiBAcGFyYW0gcmF3U2l6ZSBUaGUgc2l6ZSBvZiB0aGUgaW5wdXQgYnVmZmVyLlxuICogQHJldHVybnMgVGhlIHNpemUgb2YgdGhlIG91dHB1dCBidWZmZXIuXG4gKlxuICogQGV4YW1wbGUgQmFzaWMgVXNhZ2VcbiAqIGBgYHRzXG4gKiBpbXBvcnQgeyBhc3NlcnRFcXVhbHMgfSBmcm9tIFwiQHN0ZC9hc3NlcnRcIjtcbiAqIGltcG9ydCB7IGNhbGNTaXplQmFzZTMyIH0gZnJvbSBcIkBzdGQvZW5jb2RpbmcvdW5zdGFibGUtYmFzZTMyXCI7XG4gKlxuICogYXNzZXJ0RXF1YWxzKGNhbGNTaXplQmFzZTMyKDEpLCA4KTtcbiAqIGBgYFxuICovXG5leHBvcnQgZnVuY3Rpb24gY2FsY1NpemVCYXNlMzIocmF3U2l6ZSkge1xuICAgIHJldHVybiAoKHJhd1NpemUgKyA0KSAvIDUgfCAwKSAqIDg7XG59XG5leHBvcnQgZnVuY3Rpb24gZW5jb2RlKGJ1ZmZlciwgaSwgbywgYWxwaGFiZXQsIHBhZGRpbmcpIHtcbiAgICBpICs9IDQ7XG4gICAgZm9yICg7IGkgPCBidWZmZXIubGVuZ3RoOyBpICs9IDUpIHtcbiAgICAgICAgbGV0IHggPSAoYnVmZmVyW2kgLSA0XSA8PCAxNikgfCAoYnVmZmVyW2kgLSAzXSA8PCA4KSB8IGJ1ZmZlcltpIC0gMl07XG4gICAgICAgIGJ1ZmZlcltvKytdID0gYWxwaGFiZXRbeCA+PiAxOV07XG4gICAgICAgIGJ1ZmZlcltvKytdID0gYWxwaGFiZXRbeCA+PiAxNCAmIDB4MUZdO1xuICAgICAgICBidWZmZXJbbysrXSA9IGFscGhhYmV0W3ggPj4gOSAmIDB4MUZdO1xuICAgICAgICBidWZmZXJbbysrXSA9IGFscGhhYmV0W3ggPj4gNCAmIDB4MUZdO1xuICAgICAgICB4ID0gKHggPDwgMTYpIHwgKGJ1ZmZlcltpIC0gMV0gPDwgOCkgfCBidWZmZXJbaV07XG4gICAgICAgIGJ1ZmZlcltvKytdID0gYWxwaGFiZXRbeCA+PiAxNSAmIDB4MUZdO1xuICAgICAgICBidWZmZXJbbysrXSA9IGFscGhhYmV0W3ggPj4gMTAgJiAweDFGXTtcbiAgICAgICAgYnVmZmVyW28rK10gPSBhbHBoYWJldFt4ID4+IDUgJiAweDFGXTtcbiAgICAgICAgYnVmZmVyW28rK10gPSBhbHBoYWJldFt4ICYgMHgxRl07XG4gICAgfVxuICAgIHN3aXRjaCAoaSkge1xuICAgICAgICBjYXNlIGJ1ZmZlci5sZW5ndGggKyAzOiB7XG4gICAgICAgICAgICBjb25zdCB4ID0gYnVmZmVyW2kgLSA0XSA8PCAxNjtcbiAgICAgICAgICAgIGJ1ZmZlcltvKytdID0gYWxwaGFiZXRbeCA+PiAxOV07XG4gICAgICAgICAgICBidWZmZXJbbysrXSA9IGFscGhhYmV0W3ggPj4gMTQgJiAweDFGXTtcbiAgICAgICAgICAgIGJ1ZmZlcltvKytdID0gcGFkZGluZztcbiAgICAgICAgICAgIGJ1ZmZlcltvKytdID0gcGFkZGluZztcbiAgICAgICAgICAgIGJ1ZmZlcltvKytdID0gcGFkZGluZztcbiAgICAgICAgICAgIGJ1ZmZlcltvKytdID0gcGFkZGluZztcbiAgICAgICAgICAgIGJ1ZmZlcltvKytdID0gcGFkZGluZztcbiAgICAgICAgICAgIGJ1ZmZlcltvKytdID0gcGFkZGluZztcbiAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICB9XG4gICAgICAgIGNhc2UgYnVmZmVyLmxlbmd0aCArIDI6IHtcbiAgICAgICAgICAgIGNvbnN0IHggPSAoYnVmZmVyW2kgLSA0XSA8PCAxNikgfCAoYnVmZmVyW2kgLSAzXSA8PCA4KTtcbiAgICAgICAgICAgIGJ1ZmZlcltvKytdID0gYWxwaGFiZXRbeCA+PiAxOV07XG4gICAgICAgICAgICBidWZmZXJbbysrXSA9IGFscGhhYmV0W3ggPj4gMTQgJiAweDFGXTtcbiAgICAgICAgICAgIGJ1ZmZlcltvKytdID0gYWxwaGFiZXRbeCA+PiA5ICYgMHgxRl07XG4gICAgICAgICAgICBidWZmZXJbbysrXSA9IGFscGhhYmV0W3ggPj4gNCAmIDB4MUZdO1xuICAgICAgICAgICAgYnVmZmVyW28rK10gPSBwYWRkaW5nO1xuICAgICAgICAgICAgYnVmZmVyW28rK10gPSBwYWRkaW5nO1xuICAgICAgICAgICAgYnVmZmVyW28rK10gPSBwYWRkaW5nO1xuICAgICAgICAgICAgYnVmZmVyW28rK10gPSBwYWRkaW5nO1xuICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgIH1cbiAgICAgICAgY2FzZSBidWZmZXIubGVuZ3RoICsgMToge1xuICAgICAgICAgICAgbGV0IHggPSAoYnVmZmVyW2kgLSA0XSA8PCAxNikgfCAoYnVmZmVyW2kgLSAzXSA8PCA4KSB8IGJ1ZmZlcltpIC0gMl07XG4gICAgICAgICAgICBidWZmZXJbbysrXSA9IGFscGhhYmV0W3ggPj4gMTldO1xuICAgICAgICAgICAgYnVmZmVyW28rK10gPSBhbHBoYWJldFt4ID4+IDE0ICYgMHgxRl07XG4gICAgICAgICAgICBidWZmZXJbbysrXSA9IGFscGhhYmV0W3ggPj4gOSAmIDB4MUZdO1xuICAgICAgICAgICAgYnVmZmVyW28rK10gPSBhbHBoYWJldFt4ID4+IDQgJiAweDFGXTtcbiAgICAgICAgICAgIHggPDw9IDE2O1xuICAgICAgICAgICAgYnVmZmVyW28rK10gPSBhbHBoYWJldFt4ID4+IDE1ICYgMHgxRl07XG4gICAgICAgICAgICBidWZmZXJbbysrXSA9IHBhZGRpbmc7XG4gICAgICAgICAgICBidWZmZXJbbysrXSA9IHBhZGRpbmc7XG4gICAgICAgICAgICBidWZmZXJbbysrXSA9IHBhZGRpbmc7XG4gICAgICAgICAgICBicmVhaztcbiAgICAgICAgfVxuICAgICAgICBjYXNlIGJ1ZmZlci5sZW5ndGg6IHtcbiAgICAgICAgICAgIGxldCB4ID0gKGJ1ZmZlcltpIC0gNF0gPDwgMTYpIHwgKGJ1ZmZlcltpIC0gM10gPDwgOCkgfCBidWZmZXJbaSAtIDJdO1xuICAgICAgICAgICAgYnVmZmVyW28rK10gPSBhbHBoYWJldFt4ID4+IDE5XTtcbiAgICAgICAgICAgIGJ1ZmZlcltvKytdID0gYWxwaGFiZXRbeCA+PiAxNCAmIDB4MUZdO1xuICAgICAgICAgICAgYnVmZmVyW28rK10gPSBhbHBoYWJldFt4ID4+IDkgJiAweDFGXTtcbiAgICAgICAgICAgIGJ1ZmZlcltvKytdID0gYWxwaGFiZXRbeCA+PiA0ICYgMHgxRl07XG4gICAgICAgICAgICB4ID0gKHggPDwgMTYpIHwgKGJ1ZmZlcltpIC0gMV0gPDwgOCk7XG4gICAgICAgICAgICBidWZmZXJbbysrXSA9IGFscGhhYmV0W3ggPj4gMTUgJiAweDFGXTtcbiAgICAgICAgICAgIGJ1ZmZlcltvKytdID0gYWxwaGFiZXRbeCA+PiAxMCAmIDB4MUZdO1xuICAgICAgICAgICAgYnVmZmVyW28rK10gPSBhbHBoYWJldFt4ID4+IDUgJiAweDFGXTtcbiAgICAgICAgICAgIGJ1ZmZlcltvKytdID0gcGFkZGluZztcbiAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICB9XG4gICAgfVxuICAgIHJldHVybiBvO1xufVxuZXhwb3J0IGZ1bmN0aW9uIGRlY29kZShidWZmZXIsIGksIG8sIGFscGhhYmV0LCBwYWRkaW5nKSB7XG4gICAgZm9yIChsZXQgeCA9IGJ1ZmZlci5sZW5ndGggLSA2OyB4IDwgYnVmZmVyLmxlbmd0aDsgKyt4KSB7XG4gICAgICAgIGlmIChidWZmZXJbeF0gPT09IHBhZGRpbmcpIHtcbiAgICAgICAgICAgIGZvciAobGV0IHkgPSB4ICsgMTsgeSA8IGJ1ZmZlci5sZW5ndGg7ICsreSkge1xuICAgICAgICAgICAgICAgIGlmIChidWZmZXJbeV0gIT09IHBhZGRpbmcpIHtcbiAgICAgICAgICAgICAgICAgICAgdGhyb3cgbmV3IFR5cGVFcnJvcihgQ2Fubm90IGRlY29kZSBpbnB1dCBhcyBiYXNlMzI6IEludmFsaWQgY2hhcmFjdGVyICgke1N0cmluZy5mcm9tQ2hhckNvZGUoYnVmZmVyW3ldKX0pYCk7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfVxuICAgICAgICAgICAgYnVmZmVyID0gYnVmZmVyLnN1YmFycmF5KDAsIHgpO1xuICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgIH1cbiAgICB9XG4gICAgc3dpdGNoICgoYnVmZmVyLmxlbmd0aCAtIG8pICUgOCkge1xuICAgICAgICBjYXNlIDY6XG4gICAgICAgIGNhc2UgMzpcbiAgICAgICAgY2FzZSAxOlxuICAgICAgICAgICAgdGhyb3cgbmV3IFJhbmdlRXJyb3IoYENhbm5vdCBkZWNvZGUgaW5wdXQgYXMgYmFzZTMyOiBMZW5ndGggKCR7YnVmZmVyLmxlbmd0aCAtIG99KSwgZXhjbHVkaW5nIHBhZGRpbmcsIG11c3Qgbm90IGhhdmUgYSByZW1haW5kZXIgb2YgMSwgMywgb3IgNiB3aGVuIGRpdmlkZWQgYnkgOGApO1xuICAgIH1cbiAgICBpICs9IDc7XG4gICAgZm9yICg7IGkgPCBidWZmZXIubGVuZ3RoOyBpICs9IDgpIHtcbiAgICAgICAgbGV0IHggPSAoZ2V0Qnl0ZShidWZmZXJbaSAtIDddLCBhbHBoYWJldCkgPDwgMTkpIHxcbiAgICAgICAgICAgIChnZXRCeXRlKGJ1ZmZlcltpIC0gNl0sIGFscGhhYmV0KSA8PCAxNCkgfFxuICAgICAgICAgICAgKGdldEJ5dGUoYnVmZmVyW2kgLSA1XSwgYWxwaGFiZXQpIDw8IDkpIHxcbiAgICAgICAgICAgIChnZXRCeXRlKGJ1ZmZlcltpIC0gNF0sIGFscGhhYmV0KSA8PCA0KTtcbiAgICAgICAgYnVmZmVyW28rK10gPSB4ID4+IDE2O1xuICAgICAgICBidWZmZXJbbysrXSA9IHggPj4gOCAmIDB4RkY7XG4gICAgICAgIHggPSAoeCA8PCAxNikgfFxuICAgICAgICAgICAgKGdldEJ5dGUoYnVmZmVyW2kgLSAzXSwgYWxwaGFiZXQpIDw8IDE1KSB8XG4gICAgICAgICAgICAoZ2V0Qnl0ZShidWZmZXJbaSAtIDJdLCBhbHBoYWJldCkgPDwgMTApIHxcbiAgICAgICAgICAgIChnZXRCeXRlKGJ1ZmZlcltpIC0gMV0sIGFscGhhYmV0KSA8PCA1KSB8XG4gICAgICAgICAgICBnZXRCeXRlKGJ1ZmZlcltpXSwgYWxwaGFiZXQpO1xuICAgICAgICBidWZmZXJbbysrXSA9IHggPj4gMTYgJiAweEZGO1xuICAgICAgICBidWZmZXJbbysrXSA9IHggPj4gOCAmIDB4RkY7XG4gICAgICAgIGJ1ZmZlcltvKytdID0geCAmIDB4RkY7XG4gICAgfVxuICAgIHN3aXRjaCAoaSkge1xuICAgICAgICBjYXNlIGJ1ZmZlci5sZW5ndGggKyA1OiB7XG4gICAgICAgICAgICBjb25zdCB4ID0gKGdldEJ5dGUoYnVmZmVyW2kgLSA3XSwgYWxwaGFiZXQpIDw8IDE5KSB8XG4gICAgICAgICAgICAgICAgKGdldEJ5dGUoYnVmZmVyW2kgLSA2XSwgYWxwaGFiZXQpIDw8IDE0KTtcbiAgICAgICAgICAgIGJ1ZmZlcltvKytdID0geCA+PiAxNjtcbiAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICB9XG4gICAgICAgIGNhc2UgYnVmZmVyLmxlbmd0aCArIDM6IHtcbiAgICAgICAgICAgIGNvbnN0IHggPSAoZ2V0Qnl0ZShidWZmZXJbaSAtIDddLCBhbHBoYWJldCkgPDwgMTkpIHxcbiAgICAgICAgICAgICAgICAoZ2V0Qnl0ZShidWZmZXJbaSAtIDZdLCBhbHBoYWJldCkgPDwgMTQpIHxcbiAgICAgICAgICAgICAgICAoZ2V0Qnl0ZShidWZmZXJbaSAtIDVdLCBhbHBoYWJldCkgPDwgOSkgfFxuICAgICAgICAgICAgICAgIChnZXRCeXRlKGJ1ZmZlcltpIC0gNF0sIGFscGhhYmV0KSA8PCA0KTtcbiAgICAgICAgICAgIGJ1ZmZlcltvKytdID0geCA+PiAxNjtcbiAgICAgICAgICAgIGJ1ZmZlcltvKytdID0geCA+PiA4ICYgMHhGRjtcbiAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICB9XG4gICAgICAgIGNhc2UgYnVmZmVyLmxlbmd0aCArIDI6IHtcbiAgICAgICAgICAgIGxldCB4ID0gKGdldEJ5dGUoYnVmZmVyW2kgLSA3XSwgYWxwaGFiZXQpIDw8IDE5KSB8XG4gICAgICAgICAgICAgICAgKGdldEJ5dGUoYnVmZmVyW2kgLSA2XSwgYWxwaGFiZXQpIDw8IDE0KSB8XG4gICAgICAgICAgICAgICAgKGdldEJ5dGUoYnVmZmVyW2kgLSA1XSwgYWxwaGFiZXQpIDw8IDkpIHxcbiAgICAgICAgICAgICAgICAoZ2V0Qnl0ZShidWZmZXJbaSAtIDRdLCBhbHBoYWJldCkgPDwgNCk7XG4gICAgICAgICAgICBidWZmZXJbbysrXSA9IHggPj4gMTY7XG4gICAgICAgICAgICBidWZmZXJbbysrXSA9IHggPj4gOCAmIDB4RkY7XG4gICAgICAgICAgICB4ID0gKHggPDwgMTYpIHxcbiAgICAgICAgICAgICAgICAoZ2V0Qnl0ZShidWZmZXJbaSAtIDNdLCBhbHBoYWJldCkgPDwgMTUpO1xuICAgICAgICAgICAgYnVmZmVyW28rK10gPSB4ID4+IDE2ICYgMHhGRjtcbiAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICB9XG4gICAgICAgIGNhc2UgYnVmZmVyLmxlbmd0aDoge1xuICAgICAgICAgICAgbGV0IHggPSAoZ2V0Qnl0ZShidWZmZXJbaSAtIDddLCBhbHBoYWJldCkgPDwgMTkpIHxcbiAgICAgICAgICAgICAgICAoZ2V0Qnl0ZShidWZmZXJbaSAtIDZdLCBhbHBoYWJldCkgPDwgMTQpIHxcbiAgICAgICAgICAgICAgICAoZ2V0Qnl0ZShidWZmZXJbaSAtIDVdLCBhbHBoYWJldCkgPDwgOSkgfFxuICAgICAgICAgICAgICAgIChnZXRCeXRlKGJ1ZmZlcltpIC0gNF0sIGFscGhhYmV0KSA8PCA0KTtcbiAgICAgICAgICAgIGJ1ZmZlcltvKytdID0geCA+PiAxNjtcbiAgICAgICAgICAgIGJ1ZmZlcltvKytdID0geCA+PiA4ICYgMHhGRjtcbiAgICAgICAgICAgIHggPSAoeCA8PCAxNikgfFxuICAgICAgICAgICAgICAgIChnZXRCeXRlKGJ1ZmZlcltpIC0gM10sIGFscGhhYmV0KSA8PCAxNSkgfFxuICAgICAgICAgICAgICAgIChnZXRCeXRlKGJ1ZmZlcltpIC0gMl0sIGFscGhhYmV0KSA8PCAxMCkgfFxuICAgICAgICAgICAgICAgIChnZXRCeXRlKGJ1ZmZlcltpIC0gMV0sIGFscGhhYmV0KSA8PCA1KTtcbiAgICAgICAgICAgIGJ1ZmZlcltvKytdID0geCA+PiAxNiAmIDB4RkY7XG4gICAgICAgICAgICBidWZmZXJbbysrXSA9IHggPj4gOCAmIDB4RkY7XG4gICAgICAgICAgICBicmVhaztcbiAgICAgICAgfVxuICAgIH1cbiAgICByZXR1cm4gbztcbn1cbmZ1bmN0aW9uIGdldEJ5dGUoY2hhciwgYWxwaGFiZXQpIHtcbiAgICBjb25zdCBieXRlID0gYWxwaGFiZXRbY2hhcl0gPz8gMzI7XG4gICAgaWYgKGJ5dGUgPT09IDMyKSB7IC8vIGFscGhhYmV0LkJhc2UzMi5sZW5ndGhcbiAgICAgICAgdGhyb3cgbmV3IFR5cGVFcnJvcihgQ2Fubm90IGRlY29kZSBpbnB1dCBhcyBiYXNlMzI6IEludmFsaWQgY2hhcmFjdGVyICgke1N0cmluZy5mcm9tQ2hhckNvZGUoY2hhcil9KWApO1xuICAgIH1cbiAgICByZXR1cm4gYnl0ZTtcbn1cbiIsIi8vIENvcHlyaWdodCAyMDE4LTIwMjUgdGhlIERlbm8gYXV0aG9ycy4gTUlUIGxpY2Vuc2UuXG5leHBvcnQgY29uc3QgcGFkZGluZyA9IFwiPVwiLmNoYXJDb2RlQXQoMCk7XG5leHBvcnQgY29uc3QgYWxwaGFiZXQgPSB7XG4gICAgYmFzZTY0OiBuZXcgVGV4dEVuY29kZXIoKVxuICAgICAgICAuZW5jb2RlKFwiQUJDREVGR0hJSktMTU5PUFFSU1RVVldYWVphYmNkZWZnaGlqa2xtbm9wcXJzdHV2d3h5ejAxMjM0NTY3ODkrL1wiKSxcbiAgICBiYXNlNjR1cmw6IG5ldyBUZXh0RW5jb2RlcigpXG4gICAgICAgIC5lbmNvZGUoXCJBQkNERUZHSElKS0xNTk9QUVJTVFVWV1hZWmFiY2RlZmdoaWprbG1ub3BxcnN0dXZ3eHl6MDEyMzQ1Njc4OS1fXCIpLFxufTtcbmV4cG9ydCBjb25zdCByQWxwaGFiZXQgPSB7XG4gICAgYmFzZTY0OiBuZXcgVWludDhBcnJheSgxMjgpLmZpbGwoNjQpLCAvLyBhbHBoYWJldC5iYXNlNjQubGVuZ3RoXG4gICAgYmFzZTY0dXJsOiBuZXcgVWludDhBcnJheSgxMjgpLmZpbGwoNjQpLFxufTtcbmFscGhhYmV0LmJhc2U2NFxuICAgIC5mb3JFYWNoKChieXRlLCBpKSA9PiByQWxwaGFiZXQuYmFzZTY0W2J5dGVdID0gaSk7XG5hbHBoYWJldC5iYXNlNjR1cmxcbiAgICAuZm9yRWFjaCgoYnl0ZSwgaSkgPT4gckFscGhhYmV0LmJhc2U2NHVybFtieXRlXSA9IGkpO1xuLyoqXG4gKiBDYWxjdWxhdGUgdGhlIG91dHB1dCBzaXplIG5lZWRlZCB0byBlbmNvZGUgYSBnaXZlbiBpbnB1dCBzaXplIGZvclxuICoge0BsaW5rY29kZSBlbmNvZGVJbnRvQmFzZTY0fS5cbiAqXG4gKiBAcGFyYW0gb3JpZ2luYWxTaXplIFRoZSBzaXplIG9mIHRoZSBpbnB1dCBidWZmZXIuXG4gKiBAcmV0dXJucyBUaGUgc2l6ZSBvZiB0aGUgb3V0cHV0IGJ1ZmZlci5cbiAqXG4gKiBAZXhhbXBsZSBCYXNpYyBVc2FnZVxuICogYGBgdHNcbiAqIGltcG9ydCB7IGFzc2VydEVxdWFscyB9IGZyb20gXCJAc3RkL2Fzc2VydFwiO1xuICogaW1wb3J0IHsgY2FsY1NpemVCYXNlNjQgfSBmcm9tIFwiQHN0ZC9lbmNvZGluZy91bnN0YWJsZS1iYXNlNjRcIjtcbiAqXG4gKiBhc3NlcnRFcXVhbHMoY2FsY1NpemVCYXNlNjQoMSksIDQpO1xuICogYGBgXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBjYWxjU2l6ZUJhc2U2NChvcmlnaW5hbFNpemUpIHtcbiAgICByZXR1cm4gKChvcmlnaW5hbFNpemUgKyAyKSAvIDMgfCAwKSAqIDQ7XG59XG5leHBvcnQgZnVuY3Rpb24gZW5jb2RlKGJ1ZmZlciwgaSwgbywgYWxwaGFiZXQsIHBhZGRpbmcpIHtcbiAgICBpICs9IDI7XG4gICAgZm9yICg7IGkgPCBidWZmZXIubGVuZ3RoOyBpICs9IDMpIHtcbiAgICAgICAgY29uc3QgeCA9IChidWZmZXJbaSAtIDJdIDw8IDE2KSB8IChidWZmZXJbaSAtIDFdIDw8IDgpIHwgYnVmZmVyW2ldO1xuICAgICAgICBidWZmZXJbbysrXSA9IGFscGhhYmV0W3ggPj4gMThdO1xuICAgICAgICBidWZmZXJbbysrXSA9IGFscGhhYmV0W3ggPj4gMTIgJiAweDNGXTtcbiAgICAgICAgYnVmZmVyW28rK10gPSBhbHBoYWJldFt4ID4+IDYgJiAweDNGXTtcbiAgICAgICAgYnVmZmVyW28rK10gPSBhbHBoYWJldFt4ICYgMHgzRl07XG4gICAgfVxuICAgIHN3aXRjaCAoaSkge1xuICAgICAgICBjYXNlIGJ1ZmZlci5sZW5ndGggKyAxOiB7XG4gICAgICAgICAgICBjb25zdCB4ID0gYnVmZmVyW2kgLSAyXSA8PCAxNjtcbiAgICAgICAgICAgIGJ1ZmZlcltvKytdID0gYWxwaGFiZXRbeCA+PiAxOF07XG4gICAgICAgICAgICBidWZmZXJbbysrXSA9IGFscGhhYmV0W3ggPj4gMTIgJiAweDNGXTtcbiAgICAgICAgICAgIGJ1ZmZlcltvKytdID0gcGFkZGluZztcbiAgICAgICAgICAgIGJ1ZmZlcltvKytdID0gcGFkZGluZztcbiAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICB9XG4gICAgICAgIGNhc2UgYnVmZmVyLmxlbmd0aDoge1xuICAgICAgICAgICAgY29uc3QgeCA9IChidWZmZXJbaSAtIDJdIDw8IDE2KSB8IChidWZmZXJbaSAtIDFdIDw8IDgpO1xuICAgICAgICAgICAgYnVmZmVyW28rK10gPSBhbHBoYWJldFt4ID4+IDE4XTtcbiAgICAgICAgICAgIGJ1ZmZlcltvKytdID0gYWxwaGFiZXRbeCA+PiAxMiAmIDB4M0ZdO1xuICAgICAgICAgICAgYnVmZmVyW28rK10gPSBhbHBoYWJldFt4ID4+IDYgJiAweDNGXTtcbiAgICAgICAgICAgIGJ1ZmZlcltvKytdID0gcGFkZGluZztcbiAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICB9XG4gICAgfVxuICAgIHJldHVybiBvO1xufVxuZXhwb3J0IGZ1bmN0aW9uIGRlY29kZShidWZmZXIsIGksIG8sIGFscGhhYmV0LCBwYWRkaW5nKSB7XG4gICAgZm9yIChsZXQgeCA9IGJ1ZmZlci5sZW5ndGggLSAyOyB4IDwgYnVmZmVyLmxlbmd0aDsgKyt4KSB7XG4gICAgICAgIGlmIChidWZmZXJbeF0gPT09IHBhZGRpbmcpIHtcbiAgICAgICAgICAgIGZvciAobGV0IHkgPSB4ICsgMTsgeSA8IGJ1ZmZlci5sZW5ndGg7ICsreSkge1xuICAgICAgICAgICAgICAgIGlmIChidWZmZXJbeV0gIT09IHBhZGRpbmcpIHtcbiAgICAgICAgICAgICAgICAgICAgdGhyb3cgbmV3IFR5cGVFcnJvcihgQ2Fubm90IGRlY29kZSBpbnB1dCBhcyBiYXNlNjQ6IEludmFsaWQgY2hhcmFjdGVyICgke1N0cmluZy5mcm9tQ2hhckNvZGUoYnVmZmVyW3ldKX0pYCk7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfVxuICAgICAgICAgICAgYnVmZmVyID0gYnVmZmVyLnN1YmFycmF5KDAsIHgpO1xuICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgIH1cbiAgICB9XG4gICAgaWYgKChidWZmZXIubGVuZ3RoIC0gbykgJSA0ID09PSAxKSB7XG4gICAgICAgIHRocm93IG5ldyBSYW5nZUVycm9yKGBDYW5ub3QgZGVjb2RlIGlucHV0IGFzIGJhc2U2NDogTGVuZ3RoICgke2J1ZmZlci5sZW5ndGggLSBvfSksIGV4Y2x1ZGluZyBwYWRkaW5nLCBtdXN0IG5vdCBoYXZlIGEgcmVtYWluZGVyIG9mIDEgd2hlbiBkaXZpZGVkIGJ5IDRgKTtcbiAgICB9XG4gICAgaSArPSAzO1xuICAgIGZvciAoOyBpIDwgYnVmZmVyLmxlbmd0aDsgaSArPSA0KSB7XG4gICAgICAgIGNvbnN0IHggPSAoZ2V0Qnl0ZShidWZmZXJbaSAtIDNdLCBhbHBoYWJldCkgPDwgMTgpIHxcbiAgICAgICAgICAgIChnZXRCeXRlKGJ1ZmZlcltpIC0gMl0sIGFscGhhYmV0KSA8PCAxMikgfFxuICAgICAgICAgICAgKGdldEJ5dGUoYnVmZmVyW2kgLSAxXSwgYWxwaGFiZXQpIDw8IDYpIHxcbiAgICAgICAgICAgIGdldEJ5dGUoYnVmZmVyW2ldLCBhbHBoYWJldCk7XG4gICAgICAgIGJ1ZmZlcltvKytdID0geCA+PiAxNjtcbiAgICAgICAgYnVmZmVyW28rK10gPSB4ID4+IDggJiAweEZGO1xuICAgICAgICBidWZmZXJbbysrXSA9IHggJiAweEZGO1xuICAgIH1cbiAgICBzd2l0Y2ggKGkpIHtcbiAgICAgICAgY2FzZSBidWZmZXIubGVuZ3RoICsgMToge1xuICAgICAgICAgICAgY29uc3QgeCA9IChnZXRCeXRlKGJ1ZmZlcltpIC0gM10sIGFscGhhYmV0KSA8PCAxOCkgfFxuICAgICAgICAgICAgICAgIChnZXRCeXRlKGJ1ZmZlcltpIC0gMl0sIGFscGhhYmV0KSA8PCAxMik7XG4gICAgICAgICAgICBidWZmZXJbbysrXSA9IHggPj4gMTY7XG4gICAgICAgICAgICBicmVhaztcbiAgICAgICAgfVxuICAgICAgICBjYXNlIGJ1ZmZlci5sZW5ndGg6IHtcbiAgICAgICAgICAgIGNvbnN0IHggPSAoZ2V0Qnl0ZShidWZmZXJbaSAtIDNdLCBhbHBoYWJldCkgPDwgMTgpIHxcbiAgICAgICAgICAgICAgICAoZ2V0Qnl0ZShidWZmZXJbaSAtIDJdLCBhbHBoYWJldCkgPDwgMTIpIHxcbiAgICAgICAgICAgICAgICAoZ2V0Qnl0ZShidWZmZXJbaSAtIDFdLCBhbHBoYWJldCkgPDwgNik7XG4gICAgICAgICAgICBidWZmZXJbbysrXSA9IHggPj4gMTY7XG4gICAgICAgICAgICBidWZmZXJbbysrXSA9IHggPj4gOCAmIDB4RkY7XG4gICAgICAgICAgICBicmVhaztcbiAgICAgICAgfVxuICAgIH1cbiAgICByZXR1cm4gbztcbn1cbmZ1bmN0aW9uIGdldEJ5dGUoY2hhciwgYWxwaGFiZXQpIHtcbiAgICBjb25zdCBieXRlID0gYWxwaGFiZXRbY2hhcl0gPz8gNjQ7XG4gICAgaWYgKGJ5dGUgPT09IDY0KSB7IC8vIGFscGhhYmV0LkJhc2U2NC5sZW5ndGhcbiAgICAgICAgdGhyb3cgbmV3IFR5cGVFcnJvcihgQ2Fubm90IGRlY29kZSBpbnB1dCBhcyBiYXNlNjQ6IEludmFsaWQgY2hhcmFjdGVyICgke1N0cmluZy5mcm9tQ2hhckNvZGUoY2hhcil9KWApO1xuICAgIH1cbiAgICByZXR1cm4gYnl0ZTtcbn1cbiIsIi8vIENvcHlyaWdodCAyMDE4LTIwMjUgdGhlIERlbm8gYXV0aG9ycy4gTUlUIGxpY2Vuc2UuXG5leHBvcnQgZnVuY3Rpb24gZGV0YWNoKGJ1ZmZlciwgbWF4U2l6ZSkge1xuICAgIGNvbnN0IG9yaWdpbmFsU2l6ZSA9IGJ1ZmZlci5sZW5ndGg7XG4gICAgaWYgKGJ1ZmZlci5ieXRlT2Zmc2V0KSB7XG4gICAgICAgIGNvbnN0IGIgPSBuZXcgVWludDhBcnJheShidWZmZXIuYnVmZmVyKTtcbiAgICAgICAgYi5zZXQoYnVmZmVyKTtcbiAgICAgICAgYnVmZmVyID0gYi5zdWJhcnJheSgwLCBvcmlnaW5hbFNpemUpO1xuICAgIH1cbiAgICAvLyBkZW5vLWxpbnQtaWdub3JlIG5vLWV4cGxpY2l0LWFueVxuICAgIGJ1ZmZlciA9IG5ldyBVaW50OEFycmF5KGJ1ZmZlci5idWZmZXIudHJhbnNmZXIobWF4U2l6ZSkpO1xuICAgIGJ1ZmZlci5zZXQoYnVmZmVyLnN1YmFycmF5KDAsIG9yaWdpbmFsU2l6ZSksIG1heFNpemUgLSBvcmlnaW5hbFNpemUpO1xuICAgIHJldHVybiBbYnVmZmVyLCBtYXhTaXplIC0gb3JpZ2luYWxTaXplXTtcbn1cbiIsIi8vIENvcHlyaWdodCAyMDE4LTIwMjUgdGhlIERlbm8gYXV0aG9ycy4gTUlUIGxpY2Vuc2UuXG5jb25zdCBlbmNvZGVyID0gbmV3IFRleHRFbmNvZGVyKCk7XG5mdW5jdGlvbiBnZXRUeXBlTmFtZSh2YWx1ZSkge1xuICAgIGNvbnN0IHR5cGUgPSB0eXBlb2YgdmFsdWU7XG4gICAgaWYgKHR5cGUgIT09IFwib2JqZWN0XCIpIHtcbiAgICAgICAgcmV0dXJuIHR5cGU7XG4gICAgfVxuICAgIGVsc2UgaWYgKHZhbHVlID09PSBudWxsKSB7XG4gICAgICAgIHJldHVybiBcIm51bGxcIjtcbiAgICB9XG4gICAgZWxzZSB7XG4gICAgICAgIHJldHVybiB2YWx1ZT8uY29uc3RydWN0b3I/Lm5hbWUgPz8gXCJvYmplY3RcIjtcbiAgICB9XG59XG5leHBvcnQgZnVuY3Rpb24gdmFsaWRhdGVCaW5hcnlMaWtlKHNvdXJjZSkge1xuICAgIGlmICh0eXBlb2Ygc291cmNlID09PSBcInN0cmluZ1wiKSB7XG4gICAgICAgIHJldHVybiBlbmNvZGVyLmVuY29kZShzb3VyY2UpO1xuICAgIH1cbiAgICBlbHNlIGlmIChzb3VyY2UgaW5zdGFuY2VvZiBVaW50OEFycmF5KSB7XG4gICAgICAgIHJldHVybiBzb3VyY2U7XG4gICAgfVxuICAgIGVsc2UgaWYgKHNvdXJjZSBpbnN0YW5jZW9mIEFycmF5QnVmZmVyKSB7XG4gICAgICAgIHJldHVybiBuZXcgVWludDhBcnJheShzb3VyY2UpO1xuICAgIH1cbiAgICB0aHJvdyBuZXcgVHlwZUVycm9yKGBDYW5ub3QgdmFsaWRhdGUgdGhlIGlucHV0IGFzIGl0IG11c3QgYmUgYSBVaW50OEFycmF5LCBhIHN0cmluZywgb3IgYW4gQXJyYXlCdWZmZXI6IHJlY2VpdmVkIGEgdmFsdWUgb2YgdGhlIHR5cGUgJHtnZXRUeXBlTmFtZShzb3VyY2UpfWApO1xufVxuIiwiLy8gQ29weXJpZ2h0IDIwMTgtMjAyNSB0aGUgRGVubyBhdXRob3JzLiBNSVQgbGljZW5zZS5cbi8vIFRoaXMgbW9kdWxlIGlzIGJyb3dzZXIgY29tcGF0aWJsZS5cbi8qKlxuICogVXRpbGl0aWVzIGZvciB3b3JraW5nIHdpdGgge0BsaW5rIGh0dHBzOi8vZW4ud2lraXBlZGlhLm9yZy93aWtpL0FzY2lpODUgfCBhc2NpaTg1fSBlbmNvZGluZy5cbiAqXG4gKiAjIyBTcGVjaWZ5aW5nIGEgc3RhbmRhcmQgYW5kIGRlbGltaXRlclxuICpcbiAqIEJ5IGRlZmF1bHQsIGFsbCBmdW5jdGlvbnMgYXJlIHVzaW5nIHRoZSBtb3N0IHBvcHVsYXIgQWRvYmUgdmVyc2lvbiBvZiBhc2NpaTg1XG4gKiBhbmQgbm90IGFkZGluZyBhbnkgZGVsaW1pdGVyLiBIb3dldmVyLCB0aGVyZSBhcmUgdGhyZWUgbW9yZSBzdGFuZGFyZHNcbiAqIHN1cHBvcnRlZCAtIGJ0b2EgKGRpZmZlcmVudCBkZWxpbWl0ZXIgYW5kIGFkZGl0aW9uYWwgY29tcHJlc3Npb24gb2YgNCBieXRlc1xuICogZXF1YWwgdG8gMzIpLCB7QGxpbmsgaHR0cHM6Ly9yZmMuemVyb21xLm9yZy9zcGVjLzMyLyB8IFo4NX0gYW5kXG4gKiB7QGxpbmsgaHR0cHM6Ly93d3cucmZjLWVkaXRvci5vcmcvcmZjL3JmYzE5MjQuaHRtbCB8IFJGQyAxOTI0fS4gSXQncyBwb3NzaWJsZSB0byB1c2UgYVxuICogZGlmZmVyZW50IGVuY29kaW5nIGJ5IHNwZWNpZnlpbmcgaXQgaW4gYG9wdGlvbnNgIG9iamVjdCBhcyBhIHNlY29uZCBwYXJhbWV0ZXIuXG4gKlxuICogU2ltaWxhcmx5LCBpdCdzIHBvc3NpYmxlIHRvIG1ha2UgYGVuY29kZWAgYWRkIGEgZGVsaW1pdGVyIChgPH5gIGFuZCBgfj5gIGZvclxuICogQWRvYmUsIGB4YnRvYSBCZWdpbmAgYW5kIGB4YnRvYSBFbmRgIHdpdGggbmV3bGluZXMgYmV0d2VlbiB0aGUgZGVsaW1pdGVycyBhbmRcbiAqIGVuY29kZWQgZGF0YSBmb3IgYnRvYS4gQ2hlY2tzdW1zIGZvciBidG9hIGFyZSBub3Qgc3VwcG9ydGVkLiBEZWxpbWl0ZXJzIGFyZSBub3RcbiAqIHN1cHBvcnRlZCBieSBvdGhlciBlbmNvZGluZ3MuKVxuICpcbiAqIEBtb2R1bGVcbiAqL1xuaW1wb3J0IHsgdmFsaWRhdGVCaW5hcnlMaWtlIH0gZnJvbSBcIi4vX3ZhbGlkYXRlX2JpbmFyeV9saWtlLmpzXCI7XG5jb25zdCByZmMxOTI0ID0gXCIwMTIzNDU2Nzg5QUJDREVGR0hJSktMTU5PUFFSU1RVVldYWVphYmNkZWZnaGlqa2xtbm9wcXJzdHV2d3h5eiEjJCUmKCkqKy07PD0+P0BeX2B7fH1+XCI7XG5jb25zdCBaODUgPSBcIjAxMjM0NTY3ODlhYmNkZWZnaGlqa2xtbm9wcXJzdHV2d3h5ekFCQ0RFRkdISUpLTE1OT1BRUlNUVVZXWFlaLi06Kz1eIS8qPyY8PigpW117fUAlJCNcIjtcbi8qKlxuICogQ29udmVydHMgZGF0YSBpbnRvIGFuIGFzY2lpODUtZW5jb2RlZCBzdHJpbmcuXG4gKlxuICogQHBhcmFtIGRhdGEgVGhlIGRhdGEgdG8gZW5jb2RlLlxuICogQHBhcmFtIG9wdGlvbnMgT3B0aW9ucyBmb3IgZW5jb2RpbmcuXG4gKlxuICogQHJldHVybnMgVGhlIGFzY2lpODUtZW5jb2RlZCBzdHJpbmcuXG4gKlxuICogQGV4YW1wbGUgVXNhZ2VcbiAqIGBgYHRzXG4gKiBpbXBvcnQgeyBlbmNvZGVBc2NpaTg1IH0gZnJvbSBcIkBzdGQvZW5jb2RpbmcvYXNjaWk4NVwiO1xuICogaW1wb3J0IHsgYXNzZXJ0RXF1YWxzIH0gZnJvbSBcIkBzdGQvYXNzZXJ0XCI7XG4gKlxuICogYXNzZXJ0RXF1YWxzKGVuY29kZUFzY2lpODUoXCJIZWxsbyB3b3JsZCFcIiksIFwiODdjVVJEXWo3QkVibzgwXCIpO1xuICogYGBgXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBlbmNvZGVBc2NpaTg1KGRhdGEsIG9wdGlvbnMgPSB7fSkge1xuICAgIGxldCB1aW50OCA9IHZhbGlkYXRlQmluYXJ5TGlrZShkYXRhKTtcbiAgICBjb25zdCB7IHN0YW5kYXJkID0gXCJBZG9iZVwiIH0gPSBvcHRpb25zO1xuICAgIGxldCBvdXRwdXQgPSBbXTtcbiAgICBsZXQgdjtcbiAgICBsZXQgbiA9IDA7XG4gICAgbGV0IGRpZmZlcmVuY2UgPSAwO1xuICAgIGlmICh1aW50OC5sZW5ndGggJSA0ICE9PSAwKSB7XG4gICAgICAgIGNvbnN0IHRtcCA9IHVpbnQ4O1xuICAgICAgICBkaWZmZXJlbmNlID0gNCAtICh0bXAubGVuZ3RoICUgNCk7XG4gICAgICAgIHVpbnQ4ID0gbmV3IFVpbnQ4QXJyYXkodG1wLmxlbmd0aCArIGRpZmZlcmVuY2UpO1xuICAgICAgICB1aW50OC5zZXQodG1wKTtcbiAgICB9XG4gICAgY29uc3QgdmlldyA9IG5ldyBEYXRhVmlldyh1aW50OC5idWZmZXIsIHVpbnQ4LmJ5dGVPZmZzZXQsIHVpbnQ4LmJ5dGVMZW5ndGgpO1xuICAgIGZvciAobGV0IGkgPSAwOyBpIDwgdWludDgubGVuZ3RoOyBpICs9IDQpIHtcbiAgICAgICAgdiA9IHZpZXcuZ2V0VWludDMyKGkpO1xuICAgICAgICAvLyBBZG9iZSBhbmQgYnRvYSBzdGFuZGFyZHMgY29tcHJlc3MgNCB6ZXJvZXMgdG8gc2luZ2xlIFwielwiIGNoYXJhY3RlclxuICAgICAgICBpZiAoKHN0YW5kYXJkID09PSBcIkFkb2JlXCIgfHwgc3RhbmRhcmQgPT09IFwiYnRvYVwiKSAmJlxuICAgICAgICAgICAgdiA9PT0gMCAmJlxuICAgICAgICAgICAgaSA8IHVpbnQ4Lmxlbmd0aCAtIGRpZmZlcmVuY2UgLSAzKSB7XG4gICAgICAgICAgICBvdXRwdXRbbisrXSA9IFwielwiO1xuICAgICAgICAgICAgY29udGludWU7XG4gICAgICAgIH1cbiAgICAgICAgLy8gYnRvYSBjb21wcmVzc2VzIDQgc3BhY2VzIC0gdGhhdCBpcywgYnl0ZXMgZXF1YWwgdG8gMzIgLSBpbnRvIHNpbmdsZSBcInlcIiBjaGFyYWN0ZXJcbiAgICAgICAgaWYgKHN0YW5kYXJkID09PSBcImJ0b2FcIiAmJiB2ID09PSA1Mzg5NzYyODgpIHtcbiAgICAgICAgICAgIG91dHB1dFtuKytdID0gXCJ5XCI7XG4gICAgICAgICAgICBjb250aW51ZTtcbiAgICAgICAgfVxuICAgICAgICBmb3IgKGxldCBqID0gNDsgaiA+PSAwOyBqLS0pIHtcbiAgICAgICAgICAgIG91dHB1dFtuICsgal0gPSBTdHJpbmcuZnJvbUNoYXJDb2RlKCh2ICUgODUpICsgMzMpO1xuICAgICAgICAgICAgdiA9IE1hdGgudHJ1bmModiAvIDg1KTtcbiAgICAgICAgfVxuICAgICAgICBuICs9IDU7XG4gICAgfVxuICAgIHN3aXRjaCAoc3RhbmRhcmQpIHtcbiAgICAgICAgY2FzZSBcIkFkb2JlXCI6XG4gICAgICAgICAgICBpZiAob3B0aW9ucz8uZGVsaW1pdGVyKSB7XG4gICAgICAgICAgICAgICAgcmV0dXJuIGA8fiR7b3V0cHV0LnNsaWNlKDAsIG91dHB1dC5sZW5ndGggLSBkaWZmZXJlbmNlKS5qb2luKFwiXCIpfX4+YDtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICBjYXNlIFwiYnRvYVwiOlxuICAgICAgICAgICAgaWYgKG9wdGlvbnM/LmRlbGltaXRlcikge1xuICAgICAgICAgICAgICAgIHJldHVybiBgeGJ0b2EgQmVnaW5cXG4ke291dHB1dFxuICAgICAgICAgICAgICAgICAgICAuc2xpY2UoMCwgb3V0cHV0Lmxlbmd0aCAtIGRpZmZlcmVuY2UpXG4gICAgICAgICAgICAgICAgICAgIC5qb2luKFwiXCIpfVxcbnhidG9hIEVuZGA7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBicmVhaztcbiAgICAgICAgY2FzZSBcIlJGQyAxOTI0XCI6XG4gICAgICAgICAgICBvdXRwdXQgPSBvdXRwdXQubWFwKCh2YWwpID0+IHJmYzE5MjRbdmFsLmNoYXJDb2RlQXQoMCkgLSAzM10pO1xuICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgIGNhc2UgXCJaODVcIjpcbiAgICAgICAgICAgIG91dHB1dCA9IG91dHB1dC5tYXAoKHZhbCkgPT4gWjg1W3ZhbC5jaGFyQ29kZUF0KDApIC0gMzNdKTtcbiAgICAgICAgICAgIGJyZWFrO1xuICAgIH1cbiAgICByZXR1cm4gb3V0cHV0LnNsaWNlKDAsIG91dHB1dC5sZW5ndGggLSBkaWZmZXJlbmNlKS5qb2luKFwiXCIpO1xufVxuLyoqXG4gKiBEZWNvZGVzIGEgYXNjaWk4NS1lbmNvZGVkIHN0cmluZy5cbiAqXG4gKiBAcGFyYW0gYXNjaWk4NSBUaGUgYXNjaWk4NS1lbmNvZGVkIHN0cmluZyB0byBkZWNvZGUuXG4gKiBAcGFyYW0gb3B0aW9ucyBPcHRpb25zIGZvciBkZWNvZGluZy5cbiAqIEByZXR1cm5zIFRoZSBkZWNvZGVkIGRhdGEuXG4gKlxuICogQGV4YW1wbGUgVXNhZ2VcbiAqIGBgYHRzXG4gKiBpbXBvcnQgeyBkZWNvZGVBc2NpaTg1IH0gZnJvbSBcIkBzdGQvZW5jb2RpbmcvYXNjaWk4NVwiO1xuICogaW1wb3J0IHsgYXNzZXJ0RXF1YWxzIH0gZnJvbSBcIkBzdGQvYXNzZXJ0XCI7XG4gKlxuICogYXNzZXJ0RXF1YWxzKFxuICogICBkZWNvZGVBc2NpaTg1KFwiODdjVVJEXWo3QkVibzgwXCIpLFxuICogICBuZXcgVGV4dEVuY29kZXIoKS5lbmNvZGUoXCJIZWxsbyB3b3JsZCFcIiksXG4gKiApO1xuICogYGBgXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBkZWNvZGVBc2NpaTg1KGFzY2lpODUsIG9wdGlvbnMgPSB7fSkge1xuICAgIGNvbnN0IHsgc3RhbmRhcmQgPSBcIkFkb2JlXCIgfSA9IG9wdGlvbnM7XG4gICAgLy8gdHJhbnNsYXRlIGFsbCBlbmNvZGluZ3MgdG8gbW9zdCBiYXNpYyBhZG9iZS9idG9hIG9uZSBhbmQgZGVjb21wcmVzcyBzb21lIHNwZWNpYWwgY2hhcmFjdGVycyAoXCJ6XCIgYW5kIFwieVwiKVxuICAgIHN3aXRjaCAoc3RhbmRhcmQpIHtcbiAgICAgICAgY2FzZSBcIkFkb2JlXCI6XG4gICAgICAgICAgICBhc2NpaTg1ID0gYXNjaWk4NS5yZXBsYWNlQWxsKC8oPH58fj4pL2csIFwiXCIpLnJlcGxhY2VBbGwoXCJ6XCIsIFwiISEhISFcIik7XG4gICAgICAgICAgICBicmVhaztcbiAgICAgICAgY2FzZSBcImJ0b2FcIjpcbiAgICAgICAgICAgIGFzY2lpODUgPSBhc2NpaTg1XG4gICAgICAgICAgICAgICAgLnJlcGxhY2VBbGwoLyh4YnRvYSBCZWdpbnx4YnRvYSBFbmR8XFxuKS9nLCBcIlwiKVxuICAgICAgICAgICAgICAgIC5yZXBsYWNlQWxsKFwielwiLCBcIiEhISEhXCIpXG4gICAgICAgICAgICAgICAgLnJlcGxhY2VBbGwoXCJ5XCIsIFwiKzxWZExcIik7XG4gICAgICAgICAgICBicmVhaztcbiAgICAgICAgY2FzZSBcIlJGQyAxOTI0XCI6XG4gICAgICAgICAgICBhc2NpaTg1ID0gYXNjaWk4NS5yZXBsYWNlQWxsKC8uL2csIChtYXRjaCkgPT4gU3RyaW5nLmZyb21DaGFyQ29kZShyZmMxOTI0LmluZGV4T2YobWF0Y2gpICsgMzMpKTtcbiAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICBjYXNlIFwiWjg1XCI6XG4gICAgICAgICAgICBhc2NpaTg1ID0gYXNjaWk4NS5yZXBsYWNlQWxsKC8uL2csIChtYXRjaCkgPT4gU3RyaW5nLmZyb21DaGFyQ29kZShaODUuaW5kZXhPZihtYXRjaCkgKyAzMykpO1xuICAgICAgICAgICAgYnJlYWs7XG4gICAgfVxuICAgIC8vIHJlbW92ZSBhbGwgaW52YWxpZCBjaGFyYWN0ZXJzXG4gICAgYXNjaWk4NSA9IGFzY2lpODUucmVwbGFjZUFsbCgvW14hLXVdL2csIFwiXCIpO1xuICAgIGNvbnN0IGxlbiA9IGFzY2lpODUubGVuZ3RoO1xuICAgIGNvbnN0IG91dHB1dCA9IG5ldyBVaW50OEFycmF5KGxlbiArIDQgLSAobGVuICUgNCkpO1xuICAgIGNvbnN0IHZpZXcgPSBuZXcgRGF0YVZpZXcob3V0cHV0LmJ1ZmZlcik7XG4gICAgbGV0IHYgPSAwO1xuICAgIGxldCBuID0gMDtcbiAgICBsZXQgbWF4ID0gMDtcbiAgICBmb3IgKGxldCBpID0gMDsgaSA8IGxlbjspIHtcbiAgICAgICAgZm9yIChtYXggKz0gNTsgaSA8IG1heDsgaSsrKSB7XG4gICAgICAgICAgICB2ID0gdiAqIDg1ICsgKGkgPCBsZW4gPyBhc2NpaTg1LmNoYXJDb2RlQXQoaSkgOiAxMTcpIC0gMzM7XG4gICAgICAgIH1cbiAgICAgICAgdmlldy5zZXRVaW50MzIobiwgdik7XG4gICAgICAgIHYgPSAwO1xuICAgICAgICBuICs9IDQ7XG4gICAgfVxuICAgIHJldHVybiBvdXRwdXQuc2xpY2UoMCwgTWF0aC50cnVuYyhsZW4gKiAwLjgpKTtcbn1cbiIsIi8vIENvcHlyaWdodCAyMDE4LTIwMjUgdGhlIERlbm8gYXV0aG9ycy4gTUlUIGxpY2Vuc2UuXG4vLyBDb3B5cmlnaHQgKGMpIDIwMTQgSmFtZXNvbiBMaXR0bGUuIE1JVCBMaWNlbnNlLlxuLy8gVGhpcyBtb2R1bGUgaXMgYnJvd3NlciBjb21wYXRpYmxlLlxuLyoqXG4gKiBVdGlsaXRpZXMgZm9yXG4gKiB7QGxpbmsgaHR0cHM6Ly93d3cucmZjLWVkaXRvci5vcmcvcmZjL3JmYzQ2NDguaHRtbCNzZWN0aW9uLTYgfCBiYXNlMzJ9XG4gKiBlbmNvZGluZyBhbmQgZGVjb2RpbmcuXG4gKlxuICogTW9kaWZpZWQgZnJvbSB7QGxpbmsgaHR0cHM6Ly9naXRodWIuY29tL2JlYXRnYW1taXQvYmFzZTY0LWpzfS5cbiAqXG4gKiBgYGB0c1xuICogaW1wb3J0IHsgZW5jb2RlQmFzZTMyLCBkZWNvZGVCYXNlMzIgfSBmcm9tIFwiQHN0ZC9lbmNvZGluZy9iYXNlMzJcIjtcbiAqIGltcG9ydCB7IGFzc2VydEVxdWFscyB9IGZyb20gXCJAc3RkL2Fzc2VydFwiO1xuICpcbiAqIGFzc2VydEVxdWFscyhlbmNvZGVCYXNlMzIoXCJmb29iYXJcIiksIFwiTVpYVzZZVEJPST09PT09PVwiKTtcbiAqXG4gKiBhc3NlcnRFcXVhbHMoXG4gKiAgIGRlY29kZUJhc2UzMihcIk1aWFc2WVRCT0k9PT09PT1cIiksXG4gKiAgIG5ldyBUZXh0RW5jb2RlcigpLmVuY29kZShcImZvb2JhclwiKVxuICogKTtcbiAqIGBgYFxuICpcbiAqIEBtb2R1bGVcbiAqL1xuaW1wb3J0IHsgY2FsY1NpemVCYXNlMzIsIGRlY29kZSwgZW5jb2RlIH0gZnJvbSBcIi4vX2NvbW1vbjMyLmpzXCI7XG5pbXBvcnQgeyBkZXRhY2ggfSBmcm9tIFwiLi9fY29tbW9uX2RldGFjaC5qc1wiO1xuY29uc3QgcGFkZGluZyA9IFwiPVwiLmNoYXJDb2RlQXQoMCk7XG5jb25zdCBhbHBoYWJldCA9IG5ldyBUZXh0RW5jb2RlcigpXG4gICAgLmVuY29kZShcIkFCQ0RFRkdISUpLTE1OT1BRUlNUVVZXWFlaMjM0NTY3XCIpO1xuY29uc3QgckFscGhhYmV0ID0gbmV3IFVpbnQ4QXJyYXkoMTI4KS5maWxsKDMyKTsgLy9hbHBoYWJldC5sZW5ndGhcbmFscGhhYmV0LmZvckVhY2goKGJ5dGUsIGkpID0+IHJBbHBoYWJldFtieXRlXSA9IGkpO1xuLyoqXG4gKiBDb252ZXJ0cyBkYXRhIGludG8gYSBiYXNlMzItZW5jb2RlZCBzdHJpbmcuXG4gKlxuICogQHNlZSB7QGxpbmsgaHR0cHM6Ly93d3cucmZjLWVkaXRvci5vcmcvcmZjL3JmYzQ2NDguaHRtbCNzZWN0aW9uLTZ9XG4gKlxuICogQHBhcmFtIGRhdGEgVGhlIGRhdGEgdG8gZW5jb2RlLlxuICogQHJldHVybnMgVGhlIGJhc2UzMi1lbmNvZGVkIHN0cmluZy5cbiAqXG4gKiBAZXhhbXBsZSBVc2FnZVxuICogYGBgdHNcbiAqIGltcG9ydCB7IGVuY29kZUJhc2UzMiB9IGZyb20gXCJAc3RkL2VuY29kaW5nL2Jhc2UzMlwiO1xuICogaW1wb3J0IHsgYXNzZXJ0RXF1YWxzIH0gZnJvbSBcIkBzdGQvYXNzZXJ0XCI7XG4gKlxuICogYXNzZXJ0RXF1YWxzKGVuY29kZUJhc2UzMihcIjZjNjBjMFwiKSwgXCJHWlJUTU1EREdBPT09PT09XCIpO1xuICogYGBgXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBlbmNvZGVCYXNlMzIoZGF0YSkge1xuICAgIGlmICh0eXBlb2YgZGF0YSA9PT0gXCJzdHJpbmdcIikge1xuICAgICAgICBkYXRhID0gbmV3IFRleHRFbmNvZGVyKCkuZW5jb2RlKGRhdGEpO1xuICAgIH1cbiAgICBlbHNlIGlmIChkYXRhIGluc3RhbmNlb2YgQXJyYXlCdWZmZXIpXG4gICAgICAgIGRhdGEgPSBuZXcgVWludDhBcnJheShkYXRhKS5zbGljZSgpO1xuICAgIGVsc2VcbiAgICAgICAgZGF0YSA9IGRhdGEuc2xpY2UoKTtcbiAgICBjb25zdCBbb3V0cHV0LCBpXSA9IGRldGFjaChkYXRhLCBjYWxjU2l6ZUJhc2UzMihkYXRhLmxlbmd0aCkpO1xuICAgIGVuY29kZShvdXRwdXQsIGksIDAsIGFscGhhYmV0LCBwYWRkaW5nKTtcbiAgICByZXR1cm4gbmV3IFRleHREZWNvZGVyKCkuZGVjb2RlKG91dHB1dCk7XG59XG4vKipcbiAqIERlY29kZXMgYSBiYXNlMzItZW5jb2RlZCBzdHJpbmcuXG4gKlxuICogQHNlZSB7QGxpbmsgaHR0cHM6Ly93d3cucmZjLWVkaXRvci5vcmcvcmZjL3JmYzQ2NDguaHRtbCNzZWN0aW9uLTZ9XG4gKlxuICogQHBhcmFtIGIzMiBUaGUgYmFzZTMyLWVuY29kZWQgc3RyaW5nIHRvIGRlY29kZS5cbiAqIEByZXR1cm5zIFRoZSBkZWNvZGVkIGRhdGEuXG4gKlxuICogQGV4YW1wbGUgVXNhZ2VcbiAqIGBgYHRzXG4gKiBpbXBvcnQgeyBkZWNvZGVCYXNlMzIgfSBmcm9tIFwiQHN0ZC9lbmNvZGluZy9iYXNlMzJcIjtcbiAqIGltcG9ydCB7IGFzc2VydEVxdWFscyB9IGZyb20gXCJAc3RkL2Fzc2VydFwiO1xuICpcbiAqIGFzc2VydEVxdWFscyhcbiAqICAgZGVjb2RlQmFzZTMyKFwiR1pSVE1NRERHQT09PT09PVwiKSxcbiAqICAgbmV3IFRleHRFbmNvZGVyKCkuZW5jb2RlKFwiNmM2MGMwXCIpLFxuICogKTtcbiAqIGBgYFxuICovXG5leHBvcnQgZnVuY3Rpb24gZGVjb2RlQmFzZTMyKGIzMikge1xuICAgIGNvbnN0IG91dHB1dCA9IG5ldyBUZXh0RW5jb2RlcigpLmVuY29kZShiMzIpO1xuICAgIGlmIChvdXRwdXQubGVuZ3RoICUgOCkge1xuICAgICAgICB0aHJvdyBuZXcgVHlwZUVycm9yKGBJbnZhbGlkIGJhc2UzMiBzdHJpbmc6IGxlbmd0aCAoJHtvdXRwdXQubGVuZ3RofSkgbXVzdCBiZSBhIG11bHRpcGxlIG9mIDhgKTtcbiAgICB9XG4gICAgLy8gZGVuby1saW50LWlnbm9yZSBuby1leHBsaWNpdC1hbnlcbiAgICByZXR1cm4gbmV3IFVpbnQ4QXJyYXkob3V0cHV0LmJ1ZmZlclxuICAgICAgICAudHJhbnNmZXIoZGVjb2RlKG91dHB1dCwgMCwgMCwgckFscGhhYmV0LCBwYWRkaW5nKSkpO1xufVxuIiwiLy8gQ29weXJpZ2h0IDIwMTgtMjAyNSB0aGUgRGVubyBhdXRob3JzLiBNSVQgbGljZW5zZS5cbi8vIFRoaXMgbW9kdWxlIGlzIGJyb3dzZXIgY29tcGF0aWJsZS5cbi8qKlxuICogVXRpbGl0aWVzIGZvclxuICoge0BsaW5rIGh0dHBzOi8vZGF0YXRyYWNrZXIuaWV0Zi5vcmcvZG9jL2h0bWwvZHJhZnQtbXNwb3JueS1iYXNlNTgtMDMgfCBiYXNlNTh9XG4gKiBlbmNvZGluZyBhbmQgZGVjb2RpbmcuXG4gKlxuICogYGBgdHNcbiAqIGltcG9ydCB7IGVuY29kZUJhc2U1OCwgZGVjb2RlQmFzZTU4IH0gZnJvbSBcIkBzdGQvZW5jb2RpbmcvYmFzZTU4XCI7XG4gKiBpbXBvcnQgeyBhc3NlcnRFcXVhbHMgfSBmcm9tIFwiQHN0ZC9hc3NlcnRcIjtcbiAqXG4gKiBjb25zdCBoZWxsbyA9IG5ldyBUZXh0RW5jb2RlcigpLmVuY29kZShcIkhlbGxvIFdvcmxkIVwiKTtcbiAqXG4gKiBhc3NlcnRFcXVhbHMoZW5jb2RlQmFzZTU4KGhlbGxvKSwgXCIyTkVwbzdUWlJSckxaU2kyVVwiKTtcbiAqXG4gKiBhc3NlcnRFcXVhbHMoZGVjb2RlQmFzZTU4KFwiMk5FcG83VFpSUnJMWlNpMlVcIiksIGhlbGxvKTtcbiAqIGBgYFxuICpcbiAqIEBtb2R1bGVcbiAqL1xuaW1wb3J0IHsgdmFsaWRhdGVCaW5hcnlMaWtlIH0gZnJvbSBcIi4vX3ZhbGlkYXRlX2JpbmFyeV9saWtlLmpzXCI7XG4vLyBkZW5vLWZtdC1pZ25vcmVcbmNvbnN0IG1hcEJhc2U1OCA9IHtcbiAgICBcIjFcIjogMCwgXCIyXCI6IDEsIFwiM1wiOiAyLCBcIjRcIjogMywgXCI1XCI6IDQsIFwiNlwiOiA1LCBcIjdcIjogNiwgXCI4XCI6IDcsIFwiOVwiOiA4LCBBOiA5LFxuICAgIEI6IDEwLCBDOiAxMSwgRDogMTIsIEU6IDEzLCBGOiAxNCwgRzogMTUsIEg6IDE2LCBKOiAxNywgSzogMTgsIEw6IDE5LCBNOiAyMCxcbiAgICBOOiAyMSwgUDogMjIsIFE6IDIzLCBSOiAyNCwgUzogMjUsIFQ6IDI2LCBVOiAyNywgVjogMjgsIFc6IDI5LCBYOiAzMCwgWTogMzEsXG4gICAgWjogMzIsIGE6IDMzLCBiOiAzNCwgYzogMzUsIGQ6IDM2LCBlOiAzNywgZjogMzgsIGc6IDM5LCBoOiA0MCwgaTogNDEsIGo6IDQyLFxuICAgIGs6IDQzLCBtOiA0NCwgbjogNDUsIG86IDQ2LCBwOiA0NywgcTogNDgsIHI6IDQ5LCBzOiA1MCwgdDogNTEsIHU6IDUyLCB2OiA1MyxcbiAgICB3OiA1NCwgeDogNTUsIHk6IDU2LCB6OiA1N1xufTtcbmNvbnN0IGJhc2U1OGFscGhhYmV0ID0gXCIxMjM0NTY3ODlBQkNERUZHSEpLTE1OUFFSU1RVVldYWVphYmNkZWZnaGlqa21ub3BxcnN0dXZ3eHl6XCIuc3BsaXQoXCJcIik7XG4vKipcbiAqIENvbnZlcnRzIGRhdGEgaW50byBhIGJhc2U1OC1lbmNvZGVkIHN0cmluZy5cbiAqXG4gKiBAc2VlIHtAbGluayBodHRwczovL2RhdGF0cmFja2VyLmlldGYub3JnL2RvYy9odG1sL2RyYWZ0LW1zcG9ybnktYmFzZTU4LTAzI3NlY3Rpb24tM31cbiAqXG4gKiBAcGFyYW0gZGF0YSBUaGUgZGF0YSB0byBlbmNvZGUuXG4gKiBAcmV0dXJucyBUaGUgYmFzZTU4LWVuY29kZWQgc3RyaW5nLlxuICpcbiAqIEBleGFtcGxlIFVzYWdlXG4gKiBgYGB0c1xuICogaW1wb3J0IHsgZW5jb2RlQmFzZTU4IH0gZnJvbSBcIkBzdGQvZW5jb2RpbmcvYmFzZTU4XCI7XG4gKiBpbXBvcnQgeyBhc3NlcnRFcXVhbHMgfSBmcm9tIFwiQHN0ZC9hc3NlcnRcIjtcbiAqXG4gKiBhc3NlcnRFcXVhbHMoZW5jb2RlQmFzZTU4KFwiSGVsbG8gV29ybGQhXCIpLCBcIjJORXBvN1RaUlJyTFpTaTJVXCIpO1xuICogYGBgXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBlbmNvZGVCYXNlNTgoZGF0YSkge1xuICAgIGNvbnN0IHVpbnQ4dERhdGEgPSB2YWxpZGF0ZUJpbmFyeUxpa2UoZGF0YSk7XG4gICAgbGV0IGxlbmd0aCA9IDA7XG4gICAgbGV0IHplcm9lcyA9IDA7XG4gICAgLy8gQ291bnRpbmcgbGVhZGluZyB6ZXJvZXNcbiAgICBsZXQgaW5kZXggPSAwO1xuICAgIHdoaWxlICh1aW50OHREYXRhW2luZGV4XSA9PT0gMCkge1xuICAgICAgICB6ZXJvZXMrKztcbiAgICAgICAgaW5kZXgrKztcbiAgICB9XG4gICAgY29uc3Qgbm90WmVyb1VpbnQ4RGF0YSA9IHVpbnQ4dERhdGEuc2xpY2UoaW5kZXgpO1xuICAgIGNvbnN0IHNpemUgPSBNYXRoLnJvdW5kKCh1aW50OHREYXRhLmxlbmd0aCAqIDEzOCkgLyAxMDAgKyAxKTtcbiAgICBjb25zdCBiNThFbmNvZGluZyA9IFtdO1xuICAgIG5vdFplcm9VaW50OERhdGEuZm9yRWFjaCgoYnl0ZSkgPT4ge1xuICAgICAgICBsZXQgaSA9IDA7XG4gICAgICAgIGxldCBjYXJyeSA9IGJ5dGU7XG4gICAgICAgIGZvciAobGV0IHJldmVyc2VJdGVyYXRvciA9IHNpemUgLSAxOyAoY2FycnkgPiAwIHx8IGkgPCBsZW5ndGgpICYmIHJldmVyc2VJdGVyYXRvciAhPT0gLTE7IHJldmVyc2VJdGVyYXRvci0tLCBpKyspIHtcbiAgICAgICAgICAgIGNhcnJ5ICs9IChiNThFbmNvZGluZ1tyZXZlcnNlSXRlcmF0b3JdID8/IDApICogMjU2O1xuICAgICAgICAgICAgYjU4RW5jb2RpbmdbcmV2ZXJzZUl0ZXJhdG9yXSA9IE1hdGgucm91bmQoY2FycnkgJSA1OCk7XG4gICAgICAgICAgICBjYXJyeSA9IE1hdGguZmxvb3IoY2FycnkgLyA1OCk7XG4gICAgICAgIH1cbiAgICAgICAgbGVuZ3RoID0gaTtcbiAgICB9KTtcbiAgICBjb25zdCBzdHJSZXN1bHQgPSBBcnJheS5mcm9tKHtcbiAgICAgICAgbGVuZ3RoOiBiNThFbmNvZGluZy5sZW5ndGggKyB6ZXJvZXMsXG4gICAgfSk7XG4gICAgaWYgKHplcm9lcyA+IDApIHtcbiAgICAgICAgc3RyUmVzdWx0LmZpbGwoXCIxXCIsIDAsIHplcm9lcyk7XG4gICAgfVxuICAgIGI1OEVuY29kaW5nLmZvckVhY2goKGJ5dGVWYWx1ZSkgPT4gc3RyUmVzdWx0LnB1c2goYmFzZTU4YWxwaGFiZXRbYnl0ZVZhbHVlXSkpO1xuICAgIHJldHVybiBzdHJSZXN1bHQuam9pbihcIlwiKTtcbn1cbi8qKlxuICogRGVjb2RlcyBhIGJhc2U1OC1lbmNvZGVkIHN0cmluZy5cbiAqXG4gKiBAc2VlIHtAbGluayBodHRwczovL2RhdGF0cmFja2VyLmlldGYub3JnL2RvYy9odG1sL2RyYWZ0LW1zcG9ybnktYmFzZTU4LTAzI3NlY3Rpb24tNH1cbiAqXG4gKiBAcGFyYW0gYjU4IFRoZSBiYXNlNTgtZW5jb2RlZCBzdHJpbmcgdG8gZGVjb2RlLlxuICogQHJldHVybnMgVGhlIGRlY29kZWQgZGF0YS5cbiAqXG4gKiBAZXhhbXBsZSBVc2FnZVxuICogYGBgdHNcbiAqIGltcG9ydCB7IGRlY29kZUJhc2U1OCB9IGZyb20gXCJAc3RkL2VuY29kaW5nL2Jhc2U1OFwiO1xuICogaW1wb3J0IHsgYXNzZXJ0RXF1YWxzIH0gZnJvbSBcIkBzdGQvYXNzZXJ0XCI7XG4gKlxuICogYXNzZXJ0RXF1YWxzKFxuICogICBkZWNvZGVCYXNlNTgoXCIyTkVwbzdUWlJSckxaU2kyVVwiKSxcbiAqICAgbmV3IFRleHRFbmNvZGVyKCkuZW5jb2RlKFwiSGVsbG8gV29ybGQhXCIpXG4gKiApO1xuICogYGBgXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBkZWNvZGVCYXNlNTgoYjU4KSB7XG4gICAgY29uc3Qgc3BsaXRJbnB1dCA9IGI1OC50cmltKCkuc3BsaXQoXCJcIik7XG4gICAgbGV0IGxlbmd0aCA9IDA7XG4gICAgbGV0IG9uZXMgPSAwO1xuICAgIC8vIENvdW50aW5nIGxlYWRpbmcgb25lc1xuICAgIGxldCBpbmRleCA9IDA7XG4gICAgd2hpbGUgKHNwbGl0SW5wdXRbaW5kZXhdID09PSBcIjFcIikge1xuICAgICAgICBvbmVzKys7XG4gICAgICAgIGluZGV4Kys7XG4gICAgfVxuICAgIGNvbnN0IG5vdFplcm9EYXRhID0gc3BsaXRJbnB1dC5zbGljZShpbmRleCk7XG4gICAgY29uc3Qgc2l6ZSA9IE1hdGgucm91bmQoKGI1OC5sZW5ndGggKiA3MzMpIC8gMTAwMCArIDEpO1xuICAgIGNvbnN0IG91dHB1dCA9IFtdO1xuICAgIG5vdFplcm9EYXRhLmZvckVhY2goKGNoYXIsIGlkeCkgPT4ge1xuICAgICAgICBsZXQgY2FycnkgPSBtYXBCYXNlNThbY2hhcl07XG4gICAgICAgIGxldCBpID0gMDtcbiAgICAgICAgaWYgKGNhcnJ5ID09PSB1bmRlZmluZWQpIHtcbiAgICAgICAgICAgIHRocm93IG5ldyBUeXBlRXJyb3IoYEludmFsaWQgYmFzZTU4IGNoYXIgYXQgaW5kZXggJHtpZHh9IHdpdGggdmFsdWUgJHtjaGFyfWApO1xuICAgICAgICB9XG4gICAgICAgIGZvciAobGV0IHJldmVyc2VJdGVyYXRvciA9IHNpemUgLSAxOyAoY2FycnkgPiAwIHx8IGkgPCBsZW5ndGgpICYmIHJldmVyc2VJdGVyYXRvciAhPT0gLTE7IHJldmVyc2VJdGVyYXRvci0tLCBpKyspIHtcbiAgICAgICAgICAgIGNhcnJ5ICs9IDU4ICogKG91dHB1dFtyZXZlcnNlSXRlcmF0b3JdID8/IDApO1xuICAgICAgICAgICAgb3V0cHV0W3JldmVyc2VJdGVyYXRvcl0gPSBNYXRoLnJvdW5kKGNhcnJ5ICUgMjU2KTtcbiAgICAgICAgICAgIGNhcnJ5ID0gTWF0aC5mbG9vcihjYXJyeSAvIDI1Nik7XG4gICAgICAgIH1cbiAgICAgICAgbGVuZ3RoID0gaTtcbiAgICB9KTtcbiAgICBjb25zdCB2YWxpZE91dHB1dCA9IG91dHB1dC5maWx0ZXIoKGl0ZW0pID0+IGl0ZW0gIT09IHVuZGVmaW5lZCk7XG4gICAgaWYgKG9uZXMgPiAwKSB7XG4gICAgICAgIGNvbnN0IG9uZXNSZXN1bHQgPSBBcnJheS5mcm9tKHsgbGVuZ3RoOiBvbmVzIH0pLmZpbGwoMCwgMCwgb25lcyk7XG4gICAgICAgIHJldHVybiBuZXcgVWludDhBcnJheShbLi4ub25lc1Jlc3VsdCwgLi4udmFsaWRPdXRwdXRdKTtcbiAgICB9XG4gICAgcmV0dXJuIG5ldyBVaW50OEFycmF5KHZhbGlkT3V0cHV0KTtcbn1cbiIsIi8vIENvcHlyaWdodCAyMDE4LTIwMjUgdGhlIERlbm8gYXV0aG9ycy4gTUlUIGxpY2Vuc2UuXG4vLyBUaGlzIG1vZHVsZSBpcyBicm93c2VyIGNvbXBhdGlibGUuXG4vKipcbiAqIFV0aWxpdGllcyBmb3JcbiAqIHtAbGluayBodHRwczovL3d3dy5yZmMtZWRpdG9yLm9yZy9yZmMvcmZjNDY0OC5odG1sI3NlY3Rpb24tNCB8IGJhc2U2NH1cbiAqIGVuY29kaW5nIGFuZCBkZWNvZGluZy5cbiAqXG4gKiBgYGB0c1xuICogaW1wb3J0IHtcbiAqICAgZW5jb2RlQmFzZTY0LFxuICogICBkZWNvZGVCYXNlNjQsXG4gKiB9IGZyb20gXCJAc3RkL2VuY29kaW5nL2Jhc2U2NFwiO1xuICogaW1wb3J0IHsgYXNzZXJ0RXF1YWxzIH0gZnJvbSBcIkBzdGQvYXNzZXJ0XCI7XG4gKlxuICogY29uc3QgZm9vYmFyID0gbmV3IFRleHRFbmNvZGVyKCkuZW5jb2RlKFwiZm9vYmFyXCIpO1xuICpcbiAqIGFzc2VydEVxdWFscyhlbmNvZGVCYXNlNjQoZm9vYmFyKSwgXCJabTl2WW1GeVwiKTtcbiAqIGFzc2VydEVxdWFscyhkZWNvZGVCYXNlNjQoXCJabTl2WW1GeVwiKSwgZm9vYmFyKTtcbiAqIGBgYFxuICpcbiAqIEBtb2R1bGVcbiAqL1xuaW1wb3J0IHsgY2FsY1NpemVCYXNlNjQsIGRlY29kZSwgZW5jb2RlIH0gZnJvbSBcIi4vX2NvbW1vbjY0LmpzXCI7XG5pbXBvcnQgeyBkZXRhY2ggfSBmcm9tIFwiLi9fY29tbW9uX2RldGFjaC5qc1wiO1xuY29uc3QgcGFkZGluZyA9IFwiPVwiLmNoYXJDb2RlQXQoMCk7XG5jb25zdCBhbHBoYWJldCA9IG5ldyBUZXh0RW5jb2RlcigpXG4gICAgLmVuY29kZShcIkFCQ0RFRkdISUpLTE1OT1BRUlNUVVZXWFlaYWJjZGVmZ2hpamtsbW5vcHFyc3R1dnd4eXowMTIzNDU2Nzg5Ky9cIik7XG5jb25zdCByQWxwaGFiZXQgPSBuZXcgVWludDhBcnJheSgxMjgpLmZpbGwoNjQpOyAvLyBhbHBoYWJldC5sZW5ndGhcbmFscGhhYmV0LmZvckVhY2goKGJ5dGUsIGkpID0+IHJBbHBoYWJldFtieXRlXSA9IGkpO1xuLyoqXG4gKiBDb252ZXJ0cyBkYXRhIGludG8gYSBiYXNlNjQtZW5jb2RlZCBzdHJpbmcuXG4gKlxuICogQHNlZSB7QGxpbmsgaHR0cHM6Ly93d3cucmZjLWVkaXRvci5vcmcvcmZjL3JmYzQ2NDguaHRtbCNzZWN0aW9uLTR9XG4gKlxuICogQHBhcmFtIGRhdGEgVGhlIGRhdGEgdG8gZW5jb2RlLlxuICogQHJldHVybnMgVGhlIGJhc2U2NC1lbmNvZGVkIHN0cmluZy5cbiAqXG4gKiBAZXhhbXBsZSBVc2FnZVxuICogYGBgdHNcbiAqIGltcG9ydCB7IGVuY29kZUJhc2U2NCB9IGZyb20gXCJAc3RkL2VuY29kaW5nL2Jhc2U2NFwiO1xuICogaW1wb3J0IHsgYXNzZXJ0RXF1YWxzIH0gZnJvbSBcIkBzdGQvYXNzZXJ0XCI7XG4gKlxuICogYXNzZXJ0RXF1YWxzKGVuY29kZUJhc2U2NChcImZvb2JhclwiKSwgXCJabTl2WW1GeVwiKTtcbiAqIGBgYFxuICovXG5leHBvcnQgZnVuY3Rpb24gZW5jb2RlQmFzZTY0KGRhdGEpIHtcbiAgICBpZiAodHlwZW9mIGRhdGEgPT09IFwic3RyaW5nXCIpIHtcbiAgICAgICAgZGF0YSA9IG5ldyBUZXh0RW5jb2RlcigpLmVuY29kZShkYXRhKTtcbiAgICB9XG4gICAgZWxzZSBpZiAoZGF0YSBpbnN0YW5jZW9mIEFycmF5QnVmZmVyKVxuICAgICAgICBkYXRhID0gbmV3IFVpbnQ4QXJyYXkoZGF0YSkuc2xpY2UoKTtcbiAgICBlbHNlXG4gICAgICAgIGRhdGEgPSBkYXRhLnNsaWNlKCk7XG4gICAgY29uc3QgW291dHB1dCwgaV0gPSBkZXRhY2goZGF0YSwgY2FsY1NpemVCYXNlNjQoZGF0YS5sZW5ndGgpKTtcbiAgICBlbmNvZGUob3V0cHV0LCBpLCAwLCBhbHBoYWJldCwgcGFkZGluZyk7XG4gICAgcmV0dXJuIG5ldyBUZXh0RGVjb2RlcigpLmRlY29kZShvdXRwdXQpO1xufVxuLyoqXG4gKiBEZWNvZGVzIGEgYmFzZTY0LWVuY29kZWQgc3RyaW5nLlxuICpcbiAqIEBzZWUge0BsaW5rIGh0dHBzOi8vd3d3LnJmYy1lZGl0b3Iub3JnL3JmYy9yZmM0NjQ4Lmh0bWwjc2VjdGlvbi00fVxuICpcbiAqIEBwYXJhbSBiNjQgVGhlIGJhc2U2NC1lbmNvZGVkIHN0cmluZyB0byBkZWNvZGUuXG4gKiBAcmV0dXJucyBUaGUgZGVjb2RlZCBkYXRhLlxuICpcbiAqIEBleGFtcGxlIFVzYWdlXG4gKiBgYGB0c1xuICogaW1wb3J0IHsgZGVjb2RlQmFzZTY0IH0gZnJvbSBcIkBzdGQvZW5jb2RpbmcvYmFzZTY0XCI7XG4gKiBpbXBvcnQgeyBhc3NlcnRFcXVhbHMgfSBmcm9tIFwiQHN0ZC9hc3NlcnRcIjtcbiAqXG4gKiBhc3NlcnRFcXVhbHMoXG4gKiAgIGRlY29kZUJhc2U2NChcIlptOXZZbUZ5XCIpLFxuICogICBuZXcgVGV4dEVuY29kZXIoKS5lbmNvZGUoXCJmb29iYXJcIilcbiAqICk7XG4gKiBgYGBcbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIGRlY29kZUJhc2U2NChiNjQpIHtcbiAgICBjb25zdCBvdXRwdXQgPSBuZXcgVGV4dEVuY29kZXIoKS5lbmNvZGUoYjY0KTtcbiAgICAvLyBkZW5vLWxpbnQtaWdub3JlIG5vLWV4cGxpY2l0LWFueVxuICAgIHJldHVybiBuZXcgVWludDhBcnJheShvdXRwdXQuYnVmZmVyXG4gICAgICAgIC50cmFuc2ZlcihkZWNvZGUob3V0cHV0LCAwLCAwLCByQWxwaGFiZXQsIHBhZGRpbmcpKSk7XG59XG4iLCIvLyBDb3B5cmlnaHQgMjAxOC0yMDI1IHRoZSBEZW5vIGF1dGhvcnMuIE1JVCBsaWNlbnNlLlxuLy8gVGhpcyBtb2R1bGUgaXMgYnJvd3NlciBjb21wYXRpYmxlLlxuLyoqXG4gKiBVdGlsaXRpZXMgZm9yXG4gKiB7QGxpbmsgaHR0cHM6Ly93d3cucmZjLWVkaXRvci5vcmcvcmZjL3JmYzQ2NDguaHRtbCNzZWN0aW9uLTUgfCBiYXNlNjR1cmx9XG4gKiBlbmNvZGluZyBhbmQgZGVjb2RpbmcuXG4gKlxuICogQG1vZHVsZVxuICovXG5pbXBvcnQgeyBjYWxjU2l6ZUJhc2U2NCwgZGVjb2RlLCBlbmNvZGUgfSBmcm9tIFwiLi9fY29tbW9uNjQuanNcIjtcbmltcG9ydCB7IGRldGFjaCB9IGZyb20gXCIuL19jb21tb25fZGV0YWNoLmpzXCI7XG5jb25zdCBwYWRkaW5nID0gXCI9XCIuY2hhckNvZGVBdCgwKTtcbmNvbnN0IGFscGhhYmV0ID0gbmV3IFRleHRFbmNvZGVyKClcbiAgICAuZW5jb2RlKFwiQUJDREVGR0hJSktMTU5PUFFSU1RVVldYWVphYmNkZWZnaGlqa2xtbm9wcXJzdHV2d3h5ejAxMjM0NTY3ODktX1wiKTtcbmNvbnN0IHJBbHBoYWJldCA9IG5ldyBVaW50OEFycmF5KDEyOCkuZmlsbCg2NCk7IC8vIGFscGhhYmV0Lmxlbmd0aFxuYWxwaGFiZXQuZm9yRWFjaCgoYnl0ZSwgaSkgPT4gckFscGhhYmV0W2J5dGVdID0gaSk7XG4vKipcbiAqIENvbnZlcnQgZGF0YSBpbnRvIGEgYmFzZTY0dXJsLWVuY29kZWQgc3RyaW5nLlxuICpcbiAqIEBzZWUge0BsaW5rIGh0dHBzOi8vd3d3LnJmYy1lZGl0b3Iub3JnL3JmYy9yZmM0NjQ4Lmh0bWwjc2VjdGlvbi01fVxuICpcbiAqIEBwYXJhbSBkYXRhIFRoZSBkYXRhIHRvIGVuY29kZS5cbiAqIEByZXR1cm5zIFRoZSBiYXNlNjR1cmwtZW5jb2RlZCBzdHJpbmcuXG4gKlxuICogQGV4YW1wbGUgVXNhZ2VcbiAqIGBgYHRzXG4gKiBpbXBvcnQgeyBlbmNvZGVCYXNlNjRVcmwgfSBmcm9tIFwiQHN0ZC9lbmNvZGluZy9iYXNlNjR1cmxcIjtcbiAqIGltcG9ydCB7IGFzc2VydEVxdWFscyB9IGZyb20gXCJAc3RkL2Fzc2VydFwiO1xuICpcbiAqIGFzc2VydEVxdWFscyhlbmNvZGVCYXNlNjRVcmwoXCJmb29iYXJcIiksIFwiWm05dlltRnlcIik7XG4gKiBgYGBcbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIGVuY29kZUJhc2U2NFVybChkYXRhKSB7XG4gICAgaWYgKHR5cGVvZiBkYXRhID09PSBcInN0cmluZ1wiKSB7XG4gICAgICAgIGRhdGEgPSBuZXcgVGV4dEVuY29kZXIoKS5lbmNvZGUoZGF0YSk7XG4gICAgfVxuICAgIGVsc2UgaWYgKGRhdGEgaW5zdGFuY2VvZiBBcnJheUJ1ZmZlcilcbiAgICAgICAgZGF0YSA9IG5ldyBVaW50OEFycmF5KGRhdGEpLnNsaWNlKCk7XG4gICAgZWxzZVxuICAgICAgICBkYXRhID0gZGF0YS5zbGljZSgpO1xuICAgIGNvbnN0IFtvdXRwdXQsIGldID0gZGV0YWNoKGRhdGEsIGNhbGNTaXplQmFzZTY0KGRhdGEubGVuZ3RoKSk7XG4gICAgbGV0IG8gPSBlbmNvZGUob3V0cHV0LCBpLCAwLCBhbHBoYWJldCwgcGFkZGluZyk7XG4gICAgbyA9IG91dHB1dC5pbmRleE9mKHBhZGRpbmcsIG8gLSAyKTtcbiAgICByZXR1cm4gbmV3IFRleHREZWNvZGVyKCkuZGVjb2RlKFxuICAgIC8vIGRlbm8tbGludC1pZ25vcmUgbm8tZXhwbGljaXQtYW55XG4gICAgbyA+IDAgPyBuZXcgVWludDhBcnJheShvdXRwdXQuYnVmZmVyLnRyYW5zZmVyKG8pKSA6IG91dHB1dCk7XG59XG4vKipcbiAqIERlY29kZXMgYSBnaXZlbiBiYXNlNjR1cmwtZW5jb2RlZCBzdHJpbmcuXG4gKlxuICogQHNlZSB7QGxpbmsgaHR0cHM6Ly93d3cucmZjLWVkaXRvci5vcmcvcmZjL3JmYzQ2NDguaHRtbCNzZWN0aW9uLTV9XG4gKlxuICogQHBhcmFtIGI2NHVybCBUaGUgYmFzZTY0dXJsLWVuY29kZWQgc3RyaW5nIHRvIGRlY29kZS5cbiAqIEByZXR1cm5zIFRoZSBkZWNvZGVkIGRhdGEuXG4gKlxuICogQGV4YW1wbGUgVXNhZ2VcbiAqIGBgYHRzXG4gKiBpbXBvcnQgeyBkZWNvZGVCYXNlNjRVcmwgfSBmcm9tIFwiQHN0ZC9lbmNvZGluZy9iYXNlNjR1cmxcIjtcbiAqIGltcG9ydCB7IGFzc2VydEVxdWFscyB9IGZyb20gXCJAc3RkL2Fzc2VydFwiO1xuICpcbiAqIGFzc2VydEVxdWFscyhcbiAqICAgZGVjb2RlQmFzZTY0VXJsKFwiWm05dlltRnlcIiksXG4gKiAgIG5ldyBUZXh0RW5jb2RlcigpLmVuY29kZShcImZvb2JhclwiKVxuICogKTtcbiAqIGBgYFxuICovXG5leHBvcnQgZnVuY3Rpb24gZGVjb2RlQmFzZTY0VXJsKGI2NHVybCkge1xuICAgIGNvbnN0IG91dHB1dCA9IG5ldyBUZXh0RW5jb2RlcigpLmVuY29kZShiNjR1cmwpO1xuICAgIC8vIGRlbm8tbGludC1pZ25vcmUgbm8tZXhwbGljaXQtYW55XG4gICAgcmV0dXJuIG5ldyBVaW50OEFycmF5KG91dHB1dC5idWZmZXJcbiAgICAgICAgLnRyYW5zZmVyKGRlY29kZShvdXRwdXQsIDAsIDAsIHJBbHBoYWJldCwgcGFkZGluZykpKTtcbn1cbiIsIi8vIENvcHlyaWdodCAyMDA5IFRoZSBHbyBBdXRob3JzLiBBbGwgcmlnaHRzIHJlc2VydmVkLlxuLy8gaHR0cHM6Ly9naXRodWIuY29tL2dvbGFuZy9nby9ibG9iL21hc3Rlci9MSUNFTlNFXG4vLyBDb3B5cmlnaHQgMjAxOC0yMDI1IHRoZSBEZW5vIGF1dGhvcnMuIE1JVCBsaWNlbnNlLlxuLy8gVGhpcyBtb2R1bGUgaXMgYnJvd3NlciBjb21wYXRpYmxlLlxuLyoqXG4gKiBQb3J0IG9mIHRoZSBHb1xuICoge0BsaW5rIGh0dHBzOi8vZ2l0aHViLmNvbS9nb2xhbmcvZ28vYmxvYi9nbzEuMTIuNS9zcmMvZW5jb2RpbmcvaGV4L2hleC5nbyB8IGVuY29kaW5nL2hleH1cbiAqIGxpYnJhcnkuXG4gKlxuICogYGBgdHNcbiAqIGltcG9ydCB7XG4gKiAgIGRlY29kZUhleCxcbiAqICAgZW5jb2RlSGV4LFxuICogfSBmcm9tIFwiQHN0ZC9lbmNvZGluZy9oZXhcIjtcbiAqIGltcG9ydCB7IGFzc2VydEVxdWFscyB9IGZyb20gXCJAc3RkL2Fzc2VydFwiO1xuICpcbiAqIGFzc2VydEVxdWFscyhlbmNvZGVIZXgoXCJhYmNcIiksIFwiNjE2MjYzXCIpO1xuICpcbiAqIGFzc2VydEVxdWFscyhcbiAqICAgZGVjb2RlSGV4KFwiNjE2MjYzXCIpLFxuICogICBuZXcgVGV4dEVuY29kZXIoKS5lbmNvZGUoXCJhYmNcIiksXG4gKiApO1xuICogYGBgXG4gKlxuICogQG1vZHVsZVxuICovXG5pbXBvcnQgeyBjYWxjU2l6ZUhleCwgZGVjb2RlLCBlbmNvZGUgfSBmcm9tIFwiLi9fY29tbW9uMTYuanNcIjtcbmltcG9ydCB7IGRldGFjaCB9IGZyb20gXCIuL19jb21tb25fZGV0YWNoLmpzXCI7XG5jb25zdCBhbHBoYWJldCA9IG5ldyBUZXh0RW5jb2RlcigpXG4gICAgLmVuY29kZShcIjAxMjM0NTY3ODlhYmNkZWZcIik7XG5jb25zdCByQWxwaGFiZXQgPSBuZXcgVWludDhBcnJheSgxMjgpLmZpbGwoMTYpOyAvLyBhbHBoYWJldC5sZW5ndGhcbmFscGhhYmV0LmZvckVhY2goKGJ5dGUsIGkpID0+IHJBbHBoYWJldFtieXRlXSA9IGkpO1xubmV3IFRleHRFbmNvZGVyKClcbiAgICAuZW5jb2RlKFwiQUJDREVGXCIpXG4gICAgLmZvckVhY2goKGJ5dGUsIGkpID0+IHJBbHBoYWJldFtieXRlXSA9IGkgKyAxMCk7XG4vKipcbiAqIENvbnZlcnRzIGRhdGEgaW50byBhIGhleC1lbmNvZGVkIHN0cmluZy5cbiAqXG4gKiBAcGFyYW0gc3JjIFRoZSBkYXRhIHRvIGVuY29kZS5cbiAqXG4gKiBAcmV0dXJucyBUaGUgaGV4LWVuY29kZWQgc3RyaW5nLlxuICpcbiAqIEBleGFtcGxlIFVzYWdlXG4gKiBgYGB0c1xuICogaW1wb3J0IHsgZW5jb2RlSGV4IH0gZnJvbSBcIkBzdGQvZW5jb2RpbmcvaGV4XCI7XG4gKiBpbXBvcnQgeyBhc3NlcnRFcXVhbHMgfSBmcm9tIFwiQHN0ZC9hc3NlcnRcIjtcbiAqXG4gKiBhc3NlcnRFcXVhbHMoZW5jb2RlSGV4KFwiYWJjXCIpLCBcIjYxNjI2M1wiKTtcbiAqIGBgYFxuICovXG5leHBvcnQgZnVuY3Rpb24gZW5jb2RlSGV4KHNyYykge1xuICAgIGlmICh0eXBlb2Ygc3JjID09PSBcInN0cmluZ1wiKSB7XG4gICAgICAgIHNyYyA9IG5ldyBUZXh0RW5jb2RlcigpLmVuY29kZShzcmMpO1xuICAgIH1cbiAgICBlbHNlIGlmIChzcmMgaW5zdGFuY2VvZiBBcnJheUJ1ZmZlcilcbiAgICAgICAgc3JjID0gbmV3IFVpbnQ4QXJyYXkoc3JjKS5zbGljZSgpO1xuICAgIGVsc2VcbiAgICAgICAgc3JjID0gc3JjLnNsaWNlKCk7XG4gICAgY29uc3QgW291dHB1dCwgaV0gPSBkZXRhY2goc3JjLCBjYWxjU2l6ZUhleChzcmMubGVuZ3RoKSk7XG4gICAgZW5jb2RlKG91dHB1dCwgaSwgMCwgYWxwaGFiZXQpO1xuICAgIHJldHVybiBuZXcgVGV4dERlY29kZXIoKS5kZWNvZGUob3V0cHV0KTtcbn1cbi8qKlxuICogRGVjb2RlcyB0aGUgZ2l2ZW4gaGV4LWVuY29kZWQgc3RyaW5nLiBJZiB0aGUgaW5wdXQgaXMgbWFsZm9ybWVkLCBhbiBlcnJvciBpc1xuICogdGhyb3duLlxuICpcbiAqIEBwYXJhbSBzcmMgVGhlIGhleC1lbmNvZGVkIHN0cmluZyB0byBkZWNvZGUuXG4gKlxuICogQHJldHVybnMgVGhlIGRlY29kZWQgZGF0YS5cbiAqXG4gKiBAZXhhbXBsZSBVc2FnZVxuICogYGBgdHNcbiAqIGltcG9ydCB7IGRlY29kZUhleCB9IGZyb20gXCJAc3RkL2VuY29kaW5nL2hleFwiO1xuICogaW1wb3J0IHsgYXNzZXJ0RXF1YWxzIH0gZnJvbSBcIkBzdGQvYXNzZXJ0XCI7XG4gKlxuICogYXNzZXJ0RXF1YWxzKFxuICogICBkZWNvZGVIZXgoXCI2MTYyNjNcIiksXG4gKiAgIG5ldyBUZXh0RW5jb2RlcigpLmVuY29kZShcImFiY1wiKSxcbiAqICk7XG4gKiBgYGBcbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIGRlY29kZUhleChzcmMpIHtcbiAgICBjb25zdCBvdXRwdXQgPSBuZXcgVGV4dEVuY29kZXIoKS5lbmNvZGUoc3JjKTtcbiAgICAvLyBkZW5vLWxpbnQtaWdub3JlIG5vLWV4cGxpY2l0LWFueVxuICAgIHJldHVybiBuZXcgVWludDhBcnJheShvdXRwdXQuYnVmZmVyXG4gICAgICAgIC50cmFuc2ZlcihkZWNvZGUob3V0cHV0LCAwLCAwLCByQWxwaGFiZXQpKSk7XG59XG4iLCIvLyBDb3B5cmlnaHQgMjAxOC0yMDI1IHRoZSBEZW5vIGF1dGhvcnMuIE1JVCBsaWNlbnNlLlxuLy8gVGhpcyBtb2R1bGUgaXMgYnJvd3NlciBjb21wYXRpYmxlLlxuLyoqXG4gKiBVdGlsaXRpZXMgZm9yIGVuY29kaW5nIGFuZCBkZWNvZGluZyBjb21tb24gZm9ybWF0cyBsaWtlIGhleCwgYmFzZTY0LCBhbmQgdmFyaW50LlxuICpcbiAqICMjIEJhc2ljIFVzYWdlXG4gKlxuICogYGBgdHNcbiAqIGltcG9ydCB7IGVuY29kZUJhc2U2NCwgZGVjb2RlQmFzZTY0IH0gZnJvbSBcIkBzdGQvZW5jb2RpbmdcIjtcbiAqIGltcG9ydCB7IGFzc2VydEVxdWFscyB9IGZyb20gXCJAc3RkL2Fzc2VydFwiO1xuICpcbiAqIGNvbnN0IGZvb2JhciA9IG5ldyBUZXh0RW5jb2RlcigpLmVuY29kZShcImZvb2JhclwiKTtcbiAqIGFzc2VydEVxdWFscyhlbmNvZGVCYXNlNjQoZm9vYmFyKSwgXCJabTl2WW1GeVwiKTtcbiAqIGFzc2VydEVxdWFscyhkZWNvZGVCYXNlNjQoXCJabTl2WW1GeVwiKSwgZm9vYmFyKTtcbiAqIGBgYFxuICpcbiAqICMjIFZhcmlvdXMgRW5jb2RpbmcgRm9ybWF0c1xuICpcbiAqIGBgYHRzXG4gKiBpbXBvcnQge1xuICogICBlbmNvZGVIZXgsXG4gKiAgIGVuY29kZUJhc2UzMixcbiAqICAgZW5jb2RlQmFzZTU4LFxuICogICBlbmNvZGVCYXNlNjQsXG4gKiAgIGVuY29kZUFzY2lpODUsXG4gKiAgIGRlY29kZUhleCxcbiAqICAgZGVjb2RlQmFzZTMyLFxuICogICBkZWNvZGVCYXNlNTgsXG4gKiAgIGRlY29kZUJhc2U2NCxcbiAqICAgZGVjb2RlQXNjaWk4NSxcbiAqIH0gZnJvbSBcIkBzdGQvZW5jb2RpbmdcIjtcbiAqIGltcG9ydCB7IGFzc2VydEVxdWFscyB9IGZyb20gXCJAc3RkL2Fzc2VydFwiO1xuICpcbiAqIC8vIE1hbnkgZGlmZmVyZW50IGVuY29kaW5ncyBmb3IgZGlmZmVyZW50IGNoYXJhY3RlciBzZXRzXG4gKiBhc3NlcnRFcXVhbHMoZW5jb2RlSGV4KFwiSGVsbG8gd29ybGQhXCIpLCBcIjQ4NjU2YzZjNmYyMDc3NmY3MjZjNjQyMVwiKTtcbiAqIGFzc2VydEVxdWFscyhlbmNvZGVCYXNlMzIoXCJIZWxsbyB3b3JsZCFcIiksIFwiSkJTV1kzRFBFQjNXNjRUTU1RUVE9PT09XCIpO1xuICogYXNzZXJ0RXF1YWxzKGVuY29kZUJhc2U1OChcIkhlbGxvIHdvcmxkIVwiKSwgXCIyTkVwbzdUWlJobmE3dlN2TFwiKTtcbiAqIGFzc2VydEVxdWFscyhlbmNvZGVCYXNlNjQoXCJIZWxsbyB3b3JsZCFcIiksIFwiU0dWc2JHOGdkMjl5YkdRaFwiKTtcbiAqIGFzc2VydEVxdWFscyhlbmNvZGVBc2NpaTg1KFwiSGVsbG8gd29ybGQhXCIpLCBcIjg3Y1VSRF1qN0JFYm84MFwiKTtcbiAqXG4gKiAvLyBEZWNvZGluZ1xuICogYXNzZXJ0RXF1YWxzKG5ldyBUZXh0RGVjb2RlcigpLmRlY29kZShkZWNvZGVIZXgoXCI0ODY1NmM2YzZmMjA3NzZmNzI2YzY0MjFcIikpLCBcIkhlbGxvIHdvcmxkIVwiKTtcbiAqIGFzc2VydEVxdWFscyhuZXcgVGV4dERlY29kZXIoKS5kZWNvZGUoZGVjb2RlQmFzZTMyKFwiSkJTV1kzRFBFQjNXNjRUTU1RUVE9PT09XCIpKSwgXCJIZWxsbyB3b3JsZCFcIik7XG4gKiBhc3NlcnRFcXVhbHMobmV3IFRleHREZWNvZGVyKCkuZGVjb2RlKGRlY29kZUJhc2U1OChcIjJORXBvN1RaUmhuYTd2U3ZMXCIpKSwgXCJIZWxsbyB3b3JsZCFcIik7XG4gKiBhc3NlcnRFcXVhbHMobmV3IFRleHREZWNvZGVyKCkuZGVjb2RlKGRlY29kZUJhc2U2NChcIlNHVnNiRzhnZDI5eWJHUWhcIikpLCBcIkhlbGxvIHdvcmxkIVwiKTtcbiAqIGFzc2VydEVxdWFscyhuZXcgVGV4dERlY29kZXIoKS5kZWNvZGUoZGVjb2RlQXNjaWk4NShcIjg3Y1VSRF1qN0JFYm84MFwiKSksIFwiSGVsbG8gd29ybGQhXCIpO1xuICogYGBgXG4gKlxuICogIyMgVVJMLVNhZmUgQmFzZTY0XG4gKlxuICogYGBgdHNcbiAqIGltcG9ydCB7IGVuY29kZUJhc2U2NCwgZW5jb2RlQmFzZTY0VXJsIH0gZnJvbSBcIkBzdGQvZW5jb2RpbmdcIjtcbiAqIGltcG9ydCB7IGFzc2VydEVxdWFscyB9IGZyb20gXCJAc3RkL2Fzc2VydFwiO1xuICpcbiAqIGFzc2VydEVxdWFscyhlbmNvZGVCYXNlNjQoXCJpY2UgY3JlYW1zXCIpLCBcImFXTmxJR055WldGdGN3PT1cIik7IC8vIE5vdCB1cmwtc2FmZSBiZWNhdXNlIG9mIGA9YFxuICogYXNzZXJ0RXF1YWxzKGVuY29kZUJhc2U2NFVybChcImljZSBjcmVhbXNcIiksIFwiYVdObElHTnlaV0Z0Y3dcIik7IC8vIFVSTC1zYWZlIVxuICpcbiAqIC8vIEJhc2U2NFVybCByZXBsYWNlcyArIHdpdGggLSBhbmQgLyB3aXRoIF9cbiAqIGFzc2VydEVxdWFscyhlbmNvZGVCYXNlNjQoXCJzdWJqZWN0cz9cIiksIFwiYzNWaWFtVmpkSE0vXCIpOyAvLyBzbGFzaCBpcyBub3QgVVJMLXNhZmVcbiAqIGFzc2VydEVxdWFscyhlbmNvZGVCYXNlNjRVcmwoXCJzdWJqZWN0cz9cIiksIFwiYzNWaWFtVmpkSE1fXCIpOyAvLyBfIGlzIFVSTC1zYWZlXG4gKiBgYGBcbiAqXG4gKiAjIyBCaW5hcnkgRGF0YSBFbmNvZGluZ1xuICpcbiAqIGBgYHRzXG4gKiBpbXBvcnQgeyBlbmNvZGVIZXgsIGVuY29kZUJhc2U2NCB9IGZyb20gXCJAc3RkL2VuY29kaW5nXCI7XG4gKiBpbXBvcnQgeyBhc3NlcnRFcXVhbHMgfSBmcm9tIFwiQHN0ZC9hc3NlcnRcIjtcbiAqXG4gKiAvLyBXb3JraW5nIHdpdGggYmluYXJ5IGRhdGFcbiAqIGNvbnN0IGJpbmFyeURhdGEgPSBuZXcgVWludDhBcnJheShbMHhERSwgMHhBRCwgMHhCRSwgMHhFRl0pO1xuICogYXNzZXJ0RXF1YWxzKGVuY29kZUhleChiaW5hcnlEYXRhKSwgXCJkZWFkYmVlZlwiKTtcbiAqIGFzc2VydEVxdWFscyhlbmNvZGVCYXNlNjQoYmluYXJ5RGF0YSksIFwiM3EyKzd3PT1cIik7XG4gKiBgYGBcbiAqXG4gKiAjIyBWYXJpbnQgRW5jb2RpbmdcbiAqXG4gKiBMZWFybiBtb3JlIGZyb20gdGhlIFtwcm90b2J1ZiBWYXJpbnQgZW5jb2RpbmcgZG9jc10oaHR0cHM6Ly9wcm90b2J1Zi5kZXYvcHJvZ3JhbW1pbmctZ3VpZGVzL2VuY29kaW5nLyN2YXJpbnRzKS5cbiAqXG4gKiBgYGB0c1xuICogaW1wb3J0IHsgZW5jb2RlVmFyaW50LCBkZWNvZGVWYXJpbnQgfSBmcm9tIFwiQHN0ZC9lbmNvZGluZ1wiO1xuICogaW1wb3J0IHsgYXNzZXJ0RXF1YWxzIH0gZnJvbSBcIkBzdGQvYXNzZXJ0XCI7XG4gKlxuICogLy8gVmFyaW50IGVuY29kaW5nIHN1cHBvcnRcbiAqIGFzc2VydEVxdWFscyhlbmNvZGVWYXJpbnQoOTYwMW4pLCBbbmV3IFVpbnQ4QXJyYXkoWzEyOSwgNzVdKSwgMl0pO1xuICpcbiAqIC8vIERlY29kZSBhIHZhcmludFxuICogY29uc3QgYnl0ZXMgPSBuZXcgVWludDhBcnJheShbMTI5LCA3NV0pO1xuICogYXNzZXJ0RXF1YWxzKGRlY29kZVZhcmludChieXRlcyksIFs5NjAxbiwgMl0pO1xuICogYGBgXG4gKlxuICogQG1vZHVsZVxuICovXG5leHBvcnQgKiBmcm9tIFwiLi9hc2NpaTg1LmpzXCI7XG5leHBvcnQgKiBmcm9tIFwiLi9iYXNlMzIuanNcIjtcbmV4cG9ydCAqIGZyb20gXCIuL2Jhc2U1OC5qc1wiO1xuZXhwb3J0ICogZnJvbSBcIi4vYmFzZTY0LmpzXCI7XG5leHBvcnQgKiBmcm9tIFwiLi9iYXNlNjR1cmwuanNcIjtcbmV4cG9ydCAqIGZyb20gXCIuL2hleC5qc1wiO1xuZXhwb3J0ICogZnJvbSBcIi4vdmFyaW50LmpzXCI7XG4iLCIvLyBDb3B5cmlnaHQgMjAxOC0yMDI1IHRoZSBEZW5vIGF1dGhvcnMuIE1JVCBsaWNlbnNlLlxuLy8gQ29weXJpZ2h0IDIwMjAgS2VpdGggQ2lya2VsLiBBbGwgcmlnaHRzIHJlc2VydmVkLiBNSVQgbGljZW5zZS5cbi8vIENvcHlyaWdodCAyMDIzIFNreWUgXCJNaWVyZW5NYW56XCIuIEFsbCByaWdodHMgcmVzZXJ2ZWQuIE1JVCBsaWNlbnNlLlxuLyoqXG4gKiBVdGlsaXRpZXMgZm9yIHtAbGluayBodHRwczovL3Byb3RvYnVmLmRldi9wcm9ncmFtbWluZy1ndWlkZXMvZW5jb2RpbmcvI3ZhcmludHMgVmFyaW50fSBlbmNvZGluZ1xuICogb2YgdHlwZWQgaW50ZWdlcnMuIFZhcmludCBlbmNvZGluZyByZXByZXNlbnRzIGludGVnZXJzIHVzaW5nIGEgdmFyaWFibGUgbnVtYmVyIG9mIGJ5dGVzLCB3aXRoXG4gKiBzbWFsbGVyIHZhbHVlcyByZXF1aXJpbmcgZmV3ZXIgYnl0ZXMuXG4gKlxuICogYGBgdHNcbiAqIGltcG9ydCB7IGVuY29kZVZhcmludCwgZGVjb2RlVmFyaW50IH0gZnJvbSBcIkBzdGQvZW5jb2RpbmcvdmFyaW50XCI7XG4gKiBpbXBvcnQgeyBhc3NlcnRFcXVhbHMgfSBmcm9tIFwiQHN0ZC9hc3NlcnRcIjtcbiAqXG4gKiBjb25zdCBidWYgPSBuZXcgVWludDhBcnJheSgxMCk7XG4gKiBhc3NlcnRFcXVhbHMoXG4gKiAgIGVuY29kZVZhcmludCg0Mm4sIGJ1ZiksXG4gKiAgIFtuZXcgVWludDhBcnJheShbNDJdKSwgMV1cbiAqICk7XG4gKlxuICogYXNzZXJ0RXF1YWxzKFxuICogICBkZWNvZGVWYXJpbnQobmV3IFVpbnQ4QXJyYXkoWzQyXSkpLFxuICogICBbIDQybiwgMSBdXG4gKiApO1xuICogYGBgXG4gKlxuICogQG1vZHVsZVxuICovXG4vKipcbiAqIFRoZSBtYXhpbXVtIHZhbHVlIG9mIGFuIHVuc2lnbmVkIDY0LWJpdCBpbnRlZ2VyLlxuICogRXF1aXZhbGVudCB0byBgMm4qKjY0biAtIDFuYFxuICovXG5leHBvcnQgY29uc3QgTWF4VWludDY0ID0gMTg0NDY3NDQwNzM3MDk1NTE2MTVuO1xuLyoqXG4gKiBUaGUgbWF4aW11bSBsZW5ndGgsIGluIGJ5dGVzLCBvZiBhIFZhcmludCBlbmNvZGVkIDY0LWJpdCBpbnRlZ2VyLlxuICovXG5leHBvcnQgY29uc3QgTWF4VmFyaW50TGVuNjQgPSAxMDtcbi8qKlxuICogVGhlIG1heGltdW0gbGVuZ3RoLCBpbiBieXRlcywgb2YgYSBWYXJpbnQgZW5jb2RlZCAzMi1iaXQgaW50ZWdlci5cbiAqL1xuZXhwb3J0IGNvbnN0IE1heFZhcmludExlbjMyID0gNTtcbmNvbnN0IE1TQiA9IDB4ODA7XG5jb25zdCBSRVNUID0gMHg3ZjtcbmNvbnN0IFNISUZUID0gNztcbmNvbnN0IE1TQk4gPSAweDgwbjtcbmNvbnN0IFNISUZUTiA9IDduO1xuLy8gQXJyYXlCdWZmZXIgYW5kIFR5cGVkQXJyYXkncyBmb3IgXCJwb2ludGVyIGNhc3RpbmdcIlxuY29uc3QgQUIgPSBuZXcgQXJyYXlCdWZmZXIoOCk7XG5jb25zdCBVMzJfVklFVyA9IG5ldyBVaW50MzJBcnJheShBQik7XG5jb25zdCBVNjRfVklFVyA9IG5ldyBCaWdVaW50NjRBcnJheShBQik7XG4vKipcbiAqIEdpdmVuIGEgbm9uIGVtcHR5IGBidWZgLCBzdGFydGluZyBhdCBgb2Zmc2V0YCAoZGVmYXVsdDogMCksIGJlZ2luIGRlY29kaW5nIGJ5dGVzIGFzXG4gKiBWYXJpbnQgZW5jb2RlZCBieXRlcywgZm9yIGEgbWF4aW11bSBvZiAxMCBieXRlcyAob2Zmc2V0ICsgMTApLiBUaGUgcmV0dXJuZWRcbiAqIHR1cGxlIGlzIG9mIHRoZSBkZWNvZGVkIHZhcmludCAzMi1iaXQgbnVtYmVyLCBhbmQgdGhlIG5ldyBvZmZzZXQgd2l0aCB3aGljaFxuICogdG8gY29udGludWUgZGVjb2Rpbmcgb3RoZXIgZGF0YS5cbiAqXG4gKiBJZiBhIGBiaWdpbnRgIGluIHJldHVybiBpcyB1bmRlc2lyZWQsIHRoZSBgZGVjb2RlMzJgIGZ1bmN0aW9uIHdpbGwgcmV0dXJuIGFcbiAqIGBudW1iZXJgLCBidXQgdGhpcyBzaG91bGQgb25seSBiZSB1c2VkIGluIGNhc2VzIHdoZXJlIHRoZSB2YXJpbnQgaXNcbiAqIF9hc3N1cmVkXyB0byBiZSAzMi1iaXRzLiBJZiBpbiBkb3VidCwgdXNlIGBkZWNvZGUoKWAuXG4gKlxuICogVG8ga25vdyBob3cgbWFueSBieXRlcyB0aGUgVmFyaW50IHRvb2sgdG8gZW5jb2RlLCBzaW1wbHkgbmVnYXRlIGBvZmZzZXRgXG4gKiBmcm9tIHRoZSByZXR1cm5lZCBuZXcgYG9mZnNldGAuXG4gKlxuICogQHBhcmFtIGJ1ZiBUaGUgYnVmZmVyIHRvIGRlY29kZSBmcm9tLlxuICogQHBhcmFtIG9mZnNldCBUaGUgb2Zmc2V0IHRvIHN0YXJ0IGRlY29kaW5nIGZyb20uXG4gKiBAcmV0dXJucyBBIHR1cGxlIG9mIHRoZSBkZWNvZGVkIHZhcmludCA2NC1iaXQgbnVtYmVyLCBhbmQgdGhlIG5ldyBvZmZzZXQuXG4gKlxuICogQGV4YW1wbGUgVXNhZ2VcbiAqIGBgYHRzXG4gKiBpbXBvcnQgeyBkZWNvZGVWYXJpbnQgfSBmcm9tIFwiQHN0ZC9lbmNvZGluZy92YXJpbnRcIjtcbiAqIGltcG9ydCB7IGFzc2VydEVxdWFscyB9IGZyb20gXCJAc3RkL2Fzc2VydFwiO1xuICpcbiAqIGNvbnN0IGJ1ZiA9IG5ldyBVaW50OEFycmF5KFsweDhFLCAweDAyXSk7XG4gKiBhc3NlcnRFcXVhbHMoZGVjb2RlVmFyaW50KGJ1ZiksIFsyNzBuLCAyXSk7XG4gKiBgYGBcbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIGRlY29kZVZhcmludChidWYsIG9mZnNldCA9IDApIHtcbiAgICAvLyBDbGVhciB0aGUgbGFzdCByZXN1bHQgZnJvbSB0aGUgVHdvJ3MgY29tcGxlbWVudCB2aWV3XG4gICAgVTY0X1ZJRVdbMF0gPSAwbjtcbiAgICAvLyBTZXR1cCB0aGUgaW5pdGlhdCBzdGF0ZSBvZiB0aGUgZnVuY3Rpb25cbiAgICBsZXQgaW50ZXJtZWRpYXRlID0gMDtcbiAgICBsZXQgcG9zaXRpb24gPSAwO1xuICAgIGxldCBpID0gb2Zmc2V0O1xuICAgIC8vIElmIHRoZSBidWZmZXIgaXMgZW1wdHkgVGhyb3dcbiAgICBpZiAoYnVmLmxlbmd0aCA9PT0gMClcbiAgICAgICAgdGhyb3cgbmV3IFJhbmdlRXJyb3IoXCJDYW5ub3QgcmVhZCBlbXB0eSBidWZmZXJcIik7XG4gICAgbGV0IGJ5dGU7XG4gICAgZG8ge1xuICAgICAgICAvLyBHZXQgYSBzaW5nbGUgYnl0ZSBmcm9tIHRoZSBidWZmZXJcbiAgICAgICAgYnl0ZSA9IGJ1ZltpXTtcbiAgICAgICAgLy8gMS4gVGFrZSB0aGUgbG93ZXIgNyBiaXRzIG9mIHRoZSBieXRlLlxuICAgICAgICAvLyAyLiBTaGlmdCB0aGUgYml0cyBpbnRvIHRoZSBjb3JyZWN0IHBvc2l0aW9uLlxuICAgICAgICAvLyAzLiBCaXR3aXNlIE9SIGl0IHdpdGggdGhlIGludGVybWVkaWF0ZSB2YWx1ZVxuICAgICAgICAvLyBRVUlSSzogaW4gdGhlIDV0aCAoYW5kIDEwdGgpIGl0ZXJhdGlvbiBvZiB0aGlzIGxvb3AgaXQgd2lsbCBvdmVyZmxvdyBvbiB0aGUgc2hpZnQuXG4gICAgICAgIC8vIFRoaXMgY2F1c2VzIG9ubHkgdGhlIGxvd2VyIDQgYml0cyB0byBiZSBzaGlmdGVkIGludG8gcGxhY2UgYW5kIHJlbW92aW5nIHRoZSB1cHBlciAzIGJpdHNcbiAgICAgICAgaW50ZXJtZWRpYXRlIHw9IChieXRlICYgMGIwMTExMTExMSkgPDwgcG9zaXRpb247XG4gICAgICAgIC8vIElmIHBvc2l0aW9uIGlzIDI4XG4gICAgICAgIC8vIGl0IG1lYW5zIHRoYXQgdGhpcyBpdGVyYXRpb24gbmVlZHMgdG8gYmUgd3JpdHRlbiB0aGUgdGhlIHR3bydzIGNvbXBsZW1lbnQgdmlld1xuICAgICAgICAvLyBUaGlzIG9ubHkgaGFwcGVucyBvbmNlIGR1ZSB0byB0aGUgYC00YCBpbiB0aGlzIGJyYW5jaFxuICAgICAgICBpZiAocG9zaXRpb24gPT09IDI4KSB7XG4gICAgICAgICAgICAvLyBXcml0ZSB0byB0aGUgdmlld1xuICAgICAgICAgICAgVTMyX1ZJRVdbMF0gPSBpbnRlcm1lZGlhdGU7XG4gICAgICAgICAgICAvLyBzZXQgYGludGVybWVkaWF0ZWAgdG8gdGhlIHJlbWFpbmluZyAzIGJpdHNcbiAgICAgICAgICAgIC8vIFdlIG9ubHkgd2FudCB0aGUgcmVtYWluaW5nIHRocmVlIGJpdHMgYmVjYXVzZSB0aGUgb3RoZXIgNCBoYXZlIGJlZW4gXCJjb25zdW1lZFwiIG9uIGxpbmUgMjFcbiAgICAgICAgICAgIGludGVybWVkaWF0ZSA9IChieXRlICYgMGIwMTExMDAwMCkgPj4+IDQ7XG4gICAgICAgICAgICAvLyBzZXQgYHBvc2l0aW9uYCB0byAtNCBiZWNhdXNlIGxhdGVyIDcgd2lsbCBiZSBhZGRlZCwgbWFraW5nIGl0IDNcbiAgICAgICAgICAgIHBvc2l0aW9uID0gLTQ7XG4gICAgICAgIH1cbiAgICAgICAgLy8gSW5jcmVtZW50IHRoZSBzaGlmdCBwb3NpdGlvbiBieSA3XG4gICAgICAgIHBvc2l0aW9uICs9IDc7XG4gICAgICAgIC8vIEluY3JlbWVudCB0aGUgaXRlcmF0b3IgYnkgMVxuICAgICAgICBpKys7XG4gICAgICAgIC8vIEtlZXAgZ29pbmcgd2hpbGUgdGhlcmUgaXMgYSBjb250aW51YXRpb24gYml0XG4gICAgfSB3aGlsZSAoKGJ5dGUgJiAwYjEwMDAwMDAwKSA9PT0gMGIxMDAwMDAwMCk7XG4gICAgLy8gc3VidHJhY3QgdGhlIGluaXRpYWwgb2Zmc2V0IGZyb20gYGlgIHRvIGdldCB0aGUgYnl0ZXMgcmVhZFxuICAgIGNvbnN0IG5SZWFkID0gaSAtIG9mZnNldDtcbiAgICAvLyBJZiAxMCBieXRlcyBoYXZlIGJlZW4gcmVhZCBhbmQgaW50ZXJtZWRpYXRlIGhhcyBvdmVyZmxvd25cbiAgICAvLyBpdCBtZWFucyB0aGF0IHRoZSB2YXJpbnQgaXMgbWFsZm9ybWVkXG4gICAgLy8gSWYgMTEgYnl0ZXMgaGF2ZSBiZWVuIHJlYWQgaXQgbWVhbnMgdGhhdCB0aGUgdmFyaW50IGlzIG1hbGZvcm1lZFxuICAgIC8vIElmIGBpYCBpcyBiaWdnZXIgdGhhbiB0aGUgYnVmZmVyIGl0IG1lYW5zIHdlIG92ZXJyZWFkIHRoZSBidWZmZXIgYW5kIHRoZSB2YXJpbnQgaXMgbWFsZm9ybWVkXG4gICAgaWYgKChuUmVhZCA9PT0gMTAgJiYgaW50ZXJtZWRpYXRlID4gLTEpIHx8IG5SZWFkID09PSAxMSB8fCBpID4gYnVmLmxlbmd0aCkge1xuICAgICAgICB0aHJvdyBuZXcgUmFuZ2VFcnJvcihcIkNhbm5vdCBkZWNvZGUgdGhlIHZhcmludCBpbnB1dDogTWFsZm9ybWVkIG9yIG92ZXJmbG93IHZhcmludFwiKTtcbiAgICB9XG4gICAgLy8gV3JpdGUgdGhlIGludGVybWVkaWF0ZSB2YWx1ZSB0byB0aGUgXCJlbXB0eVwiIHNsb3RcbiAgICAvLyBpZiB0aGUgZmlyc3Qgc2xvdCBpcyB0YWtlbi4gVGFrZSB0aGUgc2Vjb25kIHNsb3RcbiAgICBVMzJfVklFV1tOdW1iZXIoblJlYWQgPiA0KV0gPSBpbnRlcm1lZGlhdGU7XG4gICAgcmV0dXJuIFtVNjRfVklFV1swXSwgaV07XG59XG4vKipcbiAqIEdpdmVuIGEgYGJ1ZmAsIHN0YXJ0aW5nIGF0IGBvZmZzZXRgIChkZWZhdWx0OiAwKSwgYmVnaW4gZGVjb2RpbmcgYnl0ZXMgYXNcbiAqIFZhcmludCBlbmNvZGVkIGJ5dGVzLCBmb3IgYSBtYXhpbXVtIG9mIDUgYnl0ZXMgKG9mZnNldCArIDUpLiBUaGUgcmV0dXJuZWRcbiAqIHR1cGxlIGlzIG9mIHRoZSBkZWNvZGVkIHZhcmludCAzMi1iaXQgbnVtYmVyLCBhbmQgdGhlIG5ldyBvZmZzZXQgd2l0aCB3aGljaFxuICogdG8gY29udGludWUgZGVjb2Rpbmcgb3RoZXIgZGF0YS5cbiAqXG4gKiBWYXJpbnRzIGFyZSBfbm90IDMyLWJpdCBieSBkZWZhdWx0XyBzbyB0aGlzIHNob3VsZCBvbmx5IGJlIHVzZWQgaW4gY2FzZXNcbiAqIHdoZXJlIHRoZSB2YXJpbnQgaXMgX2Fzc3VyZWRfIHRvIGJlIDMyLWJpdHMuIElmIGluIGRvdWJ0LCB1c2UgYGRlY29kZSgpYC5cbiAqXG4gKiBUbyBrbm93IGhvdyBtYW55IGJ5dGVzIHRoZSBWYXJpbnQgdG9vayB0byBlbmNvZGUsIHNpbXBseSBuZWdhdGUgYG9mZnNldGBcbiAqIGZyb20gdGhlIHJldHVybmVkIG5ldyBgb2Zmc2V0YC5cbiAqXG4gKiBAcGFyYW0gYnVmIFRoZSBidWZmZXIgdG8gZGVjb2RlIGZyb20uXG4gKiBAcGFyYW0gb2Zmc2V0IFRoZSBvZmZzZXQgdG8gc3RhcnQgZGVjb2RpbmcgZnJvbS5cbiAqIEByZXR1cm5zIEEgdHVwbGUgb2YgdGhlIGRlY29kZWQgdmFyaW50IDMyLWJpdCBudW1iZXIsIGFuZCB0aGUgbmV3IG9mZnNldC5cbiAqXG4gKiBAZXhhbXBsZSBVc2FnZVxuICogYGBgdHNcbiAqIGltcG9ydCB7IGRlY29kZVZhcmludDMyIH0gZnJvbSBcIkBzdGQvZW5jb2RpbmcvdmFyaW50XCI7XG4gKiBpbXBvcnQgeyBhc3NlcnRFcXVhbHMgfSBmcm9tIFwiQHN0ZC9hc3NlcnRcIjtcbiAqXG4gKiBjb25zdCBidWYgPSBuZXcgVWludDhBcnJheShbMHg4RSwgMHgwMl0pO1xuICogYXNzZXJ0RXF1YWxzKGRlY29kZVZhcmludDMyKGJ1ZiksIFsyNzAsIDJdKTtcbiAqIGBgYFxuICovXG5leHBvcnQgZnVuY3Rpb24gZGVjb2RlVmFyaW50MzIoYnVmLCBvZmZzZXQgPSAwKSB7XG4gICAgbGV0IHNoaWZ0ID0gMDtcbiAgICBsZXQgZGVjb2RlZCA9IDA7XG4gICAgZm9yIChsZXQgaSA9IG9mZnNldDsgaSA8PSBNYXRoLm1pbihidWYubGVuZ3RoLCBvZmZzZXQgKyBNYXhWYXJpbnRMZW4zMik7IGkgKz0gMSwgc2hpZnQgKz0gU0hJRlQpIHtcbiAgICAgICAgY29uc3QgYnl0ZSA9IGJ1ZltpXTtcbiAgICAgICAgZGVjb2RlZCArPSAoYnl0ZSAmIFJFU1QpICogTWF0aC5wb3coMiwgc2hpZnQpO1xuICAgICAgICBpZiAoIShieXRlICYgTVNCKSlcbiAgICAgICAgICAgIHJldHVybiBbZGVjb2RlZCwgaSArIDFdO1xuICAgIH1cbiAgICB0aHJvdyBuZXcgUmFuZ2VFcnJvcihcIkNhbm5vdCBkZWNvZGUgdGhlIHZhcmludCBpbnB1dDogTWFsZm9ybWVkIG9yIG92ZXJmbG93IHZhcmludFwiKTtcbn1cbi8qKlxuICogVGFrZXMgdW5zaWduZWQgbnVtYmVyIGBudW1gIGFuZCBjb252ZXJ0cyBpdCBpbnRvIGEgVmFyaW50IGVuY29kZWRcbiAqIGBVaW50OEFycmF5YCwgcmV0dXJuaW5nIGEgdHVwbGUgY29uc2lzdGluZyBvZiBhIGBVaW50OEFycmF5YCBzbGljZSBvZiB0aGVcbiAqIGVuY29kZWQgVmFyaW50LCBhbmQgYW4gb2Zmc2V0IHdoZXJlIHRoZSBWYXJpbnQgZW5jb2RlZCBieXRlcyBlbmQgd2l0aGluIHRoZVxuICogYFVpbnQ4QXJyYXlgLlxuICpcbiAqIElmIGBidWZgIGlzIG5vdCBnaXZlbiB0aGVuIGEgVWludDhBcnJheSB3aWxsIGJlIGNyZWF0ZWQuXG4gKiBgb2Zmc2V0YCBkZWZhdWx0cyB0byBgMGAuXG4gKlxuICogSWYgcGFzc2VkIGBidWZgIHRoZW4gdGhhdCB3aWxsIGJlIHdyaXR0ZW4gaW50bywgc3RhcnRpbmcgYXQgYG9mZnNldGAuIFRoZVxuICogcmVzdWx0aW5nIHJldHVybmVkIGBVaW50OEFycmF5YCB3aWxsIGJlIGEgc2xpY2Ugb2YgYGJ1ZmAuIFRoZSByZXN1bHRpbmdcbiAqIHJldHVybmVkIG51bWJlciBpcyBlZmZlY3RpdmVseSBgb2Zmc2V0ICsgYnl0ZXNXcml0dGVuYC5cbiAqXG4gKiBAcGFyYW0gbnVtIFRoZSBudW1iZXIgdG8gZW5jb2RlLlxuICogQHBhcmFtIGJ1ZiBUaGUgYnVmZmVyIHRvIHdyaXRlIGludG8uXG4gKiBAcGFyYW0gb2Zmc2V0IFRoZSBvZmZzZXQgdG8gc3RhcnQgd3JpdGluZyBhdC5cbiAqIEByZXR1cm5zIEEgdHVwbGUgb2YgdGhlIGVuY29kZWQgVmFyaW50IGBVaW50OEFycmF5YCBhbmQgdGhlIG5ldyBvZmZzZXQuXG4gKlxuICogQGV4YW1wbGUgVXNhZ2VcbiAqIGBgYHRzXG4gKiBpbXBvcnQgeyBlbmNvZGVWYXJpbnQgfSBmcm9tIFwiQHN0ZC9lbmNvZGluZy92YXJpbnRcIjtcbiAqIGltcG9ydCB7IGFzc2VydEVxdWFscyB9IGZyb20gXCJAc3RkL2Fzc2VydFwiO1xuICpcbiAqIGNvbnN0IGJ1ZiA9IG5ldyBVaW50OEFycmF5KDEwKTtcbiAqIGFzc2VydEVxdWFscyhlbmNvZGVWYXJpbnQoNDJuLCBidWYpLCBbbmV3IFVpbnQ4QXJyYXkoWzQyXSksIDFdKTtcbiAqIGBgYFxuICovXG5leHBvcnQgZnVuY3Rpb24gZW5jb2RlVmFyaW50KG51bSwgYnVmID0gbmV3IFVpbnQ4QXJyYXkoTWF4VmFyaW50TGVuNjQpLCBvZmZzZXQgPSAwKSB7XG4gICAgbnVtID0gQmlnSW50KG51bSk7XG4gICAgaWYgKG51bSA8IDBuKSB7XG4gICAgICAgIHRocm93IG5ldyBSYW5nZUVycm9yKGBDYW5ub3QgZW5jb2RlIHRoZSBpbnB1dCBpbnRvIHZhcmludCBhcyBpdCBzaG91bGQgYmUgbm9uLW5lZ2F0aXZlIGludGVnZXI6IHJlY2VpdmVkICR7bnVtfWApO1xuICAgIH1cbiAgICBmb3IgKGxldCBpID0gb2Zmc2V0OyBpIDw9IE1hdGgubWluKGJ1Zi5sZW5ndGgsIE1heFZhcmludExlbjY0KTsgaSArPSAxKSB7XG4gICAgICAgIGlmIChudW0gPCBNU0JOKSB7XG4gICAgICAgICAgICBidWZbaV0gPSBOdW1iZXIobnVtKTtcbiAgICAgICAgICAgIGkgKz0gMTtcbiAgICAgICAgICAgIHJldHVybiBbYnVmLnNsaWNlKG9mZnNldCwgaSksIGldO1xuICAgICAgICB9XG4gICAgICAgIGJ1ZltpXSA9IE51bWJlcigobnVtICYgMHhmZm4pIHwgTVNCTik7XG4gICAgICAgIG51bSA+Pj0gU0hJRlROO1xuICAgIH1cbiAgICB0aHJvdyBuZXcgUmFuZ2VFcnJvcihgQ2Fubm90IGVuY29kZSB0aGUgaW5wdXQgJHtudW19IGludG8gdmFyaW50IGFzIGl0IG92ZXJmbG93cyB1aW50NjRgKTtcbn1cbiIsIi8qKlxuICogQ3VzdG9tIGVycm9yIHR5cGVzIGZvciB4LWNsaWVudC10cmFuc2FjdGlvbi1pZC5cbiAqL1xuY2xhc3MgQ2xpZW50VHJhbnNhY3Rpb25FcnJvciBleHRlbmRzIEVycm9yIHtcbiAgICBjb25zdHJ1Y3RvcihtZXNzYWdlLCBvcHRpb25zID0ge30pIHtcbiAgICAgICAgc3VwZXIobWVzc2FnZSwgb3B0aW9ucy5jYXVzZSA/IHsgY2F1c2U6IG9wdGlvbnMuY2F1c2UgfSA6IHVuZGVmaW5lZCk7XG4gICAgICAgIE9iamVjdC5kZWZpbmVQcm9wZXJ0eSh0aGlzLCBcImNvZGVcIiwge1xuICAgICAgICAgICAgZW51bWVyYWJsZTogdHJ1ZSxcbiAgICAgICAgICAgIGNvbmZpZ3VyYWJsZTogdHJ1ZSxcbiAgICAgICAgICAgIHdyaXRhYmxlOiB0cnVlLFxuICAgICAgICAgICAgdmFsdWU6IHZvaWQgMFxuICAgICAgICB9KTtcbiAgICAgICAgdGhpcy5uYW1lID0gbmV3LnRhcmdldC5uYW1lO1xuICAgICAgICB0aGlzLmNvZGUgPSBvcHRpb25zLmNvZGUgPz8gXCJDTElFTlRfVFJBTlNBQ1RJT05fRVJST1JcIjtcbiAgICB9XG59XG5jbGFzcyBDbGllbnRUcmFuc2FjdGlvbkluaXRpYWxpemF0aW9uRXJyb3IgZXh0ZW5kcyBDbGllbnRUcmFuc2FjdGlvbkVycm9yIHtcbiAgICBjb25zdHJ1Y3RvcihtZXNzYWdlLCBvcHRpb25zID0ge30pIHtcbiAgICAgICAgc3VwZXIobWVzc2FnZSwge1xuICAgICAgICAgICAgY29kZTogb3B0aW9ucy5jb2RlID8/IFwiQ0xJRU5UX1RSQU5TQUNUSU9OX0lOSVRJQUxJWkFUSU9OX0VSUk9SXCIsXG4gICAgICAgICAgICBjYXVzZTogb3B0aW9ucy5jYXVzZSxcbiAgICAgICAgfSk7XG4gICAgfVxufVxuY2xhc3MgT25EZW1hbmRGaWxlVXJsUmVzb2x1dGlvbkVycm9yIGV4dGVuZHMgQ2xpZW50VHJhbnNhY3Rpb25Jbml0aWFsaXphdGlvbkVycm9yIHtcbiAgICBjb25zdHJ1Y3RvcigpIHtcbiAgICAgICAgc3VwZXIoXCJVbmFibGUgdG8gcmVzb2x2ZSB0aGUgWCBvbmRlbWFuZCBjaHVuayBVUkwgZnJvbSB0aGUgaG9tZXBhZ2UgcnVudGltZS5cIiwgeyBjb2RlOiBcIk9OREVNQU5EX0ZJTEVfVVJMX1JFU09MVVRJT05fRVJST1JcIiB9KTtcbiAgICB9XG59XG5jbGFzcyBPbkRlbWFuZEZpbGVGZXRjaEVycm9yIGV4dGVuZHMgQ2xpZW50VHJhbnNhY3Rpb25Jbml0aWFsaXphdGlvbkVycm9yIHtcbiAgICBjb25zdHJ1Y3Rvcih1cmwsIHN0YXR1cywgc3RhdHVzVGV4dCkge1xuICAgICAgICBzdXBlcihgVW5hYmxlIHRvIGZldGNoIHRoZSBYIG9uZGVtYW5kIGNodW5rIGZyb20gXCIke3VybH1cIjogJHtzdGF0dXN9ICR7c3RhdHVzVGV4dH0uYCwgeyBjb2RlOiBcIk9OREVNQU5EX0ZJTEVfRkVUQ0hfRVJST1JcIiB9KTtcbiAgICAgICAgT2JqZWN0LmRlZmluZVByb3BlcnR5KHRoaXMsIFwidXJsXCIsIHtcbiAgICAgICAgICAgIGVudW1lcmFibGU6IHRydWUsXG4gICAgICAgICAgICBjb25maWd1cmFibGU6IHRydWUsXG4gICAgICAgICAgICB3cml0YWJsZTogdHJ1ZSxcbiAgICAgICAgICAgIHZhbHVlOiB2b2lkIDBcbiAgICAgICAgfSk7XG4gICAgICAgIE9iamVjdC5kZWZpbmVQcm9wZXJ0eSh0aGlzLCBcInN0YXR1c1wiLCB7XG4gICAgICAgICAgICBlbnVtZXJhYmxlOiB0cnVlLFxuICAgICAgICAgICAgY29uZmlndXJhYmxlOiB0cnVlLFxuICAgICAgICAgICAgd3JpdGFibGU6IHRydWUsXG4gICAgICAgICAgICB2YWx1ZTogdm9pZCAwXG4gICAgICAgIH0pO1xuICAgICAgICBPYmplY3QuZGVmaW5lUHJvcGVydHkodGhpcywgXCJzdGF0dXNUZXh0XCIsIHtcbiAgICAgICAgICAgIGVudW1lcmFibGU6IHRydWUsXG4gICAgICAgICAgICBjb25maWd1cmFibGU6IHRydWUsXG4gICAgICAgICAgICB3cml0YWJsZTogdHJ1ZSxcbiAgICAgICAgICAgIHZhbHVlOiB2b2lkIDBcbiAgICAgICAgfSk7XG4gICAgICAgIHRoaXMudXJsID0gdXJsO1xuICAgICAgICB0aGlzLnN0YXR1cyA9IHN0YXR1cztcbiAgICAgICAgdGhpcy5zdGF0dXNUZXh0ID0gc3RhdHVzVGV4dDtcbiAgICB9XG59XG5jbGFzcyBLZXlCeXRlSW5kaWNlc0V4dHJhY3Rpb25FcnJvciBleHRlbmRzIENsaWVudFRyYW5zYWN0aW9uSW5pdGlhbGl6YXRpb25FcnJvciB7XG4gICAgY29uc3RydWN0b3IoKSB7XG4gICAgICAgIHN1cGVyKFwiVW5hYmxlIHRvIGV4dHJhY3Qga2V5IGJ5dGUgaW5kaWNlcyBmcm9tIHRoZSBYIG9uZGVtYW5kIGNodW5rLlwiLCB7IGNvZGU6IFwiS0VZX0JZVEVfSU5ESUNFU19FWFRSQUNUSU9OX0VSUk9SXCIgfSk7XG4gICAgfVxufVxuY2xhc3MgU2l0ZVZlcmlmaWNhdGlvbktleU5vdEZvdW5kRXJyb3IgZXh0ZW5kcyBDbGllbnRUcmFuc2FjdGlvbkluaXRpYWxpemF0aW9uRXJyb3Ige1xuICAgIGNvbnN0cnVjdG9yKCkge1xuICAgICAgICBzdXBlcihcIlVuYWJsZSB0byBmaW5kIHRoZSB0d2l0dGVyLXNpdGUtdmVyaWZpY2F0aW9uIG1ldGEgdGFnIGluIHRoZSBob21lcGFnZSBkb2N1bWVudC5cIiwgeyBjb2RlOiBcIlNJVEVfVkVSSUZJQ0FUSU9OX0tFWV9OT1RfRk9VTkRfRVJST1JcIiB9KTtcbiAgICB9XG59XG5jbGFzcyBJbmRpY2VzTm90SW5pdGlhbGl6ZWRFcnJvciBleHRlbmRzIENsaWVudFRyYW5zYWN0aW9uRXJyb3Ige1xuICAgIGNvbnN0cnVjdG9yKCkge1xuICAgICAgICBzdXBlcihcIkNsaWVudFRyYW5zYWN0aW9uIGluZGljZXMgYXJlIG5vdCBpbml0aWFsaXplZC4gQ2FsbCBpbml0aWFsaXplKCkgYmVmb3JlIGdlbmVyYXRpbmcgYW5pbWF0aW9uIGRhdGEuXCIsIHsgY29kZTogXCJJTkRJQ0VTX05PVF9JTklUSUFMSVpFRF9FUlJPUlwiIH0pO1xuICAgIH1cbn1cbmNsYXNzIEFuaW1hdGlvbkZyYW1lRGF0YUVycm9yIGV4dGVuZHMgQ2xpZW50VHJhbnNhY3Rpb25Jbml0aWFsaXphdGlvbkVycm9yIHtcbiAgICBjb25zdHJ1Y3Rvcihyb3dJbmRleCkge1xuICAgICAgICBzdXBlcihgVW5hYmxlIHRvIGJ1aWxkIGFuaW1hdGlvbiBkYXRhIGZvciByb3cgJHtyb3dJbmRleH0uIFRoZSBob21lcGFnZSBhbmltYXRpb24gbWFya3VwIG1heSBoYXZlIGNoYW5nZWQuYCwgeyBjb2RlOiBcIkFOSU1BVElPTl9GUkFNRV9EQVRBX0VSUk9SXCIgfSk7XG4gICAgICAgIE9iamVjdC5kZWZpbmVQcm9wZXJ0eSh0aGlzLCBcInJvd0luZGV4XCIsIHtcbiAgICAgICAgICAgIGVudW1lcmFibGU6IHRydWUsXG4gICAgICAgICAgICBjb25maWd1cmFibGU6IHRydWUsXG4gICAgICAgICAgICB3cml0YWJsZTogdHJ1ZSxcbiAgICAgICAgICAgIHZhbHVlOiB2b2lkIDBcbiAgICAgICAgfSk7XG4gICAgICAgIHRoaXMucm93SW5kZXggPSByb3dJbmRleDtcbiAgICB9XG59XG5jbGFzcyBDbGllbnRUcmFuc2FjdGlvbk5vdEluaXRpYWxpemVkRXJyb3IgZXh0ZW5kcyBDbGllbnRUcmFuc2FjdGlvbkVycm9yIHtcbiAgICBjb25zdHJ1Y3RvcigpIHtcbiAgICAgICAgc3VwZXIoXCJDbGllbnRUcmFuc2FjdGlvbiBoYXMgbm90IGJlZW4gaW5pdGlhbGl6ZWQuIENhbGwgaW5pdGlhbGl6ZSgpIG9yIHVzZSBDbGllbnRUcmFuc2FjdGlvbi5jcmVhdGUoKSBmaXJzdC5cIiwgeyBjb2RlOiBcIkNMSUVOVF9UUkFOU0FDVElPTl9OT1RfSU5JVElBTElaRURfRVJST1JcIiB9KTtcbiAgICB9XG59XG5jbGFzcyBIYW5kbGVYTWlncmF0aW9uRXJyb3IgZXh0ZW5kcyBDbGllbnRUcmFuc2FjdGlvbkVycm9yIHtcbiAgICBjb25zdHJ1Y3RvcihtZXNzYWdlLCBvcHRpb25zID0ge30pIHtcbiAgICAgICAgc3VwZXIobWVzc2FnZSwge1xuICAgICAgICAgICAgY29kZTogb3B0aW9ucy5jb2RlID8/IFwiSEFORExFX1hfTUlHUkFUSU9OX0VSUk9SXCIsXG4gICAgICAgICAgICBjYXVzZTogb3B0aW9ucy5jYXVzZSxcbiAgICAgICAgfSk7XG4gICAgfVxufVxuY2xhc3MgWEhvbWVQYWdlRmV0Y2hFcnJvciBleHRlbmRzIEhhbmRsZVhNaWdyYXRpb25FcnJvciB7XG4gICAgY29uc3RydWN0b3Ioc3RhdHVzLCBzdGF0dXNUZXh0KSB7XG4gICAgICAgIHN1cGVyKGBVbmFibGUgdG8gZmV0Y2ggdGhlIFggaG9tZXBhZ2U6ICR7c3RhdHVzfSAke3N0YXR1c1RleHR9LmAsIHsgY29kZTogXCJYX0hPTUVQQUdFX0ZFVENIX0VSUk9SXCIgfSk7XG4gICAgICAgIE9iamVjdC5kZWZpbmVQcm9wZXJ0eSh0aGlzLCBcInN0YXR1c1wiLCB7XG4gICAgICAgICAgICBlbnVtZXJhYmxlOiB0cnVlLFxuICAgICAgICAgICAgY29uZmlndXJhYmxlOiB0cnVlLFxuICAgICAgICAgICAgd3JpdGFibGU6IHRydWUsXG4gICAgICAgICAgICB2YWx1ZTogdm9pZCAwXG4gICAgICAgIH0pO1xuICAgICAgICBPYmplY3QuZGVmaW5lUHJvcGVydHkodGhpcywgXCJzdGF0dXNUZXh0XCIsIHtcbiAgICAgICAgICAgIGVudW1lcmFibGU6IHRydWUsXG4gICAgICAgICAgICBjb25maWd1cmFibGU6IHRydWUsXG4gICAgICAgICAgICB3cml0YWJsZTogdHJ1ZSxcbiAgICAgICAgICAgIHZhbHVlOiB2b2lkIDBcbiAgICAgICAgfSk7XG4gICAgICAgIHRoaXMuc3RhdHVzID0gc3RhdHVzO1xuICAgICAgICB0aGlzLnN0YXR1c1RleHQgPSBzdGF0dXNUZXh0O1xuICAgIH1cbn1cbmNsYXNzIFhNaWdyYXRpb25SZWRpcmVjdGlvbkVycm9yIGV4dGVuZHMgSGFuZGxlWE1pZ3JhdGlvbkVycm9yIHtcbiAgICBjb25zdHJ1Y3RvcihzdGF0dXMsIHN0YXR1c1RleHQpIHtcbiAgICAgICAgc3VwZXIoYFVuYWJsZSB0byBmb2xsb3cgdGhlIFggbWlncmF0aW9uIHJlZGlyZWN0OiAke3N0YXR1c30gJHtzdGF0dXNUZXh0fS5gLCB7IGNvZGU6IFwiWF9NSUdSQVRJT05fUkVESVJFQ1RJT05fRVJST1JcIiB9KTtcbiAgICAgICAgT2JqZWN0LmRlZmluZVByb3BlcnR5KHRoaXMsIFwic3RhdHVzXCIsIHtcbiAgICAgICAgICAgIGVudW1lcmFibGU6IHRydWUsXG4gICAgICAgICAgICBjb25maWd1cmFibGU6IHRydWUsXG4gICAgICAgICAgICB3cml0YWJsZTogdHJ1ZSxcbiAgICAgICAgICAgIHZhbHVlOiB2b2lkIDBcbiAgICAgICAgfSk7XG4gICAgICAgIE9iamVjdC5kZWZpbmVQcm9wZXJ0eSh0aGlzLCBcInN0YXR1c1RleHRcIiwge1xuICAgICAgICAgICAgZW51bWVyYWJsZTogdHJ1ZSxcbiAgICAgICAgICAgIGNvbmZpZ3VyYWJsZTogdHJ1ZSxcbiAgICAgICAgICAgIHdyaXRhYmxlOiB0cnVlLFxuICAgICAgICAgICAgdmFsdWU6IHZvaWQgMFxuICAgICAgICB9KTtcbiAgICAgICAgdGhpcy5zdGF0dXMgPSBzdGF0dXM7XG4gICAgICAgIHRoaXMuc3RhdHVzVGV4dCA9IHN0YXR1c1RleHQ7XG4gICAgfVxufVxuY2xhc3MgWE1pZ3JhdGlvbkZvcm1FcnJvciBleHRlbmRzIEhhbmRsZVhNaWdyYXRpb25FcnJvciB7XG4gICAgY29uc3RydWN0b3Ioc3RhdHVzLCBzdGF0dXNUZXh0KSB7XG4gICAgICAgIHN1cGVyKGBVbmFibGUgdG8gc3VibWl0IHRoZSBYIG1pZ3JhdGlvbiBmb3JtOiAke3N0YXR1c30gJHtzdGF0dXNUZXh0fS5gLCB7IGNvZGU6IFwiWF9NSUdSQVRJT05fRk9STV9FUlJPUlwiIH0pO1xuICAgICAgICBPYmplY3QuZGVmaW5lUHJvcGVydHkodGhpcywgXCJzdGF0dXNcIiwge1xuICAgICAgICAgICAgZW51bWVyYWJsZTogdHJ1ZSxcbiAgICAgICAgICAgIGNvbmZpZ3VyYWJsZTogdHJ1ZSxcbiAgICAgICAgICAgIHdyaXRhYmxlOiB0cnVlLFxuICAgICAgICAgICAgdmFsdWU6IHZvaWQgMFxuICAgICAgICB9KTtcbiAgICAgICAgT2JqZWN0LmRlZmluZVByb3BlcnR5KHRoaXMsIFwic3RhdHVzVGV4dFwiLCB7XG4gICAgICAgICAgICBlbnVtZXJhYmxlOiB0cnVlLFxuICAgICAgICAgICAgY29uZmlndXJhYmxlOiB0cnVlLFxuICAgICAgICAgICAgd3JpdGFibGU6IHRydWUsXG4gICAgICAgICAgICB2YWx1ZTogdm9pZCAwXG4gICAgICAgIH0pO1xuICAgICAgICB0aGlzLnN0YXR1cyA9IHN0YXR1cztcbiAgICAgICAgdGhpcy5zdGF0dXNUZXh0ID0gc3RhdHVzVGV4dDtcbiAgICB9XG59XG5jbGFzcyBJbnRlcnBvbGF0aW9uSW5wdXRFcnJvciBleHRlbmRzIENsaWVudFRyYW5zYWN0aW9uRXJyb3Ige1xuICAgIGNvbnN0cnVjdG9yKGZyb21MZW5ndGgsIHRvTGVuZ3RoKSB7XG4gICAgICAgIHN1cGVyKGBJbnRlcnBvbGF0aW9uIHJlcXVpcmVzIGFycmF5cyBvZiB0aGUgc2FtZSBsZW5ndGgsIGJ1dCByZWNlaXZlZCAke2Zyb21MZW5ndGh9IGFuZCAke3RvTGVuZ3RofS5gLCB7IGNvZGU6IFwiSU5URVJQT0xBVElPTl9JTlBVVF9FUlJPUlwiIH0pO1xuICAgICAgICBPYmplY3QuZGVmaW5lUHJvcGVydHkodGhpcywgXCJmcm9tTGVuZ3RoXCIsIHtcbiAgICAgICAgICAgIGVudW1lcmFibGU6IHRydWUsXG4gICAgICAgICAgICBjb25maWd1cmFibGU6IHRydWUsXG4gICAgICAgICAgICB3cml0YWJsZTogdHJ1ZSxcbiAgICAgICAgICAgIHZhbHVlOiB2b2lkIDBcbiAgICAgICAgfSk7XG4gICAgICAgIE9iamVjdC5kZWZpbmVQcm9wZXJ0eSh0aGlzLCBcInRvTGVuZ3RoXCIsIHtcbiAgICAgICAgICAgIGVudW1lcmFibGU6IHRydWUsXG4gICAgICAgICAgICBjb25maWd1cmFibGU6IHRydWUsXG4gICAgICAgICAgICB3cml0YWJsZTogdHJ1ZSxcbiAgICAgICAgICAgIHZhbHVlOiB2b2lkIDBcbiAgICAgICAgfSk7XG4gICAgICAgIHRoaXMuZnJvbUxlbmd0aCA9IGZyb21MZW5ndGg7XG4gICAgICAgIHRoaXMudG9MZW5ndGggPSB0b0xlbmd0aDtcbiAgICB9XG59XG5leHBvcnQgeyBBbmltYXRpb25GcmFtZURhdGFFcnJvciwgQ2xpZW50VHJhbnNhY3Rpb25FcnJvciwgQ2xpZW50VHJhbnNhY3Rpb25Jbml0aWFsaXphdGlvbkVycm9yLCBDbGllbnRUcmFuc2FjdGlvbk5vdEluaXRpYWxpemVkRXJyb3IsIEhhbmRsZVhNaWdyYXRpb25FcnJvciwgSW5kaWNlc05vdEluaXRpYWxpemVkRXJyb3IsIEludGVycG9sYXRpb25JbnB1dEVycm9yLCBLZXlCeXRlSW5kaWNlc0V4dHJhY3Rpb25FcnJvciwgT25EZW1hbmRGaWxlRmV0Y2hFcnJvciwgT25EZW1hbmRGaWxlVXJsUmVzb2x1dGlvbkVycm9yLCBTaXRlVmVyaWZpY2F0aW9uS2V5Tm90Rm91bmRFcnJvciwgWEhvbWVQYWdlRmV0Y2hFcnJvciwgWE1pZ3JhdGlvbkZvcm1FcnJvciwgWE1pZ3JhdGlvblJlZGlyZWN0aW9uRXJyb3IsIH07XG4iLCIvKipcbiAqIEludGVycG9sYXRpb24gdXRpbGl0eSBmdW5jdGlvbnNcbiAqXG4gKiBUaGlzIG1vZHVsZSBwcm92aWRlcyBmdW5jdGlvbnMgZm9yIGludGVycG9sYXRpbmcgYmV0d2VlbiB2YWx1ZXMsXG4gKiB1c2VkIGluIHRoZSBhbmltYXRpb24ga2V5IGdlbmVyYXRpb24gcHJvY2Vzcy5cbiAqL1xuLyoqXG4gKiBJbnRlcnBvbGF0ZXMgYmV0d2VlbiB0d28gYXJyYXlzIG9mIG51bWJlcnNcbiAqIEBwYXJhbSBmcm9tTGlzdCBTdGFydGluZyB2YWx1ZXNcbiAqIEBwYXJhbSB0b0xpc3QgRW5kaW5nIHZhbHVlc1xuICogQHBhcmFtIGYgSW50ZXJwb2xhdGlvbiBmYWN0b3IgKDAuMCB0byAxLjApXG4gKiBAcmV0dXJucyBBcnJheSBvZiBpbnRlcnBvbGF0ZWQgdmFsdWVzXG4gKi9cbmltcG9ydCB7IEludGVycG9sYXRpb25JbnB1dEVycm9yIH0gZnJvbSBcIi4vZXJyb3JzLmpzXCI7XG5mdW5jdGlvbiBpbnRlcnBvbGF0ZShmcm9tTGlzdCwgdG9MaXN0LCBmKSB7XG4gICAgaWYgKGZyb21MaXN0Lmxlbmd0aCAhPT0gdG9MaXN0Lmxlbmd0aCkge1xuICAgICAgICB0aHJvdyBuZXcgSW50ZXJwb2xhdGlvbklucHV0RXJyb3IoZnJvbUxpc3QubGVuZ3RoLCB0b0xpc3QubGVuZ3RoKTtcbiAgICB9XG4gICAgY29uc3Qgb3V0ID0gW107XG4gICAgZm9yIChsZXQgaSA9IDA7IGkgPCBmcm9tTGlzdC5sZW5ndGg7IGkrKykge1xuICAgICAgICBvdXQucHVzaChpbnRlcnBvbGF0ZU51bShmcm9tTGlzdFtpXSwgdG9MaXN0W2ldLCBmKSk7XG4gICAgfVxuICAgIHJldHVybiBvdXQ7XG59XG4vKipcbiAqIEludGVycG9sYXRlcyBiZXR3ZWVuIHR3byB2YWx1ZXMgKG51bWVyaWMgb3IgYm9vbGVhbilcbiAqIEBwYXJhbSBmcm9tVmFsIFN0YXJ0aW5nIHZhbHVlXG4gKiBAcGFyYW0gdG9WYWwgRW5kaW5nIHZhbHVlXG4gKiBAcGFyYW0gZiBJbnRlcnBvbGF0aW9uIGZhY3RvciAoMC4wIHRvIDEuMClcbiAqIEByZXR1cm5zIEludGVycG9sYXRlZCB2YWx1ZVxuICovXG5mdW5jdGlvbiBpbnRlcnBvbGF0ZU51bShmcm9tVmFsLCB0b1ZhbCwgZikge1xuICAgIGlmICh0eXBlb2YgZnJvbVZhbCA9PT0gXCJudW1iZXJcIiAmJiB0eXBlb2YgdG9WYWwgPT09IFwibnVtYmVyXCIpIHtcbiAgICAgICAgcmV0dXJuIGZyb21WYWwgKiAoMSAtIGYpICsgdG9WYWwgKiBmO1xuICAgIH1cbiAgICBpZiAodHlwZW9mIGZyb21WYWwgPT09IFwiYm9vbGVhblwiICYmIHR5cGVvZiB0b1ZhbCA9PT0gXCJib29sZWFuXCIpIHtcbiAgICAgICAgcmV0dXJuIGYgPCAwLjUgPyAoZnJvbVZhbCA/IDEgOiAwKSA6IHRvVmFsID8gMSA6IDA7XG4gICAgfVxuICAgIHJldHVybiAwO1xufVxuZXhwb3J0IHsgaW50ZXJwb2xhdGUsIGludGVycG9sYXRlTnVtIH07XG4iLCIvKipcbiAqIEBsYW1pL3gtY2xpZW50LXRyYW5zYWN0aW9uLWlkXG4gKlxuICogQSBsaWJyYXJ5IGZvciBnZW5lcmF0aW5nIGNsaWVudCB0cmFuc2FjdGlvbiBJRHMgcmVxdWlyZWQgZm9yXG4gKiBhdXRoZW50aWNhdGVkIEFQSSByZXF1ZXN0cyB0byBYIChmb3JtZXJseSBUd2l0dGVyKS5cbiAqXG4gKiBUaGlzIG1vZHVsZSBleHBvcnRzIHRoZSBtYWluIENsaWVudFRyYW5zYWN0aW9uIGNsYXNzIGFuZCB1dGlsaXR5IGZ1bmN0aW9uc1xuICogbmVlZGVkIHRvIGdlbmVyYXRlIHZhbGlkIHgtY2xpZW50LXRyYW5zYWN0aW9uLWlkIGhlYWRlcnMgZm9yIFggQVBJIHJlcXVlc3RzLlxuICpcbiAqIEBtb2R1bGVcbiAqL1xuaW1wb3J0IFwiLi9fZG50LnBvbHlmaWxscy5qc1wiO1xuaW1wb3J0IENsaWVudFRyYW5zYWN0aW9uIGZyb20gXCIuL3RyYW5zYWN0aW9uLmpzXCI7XG5pbXBvcnQgQ3ViaWMgZnJvbSBcIi4vY3ViaWMuanNcIjtcbmltcG9ydCB7IEFuaW1hdGlvbkZyYW1lRGF0YUVycm9yLCBDbGllbnRUcmFuc2FjdGlvbkVycm9yLCBDbGllbnRUcmFuc2FjdGlvbkluaXRpYWxpemF0aW9uRXJyb3IsIENsaWVudFRyYW5zYWN0aW9uTm90SW5pdGlhbGl6ZWRFcnJvciwgSGFuZGxlWE1pZ3JhdGlvbkVycm9yLCBJbmRpY2VzTm90SW5pdGlhbGl6ZWRFcnJvciwgSW50ZXJwb2xhdGlvbklucHV0RXJyb3IsIEtleUJ5dGVJbmRpY2VzRXh0cmFjdGlvbkVycm9yLCBPbkRlbWFuZEZpbGVGZXRjaEVycm9yLCBPbkRlbWFuZEZpbGVVcmxSZXNvbHV0aW9uRXJyb3IsIFNpdGVWZXJpZmljYXRpb25LZXlOb3RGb3VuZEVycm9yLCBYSG9tZVBhZ2VGZXRjaEVycm9yLCBYTWlncmF0aW9uRm9ybUVycm9yLCBYTWlncmF0aW9uUmVkaXJlY3Rpb25FcnJvciwgfSBmcm9tIFwiLi9lcnJvcnMuanNcIjtcbmltcG9ydCB7IGludGVycG9sYXRlLCBpbnRlcnBvbGF0ZU51bSB9IGZyb20gXCIuL2ludGVycG9sYXRlLmpzXCI7XG5pbXBvcnQgeyBjb252ZXJ0Um90YXRpb25Ub01hdHJpeCB9IGZyb20gXCIuL3JvdGF0aW9uLmpzXCI7XG5pbXBvcnQgeyBmbG9hdFRvSGV4LCBoYW5kbGVYTWlncmF0aW9uLCBpc09kZCB9IGZyb20gXCIuL3V0aWxzLmpzXCI7XG5pbXBvcnQgeyBkZWNvZGVCYXNlNjQsIGVuY29kZUJhc2U2NCB9IGZyb20gXCIuL2RlcHMvanNyLmlvL0BzdGQvZW5jb2RpbmcvMS4wLjEwL21vZC5qc1wiO1xuZXhwb3J0IHsgQW5pbWF0aW9uRnJhbWVEYXRhRXJyb3IsIENsaWVudFRyYW5zYWN0aW9uLCBDbGllbnRUcmFuc2FjdGlvbkVycm9yLCBDbGllbnRUcmFuc2FjdGlvbkluaXRpYWxpemF0aW9uRXJyb3IsIENsaWVudFRyYW5zYWN0aW9uTm90SW5pdGlhbGl6ZWRFcnJvciwgY29udmVydFJvdGF0aW9uVG9NYXRyaXgsIEN1YmljLCBkZWNvZGVCYXNlNjQsIGVuY29kZUJhc2U2NCwgZmxvYXRUb0hleCwgaGFuZGxlWE1pZ3JhdGlvbiwgSGFuZGxlWE1pZ3JhdGlvbkVycm9yLCBJbmRpY2VzTm90SW5pdGlhbGl6ZWRFcnJvciwgaW50ZXJwb2xhdGUsIGludGVycG9sYXRlTnVtLCBJbnRlcnBvbGF0aW9uSW5wdXRFcnJvciwgaXNPZGQsIEtleUJ5dGVJbmRpY2VzRXh0cmFjdGlvbkVycm9yLCBPbkRlbWFuZEZpbGVGZXRjaEVycm9yLCBPbkRlbWFuZEZpbGVVcmxSZXNvbHV0aW9uRXJyb3IsIFNpdGVWZXJpZmljYXRpb25LZXlOb3RGb3VuZEVycm9yLCBYSG9tZVBhZ2VGZXRjaEVycm9yLCBYTWlncmF0aW9uRm9ybUVycm9yLCBYTWlncmF0aW9uUmVkaXJlY3Rpb25FcnJvciwgfTtcbmV4cG9ydCBkZWZhdWx0IENsaWVudFRyYW5zYWN0aW9uO1xuIiwiLyoqXG4gKiBSb3RhdGlvbiB1dGlsaXR5IGZ1bmN0aW9uc1xuICpcbiAqIFRoaXMgbW9kdWxlIHByb3ZpZGVzIGZ1bmN0aW9ucyBmb3IgY29udmVydGluZyByb3RhdGlvbiB2YWx1ZXMgdG8gbWF0cmljZXMsXG4gKiB1c2VkIGluIHRoZSBhbmltYXRpb24ga2V5IGdlbmVyYXRpb24gcHJvY2Vzcy5cbiAqL1xuLyoqXG4gKiBDb252ZXJ0cyBhIHJvdGF0aW9uIGFuZ2xlIGluIGRlZ3JlZXMgdG8gYSAyRCB0cmFuc2Zvcm1hdGlvbiBtYXRyaXhcbiAqIEBwYXJhbSByb3RhdGlvbiBBbmdsZSBpbiBkZWdyZWVzXG4gKiBAcmV0dXJucyBBcnJheSBvZiA0IHZhbHVlcyByZXByZXNlbnRpbmcgdGhlIHRyYW5zZm9ybWF0aW9uIG1hdHJpeCBbYSwgYiwgYywgZF1cbiAqL1xuZnVuY3Rpb24gY29udmVydFJvdGF0aW9uVG9NYXRyaXgocm90YXRpb24pIHtcbiAgICBjb25zdCByYWQgPSAocm90YXRpb24gKiBNYXRoLlBJKSAvIDE4MDtcbiAgICByZXR1cm4gW01hdGguY29zKHJhZCksIC1NYXRoLnNpbihyYWQpLCBNYXRoLnNpbihyYWQpLCBNYXRoLmNvcyhyYWQpXTtcbn1cbi8qKlxuICogQWx0ZXJuYXRpdmUgaW1wbGVtZW50YXRpb24gZm9yIGNvbnZlcnRpbmcgcm90YXRpb24gdG8gbWF0cml4XG4gKiBOb3RlOiBUaGlzIGltcGxlbWVudGF0aW9uIHJldHVybnMgYSA2LXZhbHVlIG1hdHJpeCBpbiB0aGUgZm9ybWF0IFthLCBiLCBjLCBkLCB0eCwgdHldXG4gKiBAcGFyYW0gZGVncmVlcyBBbmdsZSBpbiBkZWdyZWVzXG4gKiBAcmV0dXJucyBBcnJheSBvZiA2IHZhbHVlcyByZXByZXNlbnRpbmcgdGhlIHRyYW5zZm9ybWF0aW9uIG1hdHJpeFxuICogQHByaXZhdGVcbiAqL1xuZnVuY3Rpb24gY29udmVydFJvdGF0aW9uVG9NYXRyaXgyKGRlZ3JlZXMpIHtcbiAgICAvLyBDb252ZXJ0IGRlZ3JlZXMgdG8gcmFkaWFuc1xuICAgIGNvbnN0IHJhZGlhbnMgPSAoZGVncmVlcyAqIE1hdGguUEkpIC8gMTgwO1xuICAgIC8vIENyZWF0ZSBtYXRyaXg6XG4gICAgLy8gW2NvcyhyKSwgLXNpbihyKSwgMF1cbiAgICAvLyBbc2luKHIpLCBjb3MociksIDBdXG4gICAgLy9cbiAgICAvLyBPcmRlcjpcbiAgICAvLyBbY29zKHIpLCBzaW4ociksIC1zaW4ociksIGNvcyhyKSwgMCwgMF1cbiAgICBjb25zdCBjb3MgPSBNYXRoLmNvcyhyYWRpYW5zKTtcbiAgICBjb25zdCBzaW4gPSBNYXRoLnNpbihyYWRpYW5zKTtcbiAgICByZXR1cm4gW2Nvcywgc2luLCAtc2luLCBjb3MsIDAsIDBdO1xufVxuZXhwb3J0IHsgY29udmVydFJvdGF0aW9uVG9NYXRyaXgsIGNvbnZlcnRSb3RhdGlvblRvTWF0cml4MiB9O1xuIiwiLyoqXG4gKiBDbGllbnQgVHJhbnNhY3Rpb24gSUQgR2VuZXJhdG9yIGZvciBYIChmb3JtZXJseSBUd2l0dGVyKSBBUEkgcmVxdWVzdHNcbiAqXG4gKiBUaGlzIG1vZHVsZSBwcm92aWRlcyBmdW5jdGlvbmFsaXR5IHRvIGdlbmVyYXRlIHRoZSB4LWNsaWVudC10cmFuc2FjdGlvbi1pZFxuICogaGVhZGVyIHZhbHVlIHJlcXVpcmVkIGZvciBhdXRoZW50aWNhdGVkIEFQSSByZXF1ZXN0cyB0byBYLlxuICovXG5pbXBvcnQgQ3ViaWMgZnJvbSBcIi4vY3ViaWMuanNcIjtcbmltcG9ydCB7IEFuaW1hdGlvbkZyYW1lRGF0YUVycm9yLCBDbGllbnRUcmFuc2FjdGlvbk5vdEluaXRpYWxpemVkRXJyb3IsIEluZGljZXNOb3RJbml0aWFsaXplZEVycm9yLCBLZXlCeXRlSW5kaWNlc0V4dHJhY3Rpb25FcnJvciwgT25EZW1hbmRGaWxlRmV0Y2hFcnJvciwgT25EZW1hbmRGaWxlVXJsUmVzb2x1dGlvbkVycm9yLCBTaXRlVmVyaWZpY2F0aW9uS2V5Tm90Rm91bmRFcnJvciwgfSBmcm9tIFwiLi9lcnJvcnMuanNcIjtcbmltcG9ydCB7IGludGVycG9sYXRlIH0gZnJvbSBcIi4vaW50ZXJwb2xhdGUuanNcIjtcbmltcG9ydCB7IGNvbnZlcnRSb3RhdGlvblRvTWF0cml4IH0gZnJvbSBcIi4vcm90YXRpb24uanNcIjtcbmltcG9ydCB7IGZsb2F0VG9IZXgsIGlzT2RkIH0gZnJvbSBcIi4vdXRpbHMuanNcIjtcbmltcG9ydCB7IGRlY29kZUJhc2U2NCwgZW5jb2RlQmFzZTY0IH0gZnJvbSBcIi4vZGVwcy9qc3IuaW8vQHN0ZC9lbmNvZGluZy8xLjAuMTAvbW9kLmpzXCI7XG5jb25zdCBPTl9ERU1BTkRfQ0hVTktfTkFNRSA9IFwib25kZW1hbmQuc1wiO1xuY29uc3QgSU5ESUNFU19SRUdFWCA9IC9cXChcXHdcXFsoXFxkezEsMn0pXFxdLFxccyoxNlxcKS9nO1xuY29uc3QgT05fREVNQU5EX0ZJTEVfSEFTSF9SRUdFWCA9IC8oXFxkKyk6XFxzKltcIiddb25kZW1hbmRcXC5zW1wiJ11bXFxzXFxTXSo/XFx9XFxbZVxcXVxccypcXHxcXHxcXHMqZVxcKVxccypcXCtcXHMqW1wiJ11cXC5bXCInXVxccypcXCtcXHMqXFx7W1xcc1xcU10qP1xcYlxcMTpcXHMqW1wiJ10oW2EtekEtWjAtOV8tXSspW1wiJ10vcztcbmZ1bmN0aW9uIHJlc29sdmVPbkRlbWFuZEZpbGVVcmxGcm9tUnVudGltZShydW50aW1lU291cmNlKSB7XG4gICAgY29uc3Qgb25EZW1hbmRGaWxlTWF0Y2ggPSBPTl9ERU1BTkRfRklMRV9IQVNIX1JFR0VYLmV4ZWMocnVudGltZVNvdXJjZSk7XG4gICAgaWYgKCFvbkRlbWFuZEZpbGVNYXRjaCkge1xuICAgICAgICByZXR1cm4gbnVsbDtcbiAgICB9XG4gICAgcmV0dXJuIGBodHRwczovL2Ficy50d2ltZy5jb20vcmVzcG9uc2l2ZS13ZWIvY2xpZW50LXdlYi8ke09OX0RFTUFORF9DSFVOS19OQU1FfS4ke29uRGVtYW5kRmlsZU1hdGNoWzJdfWEuanNgO1xufVxuLyoqXG4gKiBNYWluIGNsYXNzIHJlc3BvbnNpYmxlIGZvciBnZW5lcmF0aW5nIGNsaWVudCB0cmFuc2FjdGlvbiBJRHNcbiAqIHVzZWQgaW4gYXV0aGVudGljYXRlZCBBUEkgcmVxdWVzdHMgdG8gWFxuICovXG5jbGFzcyBDbGllbnRUcmFuc2FjdGlvbiB7XG4gICAgLyoqXG4gICAgICogQ3JlYXRlcyBhIG5ldyBDbGllbnRUcmFuc2FjdGlvbiBpbnN0YW5jZVxuICAgICAqIEBwYXJhbSBob21lUGFnZURvY3VtZW50IERPTSBEb2N1bWVudCBvYmplY3QgZnJvbSBYJ3MgaG9tZXBhZ2VcbiAgICAgKi9cbiAgICBjb25zdHJ1Y3Rvcihob21lUGFnZURvY3VtZW50KSB7XG4gICAgICAgIE9iamVjdC5kZWZpbmVQcm9wZXJ0eSh0aGlzLCBcIkRFRkFVTFRfUk9XX0lOREVYXCIsIHtcbiAgICAgICAgICAgIGVudW1lcmFibGU6IHRydWUsXG4gICAgICAgICAgICBjb25maWd1cmFibGU6IHRydWUsXG4gICAgICAgICAgICB3cml0YWJsZTogdHJ1ZSxcbiAgICAgICAgICAgIHZhbHVlOiBudWxsXG4gICAgICAgIH0pO1xuICAgICAgICBPYmplY3QuZGVmaW5lUHJvcGVydHkodGhpcywgXCJERUZBVUxUX0tFWV9CWVRFU19JTkRJQ0VTXCIsIHtcbiAgICAgICAgICAgIGVudW1lcmFibGU6IHRydWUsXG4gICAgICAgICAgICBjb25maWd1cmFibGU6IHRydWUsXG4gICAgICAgICAgICB3cml0YWJsZTogdHJ1ZSxcbiAgICAgICAgICAgIHZhbHVlOiBudWxsXG4gICAgICAgIH0pO1xuICAgICAgICBPYmplY3QuZGVmaW5lUHJvcGVydHkodGhpcywgXCJob21lUGFnZURvY3VtZW50XCIsIHtcbiAgICAgICAgICAgIGVudW1lcmFibGU6IHRydWUsXG4gICAgICAgICAgICBjb25maWd1cmFibGU6IHRydWUsXG4gICAgICAgICAgICB3cml0YWJsZTogdHJ1ZSxcbiAgICAgICAgICAgIHZhbHVlOiB2b2lkIDBcbiAgICAgICAgfSk7XG4gICAgICAgIE9iamVjdC5kZWZpbmVQcm9wZXJ0eSh0aGlzLCBcImtleVwiLCB7XG4gICAgICAgICAgICBlbnVtZXJhYmxlOiB0cnVlLFxuICAgICAgICAgICAgY29uZmlndXJhYmxlOiB0cnVlLFxuICAgICAgICAgICAgd3JpdGFibGU6IHRydWUsXG4gICAgICAgICAgICB2YWx1ZTogbnVsbFxuICAgICAgICB9KTtcbiAgICAgICAgT2JqZWN0LmRlZmluZVByb3BlcnR5KHRoaXMsIFwia2V5Qnl0ZXNcIiwge1xuICAgICAgICAgICAgZW51bWVyYWJsZTogdHJ1ZSxcbiAgICAgICAgICAgIGNvbmZpZ3VyYWJsZTogdHJ1ZSxcbiAgICAgICAgICAgIHdyaXRhYmxlOiB0cnVlLFxuICAgICAgICAgICAgdmFsdWU6IG51bGxcbiAgICAgICAgfSk7XG4gICAgICAgIE9iamVjdC5kZWZpbmVQcm9wZXJ0eSh0aGlzLCBcImFuaW1hdGlvbktleVwiLCB7XG4gICAgICAgICAgICBlbnVtZXJhYmxlOiB0cnVlLFxuICAgICAgICAgICAgY29uZmlndXJhYmxlOiB0cnVlLFxuICAgICAgICAgICAgd3JpdGFibGU6IHRydWUsXG4gICAgICAgICAgICB2YWx1ZTogbnVsbFxuICAgICAgICB9KTtcbiAgICAgICAgT2JqZWN0LmRlZmluZVByb3BlcnR5KHRoaXMsIFwiaXNJbml0aWFsaXplZFwiLCB7XG4gICAgICAgICAgICBlbnVtZXJhYmxlOiB0cnVlLFxuICAgICAgICAgICAgY29uZmlndXJhYmxlOiB0cnVlLFxuICAgICAgICAgICAgd3JpdGFibGU6IHRydWUsXG4gICAgICAgICAgICB2YWx1ZTogZmFsc2VcbiAgICAgICAgfSk7XG4gICAgICAgIHRoaXMuaG9tZVBhZ2VEb2N1bWVudCA9IGhvbWVQYWdlRG9jdW1lbnQ7XG4gICAgfVxuICAgIC8qKlxuICAgICAqIEluaXRpYWxpemVzIHRoZSBDbGllbnRUcmFuc2FjdGlvbiBpbnN0YW5jZVxuICAgICAqIE11c3QgYmUgY2FsbGVkIGFmdGVyIGNvbnN0cnVjdG9yIGFuZCBiZWZvcmUgdXNpbmcgb3RoZXIgbWV0aG9kc1xuICAgICAqIEByZXR1cm5zIFByb21pc2UgdGhhdCByZXNvbHZlcyB3aGVuIGluaXRpYWxpemF0aW9uIGlzIGNvbXBsZXRlXG4gICAgICogQHRocm93cyBFcnJvciBpZiBpbml0aWFsaXphdGlvbiBmYWlsc1xuICAgICAqL1xuICAgIGFzeW5jIGluaXRpYWxpemUoKSB7XG4gICAgICAgIGlmICh0aGlzLmlzSW5pdGlhbGl6ZWQpXG4gICAgICAgICAgICByZXR1cm47XG4gICAgICAgIC8vIEluaXRpYWxpemUgaW5kaWNlc1xuICAgICAgICBbdGhpcy5ERUZBVUxUX1JPV19JTkRFWCwgdGhpcy5ERUZBVUxUX0tFWV9CWVRFU19JTkRJQ0VTXSA9IGF3YWl0IHRoaXNcbiAgICAgICAgICAgIC5nZXRJbmRpY2VzKHRoaXMuaG9tZVBhZ2VEb2N1bWVudCk7XG4gICAgICAgIC8vIEdldCBrZXkgZnJvbSBkb2N1bWVudFxuICAgICAgICB0aGlzLmtleSA9IHRoaXMuZ2V0S2V5KHRoaXMuaG9tZVBhZ2VEb2N1bWVudCk7XG4gICAgICAgIC8vIENvbnZlcnQga2V5IHRvIGJ5dGUgYXJyYXlcbiAgICAgICAgdGhpcy5rZXlCeXRlcyA9IHRoaXMuZ2V0S2V5Qnl0ZXModGhpcy5rZXkpO1xuICAgICAgICAvLyBHZW5lcmF0ZSBhbmltYXRpb24ga2V5XG4gICAgICAgIHRoaXMuYW5pbWF0aW9uS2V5ID0gdGhpcy5nZXRBbmltYXRpb25LZXkodGhpcy5rZXlCeXRlcywgdGhpcy5ob21lUGFnZURvY3VtZW50KTtcbiAgICAgICAgLy8gTWFyayBpbml0aWFsaXphdGlvbiBhcyBjb21wbGV0ZVxuICAgICAgICB0aGlzLmlzSW5pdGlhbGl6ZWQgPSB0cnVlO1xuICAgIH1cbiAgICAvKipcbiAgICAgKiBTdGF0aWMgZmFjdG9yeSBtZXRob2QgdGhhdCBjcmVhdGVzIGFuZCBpbml0aWFsaXplcyBhIENsaWVudFRyYW5zYWN0aW9uIGluc3RhbmNlXG4gICAgICogQHBhcmFtIGhvbWVQYWdlRG9jdW1lbnQgRE9NIERvY3VtZW50IG9iamVjdCBmcm9tIFgncyBob21lcGFnZVxuICAgICAqIEByZXR1cm5zIEluaXRpYWxpemVkIENsaWVudFRyYW5zYWN0aW9uIGluc3RhbmNlXG4gICAgICovXG4gICAgc3RhdGljIGFzeW5jIGNyZWF0ZShob21lUGFnZURvY3VtZW50KSB7XG4gICAgICAgIGNvbnN0IGluc3RhbmNlID0gbmV3IENsaWVudFRyYW5zYWN0aW9uKGhvbWVQYWdlRG9jdW1lbnQpO1xuICAgICAgICBhd2FpdCBpbnN0YW5jZS5pbml0aWFsaXplKCk7XG4gICAgICAgIHJldHVybiBpbnN0YW5jZTtcbiAgICB9XG4gICAgLyoqXG4gICAgICogRXh0cmFjdHMga2V5IGJ5dGUgaW5kaWNlcyBmcm9tIGhvbWVwYWdlIGRvY3VtZW50XG4gICAgICogQHBhcmFtIGhvbWVQYWdlRG9jdW1lbnQgT3B0aW9uYWwgZG9jdW1lbnQgdG8gdXNlIGluc3RlYWQgb2Ygc3RvcmVkIG9uZVxuICAgICAqIEByZXR1cm5zIFR1cGxlIG9mIFtyb3dJbmRleCwga2V5Qnl0ZUluZGljZXNdXG4gICAgICogQHByaXZhdGVcbiAgICAgKi9cbiAgICBhc3luYyBnZXRJbmRpY2VzKGhvbWVQYWdlRG9jdW1lbnQpIHtcbiAgICAgICAgY29uc3Qga2V5Qnl0ZUluZGljZXMgPSBbXTtcbiAgICAgICAgY29uc3QgcmVzcG9uc2UgPSBob21lUGFnZURvY3VtZW50IHx8IHRoaXMuaG9tZVBhZ2VEb2N1bWVudDtcbiAgICAgICAgY29uc3Qgb25EZW1hbmRGaWxlVXJsID0gdGhpcy5nZXRPbkRlbWFuZEZpbGVVcmwocmVzcG9uc2UpO1xuICAgICAgICBjb25zdCBvbkRlbWFuZEZpbGVSZXNwb25zZSA9IGF3YWl0IGZldGNoKG9uRGVtYW5kRmlsZVVybCk7XG4gICAgICAgIGlmICghb25EZW1hbmRGaWxlUmVzcG9uc2Uub2spIHtcbiAgICAgICAgICAgIHRocm93IG5ldyBPbkRlbWFuZEZpbGVGZXRjaEVycm9yKG9uRGVtYW5kRmlsZVVybCwgb25EZW1hbmRGaWxlUmVzcG9uc2Uuc3RhdHVzLCBvbkRlbWFuZEZpbGVSZXNwb25zZS5zdGF0dXNUZXh0KTtcbiAgICAgICAgfVxuICAgICAgICBjb25zdCByZXNwb25zZVRleHQgPSBhd2FpdCBvbkRlbWFuZEZpbGVSZXNwb25zZS50ZXh0KCk7XG4gICAgICAgIC8vIEV4dHJhY3QgaW5kaWNlcyB1c2luZyByZWdleFxuICAgICAgICBsZXQgbWF0Y2g7XG4gICAgICAgIElORElDRVNfUkVHRVgubGFzdEluZGV4ID0gMDsgLy8gUmVzZXQgcmVnZXggaW5kZXhcbiAgICAgICAgd2hpbGUgKChtYXRjaCA9IElORElDRVNfUkVHRVguZXhlYyhyZXNwb25zZVRleHQpKSAhPT0gbnVsbCkge1xuICAgICAgICAgICAga2V5Qnl0ZUluZGljZXMucHVzaChtYXRjaFsxXSk7XG4gICAgICAgIH1cbiAgICAgICAgaWYgKCFrZXlCeXRlSW5kaWNlcy5sZW5ndGgpIHtcbiAgICAgICAgICAgIHRocm93IG5ldyBLZXlCeXRlSW5kaWNlc0V4dHJhY3Rpb25FcnJvcigpO1xuICAgICAgICB9XG4gICAgICAgIC8vIENvbnZlcnQgc3RyaW5ncyB0byBudW1iZXJzXG4gICAgICAgIGNvbnN0IG51bWVyaWNJbmRpY2VzID0ga2V5Qnl0ZUluZGljZXMubWFwKChpbmRleCkgPT4gcGFyc2VJbnQoaW5kZXgsIDEwKSk7XG4gICAgICAgIHJldHVybiBbbnVtZXJpY0luZGljZXNbMF0sIG51bWVyaWNJbmRpY2VzLnNsaWNlKDEpXTtcbiAgICB9XG4gICAgLyoqXG4gICAgICogUmVzb2x2ZXMgdGhlIGN1cnJlbnQgb25kZW1hbmQgY2h1bmsgVVJMIGZyb20gd2VicGFjayBydW50aW1lIG1ldGFkYXRhLlxuICAgICAqIEBwYXJhbSByZXNwb25zZSBPcHRpb25hbCBkb2N1bWVudCB0byB1c2UgaW5zdGVhZCBvZiBzdG9yZWQgb25lXG4gICAgICogQHJldHVybnMgQWJzb2x1dGUgVVJMIGZvciB0aGUgb25kZW1hbmQgY2h1bmsgZmlsZVxuICAgICAqIEBwcml2YXRlXG4gICAgICovXG4gICAgZ2V0T25EZW1hbmRGaWxlVXJsKHJlc3BvbnNlKSB7XG4gICAgICAgIGNvbnN0IGRvY3VtZW50ID0gcmVzcG9uc2UgfHwgdGhpcy5ob21lUGFnZURvY3VtZW50O1xuICAgICAgICBjb25zdCBydW50aW1lU291cmNlcyA9IEFycmF5LmZyb20oZG9jdW1lbnQucXVlcnlTZWxlY3RvckFsbChcInNjcmlwdFwiKSlcbiAgICAgICAgICAgIC5tYXAoKHNjcmlwdCkgPT4gc2NyaXB0LnRleHRDb250ZW50IHx8IFwiXCIpXG4gICAgICAgICAgICAuZmlsdGVyKChzY3JpcHRUZXh0KSA9PiBzY3JpcHRUZXh0LmluY2x1ZGVzKE9OX0RFTUFORF9DSFVOS19OQU1FKSk7XG4gICAgICAgIHJ1bnRpbWVTb3VyY2VzLnB1c2goZG9jdW1lbnQuZG9jdW1lbnRFbGVtZW50Lm91dGVySFRNTCk7XG4gICAgICAgIGZvciAoY29uc3QgcnVudGltZVNvdXJjZSBvZiBydW50aW1lU291cmNlcykge1xuICAgICAgICAgICAgY29uc3Qgb25EZW1hbmRGaWxlVXJsID0gcmVzb2x2ZU9uRGVtYW5kRmlsZVVybEZyb21SdW50aW1lKHJ1bnRpbWVTb3VyY2UpO1xuICAgICAgICAgICAgaWYgKG9uRGVtYW5kRmlsZVVybCkge1xuICAgICAgICAgICAgICAgIHJldHVybiBvbkRlbWFuZEZpbGVVcmw7XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgICAgdGhyb3cgbmV3IE9uRGVtYW5kRmlsZVVybFJlc29sdXRpb25FcnJvcigpO1xuICAgIH1cbiAgICAvKipcbiAgICAgKiBFeHRyYWN0cyB2ZXJpZmljYXRpb24ga2V5IGZyb20gZG9jdW1lbnRcbiAgICAgKiBAcGFyYW0gcmVzcG9uc2UgT3B0aW9uYWwgZG9jdW1lbnQgdG8gdXNlIGluc3RlYWQgb2Ygc3RvcmVkIG9uZVxuICAgICAqIEByZXR1cm5zIFggc2l0ZSB2ZXJpZmljYXRpb24ga2V5XG4gICAgICogQHByaXZhdGVcbiAgICAgKi9cbiAgICBnZXRLZXkocmVzcG9uc2UpIHtcbiAgICAgICAgcmVzcG9uc2UgPSByZXNwb25zZSB8fCB0aGlzLmhvbWVQYWdlRG9jdW1lbnQ7XG4gICAgICAgIGxldCBjb250ZW50ID0gXCJcIjtcbiAgICAgICAgLy8gRXh0cmFjdCBrZXkgZnJvbSBtZXRhIHRhZ1xuICAgICAgICBjb25zdCBlbGVtZW50ID0gcmVzcG9uc2UucXVlcnlTZWxlY3RvcihcIltuYW1lPSd0d2l0dGVyLXNpdGUtdmVyaWZpY2F0aW9uJ11cIik7XG4gICAgICAgIGlmIChlbGVtZW50KSB7XG4gICAgICAgICAgICBjb250ZW50ID0gZWxlbWVudC5nZXRBdHRyaWJ1dGUoXCJjb250ZW50XCIpID8/IFwiXCI7XG4gICAgICAgIH1cbiAgICAgICAgaWYgKCFjb250ZW50KSB7XG4gICAgICAgICAgICB0aHJvdyBuZXcgU2l0ZVZlcmlmaWNhdGlvbktleU5vdEZvdW5kRXJyb3IoKTtcbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gY29udGVudDtcbiAgICB9XG4gICAgLyoqXG4gICAgICogQ29udmVydHMga2V5IHN0cmluZyB0byBieXRlIGFycmF5XG4gICAgICogQHBhcmFtIGtleSBCYXNlNjQgZW5jb2RlZCBrZXkgc3RyaW5nXG4gICAgICogQHJldHVybnMgQXJyYXkgb2YgYnl0ZSB2YWx1ZXNcbiAgICAgKiBAcHJpdmF0ZVxuICAgICAqL1xuICAgIGdldEtleUJ5dGVzKGtleSkge1xuICAgICAgICByZXR1cm4gQXJyYXkuZnJvbShkZWNvZGVCYXNlNjQoa2V5KSk7XG4gICAgfVxuICAgIC8qKlxuICAgICAqIEdldHMgYW5pbWF0aW9uIGZyYW1lcyBmcm9tIGRvY3VtZW50XG4gICAgICogQHBhcmFtIHJlc3BvbnNlIE9wdGlvbmFsIGRvY3VtZW50IHRvIHVzZSBpbnN0ZWFkIG9mIHN0b3JlZCBvbmVcbiAgICAgKiBAcmV0dXJucyBBcnJheSBvZiBmcmFtZSBlbGVtZW50c1xuICAgICAqIEBwcml2YXRlXG4gICAgICovXG4gICAgZ2V0RnJhbWVzKHJlc3BvbnNlKSB7XG4gICAgICAgIHJlc3BvbnNlID0gcmVzcG9uc2UgfHwgdGhpcy5ob21lUGFnZURvY3VtZW50O1xuICAgICAgICByZXR1cm4gQXJyYXkuZnJvbShyZXNwb25zZS5xdWVyeVNlbGVjdG9yQWxsKFwiW2lkXj0nbG9hZGluZy14LWFuaW0nXVwiKSk7XG4gICAgfVxuICAgIC8qKlxuICAgICAqIFBhcnNlcyBTVkcgcGF0aHMgdG8gZXh0cmFjdCBjb29yZGluYXRlIGFycmF5c1xuICAgICAqIEBwYXJhbSBrZXlCeXRlcyBLZXkgYnl0ZXMgZnJvbSBzaXRlIHZlcmlmaWNhdGlvblxuICAgICAqIEBwYXJhbSByZXNwb25zZSBPcHRpb25hbCBkb2N1bWVudCB0byB1c2VcbiAgICAgKiBAcGFyYW0gZnJhbWVzIE9wdGlvbmFsIGZyYW1lIGVsZW1lbnRzIGlmIGFscmVhZHkgZmV0Y2hlZFxuICAgICAqIEByZXR1cm5zIDJEIGFycmF5IG9mIGZyYW1lIGNvb3JkaW5hdGVzXG4gICAgICogQHByaXZhdGVcbiAgICAgKi9cbiAgICBnZXQyZEFycmF5KGtleUJ5dGVzLCByZXNwb25zZSwgZnJhbWVzKSB7XG4gICAgICAgIGlmICghZnJhbWVzKSB7XG4gICAgICAgICAgICBmcmFtZXMgPSB0aGlzLmdldEZyYW1lcyhyZXNwb25zZSk7XG4gICAgICAgIH1cbiAgICAgICAgaWYgKCFmcmFtZXMgfHwgIWZyYW1lcy5sZW5ndGgpIHtcbiAgICAgICAgICAgIHJldHVybiBbW11dOyAvLyBSZXR1cm4gZW1wdHkgMkQgYXJyYXlcbiAgICAgICAgfVxuICAgICAgICAvLyAxLiBTZWxlY3QgZnJhbWUgYW5kIG5hdmlnYXRlIERPTSB0byBnZXQgXCJkXCIgYXR0cmlidXRlXG4gICAgICAgIGNvbnN0IGZyYW1lID0gZnJhbWVzW2tleUJ5dGVzWzVdICUgNF07XG4gICAgICAgIGNvbnN0IGZpcnN0Q2hpbGQgPSBmcmFtZS5jaGlsZHJlblswXTtcbiAgICAgICAgY29uc3QgdGFyZ2V0Q2hpbGQgPSBmaXJzdENoaWxkLmNoaWxkcmVuWzFdO1xuICAgICAgICBjb25zdCBkQXR0ciA9IHRhcmdldENoaWxkLmdldEF0dHJpYnV0ZShcImRcIik7XG4gICAgICAgIGlmIChkQXR0ciA9PT0gbnVsbCkge1xuICAgICAgICAgICAgcmV0dXJuIFtdO1xuICAgICAgICB9XG4gICAgICAgIC8vIDIuIFJlbW92ZSBmaXJzdCA5IGNoYXJzIGFuZCBzcGxpdCBieSBcIkNcIlxuICAgICAgICBjb25zdCBpdGVtcyA9IGRBdHRyLnN1YnN0cmluZyg5KS5zcGxpdChcIkNcIik7XG4gICAgICAgIC8vIDMuIEV4dHJhY3QgYW5kIGNvbnZlcnQgbnVtYmVycyBmcm9tIGVhY2ggc2VnbWVudFxuICAgICAgICByZXR1cm4gaXRlbXMubWFwKChpdGVtKSA9PiB7XG4gICAgICAgICAgICAvLyBhKSBSZXBsYWNlIG5vbi1kaWdpdHMgd2l0aCBzcGFjZXNcbiAgICAgICAgICAgIGNvbnN0IGNsZWFuZWQgPSBpdGVtLnJlcGxhY2UoL1teXFxkXSsvZywgXCIgXCIpLnRyaW0oKTtcbiAgICAgICAgICAgIC8vIGIpIFNwbGl0IGJ5IHdoaXRlc3BhY2VcbiAgICAgICAgICAgIGNvbnN0IHBhcnRzID0gY2xlYW5lZCA9PT0gXCJcIiA/IFtdIDogY2xlYW5lZC5zcGxpdCgvXFxzKy8pO1xuICAgICAgICAgICAgLy8gYykgQ29udmVydCBzdHJpbmcgdG8gaW50ZWdlcnNcbiAgICAgICAgICAgIHJldHVybiBwYXJ0cy5tYXAoKHN0cikgPT4gcGFyc2VJbnQoc3RyLCAxMCkpO1xuICAgICAgICB9KTtcbiAgICB9XG4gICAgLyoqXG4gICAgICogQ2FsY3VsYXRlcyB2YWx1ZSB3aXRoaW4gc3BlY2lmaWVkIHJhbmdlXG4gICAgICogQHBhcmFtIHZhbHVlIElucHV0IHZhbHVlICgwLTI1NSlcbiAgICAgKiBAcGFyYW0gbWluVmFsIE1pbmltdW0gb3V0cHV0IHZhbHVlXG4gICAgICogQHBhcmFtIG1heFZhbCBNYXhpbXVtIG91dHB1dCB2YWx1ZVxuICAgICAqIEBwYXJhbSByb3VuZGluZyBXaGV0aGVyIHRvIHVzZSBmbG9vciAodHJ1ZSkgb3Igcm91bmQgKGZhbHNlKVxuICAgICAqIEByZXR1cm5zIENhbGN1bGF0ZWQgdmFsdWVcbiAgICAgKiBAcHJpdmF0ZVxuICAgICAqL1xuICAgIHNvbHZlKHZhbHVlLCBtaW5WYWwsIG1heFZhbCwgcm91bmRpbmcpIHtcbiAgICAgICAgY29uc3QgcmVzdWx0ID0gKHZhbHVlICogKG1heFZhbCAtIG1pblZhbCkpIC8gMjU1ICsgbWluVmFsO1xuICAgICAgICByZXR1cm4gcm91bmRpbmcgPyBNYXRoLmZsb29yKHJlc3VsdCkgOiBNYXRoLnJvdW5kKHJlc3VsdCAqIDEwMCkgLyAxMDA7XG4gICAgfVxuICAgIC8qKlxuICAgICAqIEdlbmVyYXRlcyBhbmltYXRpb24ga2V5IGZyb20gZnJhbWUgZGF0YVxuICAgICAqIEBwYXJhbSBmcmFtZXMgQXJyYXkgb2YgZnJhbWUgdmFsdWVzXG4gICAgICogQHBhcmFtIHRhcmdldFRpbWUgVGFyZ2V0IHRpbWUgZm9yIGFuaW1hdGlvblxuICAgICAqIEByZXR1cm5zIEFuaW1hdGlvbiBrZXkgc3RyaW5nXG4gICAgICogQHByaXZhdGVcbiAgICAgKi9cbiAgICBhbmltYXRlKGZyYW1lcywgdGFyZ2V0VGltZSkge1xuICAgICAgICBjb25zdCBmcm9tQ29sb3IgPSBmcmFtZXMuc2xpY2UoMCwgMykuY29uY2F0KDEpLm1hcChOdW1iZXIpO1xuICAgICAgICBjb25zdCB0b0NvbG9yID0gZnJhbWVzLnNsaWNlKDMsIDYpLmNvbmNhdCgxKS5tYXAoTnVtYmVyKTtcbiAgICAgICAgY29uc3QgZnJvbVJvdGF0aW9uID0gWzAuMF07XG4gICAgICAgIGNvbnN0IHRvUm90YXRpb24gPSBbdGhpcy5zb2x2ZShmcmFtZXNbNl0sIDYwLjAsIDM2MC4wLCB0cnVlKV07XG4gICAgICAgIGNvbnN0IHJlbWFpbmluZ0ZyYW1lcyA9IGZyYW1lcy5zbGljZSg3KTtcbiAgICAgICAgY29uc3QgY3VydmVzID0gcmVtYWluaW5nRnJhbWVzLm1hcCgoaXRlbSwgY291bnRlcikgPT4gdGhpcy5zb2x2ZShpdGVtLCBpc09kZChjb3VudGVyKSwgMS4wLCBmYWxzZSkpO1xuICAgICAgICBjb25zdCBjdWJpYyA9IG5ldyBDdWJpYyhjdXJ2ZXMpO1xuICAgICAgICBjb25zdCB2YWwgPSBjdWJpYy5nZXRWYWx1ZSh0YXJnZXRUaW1lKTtcbiAgICAgICAgY29uc3QgY29sb3IgPSBpbnRlcnBvbGF0ZShmcm9tQ29sb3IsIHRvQ29sb3IsIHZhbCkubWFwKCh2YWx1ZSkgPT4gdmFsdWUgPiAwID8gdmFsdWUgOiAwKTtcbiAgICAgICAgY29uc3Qgcm90YXRpb24gPSBpbnRlcnBvbGF0ZShmcm9tUm90YXRpb24sIHRvUm90YXRpb24sIHZhbCk7XG4gICAgICAgIGNvbnN0IG1hdHJpeCA9IGNvbnZlcnRSb3RhdGlvblRvTWF0cml4KHJvdGF0aW9uWzBdKTtcbiAgICAgICAgLy8gQ29udmVydCBjb2xvciBhbmQgbWF0cml4IHZhbHVlcyB0byBoZXggc3RyaW5nXG4gICAgICAgIGNvbnN0IHN0ckFyciA9IGNvbG9yXG4gICAgICAgICAgICAuc2xpY2UoMCwgLTEpXG4gICAgICAgICAgICAubWFwKCh2YWx1ZSkgPT4gTWF0aC5yb3VuZCh2YWx1ZSkudG9TdHJpbmcoMTYpKTtcbiAgICAgICAgZm9yIChjb25zdCB2YWx1ZSBvZiBtYXRyaXgpIHtcbiAgICAgICAgICAgIGxldCByb3VuZGVkID0gTWF0aC5yb3VuZCh2YWx1ZSAqIDEwMCkgLyAxMDA7XG4gICAgICAgICAgICBpZiAocm91bmRlZCA8IDApIHtcbiAgICAgICAgICAgICAgICByb3VuZGVkID0gLXJvdW5kZWQ7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBjb25zdCBoZXhWYWx1ZSA9IGZsb2F0VG9IZXgocm91bmRlZCk7XG4gICAgICAgICAgICBzdHJBcnIucHVzaChoZXhWYWx1ZS5zdGFydHNXaXRoKFwiLlwiKVxuICAgICAgICAgICAgICAgID8gYDAke2hleFZhbHVlfWAudG9Mb3dlckNhc2UoKVxuICAgICAgICAgICAgICAgIDogaGV4VmFsdWUgfHwgXCIwXCIpO1xuICAgICAgICB9XG4gICAgICAgIHN0ckFyci5wdXNoKFwiMFwiLCBcIjBcIik7XG4gICAgICAgIGNvbnN0IGFuaW1hdGlvbktleSA9IHN0ckFyci5qb2luKFwiXCIpLnJlcGxhY2UoL1suLV0vZywgXCJcIik7XG4gICAgICAgIHJldHVybiBhbmltYXRpb25LZXk7XG4gICAgfVxuICAgIC8qKlxuICAgICAqIEdlbmVyYXRlcyBhbmltYXRpb24ga2V5IHVzZWQgaW4gdHJhbnNhY3Rpb24gSURcbiAgICAgKiBAcGFyYW0ga2V5Qnl0ZXMgS2V5IGJ5dGVzIGZyb20gc2l0ZSB2ZXJpZmljYXRpb25cbiAgICAgKiBAcGFyYW0gcmVzcG9uc2UgT3B0aW9uYWwgZG9jdW1lbnQgdG8gdXNlXG4gICAgICogQHJldHVybnMgQW5pbWF0aW9uIGtleSBzdHJpbmdcbiAgICAgKiBAcHJpdmF0ZVxuICAgICAqL1xuICAgIGdldEFuaW1hdGlvbktleShrZXlCeXRlcywgcmVzcG9uc2UpIHtcbiAgICAgICAgY29uc3QgdG90YWxUaW1lID0gNDA5NjtcbiAgICAgICAgaWYgKHRoaXMuREVGQVVMVF9ST1dfSU5ERVggPT0gbnVsbCB8fCB0aGlzLkRFRkFVTFRfS0VZX0JZVEVTX0lORElDRVMgPT0gbnVsbCkge1xuICAgICAgICAgICAgdGhyb3cgbmV3IEluZGljZXNOb3RJbml0aWFsaXplZEVycm9yKCk7XG4gICAgICAgIH1cbiAgICAgICAgY29uc3Qgcm93SW5kZXggPSBrZXlCeXRlc1t0aGlzLkRFRkFVTFRfUk9XX0lOREVYXSAlIDE2O1xuICAgICAgICAvLyBHZW5lcmF0ZSBmcmFtZSB0aW1lIHVzaW5nIGtleSBieXRlIGluZGljZXNcbiAgICAgICAgbGV0IGZyYW1lVGltZSA9IHRoaXMuREVGQVVMVF9LRVlfQllURVNfSU5ESUNFUy5yZWR1Y2UoKG51bTEsIG51bTIpID0+IHtcbiAgICAgICAgICAgIHJldHVybiBudW0xICogKGtleUJ5dGVzW251bTJdICUgMTYpO1xuICAgICAgICB9LCAxKTtcbiAgICAgICAgZnJhbWVUaW1lID0gTWF0aC5yb3VuZChmcmFtZVRpbWUgLyAxMCkgKiAxMDtcbiAgICAgICAgY29uc3QgYXJyID0gdGhpcy5nZXQyZEFycmF5KGtleUJ5dGVzLCByZXNwb25zZSk7XG4gICAgICAgIGlmICghYXJyIHx8ICFhcnJbcm93SW5kZXhdKSB7XG4gICAgICAgICAgICB0aHJvdyBuZXcgQW5pbWF0aW9uRnJhbWVEYXRhRXJyb3Iocm93SW5kZXgpO1xuICAgICAgICB9XG4gICAgICAgIGNvbnN0IGZyYW1lUm93ID0gYXJyW3Jvd0luZGV4XTtcbiAgICAgICAgY29uc3QgdGFyZ2V0VGltZSA9IGZyYW1lVGltZSAvIHRvdGFsVGltZTtcbiAgICAgICAgY29uc3QgYW5pbWF0aW9uS2V5ID0gdGhpcy5hbmltYXRlKGZyYW1lUm93LCB0YXJnZXRUaW1lKTtcbiAgICAgICAgcmV0dXJuIGFuaW1hdGlvbktleTtcbiAgICB9XG4gICAgLyoqXG4gICAgICogR2VuZXJhdGVzIGEgdHJhbnNhY3Rpb24gSUQgZm9yIFggQVBJIHJlcXVlc3RzXG4gICAgICogQHBhcmFtIG1ldGhvZCBIVFRQIG1ldGhvZCAoR0VULCBQT1NULCBldGMuKVxuICAgICAqIEBwYXJhbSBwYXRoIEFQSSBlbmRwb2ludCBwYXRoXG4gICAgICogQHBhcmFtIHJlc3BvbnNlIE9wdGlvbmFsIGRvY3VtZW50IHRvIHVzZVxuICAgICAqIEBwYXJhbSBrZXkgT3B0aW9uYWwga2V5IHRvIHVzZVxuICAgICAqIEBwYXJhbSBhbmltYXRpb25LZXkgT3B0aW9uYWwgYW5pbWF0aW9uIGtleSB0byB1c2VcbiAgICAgKiBAcGFyYW0gdGltZU5vdyBPcHRpb25hbCB0aW1lc3RhbXAgKGRlZmF1bHRzIHRvIGN1cnJlbnQgdGltZSlcbiAgICAgKiBAcmV0dXJucyBCYXNlNjQgZW5jb2RlZCB0cmFuc2FjdGlvbiBJRFxuICAgICAqL1xuICAgIGFzeW5jIGdlbmVyYXRlVHJhbnNhY3Rpb25JZChtZXRob2QsIHBhdGgsIHJlc3BvbnNlLCBrZXksIGFuaW1hdGlvbktleSwgdGltZU5vdykge1xuICAgICAgICAvLyBDaGVjayBpZiBpbnN0YW5jZSBpcyBpbml0aWFsaXplZFxuICAgICAgICBpZiAoIXRoaXMuaXNJbml0aWFsaXplZCkge1xuICAgICAgICAgICAgdGhyb3cgbmV3IENsaWVudFRyYW5zYWN0aW9uTm90SW5pdGlhbGl6ZWRFcnJvcigpO1xuICAgICAgICB9XG4gICAgICAgIHRpbWVOb3cgPSB0aW1lTm93IHx8IE1hdGguZmxvb3IoKERhdGUubm93KCkgLSAxNjgyOTI0NDAwICogMTAwMCkgLyAxMDAwKTtcbiAgICAgICAgY29uc3QgdGltZU5vd0J5dGVzID0gW1xuICAgICAgICAgICAgdGltZU5vdyAmIDB4ZmYsXG4gICAgICAgICAgICAodGltZU5vdyA+PiA4KSAmIDB4ZmYsXG4gICAgICAgICAgICAodGltZU5vdyA+PiAxNikgJiAweGZmLFxuICAgICAgICAgICAgKHRpbWVOb3cgPj4gMjQpICYgMHhmZixcbiAgICAgICAgXTtcbiAgICAgICAga2V5ID0ga2V5IHx8IHRoaXMua2V5IHx8IHRoaXMuZ2V0S2V5KHJlc3BvbnNlKTtcbiAgICAgICAgY29uc3Qga2V5Qnl0ZXMgPSBrZXlcbiAgICAgICAgICAgID8gdGhpcy5nZXRLZXlCeXRlcyhrZXkpXG4gICAgICAgICAgICA6IHRoaXMua2V5Qnl0ZXMgfHwgdGhpcy5nZXRLZXlCeXRlcyhrZXkpO1xuICAgICAgICBhbmltYXRpb25LZXkgPSBhbmltYXRpb25LZXkgfHxcbiAgICAgICAgICAgIHRoaXMuYW5pbWF0aW9uS2V5IHx8XG4gICAgICAgICAgICB0aGlzLmdldEFuaW1hdGlvbktleShrZXlCeXRlcywgcmVzcG9uc2UpO1xuICAgICAgICAvLyBHZW5lcmF0ZSBoYXNoIGRhdGFcbiAgICAgICAgY29uc3QgZGF0YSA9IGAke21ldGhvZH0hJHtwYXRofSEke3RpbWVOb3d9JHtDbGllbnRUcmFuc2FjdGlvbi5ERUZBVUxUX0tFWVdPUkR9JHthbmltYXRpb25LZXl9YDtcbiAgICAgICAgLy8gQ2FsY3VsYXRlIFNIQS0yNTYgaGFzaFxuICAgICAgICBjb25zdCBlbmNvZGVyID0gbmV3IFRleHRFbmNvZGVyKCk7XG4gICAgICAgIGNvbnN0IGRhdGFCdWZmZXIgPSBlbmNvZGVyLmVuY29kZShkYXRhKTtcbiAgICAgICAgY29uc3QgaGFzaEJ1ZmZlciA9IGF3YWl0IGNyeXB0by5zdWJ0bGUuZGlnZXN0KFwiU0hBLTI1NlwiLCBkYXRhQnVmZmVyKTtcbiAgICAgICAgY29uc3QgaGFzaEJ5dGVzID0gQXJyYXkuZnJvbShuZXcgVWludDhBcnJheShoYXNoQnVmZmVyKSk7XG4gICAgICAgIGNvbnN0IHJhbmRvbU51bSA9IE1hdGguZmxvb3IoTWF0aC5yYW5kb20oKSAqIDI1Nik7XG4gICAgICAgIGNvbnN0IGJ5dGVzQXJyID0gW1xuICAgICAgICAgICAgLi4ua2V5Qnl0ZXMsXG4gICAgICAgICAgICAuLi50aW1lTm93Qnl0ZXMsXG4gICAgICAgICAgICAuLi5oYXNoQnl0ZXMuc2xpY2UoMCwgMTYpLFxuICAgICAgICAgICAgQ2xpZW50VHJhbnNhY3Rpb24uQURESVRJT05BTF9SQU5ET01fTlVNQkVSLFxuICAgICAgICBdO1xuICAgICAgICBjb25zdCBvdXQgPSBuZXcgVWludDhBcnJheShbXG4gICAgICAgICAgICByYW5kb21OdW0sXG4gICAgICAgICAgICAuLi5ieXRlc0Fyci5tYXAoKGl0ZW0pID0+IGl0ZW0gXiByYW5kb21OdW0pLFxuICAgICAgICBdKTtcbiAgICAgICAgcmV0dXJuIGVuY29kZUJhc2U2NChvdXQpLnJlcGxhY2UoLz0vZywgXCJcIik7XG4gICAgfVxufVxuT2JqZWN0LmRlZmluZVByb3BlcnR5KENsaWVudFRyYW5zYWN0aW9uLCBcIkFERElUSU9OQUxfUkFORE9NX05VTUJFUlwiLCB7XG4gICAgZW51bWVyYWJsZTogdHJ1ZSxcbiAgICBjb25maWd1cmFibGU6IHRydWUsXG4gICAgd3JpdGFibGU6IHRydWUsXG4gICAgdmFsdWU6IDNcbn0pO1xuT2JqZWN0LmRlZmluZVByb3BlcnR5KENsaWVudFRyYW5zYWN0aW9uLCBcIkRFRkFVTFRfS0VZV09SRFwiLCB7XG4gICAgZW51bWVyYWJsZTogdHJ1ZSxcbiAgICBjb25maWd1cmFibGU6IHRydWUsXG4gICAgd3JpdGFibGU6IHRydWUsXG4gICAgdmFsdWU6IFwib2JmaW93ZXJlaGlyaW5nXCJcbn0pO1xuZXhwb3J0IGRlZmF1bHQgQ2xpZW50VHJhbnNhY3Rpb247XG4iLCIvKipcbiAqIFV0aWxpdHkgZnVuY3Rpb25zIGZvciBYIGNsaWVudCB0cmFuc2FjdGlvbiBJRCBnZW5lcmF0aW9uXG4gKlxuICogVGhpcyBtb2R1bGUgcHJvdmlkZXMgaGVscGVyIGZ1bmN0aW9ucyBmb3IgaGFuZGxpbmcgWCBkb21haW4gbWlncmF0aW9uLFxuICogbnVtYmVyIGNvbnZlcnNpb25zLCBhbmQgb3RoZXIgdXRpbGl0eSBvcGVyYXRpb25zLlxuICovXG5pbXBvcnQgeyBwYXJzZUhUTUwgfSBmcm9tIFwibGlua2Vkb21cIjtcbmltcG9ydCB7IFhIb21lUGFnZUZldGNoRXJyb3IsIFhNaWdyYXRpb25Gb3JtRXJyb3IsIFhNaWdyYXRpb25SZWRpcmVjdGlvbkVycm9yLCB9IGZyb20gXCIuL2Vycm9ycy5qc1wiO1xuLyoqXG4gKiBIYW5kbGVzIFguY29tIGRvbWFpbiBtaWdyYXRpb24gcHJvY2VzcyBhbmQgcmV0dXJucyB0aGUgSFRNTCBkb2N1bWVudFxuICpcbiAqIFRoaXMgZnVuY3Rpb24gbmF2aWdhdGVzIHRocm91Z2ggWCdzIG1pZ3JhdGlvbiByZWRpcmVjdHMgYW5kIGZvcm1zXG4gKiB0byBvYnRhaW4gdGhlIGZpbmFsIEhUTUwgZG9jdW1lbnQgbmVlZGVkIGZvciB0cmFuc2FjdGlvbiBJRCBnZW5lcmF0aW9uLlxuICpcbiAqIEByZXR1cm5zIFByb21pc2UgcmVzb2x2aW5nIHRvIHRoZSBEb2N1bWVudCBvYmplY3QgZnJvbSBYJ3MgaG9tZXBhZ2VcbiAqL1xuYXN5bmMgZnVuY3Rpb24gaGFuZGxlWE1pZ3JhdGlvbigpIHtcbiAgICAvLyBTZXQgaGVhZGVycyB0byBtaW1pYyBhIGJyb3dzZXIgcmVxdWVzdFxuICAgIGNvbnN0IGhlYWRlcnMgPSB7XG4gICAgICAgIGFjY2VwdDogXCJ0ZXh0L2h0bWwsYXBwbGljYXRpb24veGh0bWwreG1sLGFwcGxpY2F0aW9uL3htbDtxPTAuOSxpbWFnZS9hdmlmLGltYWdlL3dlYnAsaW1hZ2UvYXBuZywqLyo7cT0wLjgsYXBwbGljYXRpb24vc2lnbmVkLWV4Y2hhbmdlO3Y9YjM7cT0wLjdcIixcbiAgICAgICAgXCJhY2NlcHQtbGFuZ3VhZ2VcIjogXCJqYVwiLFxuICAgICAgICBcImNhY2hlLWNvbnRyb2xcIjogXCJuby1jYWNoZVwiLFxuICAgICAgICBwcmFnbWE6IFwibm8tY2FjaGVcIixcbiAgICAgICAgcHJpb3JpdHk6IFwidT0wLCBpXCIsXG4gICAgICAgIFwic2VjLWNoLXVhXCI6ICdcIkdvb2dsZSBDaHJvbWVcIjt2PVwiMTM1XCIsIFwiTm90LUEuQnJhbmRcIjt2PVwiOFwiLCBcIkNocm9taXVtXCI7dj1cIjEzNVwiJyxcbiAgICAgICAgXCJzZWMtY2gtdWEtbW9iaWxlXCI6IFwiPzBcIixcbiAgICAgICAgXCJzZWMtY2gtdWEtcGxhdGZvcm1cIjogJ1wiV2luZG93c1wiJyxcbiAgICAgICAgXCJzZWMtZmV0Y2gtZGVzdFwiOiBcImRvY3VtZW50XCIsXG4gICAgICAgIFwic2VjLWZldGNoLW1vZGVcIjogXCJuYXZpZ2F0ZVwiLFxuICAgICAgICBcInNlYy1mZXRjaC1zaXRlXCI6IFwibm9uZVwiLFxuICAgICAgICBcInNlYy1mZXRjaC11c2VyXCI6IFwiPzFcIixcbiAgICAgICAgXCJ1cGdyYWRlLWluc2VjdXJlLXJlcXVlc3RzXCI6IFwiMVwiLFxuICAgICAgICBcInVzZXItYWdlbnRcIjogXCJNb3ppbGxhLzUuMCAoV2luZG93cyBOVCAxMC4wOyBXaW42NDsgeDY0KSBBcHBsZVdlYktpdC81MzcuMzYgKEtIVE1MLCBsaWtlIEdlY2tvKSBDaHJvbWUvMTM1LjAuMC4wIFNhZmFyaS81MzcuMzZcIixcbiAgICB9O1xuICAgIC8vIEZldGNoIFguY29tIGhvbWVwYWdlXG4gICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBmZXRjaChcImh0dHBzOi8veC5jb21cIiwge1xuICAgICAgICBoZWFkZXJzLFxuICAgIH0pO1xuICAgIGlmICghcmVzcG9uc2Uub2spIHtcbiAgICAgICAgdGhyb3cgbmV3IFhIb21lUGFnZUZldGNoRXJyb3IocmVzcG9uc2Uuc3RhdHVzLCByZXNwb25zZS5zdGF0dXNUZXh0KTtcbiAgICB9XG4gICAgY29uc3QgaHRtbFRleHQgPSBhd2FpdCByZXNwb25zZS50ZXh0KCk7XG4gICAgLy8gUGFyc2UgSFRNTCB1c2luZyBsaW5rZWRvbVxuICAgIGxldCBkb20gPSBwYXJzZUhUTUwoaHRtbFRleHQpO1xuICAgIGxldCBkb2N1bWVudCA9IGRvbS53aW5kb3cuZG9jdW1lbnQ7XG4gICAgLy8gQ2hlY2sgZm9yIG1pZ3JhdGlvbiByZWRpcmVjdGlvbiBsaW5rc1xuICAgIGNvbnN0IG1pZ3JhdGlvblJlZGlyZWN0aW9uUmVnZXggPSBuZXcgUmVnRXhwKFwiKGh0dHAoPzpzKT86Ly8oPzp3d3dcXFxcLik/KHR3aXR0ZXJ8eCl7MX1cXFxcLmNvbSgveCk/L21pZ3JhdGUoWy8/XSk/dG9rPVthLXpBLVowLTklXFxcXC1fXSspK1wiLCBcImlcIik7XG4gICAgY29uc3QgbWV0YVJlZnJlc2ggPSBkb2N1bWVudC5xdWVyeVNlbGVjdG9yKFwibWV0YVtodHRwLWVxdWl2PSdyZWZyZXNoJ11cIik7XG4gICAgY29uc3QgbWV0YUNvbnRlbnQgPSBtZXRhUmVmcmVzaFxuICAgICAgICA/IG1ldGFSZWZyZXNoLmdldEF0dHJpYnV0ZShcImNvbnRlbnRcIikgfHwgXCJcIlxuICAgICAgICA6IFwiXCI7XG4gICAgY29uc3QgbWlncmF0aW9uUmVkaXJlY3Rpb25VcmwgPSBtaWdyYXRpb25SZWRpcmVjdGlvblJlZ2V4LmV4ZWMobWV0YUNvbnRlbnQpIHx8XG4gICAgICAgIG1pZ3JhdGlvblJlZGlyZWN0aW9uUmVnZXguZXhlYyhodG1sVGV4dCk7XG4gICAgaWYgKG1pZ3JhdGlvblJlZGlyZWN0aW9uVXJsKSB7XG4gICAgICAgIC8vIEZvbGxvdyByZWRpcmVjdGlvbiBVUkxcbiAgICAgICAgY29uc3QgcmVkaXJlY3RSZXNwb25zZSA9IGF3YWl0IGZldGNoKG1pZ3JhdGlvblJlZGlyZWN0aW9uVXJsWzBdKTtcbiAgICAgICAgaWYgKCFyZWRpcmVjdFJlc3BvbnNlLm9rKSB7XG4gICAgICAgICAgICB0aHJvdyBuZXcgWE1pZ3JhdGlvblJlZGlyZWN0aW9uRXJyb3IocmVkaXJlY3RSZXNwb25zZS5zdGF0dXMsIHJlZGlyZWN0UmVzcG9uc2Uuc3RhdHVzVGV4dCk7XG4gICAgICAgIH1cbiAgICAgICAgY29uc3QgcmVkaXJlY3RIdG1sID0gYXdhaXQgcmVkaXJlY3RSZXNwb25zZS50ZXh0KCk7XG4gICAgICAgIGRvbSA9IHBhcnNlSFRNTChyZWRpcmVjdEh0bWwpO1xuICAgICAgICBkb2N1bWVudCA9IGRvbS53aW5kb3cuZG9jdW1lbnQ7XG4gICAgfVxuICAgIC8vIEhhbmRsZSBtaWdyYXRpb24gZm9ybSBpZiBwcmVzZW50XG4gICAgY29uc3QgbWlncmF0aW9uRm9ybSA9IGRvY3VtZW50LnF1ZXJ5U2VsZWN0b3IoXCJmb3JtW25hbWU9J2YnXVwiKSB8fFxuICAgICAgICBkb2N1bWVudC5xdWVyeVNlbGVjdG9yKFwiZm9ybVthY3Rpb249J2h0dHBzOi8veC5jb20veC9taWdyYXRlJ11cIik7XG4gICAgaWYgKG1pZ3JhdGlvbkZvcm0pIHtcbiAgICAgICAgY29uc3QgdXJsID0gbWlncmF0aW9uRm9ybS5nZXRBdHRyaWJ1dGUoXCJhY3Rpb25cIikgfHxcbiAgICAgICAgICAgIFwiaHR0cHM6Ly94LmNvbS94L21pZ3JhdGVcIjtcbiAgICAgICAgY29uc3QgbWV0aG9kID0gbWlncmF0aW9uRm9ybS5nZXRBdHRyaWJ1dGUoXCJtZXRob2RcIikgfHwgXCJQT1NUXCI7XG4gICAgICAgIC8vIENvbGxlY3QgZm9ybSBpbnB1dCBmaWVsZHNcbiAgICAgICAgY29uc3QgcmVxdWVzdFBheWxvYWQgPSBuZXcgRm9ybURhdGEoKTtcbiAgICAgICAgY29uc3QgaW5wdXRGaWVsZHMgPSBtaWdyYXRpb25Gb3JtLnF1ZXJ5U2VsZWN0b3JBbGwoXCJpbnB1dFwiKTtcbiAgICAgICAgZm9yIChjb25zdCBlbGVtZW50IG9mIEFycmF5LmZyb20oaW5wdXRGaWVsZHMpKSB7XG4gICAgICAgICAgICBjb25zdCBuYW1lID0gZWxlbWVudC5nZXRBdHRyaWJ1dGUoXCJuYW1lXCIpO1xuICAgICAgICAgICAgY29uc3QgdmFsdWUgPSBlbGVtZW50LmdldEF0dHJpYnV0ZShcInZhbHVlXCIpO1xuICAgICAgICAgICAgaWYgKG5hbWUgJiYgdmFsdWUpIHtcbiAgICAgICAgICAgICAgICByZXF1ZXN0UGF5bG9hZC5hcHBlbmQobmFtZSwgdmFsdWUpO1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICAgIC8vIFN1Ym1pdCBmb3JtIHVzaW5nIFBPU1QgcmVxdWVzdFxuICAgICAgICBjb25zdCBmb3JtUmVzcG9uc2UgPSBhd2FpdCBmZXRjaCh1cmwsIHtcbiAgICAgICAgICAgIG1ldGhvZDogbWV0aG9kLFxuICAgICAgICAgICAgYm9keTogcmVxdWVzdFBheWxvYWQsXG4gICAgICAgICAgICBoZWFkZXJzLFxuICAgICAgICB9KTtcbiAgICAgICAgaWYgKCFmb3JtUmVzcG9uc2Uub2spIHtcbiAgICAgICAgICAgIHRocm93IG5ldyBYTWlncmF0aW9uRm9ybUVycm9yKGZvcm1SZXNwb25zZS5zdGF0dXMsIGZvcm1SZXNwb25zZS5zdGF0dXNUZXh0KTtcbiAgICAgICAgfVxuICAgICAgICBjb25zdCBmb3JtSHRtbCA9IGF3YWl0IGZvcm1SZXNwb25zZS50ZXh0KCk7XG4gICAgICAgIGRvbSA9IHBhcnNlSFRNTChmb3JtSHRtbCk7XG4gICAgICAgIGRvY3VtZW50ID0gZG9tLndpbmRvdy5kb2N1bWVudDtcbiAgICB9XG4gICAgLy8gUmV0dXJuIGZpbmFsIERPTSBkb2N1bWVudFxuICAgIHJldHVybiBkb2N1bWVudDtcbn1cbi8qKlxuICogQ29udmVydHMgYSBmbG9hdGluZyBwb2ludCBudW1iZXIgdG8gaGV4YWRlY2ltYWwgc3RyaW5nIHJlcHJlc2VudGF0aW9uXG4gKlxuICogQHBhcmFtIHggRmxvYXRpbmcgcG9pbnQgbnVtYmVyIHRvIGNvbnZlcnRcbiAqIEByZXR1cm5zIEhleGFkZWNpbWFsIHN0cmluZyByZXByZXNlbnRhdGlvbiBvZiB0aGUgbnVtYmVyXG4gKi9cbmZ1bmN0aW9uIGZsb2F0VG9IZXgoeCkge1xuICAgIGNvbnN0IHJlc3VsdCA9IFtdO1xuICAgIGxldCBxdW90aWVudCA9IE1hdGguZmxvb3IoeCk7XG4gICAgbGV0IGZyYWN0aW9uID0geCAtIHF1b3RpZW50O1xuICAgIC8vIENvbnZlcnQgaW50ZWdlciBwYXJ0IHRvIGhleFxuICAgIHdoaWxlIChxdW90aWVudCA+IDApIHtcbiAgICAgICAgcXVvdGllbnQgPSBNYXRoLmZsb29yKHggLyAxNik7XG4gICAgICAgIGNvbnN0IHJlbWFpbmRlciA9IE1hdGguZmxvb3IoeCAtIHF1b3RpZW50ICogMTYpO1xuICAgICAgICBpZiAocmVtYWluZGVyID4gOSkge1xuICAgICAgICAgICAgcmVzdWx0LnVuc2hpZnQoU3RyaW5nLmZyb21DaGFyQ29kZShyZW1haW5kZXIgKyA1NSkpOyAvLyBDb252ZXJ0IHRvIEEtRlxuICAgICAgICB9XG4gICAgICAgIGVsc2Uge1xuICAgICAgICAgICAgcmVzdWx0LnVuc2hpZnQocmVtYWluZGVyLnRvU3RyaW5nKCkpO1xuICAgICAgICB9XG4gICAgICAgIHggPSBxdW90aWVudDtcbiAgICB9XG4gICAgaWYgKGZyYWN0aW9uID09PSAwKSB7XG4gICAgICAgIHJldHVybiByZXN1bHQuam9pbihcIlwiKTtcbiAgICB9XG4gICAgLy8gQWRkIGRlY2ltYWwgcG9pbnQgZm9yIGZyYWN0aW9uYWwgcGFydFxuICAgIHJlc3VsdC5wdXNoKFwiLlwiKTtcbiAgICAvLyBDb252ZXJ0IGZyYWN0aW9uYWwgcGFydCB0byBoZXhcbiAgICB3aGlsZSAoZnJhY3Rpb24gPiAwKSB7XG4gICAgICAgIGZyYWN0aW9uICo9IDE2O1xuICAgICAgICBjb25zdCBpbnRlZ2VyID0gTWF0aC5mbG9vcihmcmFjdGlvbik7XG4gICAgICAgIGZyYWN0aW9uIC09IGludGVnZXI7XG4gICAgICAgIGlmIChpbnRlZ2VyID4gOSkge1xuICAgICAgICAgICAgcmVzdWx0LnB1c2goU3RyaW5nLmZyb21DaGFyQ29kZShpbnRlZ2VyICsgNTUpKTsgLy8gQ29udmVydCB0byBBLUZcbiAgICAgICAgfVxuICAgICAgICBlbHNlIHtcbiAgICAgICAgICAgIHJlc3VsdC5wdXNoKGludGVnZXIudG9TdHJpbmcoKSk7XG4gICAgICAgIH1cbiAgICB9XG4gICAgcmV0dXJuIHJlc3VsdC5qb2luKFwiXCIpO1xufVxuLyoqXG4gKiBEZXRlcm1pbmVzIGlmIGEgbnVtYmVyIGlzIG9kZCBhbmQgcmV0dXJucyBhIHNwZWNpZmljIHZhbHVlXG4gKlxuICogQHBhcmFtIG51bSBOdW1iZXIgdG8gY2hlY2tcbiAqIEByZXR1cm5zIC0xLjAgaWYgb2RkLCAwLjAgaWYgZXZlblxuICovXG5mdW5jdGlvbiBpc09kZChudW0pIHtcbiAgICBpZiAobnVtICUgMikge1xuICAgICAgICByZXR1cm4gLTEuMDtcbiAgICB9XG4gICAgcmV0dXJuIDAuMDtcbn1cbmV4cG9ydCB7IGZsb2F0VG9IZXgsIGhhbmRsZVhNaWdyYXRpb24sIGlzT2RkIH07XG4iLCIvLyBUaGUgbW9kdWxlIGNhY2hlXG52YXIgX193ZWJwYWNrX21vZHVsZV9jYWNoZV9fID0ge307XG5cbi8vIFRoZSByZXF1aXJlIGZ1bmN0aW9uXG5mdW5jdGlvbiBfX3dlYnBhY2tfcmVxdWlyZV9fKG1vZHVsZUlkKSB7XG5cdC8vIENoZWNrIGlmIG1vZHVsZSBpcyBpbiBjYWNoZVxuXHR2YXIgY2FjaGVkTW9kdWxlID0gX193ZWJwYWNrX21vZHVsZV9jYWNoZV9fW21vZHVsZUlkXTtcblx0aWYgKGNhY2hlZE1vZHVsZSAhPT0gdW5kZWZpbmVkKSB7XG5cdFx0cmV0dXJuIGNhY2hlZE1vZHVsZS5leHBvcnRzO1xuXHR9XG5cdC8vIENyZWF0ZSBhIG5ldyBtb2R1bGUgKGFuZCBwdXQgaXQgaW50byB0aGUgY2FjaGUpXG5cdHZhciBtb2R1bGUgPSBfX3dlYnBhY2tfbW9kdWxlX2NhY2hlX19bbW9kdWxlSWRdID0ge1xuXHRcdC8vIG5vIG1vZHVsZS5pZCBuZWVkZWRcblx0XHQvLyBubyBtb2R1bGUubG9hZGVkIG5lZWRlZFxuXHRcdGV4cG9ydHM6IHt9XG5cdH07XG5cblx0Ly8gRXhlY3V0ZSB0aGUgbW9kdWxlIGZ1bmN0aW9uXG5cdGlmICghKG1vZHVsZUlkIGluIF9fd2VicGFja19tb2R1bGVzX18pKSB7XG5cdFx0ZGVsZXRlIF9fd2VicGFja19tb2R1bGVfY2FjaGVfX1ttb2R1bGVJZF07XG5cdFx0dmFyIGUgPSBuZXcgRXJyb3IoXCJDYW5ub3QgZmluZCBtb2R1bGUgJ1wiICsgbW9kdWxlSWQgKyBcIidcIik7XG5cdFx0ZS5jb2RlID0gJ01PRFVMRV9OT1RfRk9VTkQnO1xuXHRcdHRocm93IGU7XG5cdH1cblx0X193ZWJwYWNrX21vZHVsZXNfX1ttb2R1bGVJZF0obW9kdWxlLCBtb2R1bGUuZXhwb3J0cywgX193ZWJwYWNrX3JlcXVpcmVfXyk7XG5cblx0Ly8gUmV0dXJuIHRoZSBleHBvcnRzIG9mIHRoZSBtb2R1bGVcblx0cmV0dXJuIG1vZHVsZS5leHBvcnRzO1xufVxuXG4iLCIvLyBkZWZpbmUgZ2V0dGVyIGZ1bmN0aW9ucyBmb3IgaGFybW9ueSBleHBvcnRzXG5fX3dlYnBhY2tfcmVxdWlyZV9fLmQgPSAoZXhwb3J0cywgZGVmaW5pdGlvbikgPT4ge1xuXHRmb3IodmFyIGtleSBpbiBkZWZpbml0aW9uKSB7XG5cdFx0aWYoX193ZWJwYWNrX3JlcXVpcmVfXy5vKGRlZmluaXRpb24sIGtleSkgJiYgIV9fd2VicGFja19yZXF1aXJlX18ubyhleHBvcnRzLCBrZXkpKSB7XG5cdFx0XHRPYmplY3QuZGVmaW5lUHJvcGVydHkoZXhwb3J0cywga2V5LCB7IGVudW1lcmFibGU6IHRydWUsIGdldDogZGVmaW5pdGlvbltrZXldIH0pO1xuXHRcdH1cblx0fVxufTsiLCJfX3dlYnBhY2tfcmVxdWlyZV9fLm8gPSAob2JqLCBwcm9wKSA9PiAoT2JqZWN0LnByb3RvdHlwZS5oYXNPd25Qcm9wZXJ0eS5jYWxsKG9iaiwgcHJvcCkpIiwiLy8gZGVmaW5lIF9fZXNNb2R1bGUgb24gZXhwb3J0c1xuX193ZWJwYWNrX3JlcXVpcmVfXy5yID0gKGV4cG9ydHMpID0+IHtcblx0aWYodHlwZW9mIFN5bWJvbCAhPT0gJ3VuZGVmaW5lZCcgJiYgU3ltYm9sLnRvU3RyaW5nVGFnKSB7XG5cdFx0T2JqZWN0LmRlZmluZVByb3BlcnR5KGV4cG9ydHMsIFN5bWJvbC50b1N0cmluZ1RhZywgeyB2YWx1ZTogJ01vZHVsZScgfSk7XG5cdH1cblx0T2JqZWN0LmRlZmluZVByb3BlcnR5KGV4cG9ydHMsICdfX2VzTW9kdWxlJywgeyB2YWx1ZTogdHJ1ZSB9KTtcbn07IiwiaW1wb3J0IHsgTXNnVHlwZSB9IGZyb20gJy4uL2NhcHR1cmUvY29uc3RzJztcbmltcG9ydCB7IHBlcmZvcm1NdXRhdGlvbiwgcGVyZm9ybUxlZ2FjeVJFU1QsIGZldGNoVXNlckJ5U2NyZWVuTmFtZSB9IGZyb20gJy4uL3hfYXBpL3R3aXR0ZXJfYXBpJztcbmltcG9ydCB7IGZpbmREZWVwVXNlciB9IGZyb20gJy4uL2NhcHR1cmUvZXh0cmFjdG9yJztcbi8qKlxuICogbWFpbl9lbnRyYW5jZS50cyAtIENvbnRlbnQgU2NyaXB0IFN1cGVydmlzb3JcbiAqXG4gKiDogYzotKPvvJpcbiAqICAxLiDlsIYgaW5qZWN0aW9uLmpzIOazqOWFpemhtemdouS4iuS4i+aWh1xuICogIDIuIOS4ree7pyBpbmplY3Rpb24g4oaSIGJhY2tncm91bmQg55qE5raI5oGv77yI5YyF5ousIGFwaVVybOOAgWJlYXJlclRva2Vu77yJXG4gKiAgMy4g5omn6KGM5YaZ5pON5L2c77yIbXV0YXRpb27vvInigJTigJQg5ZSv5LiA5ZCI5rOV55qE5YaZ5pON5L2c5omn6KGM546v5aKDXG4gKi9cbihmdW5jdGlvbiBpbmplY3QoKSB7XG4gICAgaWYgKGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKCd0Y19pbmplY3Rpb24nKSlcbiAgICAgICAgcmV0dXJuO1xuICAgIGNvbnN0IHNjcmlwdCA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ3NjcmlwdCcpO1xuICAgIHNjcmlwdC5pZCA9ICd0Y19pbmplY3Rpb24nO1xuICAgIHNjcmlwdC5zcmMgPSBjaHJvbWUucnVudGltZS5nZXRVUkwoJ2pzL2luamVjdGlvbi5qcycpO1xuICAgIChkb2N1bWVudC5oZWFkIHx8IGRvY3VtZW50LmRvY3VtZW50RWxlbWVudCkuYXBwZW5kQ2hpbGQoc2NyaXB0KTtcbiAgICBzY3JpcHQub25sb2FkID0gKCkgPT4gc2NyaXB0LnJlbW92ZSgpO1xufSkoKTtcbndpbmRvdy5hZGRFdmVudExpc3RlbmVyKCdtZXNzYWdlJywgKGV2ZW50KSA9PiB7XG4gICAgaWYgKGV2ZW50LmRhdGE/LnNvdXJjZSAhPT0gJ3R3ZWV0Y2xhdy1pbmplY3Rpb24nKVxuICAgICAgICByZXR1cm47XG4gICAgLy8g4pSA4pSAIOebtOaOpeWcqCBDb250ZW50IFNjcmlwdCDlsYLmjZXojrcgc2V0dGluZ3MuanNvbu+8jOeri+WIu+WGmeWFpSBzdG9yYWdlIOKUgOKUgFxuICAgIC8vIOS/ruWkjeiDjOaZr++8mnNldHRpbmdzLmpzb24g5pivIFJFU1Qg5o6l5Y+j77yM5ZON5bqU5L2T5rKh5pyJIGlkX3N0ciDlrZfmrrXjgIJcbiAgICAvLyBiYWNrZ3JvdW5kIOmHjOeahCBmaW5kVmlld2VyU3VtbWFyeSDkvJrlm6DkuLogdXNlcklkPT09Jycg5LiOIHR3aWQgY29va2llIHVpZCDkuI3ljLnphY1cbiAgICAvLyDogIwgcmV0dXJuIG51bGzvvIzlr7zoh7Qgc2NyZWVuTmFtZSDku47mnKrooqvlhpnlhaUgY2hyb21lLnN0b3JhZ2UubG9jYWzjgIJcbiAgICAvLyDop6PlhrPmlrnlvI/vvJrnu5Xov4cgYmFja2dyb3VuZCDpk77ot6/vvIzlnKggQ29udGVudCBTY3JpcHQg6Ieq5bex55u05o6l5YaZ44CCXG4gICAgaWYgKGV2ZW50LmRhdGEudHlwZSA9PT0gJ1NJR05BTF9DQVBUVVJFRCcgJiYgZXZlbnQuZGF0YS5vcCA9PT0gJ3NldHRpbmdzLmpzb24nKSB7XG4gICAgICAgIGNvbnN0IGQgPSBldmVudC5kYXRhLmRhdGE7XG4gICAgICAgIGNvbnN0IHNjcmVlbk5hbWUgPSBkPy5zY3JlZW5fbmFtZTtcbiAgICAgICAgY29uc3QgdXNlcklkID0gZD8uaWRfc3RyIHx8IChkPy5pZCA/IFN0cmluZyhkLmlkKSA6IHVuZGVmaW5lZCk7XG4gICAgICAgIGlmIChzY3JlZW5OYW1lKSB7XG4gICAgICAgICAgICBjb25zdCB0b1N0b3JlID0geyBzY3JlZW5OYW1lIH07XG4gICAgICAgICAgICBpZiAodXNlcklkKVxuICAgICAgICAgICAgICAgIHRvU3RvcmUudXNlcklkID0gdXNlcklkO1xuICAgICAgICAgICAgY2hyb21lLnN0b3JhZ2UubG9jYWwuc2V0KHRvU3RvcmUpLnRoZW4oKCkgPT4ge1xuICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKGBbVHdlZXRDbGF3LUNTXSDinIUgc2NyZWVuTmFtZSBjYWNoZWQgZnJvbSBzZXR0aW5ncy5qc29uOiBAJHtzY3JlZW5OYW1lfWApO1xuICAgICAgICAgICAgfSkuY2F0Y2goKCkgPT4geyB9KTtcbiAgICAgICAgfVxuICAgIH1cbiAgICAvLyDilIDilIAg5o2V6I635bm257yT5a2YIHBlci1vcGVyYXRpb24gZmVhdHVyZXMg4pSA4pSAXG4gICAgaWYgKGV2ZW50LmRhdGEudHlwZSA9PT0gJ1NJR05BTF9DQVBUVVJFRCcgJiYgZXZlbnQuZGF0YS5mZWF0dXJlcykge1xuICAgICAgICBjb25zdCBvcCA9IGV2ZW50LmRhdGEub3A7XG4gICAgICAgIGNvbnN0IGZlYXR1cmVzID0gZXZlbnQuZGF0YS5mZWF0dXJlcztcbiAgICAgICAgLy8g5a+85YWlIGNhY2hlT3BlcmF0aW9uRmVhdHVyZXMg5bm257yT5a2YXG4gICAgICAgIGltcG9ydCgnLi4veF9hcGkvZmVhdHVyZV9tYW5hZ2VyJykudGhlbigoeyBjYWNoZU9wZXJhdGlvbkZlYXR1cmVzIH0pID0+IHtcbiAgICAgICAgICAgIGNhY2hlT3BlcmF0aW9uRmVhdHVyZXMob3AsIGZlYXR1cmVzKS5jYXRjaCgoKSA9PiB7IH0pO1xuICAgICAgICB9KTtcbiAgICB9XG4gICAgaWYgKGV2ZW50LmRhdGEudHlwZSA9PT0gJ1NJR05BTF9DQVBUVVJFRCcpIHtcbiAgICAgICAgY2hyb21lLnJ1bnRpbWUuc2VuZE1lc3NhZ2Uoe1xuICAgICAgICAgICAgdHlwZTogJ0NBUFRVUkVEX0RBVEEnLFxuICAgICAgICAgICAgb3A6IGV2ZW50LmRhdGEub3AsXG4gICAgICAgICAgICBhcGlVcmw6IGV2ZW50LmRhdGEuYXBpVXJsLCAvLyDihpAg55yf5a6eIEFQSSDnq6/ngrkgVVJMXG4gICAgICAgICAgICBwYWdlVXJsOiBldmVudC5kYXRhLnBhZ2VVcmwgfHwgd2luZG93LmxvY2F0aW9uLmhyZWYsIC8vIOKGkCDlvZPliY3pobXpnaIgVVJMXG4gICAgICAgICAgICBtZXRob2Q6IGV2ZW50LmRhdGEubWV0aG9kLFxuICAgICAgICAgICAgcmVxdWVzdEJvZHk6IGV2ZW50LmRhdGEucmVxdWVzdEJvZHksXG4gICAgICAgICAgICBiZWFyZXJUb2tlbjogZXZlbnQuZGF0YS5iZWFyZXJUb2tlbiB8fCBudWxsLCAvLyDihpAgYmVhcmVyIHRva2Vu77yI5aaC5bey5LuO6K+35rGC5aS05o2V6I6377yJXG4gICAgICAgICAgICBkYXRhOiBldmVudC5kYXRhLmRhdGFcbiAgICAgICAgfSk7XG4gICAgfVxuICAgIGlmIChldmVudC5kYXRhLnR5cGUgPT09ICdIT09LX1NUQVRVU19SRVBPUlQnKSB7XG4gICAgICAgIGNocm9tZS5ydW50aW1lLnNlbmRNZXNzYWdlKHtcbiAgICAgICAgICAgIHR5cGU6ICdSRVBPUlRfSE9PS19TVEFUVVMnLFxuICAgICAgICAgICAgc3RhdHVzOiBldmVudC5kYXRhLnN0YXR1c1xuICAgICAgICB9KTtcbiAgICB9XG59KTtcbmNocm9tZS5ydW50aW1lLm9uTWVzc2FnZS5hZGRMaXN0ZW5lcigobWVzc2FnZSwgc2VuZGVyLCBzZW5kUmVzcG9uc2UpID0+IHtcbiAgICBpZiAobWVzc2FnZS50eXBlID09PSBNc2dUeXBlLlBJTkcgfHwgbWVzc2FnZS50eXBlID09PSAnVENfUElORycpIHtcbiAgICAgICAgc2VuZFJlc3BvbnNlKHsgb2s6IHRydWUsIHVybDogd2luZG93LmxvY2F0aW9uLmhyZWYsIGNvbnRleHQ6ICdDT05URU5UX1NDUklQVCcgfSk7XG4gICAgICAgIHJldHVybiB0cnVlO1xuICAgIH1cbiAgICBpZiAobWVzc2FnZS50eXBlID09PSBNc2dUeXBlLkVYRUNVVEVfQUNUSU9OKSB7XG4gICAgICAgIGxldCBvcCA9ICcnO1xuICAgICAgICBsZXQgdmFycyA9IHsgdHdlZXRfaWQ6IG1lc3NhZ2UudHdlZXRJZCB9O1xuICAgICAgICBzd2l0Y2ggKG1lc3NhZ2UuYWN0aW9uKSB7XG4gICAgICAgICAgICBjYXNlICdsaWtlJzpcbiAgICAgICAgICAgICAgICBvcCA9ICdGYXZvcml0ZVR3ZWV0JztcbiAgICAgICAgICAgICAgICBicmVhaztcbiAgICAgICAgICAgIGNhc2UgJ3JldHdlZXQnOlxuICAgICAgICAgICAgICAgIG9wID0gJ0NyZWF0ZVJldHdlZXQnO1xuICAgICAgICAgICAgICAgIHZhcnMuZGFya19yZXF1ZXN0ID0gZmFsc2U7XG4gICAgICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgICAgICBjYXNlICdib29rbWFyayc6XG4gICAgICAgICAgICAgICAgb3AgPSAnQ3JlYXRlQm9va21hcmsnO1xuICAgICAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICAgICAgY2FzZSAnZm9sbG93JzpcbiAgICAgICAgICAgICAgICBvcCA9ICdDcmVhdGVGcmllbmRzaGlwJztcbiAgICAgICAgICAgICAgICB2YXJzID0geyB1c2VyX2lkOiBtZXNzYWdlLnVzZXJJZCB9O1xuICAgICAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICAgICAgY2FzZSAndW5mb2xsb3cnOlxuICAgICAgICAgICAgICAgIG9wID0gJ0Rlc3Ryb3lGcmllbmRzaGlwJztcbiAgICAgICAgICAgICAgICB2YXJzID0geyB1c2VyX2lkOiBtZXNzYWdlLnVzZXJJZCB9O1xuICAgICAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICAgICAgY2FzZSAncG9zdF90d2VldCc6XG4gICAgICAgICAgICAgICAgLy8g5Y+R5biD5paw5o6o5paHXG4gICAgICAgICAgICAgICAgb3AgPSAnQ3JlYXRlVHdlZXQnO1xuICAgICAgICAgICAgICAgIHZhcnMgPSB7XG4gICAgICAgICAgICAgICAgICAgIHR3ZWV0X3RleHQ6IG1lc3NhZ2UudGV4dCB8fCAnJyxcbiAgICAgICAgICAgICAgICAgICAgbWVkaWE6IHtcbiAgICAgICAgICAgICAgICAgICAgICAgIG1lZGlhX2VudGl0aWVzOiBbXSxcbiAgICAgICAgICAgICAgICAgICAgICAgIHBvc3NpYmx5X3NlbnNpdGl2ZTogZmFsc2VcbiAgICAgICAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgICAgICAgICAgc2VtYW50aWNfYW5ub3RhdGlvbl9pZHM6IFtdLFxuICAgICAgICAgICAgICAgICAgICBicm9hZGNhc3Q6IHRydWUsXG4gICAgICAgICAgICAgICAgICAgIGRpc2FsbG93ZWRfcmVwbHlfb3B0aW9uczogbnVsbFxuICAgICAgICAgICAgICAgIH07XG4gICAgICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgICAgICBjYXNlICdyZXBseV90d2VldCc6XG4gICAgICAgICAgICAgICAgLy8g5Zue5aSN5o6o5paHXG4gICAgICAgICAgICAgICAgb3AgPSAnQ3JlYXRlVHdlZXQnO1xuICAgICAgICAgICAgICAgIHZhcnMgPSB7XG4gICAgICAgICAgICAgICAgICAgIHR3ZWV0X3RleHQ6IG1lc3NhZ2UudGV4dCB8fCAnJyxcbiAgICAgICAgICAgICAgICAgICAgcmVwbHk6IHtcbiAgICAgICAgICAgICAgICAgICAgICAgIGluX3JlcGx5X3RvX3R3ZWV0X2lkOiBtZXNzYWdlLnR3ZWV0SWQsXG4gICAgICAgICAgICAgICAgICAgICAgICBleGNsdWRlX3JlcGx5X3VzZXJfaWRzOiBbXVxuICAgICAgICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgICAgICAgICBtZWRpYToge1xuICAgICAgICAgICAgICAgICAgICAgICAgbWVkaWFfZW50aXRpZXM6IFtdLFxuICAgICAgICAgICAgICAgICAgICAgICAgcG9zc2libHlfc2Vuc2l0aXZlOiBmYWxzZVxuICAgICAgICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgICAgICAgICBzZW1hbnRpY19hbm5vdGF0aW9uX2lkczogW10sXG4gICAgICAgICAgICAgICAgICAgIGJyb2FkY2FzdDogdHJ1ZSxcbiAgICAgICAgICAgICAgICAgICAgZGlzYWxsb3dlZF9yZXBseV9vcHRpb25zOiBudWxsXG4gICAgICAgICAgICAgICAgfTtcbiAgICAgICAgICAgICAgICBicmVhaztcbiAgICAgICAgICAgIGNhc2UgJ3VubGlrZSc6XG4gICAgICAgICAgICAgICAgb3AgPSAnVW5mYXZvcml0ZVR3ZWV0JztcbiAgICAgICAgICAgICAgICB2YXJzID0geyB0d2VldF9pZDogbWVzc2FnZS50d2VldElkIH07XG4gICAgICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgICAgICBjYXNlICd1bnJldHdlZXQnOlxuICAgICAgICAgICAgICAgIG9wID0gJ0RlbGV0ZVJldHdlZXQnO1xuICAgICAgICAgICAgICAgIHZhcnMgPSB7IHNvdXJjZV90d2VldF9pZDogbWVzc2FnZS50d2VldElkIH07XG4gICAgICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgICAgICBjYXNlICd1bmJvb2ttYXJrJzpcbiAgICAgICAgICAgICAgICBvcCA9ICdEZWxldGVCb29rbWFyayc7XG4gICAgICAgICAgICAgICAgdmFycyA9IHsgdHdlZXRfaWQ6IG1lc3NhZ2UudHdlZXRJZCB9O1xuICAgICAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICAgICAgY2FzZSAnZGVsZXRlX3R3ZWV0JzpcbiAgICAgICAgICAgICAgICBvcCA9ICdEZWxldGVUd2VldCc7XG4gICAgICAgICAgICAgICAgdmFycyA9IHsgdHdlZXRfaWQ6IG1lc3NhZ2UudHdlZXRJZCB9O1xuICAgICAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICB9XG4gICAgICAgIGlmIChvcCkge1xuICAgICAgICAgICAgLy8g6ZKI5a+5IEZvbGxvdy9VbmZvbGxvdyDnibnmrorlpITnkIbvvJrlpoLmnpzov5jmsqHmipPliLAgR3JhcGhRTCBIYXNo77yM55u05o6l6LWwIDEuMSBSRVNUIOmZjee6p+aWueahiFxuICAgICAgICAgICAgaWYgKG1lc3NhZ2UuYWN0aW9uID09PSAnZm9sbG93JyB8fCBtZXNzYWdlLmFjdGlvbiA9PT0gJ3VuZm9sbG93Jykge1xuICAgICAgICAgICAgICAgIGNvbnN0IHBhdGggPSBtZXNzYWdlLmFjdGlvbiA9PT0gJ2ZvbGxvdycgPyAnL2kvYXBpLzEuMS9mcmllbmRzaGlwcy9jcmVhdGUuanNvbicgOiAnL2kvYXBpLzEuMS9mcmllbmRzaGlwcy9kZXN0cm95Lmpzb24nO1xuICAgICAgICAgICAgICAgIC8vIOWwneivleaJp+ihjO+8jOWmguaenCBwZXJmb3JtTXV0YXRpb24g5oql6ZSZ6K+05piO5rKh5ZOI5biM77yM5oiR5Lus5bCx55u05o6l6LWwIGxlZ2FjeVxuICAgICAgICAgICAgICAgIHBlcmZvcm1NdXRhdGlvbihvcCwgdmFycylcbiAgICAgICAgICAgICAgICAgICAgLnRoZW4ocmVzID0+IHNlbmRSZXNwb25zZSh7IG9rOiB0cnVlLCBkYXRhOiByZXMgfSkpXG4gICAgICAgICAgICAgICAgICAgIC5jYXRjaCgoKSA9PiB7XG4gICAgICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKGBbVHdlZXRDbGF3LUNTXSDwn5SEIEZhbGxiYWNrIHRvIExlZ2FjeSBSRVNUOiAke3BhdGh9YCk7XG4gICAgICAgICAgICAgICAgICAgIHBlcmZvcm1MZWdhY3lSRVNUKHBhdGgsIHsgdXNlcl9pZDogbWVzc2FnZS51c2VySWQgfSlcbiAgICAgICAgICAgICAgICAgICAgICAgIC50aGVuKHJlcyA9PiBzZW5kUmVzcG9uc2UoeyBvazogdHJ1ZSwgZGF0YTogcmVzIH0pKVxuICAgICAgICAgICAgICAgICAgICAgICAgLmNhdGNoKGVyciA9PiBzZW5kUmVzcG9uc2UoeyBvazogZmFsc2UsIGVycm9yOiBlcnIubWVzc2FnZSB9KSk7XG4gICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICAgICAgcmV0dXJuIHRydWU7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBwZXJmb3JtTXV0YXRpb24ob3AsIHZhcnMpXG4gICAgICAgICAgICAgICAgLnRoZW4ocmVzID0+IHNlbmRSZXNwb25zZSh7IG9rOiB0cnVlLCBkYXRhOiByZXMgfSkpXG4gICAgICAgICAgICAgICAgLmNhdGNoKGVyciA9PiBzZW5kUmVzcG9uc2UoeyBvazogZmFsc2UsIGVycm9yOiBlcnIubWVzc2FnZSB9KSk7XG4gICAgICAgICAgICByZXR1cm4gdHJ1ZTtcbiAgICAgICAgfVxuICAgIH1cbiAgICBpZiAobWVzc2FnZS50eXBlID09PSAnRkVUQ0hfU0VUVElOR1NfQU5EX1BST0ZJTEUnKSB7XG4gICAgICAgIChhc3luYyAoKSA9PiB7XG4gICAgICAgICAgICB0cnkge1xuICAgICAgICAgICAgICAgIC8vIOesrOS4gOatpe+8muS7jiBzdG9yYWdlIOivuyBzY3JlZW5OYW1lXG4gICAgICAgICAgICAgICAgY29uc3Qgc3RvcmVkID0gYXdhaXQgY2hyb21lLnN0b3JhZ2UubG9jYWwuZ2V0KFsnc2NyZWVuTmFtZScsICd1c2VySWQnXSk7XG4gICAgICAgICAgICAgICAgbGV0IHNjcmVlbk5hbWUgPSBzdG9yZWQuc2NyZWVuTmFtZTtcbiAgICAgICAgICAgICAgICAvLyDnrKzkuozmraXvvJrlpoLmnpwgc3RvcmFnZSDph4zov5jmsqHmnInvvIhpbmplY3Rpb24g6L+Y5rKh5a6M5oiQ5oum5oiq77yJ77yMXG4gICAgICAgICAgICAgICAgLy8g55uR5ZCsIHBvc3RNZXNzYWdlIOacgOWkmuetieW+hSA0IOenku+8jOetiSBzZXR0aW5ncy5qc29uIOiiq+aLpuaIqlxuICAgICAgICAgICAgICAgIGlmICghc2NyZWVuTmFtZSkge1xuICAgICAgICAgICAgICAgICAgICBjb25zb2xlLmxvZygnW1R3ZWV0Q2xhdy1DU10gc2NyZWVuTmFtZSBub3QgaW4gc3RvcmFnZSwgd2FpdGluZyB1cCB0byA0cyBmb3IgaW5qZWN0aW9uLi4uJyk7XG4gICAgICAgICAgICAgICAgICAgIHNjcmVlbk5hbWUgPSBhd2FpdCBuZXcgUHJvbWlzZSgocmVzb2x2ZSkgPT4ge1xuICAgICAgICAgICAgICAgICAgICAgICAgY29uc3QgdGltZXIgPSBzZXRUaW1lb3V0KCgpID0+IHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB3aW5kb3cucmVtb3ZlRXZlbnRMaXN0ZW5lcignbWVzc2FnZScsIG9uTXNnKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICByZXNvbHZlKHVuZGVmaW5lZCk7XG4gICAgICAgICAgICAgICAgICAgICAgICB9LCA0MDAwKTtcbiAgICAgICAgICAgICAgICAgICAgICAgIGZ1bmN0aW9uIG9uTXNnKGUpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZiAoZS5kYXRhPy5zb3VyY2UgPT09ICd0d2VldGNsYXctaW5qZWN0aW9uJyAmJlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBlLmRhdGE/LnR5cGUgPT09ICdTSUdOQUxfQ0FQVFVSRUQnICYmXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGUuZGF0YT8ub3AgPT09ICdzZXR0aW5ncy5qc29uJyAmJlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBlLmRhdGE/LmRhdGE/LnNjcmVlbl9uYW1lKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsZWFyVGltZW91dCh0aW1lcik7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHdpbmRvdy5yZW1vdmVFdmVudExpc3RlbmVyKCdtZXNzYWdlJywgb25Nc2cpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb25zdCBzbiA9IGUuZGF0YS5kYXRhLnNjcmVlbl9uYW1lO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb25zdCB1aWQgPSBlLmRhdGEuZGF0YS5pZF9zdHIgfHxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIChlLmRhdGEuZGF0YS5pZCA/IFN0cmluZyhlLmRhdGEuZGF0YS5pZCkgOiB1bmRlZmluZWQpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb25zdCB0b1N0b3JlID0geyBzY3JlZW5OYW1lOiBzbiB9O1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZiAodWlkKVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdG9TdG9yZS51c2VySWQgPSB1aWQ7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNocm9tZS5zdG9yYWdlLmxvY2FsLnNldCh0b1N0b3JlKS5jYXRjaCgoKSA9PiB7IH0pO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICByZXNvbHZlKHNuKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICB3aW5kb3cuYWRkRXZlbnRMaXN0ZW5lcignbWVzc2FnZScsIG9uTXNnKTtcbiAgICAgICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIGlmICghc2NyZWVuTmFtZSlcbiAgICAgICAgICAgICAgICAgICAgdGhyb3cgbmV3IEVycm9yKCdzY3JlZW5OYW1lIG5vdCBmb3VuZCBpbiBzdG9yYWdlJyk7XG4gICAgICAgICAgICAgICAgY29uc29sZS5sb2coYFtUd2VldENsYXctQ1NdIEZldGNoaW5nIHByb2ZpbGUgZm9yIEAke3NjcmVlbk5hbWV9Li4uYCk7XG4gICAgICAgICAgICAgICAgY29uc3QganNvbiA9IGF3YWl0IGZldGNoVXNlckJ5U2NyZWVuTmFtZShzY3JlZW5OYW1lKTtcbiAgICAgICAgICAgICAgICAvLyDnlKjlrrnplJnpgJLlvZLop6PmnpDmi7/liLAgdXNlciByZXN1bHQg5a+56LGhXG4gICAgICAgICAgICAgICAgY29uc3QgdXNlclJlc3VsdCA9IGZpbmREZWVwVXNlcihqc29uKTtcbiAgICAgICAgICAgICAgICBpZiAoIXVzZXJSZXN1bHQpXG4gICAgICAgICAgICAgICAgICAgIHRocm93IG5ldyBFcnJvcignZmluZERlZXBVc2VyIHJldHVybmVkIG51bGwnKTtcbiAgICAgICAgICAgICAgICBzZW5kUmVzcG9uc2UoeyBzdWNjZXNzOiB0cnVlLCByYXc6IHVzZXJSZXN1bHQgfSk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBjYXRjaCAoZSkge1xuICAgICAgICAgICAgICAgIGNvbnNvbGUuZXJyb3IoJ1tUd2VldENsYXctQ1NdIEZFVENIX1NFVFRJTkdTX0FORF9QUk9GSUxFIGZhaWw6JywgZSk7XG4gICAgICAgICAgICAgICAgc2VuZFJlc3BvbnNlKHsgc3VjY2VzczogZmFsc2UsIGVycm9yOiBlLm1lc3NhZ2UgfSk7XG4gICAgICAgICAgICB9XG4gICAgICAgIH0pKCk7XG4gICAgICAgIHJldHVybiB0cnVlOyAvLyDkv53mjIHlvILmraUgc2VuZFJlc3BvbnNlIOmAmumBk1xuICAgIH1cbiAgICBpZiAobWVzc2FnZS50eXBlID09PSAnRkVUQ0hfVVNFUl9QUk9GSUxFX0JZX1NDUkVFTl9OQU1FJykge1xuICAgICAgICAoYXN5bmMgKCkgPT4ge1xuICAgICAgICAgICAgdHJ5IHtcbiAgICAgICAgICAgICAgICBjb25zdCBjbGVhbk5hbWUgPSBtZXNzYWdlLnNjcmVlbk5hbWUucmVwbGFjZSgnQCcsICcnKTtcbiAgICAgICAgICAgICAgICBjb25zdCBqc29uID0gYXdhaXQgZmV0Y2hVc2VyQnlTY3JlZW5OYW1lKGNsZWFuTmFtZSk7XG4gICAgICAgICAgICAgICAgY29uc3QgeyBmaW5kRGVlcFVzZXIgfSA9IGF3YWl0IGltcG9ydCgnLi4vY2FwdHVyZS9leHRyYWN0b3InKTtcbiAgICAgICAgICAgICAgICBjb25zdCB1c2VyUmVzdWx0ID0gZmluZERlZXBVc2VyKGpzb24pO1xuICAgICAgICAgICAgICAgIGlmICghdXNlclJlc3VsdClcbiAgICAgICAgICAgICAgICAgICAgdGhyb3cgbmV3IEVycm9yKCdVc2VyIG5vdCBmb3VuZCBvciB1bmF2YWlsYWJsZScpO1xuICAgICAgICAgICAgICAgIGNvbnN0IGxlZ2FjeSA9IHVzZXJSZXN1bHQ/LmxlZ2FjeSA/PyB7fTtcbiAgICAgICAgICAgICAgICBjb25zdCBkYXRhID0ge1xuICAgICAgICAgICAgICAgICAgICB1c2VySWQ6IHVzZXJSZXN1bHQ/LnJlc3RfaWQgfHwgJycsXG4gICAgICAgICAgICAgICAgICAgIHNjcmVlbk5hbWU6IGxlZ2FjeS5zY3JlZW5fbmFtZSB8fCAnJyxcbiAgICAgICAgICAgICAgICAgICAgbmFtZTogbGVnYWN5Lm5hbWUgfHwgJycsXG4gICAgICAgICAgICAgICAgICAgIGRlc2NyaXB0aW9uOiBsZWdhY3kuZGVzY3JpcHRpb24gfHwgJycsXG4gICAgICAgICAgICAgICAgICAgIGZvbGxvd2Vyc0NvdW50OiBsZWdhY3kuZm9sbG93ZXJzX2NvdW50LFxuICAgICAgICAgICAgICAgICAgICBmcmllbmRzQ291bnQ6IGxlZ2FjeS5mcmllbmRzX2NvdW50LFxuICAgICAgICAgICAgICAgICAgICBzdGF0dXNlc0NvdW50OiBsZWdhY3kuc3RhdHVzZXNfY291bnQsXG4gICAgICAgICAgICAgICAgICAgIHZlcmlmaWVkOiB1c2VyUmVzdWx0Py5pc19ibHVlX3ZlcmlmaWVkIHx8IGxlZ2FjeS52ZXJpZmllZCB8fCBmYWxzZSxcbiAgICAgICAgICAgICAgICAgICAgY3JlYXRlZEF0OiBsZWdhY3kuY3JlYXRlZF9hdCB8fCAnJyxcbiAgICAgICAgICAgICAgICAgICAgYXZhdGFyOiAobGVnYWN5LnByb2ZpbGVfaW1hZ2VfdXJsX2h0dHBzIHx8ICcnKS5yZXBsYWNlKCdfbm9ybWFsJywgJycpXG4gICAgICAgICAgICAgICAgfTtcbiAgICAgICAgICAgICAgICBzZW5kUmVzcG9uc2UoeyBzdWNjZXNzOiB0cnVlLCBkYXRhIH0pO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgY2F0Y2ggKGUpIHtcbiAgICAgICAgICAgICAgICBzZW5kUmVzcG9uc2UoeyBzdWNjZXNzOiBmYWxzZSwgZXJyb3I6IGUubWVzc2FnZSB9KTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfSkoKTtcbiAgICAgICAgcmV0dXJuIHRydWU7XG4gICAgfVxuICAgIHJldHVybiBmYWxzZTtcbn0pO1xuY29uc29sZS5sb2coJ1tUd2VldENsYXctQ1NdIEFjdGl2ZS4nKTtcbiJdLCJuYW1lcyI6W10sInNvdXJjZVJvb3QiOiIifQ==