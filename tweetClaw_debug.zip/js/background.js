/******/ (() => { // webpackBootstrap
/******/ 	"use strict";
/******/ 	var __webpack_modules__ = ({

/***/ "./src/bridge/instance-id.ts"
/*!***********************************!*\
  !*** ./src/bridge/instance-id.ts ***!
  \***********************************/
(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   getOrCreateInstanceId: () => (/* binding */ getOrCreateInstanceId)
/* harmony export */ });
/**
 * 获取或创建当前 Chrome Profile 的稳定唯一标识符。
 * 存储在 chrome.storage.local 中，Profile 隔离，重启后保持不变。
 * 仅在扩展被卸载后才会丢失（chrome.storage.local 随扩展数据清除）。
 */
const INSTANCE_ID_KEY = 'bridge.instanceId';
async function getOrCreateInstanceId() {
    try {
        const result = await chrome.storage.local.get(INSTANCE_ID_KEY);
        if (result[INSTANCE_ID_KEY] && typeof result[INSTANCE_ID_KEY] === 'string') {
            return result[INSTANCE_ID_KEY];
        }
        // 首次运行：生成新 UUID 并持久化
        const newId = crypto.randomUUID();
        await chrome.storage.local.set({ [INSTANCE_ID_KEY]: newId });
        console.log('[tweetClaw] generated new instanceId:', newId);
        return newId;
    }
    catch (e) {
        // 降级：返回空字符串，Server 端会生成 tmp- 前缀的临时 ID 兜底
        console.warn('[tweetClaw] failed to read/write storage for instanceId:', e);
        return '';
    }
}


/***/ },

/***/ "./src/bridge/local-bridge-socket.ts"
/*!*******************************************!*\
  !*** ./src/bridge/local-bridge-socket.ts ***!
  \*******************************************/
(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   LocalBridgeSocket: () => (/* binding */ LocalBridgeSocket)
/* harmony export */ });
/* harmony import */ var _ws_protocol__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./ws-protocol */ "./src/bridge/ws-protocol.ts");
/* harmony import */ var _instance_id__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./instance-id */ "./src/bridge/instance-id.ts");


class LocalBridgeSocket {
    constructor() {
        this.ws = null;
        this.reconnectAttempts = 0;
        this.reconnectTimer = null;
        this.heartbeatInterval = null;
        this.serverInfo = null;
        this.lastPongTimestamp = 0;
        this.instanceId = '';
        this.queryXTabsHandler = null;
        this.queryXBasicInfoHandler = null;
        this.openTabHandler = null;
        this.closeTabHandler = null;
        this.navigateTabHandler = null;
        this.execActionHandler = null;
        this.queryHomeTimelineHandler = null;
        this.queryTweetDetailHandler = null;
        this.queryUserProfileHandler = null;
        this.querySearchTimelineHandler = null;
        this.WS_URL = 'ws://127.0.0.1:10086/ws'; // Default
        this.isConnecting = false;
        this.connect();
    }
    // ── Public status accessors (used by popup) ──────────────────────
    isConnected() {
        return this.ws !== null && this.ws.readyState === WebSocket.OPEN;
    }
    getServerInfo() {
        return this.serverInfo;
    }
    getCurrentUrl() {
        return this.WS_URL;
    }
    reconnectWithNewPort(port) {
        console.log(`[tweetClaw] reconnecting to new port: ${port}`);
        this.WS_URL = `ws://127.0.0.1:${port}/ws`;
        this.isConnecting = false;
        if (this.reconnectTimer) {
            clearTimeout(this.reconnectTimer);
            this.reconnectTimer = null;
        }
        if (this.ws) {
            this.ws.onclose = null; // prevent standard reconnect loop
            this.ws.close();
            this.ws = null;
        }
        this.reconnectAttempts = 0;
        this.connect();
    }
    async connect() {
        if (this.isConnecting)
            return;
        if (this.ws && (this.ws.readyState === WebSocket.CONNECTING || this.ws.readyState === WebSocket.OPEN)) {
            return;
        }
        // Check dynamic port
        try {
            if (typeof chrome !== 'undefined' && chrome.storage) {
                const res = await chrome.storage.local.get('wsPort');
                if (res.wsPort) {
                    this.WS_URL = `ws://127.0.0.1:${res.wsPort}/ws`;
                }
            }
        }
        catch (e) {
            console.warn('[tweetClaw] failed to get dynamic port', e);
        }
        this.isConnecting = true;
        console.log(`[tweetClaw] websocket connecting to ${this.WS_URL}...`);
        try {
            this.ws = new WebSocket(this.WS_URL);
            this.ws.onopen = async () => {
                console.log('[tweetClaw] websocket open');
                this.isConnecting = false;
                this.reconnectAttempts = 0;
                this.lastPongTimestamp = Date.now();
                // 确保 instanceId 已加载（同一 Profile 内多次重连复用同一个值）
                if (!this.instanceId) {
                    this.instanceId = await (0,_instance_id__WEBPACK_IMPORTED_MODULE_1__.getOrCreateInstanceId)();
                }
                this.sendHello();
            };
            this.ws.onclose = () => {
                console.log('[tweetClaw] websocket closed');
                this.isConnecting = false;
                this.serverInfo = null;
                this.stopHeartbeat();
                this.scheduleReconnect();
            };
            this.ws.onerror = () => {
                // Use regular log to stay silent in Chrome extension error list
                console.log('[tweetClaw] connection notice: server offline');
                this.isConnecting = false;
            };
            this.ws.onmessage = (event) => {
                this.handleMessage(event.data);
            };
        }
        catch (e) {
            console.log('[tweetClaw] initialization notice:', e);
            this.isConnecting = false;
            this.scheduleReconnect();
        }
    }
    scheduleReconnect() {
        if (this.reconnectTimer)
            return;
        const delay = this.getReconnectDelay();
        console.log(`[tweetClaw] websocket reconnect scheduled in ${delay}ms`);
        this.reconnectTimer = setTimeout(() => {
            this.reconnectTimer = null;
            this.reconnectAttempts++;
            this.connect();
        }, delay);
    }
    getReconnectDelay() {
        switch (this.reconnectAttempts) {
            case 0: return 1000;
            case 1: return 2000;
            case 2: return 5000;
            default: return 10000;
        }
    }
    sendHello() {
        const hello = {
            id: `hello_${Date.now()}`,
            type: _ws_protocol__WEBPACK_IMPORTED_MODULE_0__.MESSAGE_TYPES.CLIENT_HELLO,
            source: 'tweetClaw',
            target: 'LocalBridgeMac',
            timestamp: Date.now(),
            payload: {
                protocolName: _ws_protocol__WEBPACK_IMPORTED_MODULE_0__.PROTOCOL_NAME,
                protocolVersion: _ws_protocol__WEBPACK_IMPORTED_MODULE_0__.PROTOCOL_VERSION,
                clientName: 'tweetClaw',
                clientVersion: '0.3.17',
                browser: 'chrome',
                capabilities: ['query_x_tabs_status', 'query_x_basic_info'],
                instanceId: this.instanceId || undefined, // 新增
                incognito: chrome.extension.inIncognitoContext // 新增
            }
        };
        this.send(hello);
    }
    handleMessage(data) {
        try {
            const msg = JSON.parse(data);
            console.log(`[tweetClaw] received message: ${msg.type}`);
            switch (msg.type) {
                case _ws_protocol__WEBPACK_IMPORTED_MODULE_0__.MESSAGE_TYPES.SERVER_HELLO_ACK:
                    this.handleHelloAck(msg);
                    break;
                case _ws_protocol__WEBPACK_IMPORTED_MODULE_0__.MESSAGE_TYPES.PONG:
                    console.log('[tweetClaw] received pong');
                    this.lastPongTimestamp = Date.now();
                    break;
                case _ws_protocol__WEBPACK_IMPORTED_MODULE_0__.MESSAGE_TYPES.REQUEST_QUERY_X_TABS_STATUS:
                    this.handleQueryXTabsStatus(msg);
                    break;
                case _ws_protocol__WEBPACK_IMPORTED_MODULE_0__.MESSAGE_TYPES.REQUEST_QUERY_X_BASIC_INFO:
                    this.handleQueryXBasicInfo(msg);
                    break;
                case _ws_protocol__WEBPACK_IMPORTED_MODULE_0__.MESSAGE_TYPES.REQUEST_OPEN_TAB:
                    this.handleOpenTab(msg);
                    break;
                case _ws_protocol__WEBPACK_IMPORTED_MODULE_0__.MESSAGE_TYPES.REQUEST_CLOSE_TAB:
                    this.handleCloseTab(msg);
                    break;
                case _ws_protocol__WEBPACK_IMPORTED_MODULE_0__.MESSAGE_TYPES.REQUEST_NAVIGATE_TAB:
                    this.handleNavigateTab(msg);
                    break;
                case _ws_protocol__WEBPACK_IMPORTED_MODULE_0__.MESSAGE_TYPES.REQUEST_EXEC_ACTION:
                    this.handleExecAction(msg);
                    break;
                case _ws_protocol__WEBPACK_IMPORTED_MODULE_0__.MESSAGE_TYPES.REQUEST_QUERY_HOME_TIMELINE:
                    this.handleGenericQuery(msg, this.queryHomeTimelineHandler, _ws_protocol__WEBPACK_IMPORTED_MODULE_0__.MESSAGE_TYPES.RESPONSE_QUERY_HOME_TIMELINE);
                    break;
                case _ws_protocol__WEBPACK_IMPORTED_MODULE_0__.MESSAGE_TYPES.REQUEST_QUERY_TWEET_DETAIL:
                    this.handleGenericQuery(msg, this.queryTweetDetailHandler, _ws_protocol__WEBPACK_IMPORTED_MODULE_0__.MESSAGE_TYPES.RESPONSE_QUERY_TWEET_DETAIL);
                    break;
                case _ws_protocol__WEBPACK_IMPORTED_MODULE_0__.MESSAGE_TYPES.REQUEST_QUERY_USER_PROFILE:
                    this.handleGenericQuery(msg, this.queryUserProfileHandler, _ws_protocol__WEBPACK_IMPORTED_MODULE_0__.MESSAGE_TYPES.RESPONSE_QUERY_USER_PROFILE);
                    break;
                case _ws_protocol__WEBPACK_IMPORTED_MODULE_0__.MESSAGE_TYPES.REQUEST_QUERY_SEARCH_TIMELINE:
                    this.handleGenericQuery(msg, this.querySearchTimelineHandler, _ws_protocol__WEBPACK_IMPORTED_MODULE_0__.MESSAGE_TYPES.RESPONSE_QUERY_SEARCH_TIMELINE);
                    break;
                default:
                    console.warn(`[tweetClaw] unknown message type: ${msg.type}`);
            }
        }
        catch (e) {
            console.error('[tweetClaw] failed to parse message:', e);
        }
    }
    handleHelloAck(msg) {
        console.log('[tweetClaw] received server.hello_ack');
        this.serverInfo = msg.payload;
        this.startHeartbeat(msg.payload.heartbeatIntervalMs || 20000);
    }
    async handleQueryXTabsStatus(req) {
        console.log('[tweetClaw] handling request.query_x_tabs_status');
        if (!this.queryXTabsHandler) {
            console.error('[tweetClaw] no handler for query_x_tabs_status');
            return;
        }
        try {
            const result = await this.queryXTabsHandler();
            const resp = {
                id: req.id,
                type: _ws_protocol__WEBPACK_IMPORTED_MODULE_0__.MESSAGE_TYPES.RESPONSE_QUERY_X_TABS_STATUS,
                source: 'tweetClaw',
                target: 'LocalBridgeMac',
                timestamp: Date.now(),
                payload: result
            };
            this.send(resp);
        }
        catch (e) {
            // Send an error response
            const errResp = {
                id: req.id,
                type: _ws_protocol__WEBPACK_IMPORTED_MODULE_0__.MESSAGE_TYPES.RESPONSE_ERROR,
                source: 'tweetClaw',
                target: 'LocalBridgeMac',
                timestamp: Date.now(),
                payload: {
                    code: 'INTERNAL_ERROR',
                    message: e instanceof Error ? e.message : String(e),
                    details: null
                }
            };
            this.send(errResp);
        }
    }
    async handleQueryXBasicInfo(req) {
        console.log('[tweetClaw] handling request.query_x_basic_info');
        if (!this.queryXBasicInfoHandler) {
            console.error('[tweetClaw] no handler for query_x_basic_info');
            return;
        }
        try {
            const result = await this.queryXBasicInfoHandler();
            const resp = {
                id: req.id,
                type: _ws_protocol__WEBPACK_IMPORTED_MODULE_0__.MESSAGE_TYPES.RESPONSE_QUERY_X_BASIC_INFO,
                source: 'tweetClaw',
                target: 'LocalBridgeMac',
                timestamp: Date.now(),
                payload: result
            };
            this.send(resp);
        }
        catch (e) {
            // Send an error response
            const errResp = {
                id: req.id,
                type: _ws_protocol__WEBPACK_IMPORTED_MODULE_0__.MESSAGE_TYPES.RESPONSE_ERROR,
                source: 'tweetClaw',
                target: 'LocalBridgeMac',
                timestamp: Date.now(),
                payload: {
                    code: 'INTERNAL_ERROR',
                    message: e instanceof Error ? e.message : String(e),
                    details: null
                }
            };
            this.send(errResp);
        }
    }
    async handleOpenTab(req) {
        console.log('[tweetClaw] handling request.open_tab');
        if (!this.openTabHandler) {
            console.error('[tweetClaw] no handler for open_tab');
            return;
        }
        try {
            const result = await this.openTabHandler(req.payload);
            const resp = {
                id: req.id,
                type: _ws_protocol__WEBPACK_IMPORTED_MODULE_0__.MESSAGE_TYPES.RESPONSE_OPEN_TAB,
                source: 'tweetClaw',
                target: 'LocalBridgeMac',
                timestamp: Date.now(),
                payload: result
            };
            this.send(resp);
        }
        catch (e) {
            const errResp = {
                id: req.id,
                type: _ws_protocol__WEBPACK_IMPORTED_MODULE_0__.MESSAGE_TYPES.RESPONSE_ERROR,
                source: 'tweetClaw',
                target: 'LocalBridgeMac',
                timestamp: Date.now(),
                payload: {
                    code: 'INTERNAL_ERROR',
                    message: e instanceof Error ? e.message : String(e),
                    details: null
                }
            };
            this.send(errResp);
        }
    }
    async handleCloseTab(req) {
        console.log('[tweetClaw] handling request.close_tab');
        if (!this.closeTabHandler) {
            console.error('[tweetClaw] no handler for close_tab');
            return;
        }
        try {
            const result = await this.closeTabHandler(req.payload);
            const resp = {
                id: req.id,
                type: _ws_protocol__WEBPACK_IMPORTED_MODULE_0__.MESSAGE_TYPES.RESPONSE_CLOSE_TAB,
                source: 'tweetClaw',
                target: 'LocalBridgeMac',
                timestamp: Date.now(),
                payload: result
            };
            this.send(resp);
        }
        catch (e) {
            const errResp = {
                id: req.id,
                type: _ws_protocol__WEBPACK_IMPORTED_MODULE_0__.MESSAGE_TYPES.RESPONSE_ERROR,
                source: 'tweetClaw',
                target: 'LocalBridgeMac',
                timestamp: Date.now(),
                payload: {
                    code: 'INTERNAL_ERROR',
                    message: e instanceof Error ? e.message : String(e),
                    details: null
                }
            };
            this.send(errResp);
        }
    }
    async handleNavigateTab(req) {
        console.log('[tweetClaw] handling request.navigate_tab');
        if (!this.navigateTabHandler) {
            console.error('[tweetClaw] no handler for navigate_tab');
            return;
        }
        try {
            const result = await this.navigateTabHandler(req.payload);
            const resp = {
                id: req.id,
                type: _ws_protocol__WEBPACK_IMPORTED_MODULE_0__.MESSAGE_TYPES.RESPONSE_NAVIGATE_TAB,
                source: 'tweetClaw',
                target: 'LocalBridgeMac',
                timestamp: Date.now(),
                payload: result
            };
            this.send(resp);
        }
        catch (e) {
            const errResp = {
                id: req.id,
                type: _ws_protocol__WEBPACK_IMPORTED_MODULE_0__.MESSAGE_TYPES.RESPONSE_ERROR,
                source: 'tweetClaw',
                target: 'LocalBridgeMac',
                timestamp: Date.now(),
                payload: {
                    code: 'INTERNAL_ERROR',
                    message: e instanceof Error ? e.message : String(e),
                    details: null
                }
            };
            this.send(errResp);
        }
    }
    async handleExecAction(req) {
        console.log('[tweetClaw] handling request.exec_action');
        if (!this.execActionHandler) {
            console.error('[tweetClaw] no handler for exec_action');
            return;
        }
        try {
            const result = await this.execActionHandler(req.payload);
            const resp = {
                id: req.id,
                type: _ws_protocol__WEBPACK_IMPORTED_MODULE_0__.MESSAGE_TYPES.RESPONSE_EXEC_ACTION,
                source: 'tweetClaw',
                target: 'LocalBridgeMac',
                timestamp: Date.now(),
                payload: result
            };
            this.send(resp);
        }
        catch (e) {
            const errResp = {
                id: req.id,
                type: _ws_protocol__WEBPACK_IMPORTED_MODULE_0__.MESSAGE_TYPES.RESPONSE_ERROR,
                source: 'tweetClaw',
                target: 'LocalBridgeMac',
                timestamp: Date.now(),
                payload: {
                    code: 'INTERNAL_ERROR',
                    message: e instanceof Error ? e.message : String(e),
                    details: null
                }
            };
            this.send(errResp);
        }
    }
    async handleGenericQuery(req, handler, responseType) {
        if (!handler) {
            console.error(`[tweetClaw] no handler for ${responseType}`);
            this.send({
                id: req.id,
                type: _ws_protocol__WEBPACK_IMPORTED_MODULE_0__.MESSAGE_TYPES.RESPONSE_ERROR,
                source: 'tweetClaw',
                target: 'LocalBridgeMac',
                timestamp: Date.now(),
                payload: { code: 'INTERNAL_ERROR', message: 'Handler not registered', details: null }
            });
            return;
        }
        try {
            const result = await handler(req.payload);
            this.send({
                id: req.id,
                type: responseType,
                source: 'tweetClaw',
                target: 'LocalBridgeMac',
                timestamp: Date.now(),
                payload: result
            });
        }
        catch (e) {
            this.send({
                id: req.id,
                type: _ws_protocol__WEBPACK_IMPORTED_MODULE_0__.MESSAGE_TYPES.RESPONSE_ERROR,
                source: 'tweetClaw',
                target: 'LocalBridgeMac',
                timestamp: Date.now(),
                payload: { code: 'INTERNAL_ERROR', message: e.message, details: null }
            });
        }
    }
    startHeartbeat(interval) {
        this.stopHeartbeat();
        console.log(`[tweetClaw] starting heartbeat every ${interval}ms`);
        this.heartbeatInterval = setInterval(() => {
            // Check for timeout (60 seconds)
            const now = Date.now();
            if (this.lastPongTimestamp > 0 && now - this.lastPongTimestamp > 60000) {
                console.error('[tweetClaw] pong timeout, closing socket');
                this.ws?.close();
                return;
            }
            this.sendPing();
        }, interval);
    }
    stopHeartbeat() {
        if (this.heartbeatInterval) {
            clearInterval(this.heartbeatInterval);
            this.heartbeatInterval = null;
        }
    }
    sendPing() {
        const ping = {
            id: `ping_${Date.now()}`,
            type: _ws_protocol__WEBPACK_IMPORTED_MODULE_0__.MESSAGE_TYPES.PING,
            source: 'tweetClaw',
            target: 'LocalBridgeMac',
            timestamp: Date.now(),
            payload: {
                heartbeatIntervalMs: 20000
            }
        };
        this.send(ping);
    }
    send(msg) {
        if (this.ws && this.ws.readyState === WebSocket.OPEN) {
            this.ws.send(JSON.stringify(msg));
            console.log(`[tweetClaw] sent message: ${msg.type}`);
        }
        else {
            console.warn(`[tweetClaw] cannot send message, socket status: ${this.ws?.readyState}`);
        }
    }
}


/***/ },

/***/ "./src/bridge/ws-protocol.ts"
/*!***********************************!*\
  !*** ./src/bridge/ws-protocol.ts ***!
  \***********************************/
(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   ERROR_CODES: () => (/* binding */ ERROR_CODES),
/* harmony export */   MESSAGE_TYPES: () => (/* binding */ MESSAGE_TYPES),
/* harmony export */   PROTOCOL_NAME: () => (/* binding */ PROTOCOL_NAME),
/* harmony export */   PROTOCOL_VERSION: () => (/* binding */ PROTOCOL_VERSION)
/* harmony export */ });
const PROTOCOL_NAME = 'aihub-localbridge';
const PROTOCOL_VERSION = 'v1';
const MESSAGE_TYPES = {
    CLIENT_HELLO: 'client.hello',
    SERVER_HELLO_ACK: 'server.hello_ack',
    PING: 'ping',
    PONG: 'pong',
    REQUEST_QUERY_X_TABS_STATUS: 'request.query_x_tabs_status',
    RESPONSE_QUERY_X_TABS_STATUS: 'response.query_x_tabs_status',
    REQUEST_QUERY_X_BASIC_INFO: 'request.query_x_basic_info',
    RESPONSE_QUERY_X_BASIC_INFO: 'response.query_x_basic_info',
    REQUEST_OPEN_TAB: 'request.open_tab',
    RESPONSE_OPEN_TAB: 'response.open_tab',
    REQUEST_CLOSE_TAB: 'request.close_tab',
    RESPONSE_CLOSE_TAB: 'response.close_tab',
    REQUEST_NAVIGATE_TAB: 'request.navigate_tab',
    RESPONSE_NAVIGATE_TAB: 'response.navigate_tab',
    REQUEST_EXEC_ACTION: 'request.exec_action',
    RESPONSE_EXEC_ACTION: 'response.exec_action',
    REQUEST_QUERY_HOME_TIMELINE: 'request.query_home_timeline',
    RESPONSE_QUERY_HOME_TIMELINE: 'response.query_home_timeline',
    REQUEST_QUERY_TWEET_DETAIL: 'request.query_tweet_detail',
    RESPONSE_QUERY_TWEET_DETAIL: 'response.query_tweet_detail',
    REQUEST_QUERY_USER_PROFILE: 'request.query_user_profile',
    RESPONSE_QUERY_USER_PROFILE: 'response.query_user_profile',
    REQUEST_QUERY_SEARCH_TIMELINE: 'request.query_search_timeline',
    RESPONSE_QUERY_SEARCH_TIMELINE: 'response.query_search_timeline',
    RESPONSE_ERROR: 'response.error',
};
const ERROR_CODES = {
    INVALID_JSON: 'INVALID_JSON',
    INVALID_MESSAGE_SHAPE: 'INVALID_MESSAGE_SHAPE',
    UNSUPPORTED_MESSAGE_TYPE: 'UNSUPPORTED_MESSAGE_TYPE',
    PROTOCOL_VERSION_MISMATCH: 'PROTOCOL_VERSION_MISMATCH',
    NOT_CONNECTED: 'NOT_CONNECTED',
    REQUEST_TIMEOUT: 'REQUEST_TIMEOUT',
    INTERNAL_ERROR: 'INTERNAL_ERROR',
};


/***/ },

/***/ "./src/capture/consts.ts"
/*!*******************************!*\
  !*** ./src/capture/consts.ts ***!
  \*******************************/
(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   MsgType: () => (/* binding */ MsgType),
/* harmony export */   __DBK_bearer_token: () => (/* binding */ __DBK_bearer_token),
/* harmony export */   __DBK_dynamic_features: () => (/* binding */ __DBK_dynamic_features),
/* harmony export */   __DBK_query_id_map: () => (/* binding */ __DBK_query_id_map),
/* harmony export */   defaultQueryKeyMap: () => (/* binding */ defaultQueryKeyMap),
/* harmony export */   isGuestHandle: () => (/* binding */ isGuestHandle),
/* harmony export */   watchedOps: () => (/* binding */ watchedOps)
/* harmony export */ });
const __DBK_query_id_map = 'tc_query_id_map';
const __DBK_bearer_token = 'tc_bearer_token';
const __DBK_dynamic_features = 'tc_dynamic_features';
var MsgType;
(function (MsgType) {
    MsgType["PING"] = "PING";
    MsgType["EXECUTE_ACTION"] = "EXECUTE_ACTION";
})(MsgType || (MsgType = {}));
const watchedOps = [
    'UserTweets',
    'HomeTimeline',
    'HomeLatestTimeline',
    'TweetDetail',
    'UserByScreenName',
    'ProfileSpotlightsQuery',
    'AccountSettings',
    'AuthenticatedUserQuery',
    'Viewer',
    'VerifyCredentials',
    'CreateFriendship',
    'DestroyFriendship',
    'CreateBookmark',
    'DeleteBookmark',
    'Followers',
    'Following',
    'SearchTimeline',
    'FavoriteTweet',
    'UnfavoriteTweet',
    'CreateRetweet',
    'DeleteRetweet',
    'ListLatestTweetsTimeline',
    'TimelineHome',
    'AccountUserQuery',
    'UserByRestId',
    'CreateTweet', // 新增：发推文（含回复）
    'DeleteTweet', // 新增：删除推文
    'DeleteRetweet' // 新增：取消转发
];
const defaultQueryKeyMap = {
    'UserByScreenName': 'ck5KkZ8t5cOmoLssopN99Q',
    'UserTweets': 'E8Wq-_jFSaU7hxVcuOPR9g',
    'HomeLatestTimeline': 'SFxmNKWfN9ySJcXG_tjX8g',
    'HomeTimeline': 'DXmgQYmIft1oLP6vMkJixw',
    'TweetDetail': 'iFEr5AcP121Og4wx9Yqo3w',
    'SearchTimeline': '4fpceYZ6-YQCx_JSl_Cn_A',
    'CreateBookmark': 'aoDbu3RHznuiSkQ9aNM67Q',
    'DeleteBookmark': 'Wlmlj2-xzyS1GN3a6cj-mQ',
    'Following': 'SaWqzw0TFAWMx1nXWjXoaQ',
    'Followers': 'i6PPdIMm1MO7CpAqjau7sw',
    'FavoriteTweet': 'lI07N6Otwv1PhnEgXILM7A',
    'UnfavoriteTweet': 'ZYKSe-w7KEslx3JhSIk5LA',
    'CreateRetweet': 'mbRO74GrOvSfRcJnlMapnQ',
    'CreateFriendship': '66v9_S_vThhArew_99v9_v9',
    'DestroyFriendship': 'Opv7_p8AunMhJvD8X8c9rw',
    'UserByRestId': 'LJYI_VvTFAZf7PAdT0eWmA',
    'CreateTweet': 'zkcFc6F-RKRgWN8HUkJfZg', // 新增：已确认（2025-05）
    'DeleteTweet': 'nxpZCY2K-I6QoFHAHeojFQ', // 新增：已确认（2025-05）
    'DeleteRetweet': 'ZyZigVsNiFO6v1dEks1eWg' // 新增：已确认（2025-05）
};
/**
 * 识别 X 游客账号（Guest Token）
 *
 * X 的 guest token handle 特征：
 *   - 恰好 15 个字符
 *   - 全部是小写字母 + 数字（无大写字母、无下划线）
 *   - 含有至少一个数字
 *
 * 真实用户 handle 可以包含大写字母或下划线，不会被误判。
 * 例如误判案例：1DU1Gf7oElR2h28 → 含大写 → 不是 guest ✓
 */
function isGuestHandle(h) {
    if (!h)
        return false;
    const clean = h.startsWith('@') ? h.substring(1) : h;
    // Guest handles are random 15-char strings (e.g., 'xyz1234abc5678z' or '123456789012345')
    // Real users like 'web3bridgeninja' (15 chars, lowercase, 1 digit) are common false positives.
    if (clean.length !== 15 || !/^[a-z0-9]+$/.test(clean))
        return false;
    const digits = (clean.match(/\d/g) || []).length;
    const hasVowels = /[aeiou]/.test(clean);
    // Heuristics:
    // 1. All numeric is definitely a guest token
    if (/^\d+$/.test(clean))
        return true;
    // 2. Alphanumeric with high digit count (>= 3) and no vowels is very likely a guest
    if (digits >= 2 && !hasVowels)
        return true;
    // 3. Very high digit count (>= 5) is also a red flag even with vowels
    if (digits >= 5)
        return true;
    return false;
}


/***/ },

/***/ "./src/capture/extractor.ts"
/*!**********************************!*\
  !*** ./src/capture/extractor.ts ***!
  \**********************************/
(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   findDeepUser: () => (/* binding */ findDeepUser),
/* harmony export */   findFeaturedTweet: () => (/* binding */ findFeaturedTweet),
/* harmony export */   findProfileTweetsSnapshot: () => (/* binding */ findProfileTweetsSnapshot),
/* harmony export */   findRepliesSnapshot: () => (/* binding */ findRepliesSnapshot),
/* harmony export */   findScreenNameRecursive: () => (/* binding */ findScreenNameRecursive),
/* harmony export */   findTweetById: () => (/* binding */ findTweetById),
/* harmony export */   findViewerSummary: () => (/* binding */ findViewerSummary),
/* harmony export */   getOpName: () => (/* binding */ getOpName),
/* harmony export */   isTrustableIdentityOp: () => (/* binding */ isTrustableIdentityOp)
/* harmony export */ });
/* harmony import */ var _consts__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./consts */ "./src/capture/consts.ts");
/* harmony import */ var _timeline_extractor__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./timeline-extractor */ "./src/capture/timeline-extractor.ts");
/* harmony import */ var _utils_route_parser__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../utils/route-parser */ "./src/utils/route-parser.ts");



// ─────────────────────────────────────────────────────────────────────────────
// 仅受信任的 identity 操作（不接受普通用户主页 fetch 作为身份来源）
// ─────────────────────────────────────────────────────────────────────────────
const TRUSTED_IDENTITY_OPS = new Set([
    'AuthenticatedUserQuery',
    'Viewer',
    'AccountSettings',
    'settings.json',
    'VerifyCredentials'
]);
function isTrustableIdentityOp(op) {
    return TRUSTED_IDENTITY_OPS.has(op);
}
// ─────────────────────────────────────────────────────────────────────────────
// getOpName: 从 API URL 解析 operationName
// ─────────────────────────────────────────────────────────────────────────────
function getOpName(url) {
    if (!url)
        return null;
    // GraphQL: /i/api/graphql/{queryId}/{OperationName}[?...]
    const gqlMatch = url.match(/\/graphql\/[^\/]+\/([^?&/\s]+)/);
    if (gqlMatch)
        return gqlMatch[1];
    // REST 1.1 特殊映射
    if (url.includes('/account/settings.json'))
        return 'settings.json';
    if (url.includes('/account/verify_credentials.json'))
        return 'VerifyCredentials';
    return null;
}
// ─────────────────────────────────────────────────────────────────────────────
// findScreenNameRecursive: 递归搜索 screen_name（非 guest）
// ─────────────────────────────────────────────────────────────────────────────
function findScreenNameRecursive(obj, depth = 0) {
    if (!obj || typeof obj !== 'object' || depth > 6)
        return null;
    if (typeof obj.screen_name === 'string' && !(0,_consts__WEBPACK_IMPORTED_MODULE_0__.isGuestHandle)(obj.screen_name)) {
        return obj.screen_name;
    }
    for (const key of Object.keys(obj)) {
        const val = obj[key];
        if (val && typeof val === 'object') {
            const found = findScreenNameRecursive(val, depth + 1);
            if (found)
                return found;
        }
    }
    return null;
}
function findViewerSummary(data, targetUid) {
    if (!data)
        return null;
    const extract = (obj) => {
        if (!obj || !obj.legacy)
            return null;
        const handle = obj.legacy.screen_name;
        const userId = obj.rest_id;
        if (!handle)
            return null;
        // Safety: If it matches our confirmed UID (from twid cookie), it's the user, not a guest
        const isActuallyViewer = targetUid && userId === targetUid;
        if ((0,_consts__WEBPACK_IMPORTED_MODULE_0__.isGuestHandle)(handle) && !isActuallyViewer)
            return null;
        if (targetUid && userId !== targetUid)
            return null;
        return {
            handle: `@${handle}`,
            userId: userId,
            displayName: obj.legacy.name,
            verified: obj.legacy.verified || false,
            description: obj.legacy.description,
            avatar: obj.legacy.profile_image_url_https,
            followersCount: obj.legacy.followers_count,
            friendsCount: obj.legacy.friends_count,
            statusesCount: obj.legacy.statuses_count,
            createdAt: obj.legacy.created_at,
            raw: obj // 附加原始对象
        };
    };
    // 1. v1.1 REST 扁平结构（settings.json / verify_credentials.json）
    //    settings.json 仅在登录后可见，里面的 handle 只要存在就是真实的
    if (data.screen_name) {
        const userId = data.id_str || data.id?.toString() || '';
        const isActuallyViewer = targetUid && userId === targetUid;
        if ((0,_consts__WEBPACK_IMPORTED_MODULE_0__.isGuestHandle)(data.screen_name) && !isActuallyViewer)
            return null;
        if (targetUid && userId !== targetUid)
            return null; // 确保 UID 匹配
        return {
            handle: `@${data.screen_name}`,
            userId: userId,
            displayName: data.name || data.screen_name || '', // 确保 displayName 不为空
            verified: data.verified || false,
            description: data.description,
            avatar: data.profile_image_url_https,
            followersCount: data.followers_count,
            friendsCount: data.friends_count,
            statusesCount: data.statuses_count,
            createdAt: data.created_at,
            raw: data // 附加原始数据
        };
    }
    const u = findDeepUser(data);
    if (u) {
        console.log('[TweetClaw-Extractor] findDeepUser found valid user object');
        const summary = extract(u);
        if (summary)
            return summary;
    }
    console.warn('[TweetClaw-Extractor] findViewerSummary failed to find any valid user block in data:', {
        hasData: !!data,
        keys: Object.keys(data || {}),
        targetUid
    });
    return null;
}
// ─────────────────────────────────────────────────────────────────────────────
// findFeaturedTweet: 从响应体中提取一条代表性推文（用于 debug / quick action）
// ─────────────────────────────────────────────────────────────────────────────
function findFeaturedTweet(data, pageUrl) {
    try {
        const tweets = (0,_timeline_extractor__WEBPACK_IMPORTED_MODULE_1__.extractTweetsFromTimeline)(data);
        if (tweets.length === 0)
            return null;
        // 如果提供了 pageUrl，尝试匹配 status ID (用于 tweet_detail 场景选中主推文)
        const targetId = pageUrl ? (0,_utils_route_parser__WEBPACK_IMPORTED_MODULE_2__.extractTweetId)(pageUrl) : null;
        let best = targetId ? tweets.find(t => t.tweetId === targetId) : null;
        // 如果没找到匹配的，或者不是详情页，选第一个
        if (!best) {
            best = tweets[0];
        }
        if (!best)
            return null;
        return {
            id: best.tweetId,
            text: best.text || '',
            authorHandle: best.authorHandle || '',
            authorName: best.authorName || '',
            authorId: best.authorId || '',
            createdAt: best.createdAt || '',
            likeCount: best.likeCount ?? 0,
            replyCount: best.replyCount ?? 0,
            repostCount: best.repostCount ?? 0,
            bookmarkCount: best.bookmarkCount ?? 0
        };
    }
    catch (e) {
        console.warn('[TweetClaw-Extractor] Error in findFeaturedTweet', e);
    }
    return null;
}
/**
 * 寻找响应体中特定 ID 的推文
 * 用于当当前 URL 与已缓存的 featuredTweet 不匹配时，重新从原始响应中找回主推文
 */
function findTweetById(data, tweetId) {
    try {
        const tweets = (0,_timeline_extractor__WEBPACK_IMPORTED_MODULE_1__.extractTweetsFromTimeline)(data);
        const match = tweets.find(t => t.tweetId === tweetId);
        if (!match)
            return null;
        return {
            id: match.tweetId,
            text: match.text || '',
            authorHandle: match.authorHandle || '',
            authorName: match.authorName || '',
            authorId: match.authorId || '',
            createdAt: match.createdAt || '',
            likeCount: match.likeCount ?? 0,
            replyCount: match.replyCount ?? 0,
            repostCount: match.repostCount ?? 0,
            bookmarkCount: match.bookmarkCount ?? 0
        };
    }
    catch (e) {
        console.warn('[TweetClaw-Extractor] Error in findTweetById', e);
    }
    return null;
}
/**
 * 从响应体中提取回复列表（快照）
 */
function findRepliesSnapshot(data, pageUrl, activeAccountHandle) {
    try {
        const tweets = (0,_timeline_extractor__WEBPACK_IMPORTED_MODULE_1__.extractTweetsFromTimeline)(data);
        if (tweets.length === 0)
            return [];
        const targetId = pageUrl ? (0,_utils_route_parser__WEBPACK_IMPORTED_MODULE_2__.extractTweetId)(pageUrl) : null;
        // 过滤逻辑：
        // 1. 排除主推文 (targetId)
        // 2. 这里的 tweets 是拍平的列表，TimelineAddEntries 里的顺序通常就是回复顺序
        // 3. 结果中可能包含主推文本身（如果有的话），我们要排除它
        const replies = tweets.filter(t => t.tweetId !== targetId);
        // 去重
        const seen = new Set();
        const unique = [];
        for (const t of replies) {
            if (!seen.has(t.tweetId)) {
                seen.add(t.tweetId);
                unique.push(t);
            }
        }
        return unique.map(t => ({
            tweetId: t.tweetId,
            authorHandle: t.authorHandle,
            authorName: t.authorName,
            authorId: t.authorId,
            text: t.text,
            createdAt: t.createdAt,
            likeCount: t.likeCount,
            replyCount: t.replyCount,
            repostCount: t.repostCount,
            isByActiveAccount: activeAccountHandle ? t.authorHandle === activeAccountHandle : false
        }));
    }
    catch (e) {
        console.warn('[TweetClaw-Extractor] Error in findRepliesSnapshot', e);
    }
    return [];
}
/**
 * 从响应体中提取 Profile 场景下的推文列表（快照）
 */
function findProfileTweetsSnapshot(data, activeAccountHandle) {
    try {
        const tweets = (0,_timeline_extractor__WEBPACK_IMPORTED_MODULE_1__.extractTweetsFromTimeline)(data);
        if (tweets.length === 0)
            return [];
        // 去重
        const seen = new Set();
        const unique = [];
        for (const t of tweets) {
            if (!seen.has(t.tweetId)) {
                seen.add(t.tweetId);
                unique.push(t);
            }
        }
        return unique.map(t => ({
            tweetId: t.tweetId,
            authorHandle: t.authorHandle,
            authorName: t.authorName,
            text: t.text,
            createdAt: t.createdAt,
            likeCount: t.likeCount,
            replyCount: t.replyCount,
            repostCount: t.repostCount,
            isOwnedByActiveAccount: activeAccountHandle ? t.authorHandle === activeAccountHandle : false
        }));
    }
    catch (e) {
        console.warn('[TweetClaw-Extractor] Error in findProfileTweetsSnapshot', e);
    }
    return [];
}
/**
 * 递归在任意深度的 JSON 对象中找到 Twitter User 结果对象。
 * 兼容 UserByScreenName / UserByRestId 等多种响应结构变体。
 */
function findDeepUser(obj, depth = 0) {
    if (!obj || typeof obj !== 'object' || depth > 8)
        return null;
    // 命中条件：是一个有 rest_id 且 __typename 为 User 的对象
    if (obj.__typename === 'User' && obj.rest_id)
        return obj;
    // 优先尝试语义路径
    const priorityKeys = ['result', 'user', 'user_result', 'data'];
    for (const key of priorityKeys) {
        if (obj[key]) {
            const found = findDeepUser(obj[key], depth + 1);
            if (found)
                return found;
        }
    }
    // 兜底：遍历所有 key
    for (const key of Object.keys(obj)) {
        if (priorityKeys.includes(key))
            continue; // 已处理
        const found = findDeepUser(obj[key], depth + 1);
        if (found)
            return found;
    }
    return null;
}


/***/ },

/***/ "./src/capture/timeline-extractor.ts"
/*!*******************************************!*\
  !*** ./src/capture/timeline-extractor.ts ***!
  \*******************************************/
(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   extractTweetsFromTimeline: () => (/* binding */ extractTweetsFromTimeline)
/* harmony export */ });
/**
 * Timeline Extraction Logic
 * Robust version for Author Handle, Interaction Stats, Media, and Quotes.
 */
/**
 * Recursively searches for the 'instructions' array.
 */
function findInstructionsRecursive(obj) {
    if (!obj || typeof obj !== 'object')
        return null;
    if (Array.isArray(obj.instructions))
        return obj.instructions;
    for (const key in obj) {
        if (typeof obj[key] === 'object' && obj[key] !== null) {
            const found = findInstructionsRecursive(obj[key]);
            if (found)
                return found;
        }
    }
    return null;
}
/**
 * Extracts a list of normalized tweets from any Timeline-like GraphQL response.
 * Works for Home, Search, and TweetDetail (Thread).
 */
function extractTweetsFromTimeline(json) {
    const tweets = [];
    try {
        const instructions = findInstructionsRecursive(json) || [];
        for (const instr of instructions) {
            if (instr.type === 'TimelineAddEntries' || instr.type === 'TimelineReplaceEntry') {
                const entries = instr.entries || (instr.entry ? [instr.entry] : []);
                for (const entry of entries) {
                    // Normal Item
                    const result = entry?.content?.itemContent?.tweet_results?.result
                        || entry?.content?.content?.tweet_results?.result;
                    if (result) {
                        const tweet = parseTweetResult(result);
                        if (tweet) {
                            tweets.push(tweet);
                        }
                    }
                    // Module Items (Common in TweetDetail for replies)
                    const items = entry?.content?.items;
                    if (Array.isArray(items)) {
                        for (const item of items) {
                            const itemResult = item.item?.itemContent?.tweet_results?.result;
                            if (itemResult) {
                                const t = parseTweetResult(itemResult);
                                if (t)
                                    tweets.push(t);
                            }
                        }
                    }
                }
            }
        }
    }
    catch (e) {
        console.warn('[TweetClaw-Extractor] Error in extractTweetsFromTimeline', e);
    }
    return tweets;
}
/**
 * Normalizes a single Tweet result from X's GraphQL response.
 * Supports recursion for Quote Tweets (1 level deep).
 */
function parseTweetResult(result, depth = 0) {
    let data = result;
    // Handle nested results
    if (data.tweet)
        data = data.tweet;
    if (data.result)
        data = data.result;
    if (!data || !data.legacy)
        return null;
    // Handle Retweets: Prefer original tweet for text, metrics, and author if available
    let legacy = data.legacy;
    let core = data.core;
    const retweetedResult = data.retweeted_status_result?.result || legacy.retweeted_status_result?.result;
    if (retweetedResult) {
        const rLegacy = retweetedResult.legacy || retweetedResult.tweet?.legacy;
        const rCore = retweetedResult.core || retweetedResult.tweet?.core;
        if (rLegacy)
            legacy = rLegacy;
        if (rCore)
            core = rCore;
    }
    // 1. Author Info
    let authorHandle = 'unknown';
    let authorName = 'unknown';
    const userResult = core?.user_results?.result;
    const userLegacy = userResult?.legacy || userResult?.user?.legacy || userResult?.user_results?.result?.legacy || data.core?.user_results?.result?.legacy;
    if (userLegacy?.screen_name) {
        authorHandle = `@${userLegacy.screen_name}`;
        authorName = userLegacy.name || authorHandle;
    }
    else {
        const foundHandle = findFirstScreenName(data) || findFirstScreenName(core);
        if (foundHandle)
            authorHandle = `@${foundHandle}`;
        const foundName = findFirstAuthorName(data) || findFirstAuthorName(core);
        if (foundName)
            authorName = foundName;
    }
    // 2. Interaction Metrics
    const tweet = {
        tweetId: legacy.id_str || data.rest_id,
        authorHandle,
        authorName,
        authorId: userResult?.rest_id || 'unknown',
        text: legacy.full_text || '',
        createdAt: legacy.created_at || null,
        replyCount: legacy.reply_count ?? data.reply_count ?? null,
        repostCount: legacy.retweet_count ?? legacy.repost_count ?? data.retweet_count ?? null,
        likeCount: legacy.favorite_count ?? data.favorite_count ?? null,
        bookmarkCount: legacy.bookmark_count ?? data.bookmark_count ?? null,
    };
    // 3. Media Extraction (Photos, Videos, GIFs)
    const mediaItems = legacy.extended_entities?.media || legacy.entities?.media || [];
    if (mediaItems.length > 0) {
        tweet.media = mediaItems.map((m) => {
            const item = {
                type: m.type === 'photo' ? 'photo' : (m.type === 'video' ? 'video' : (m.type === 'animated_gif' ? 'animated_gif' : 'unknown')),
                url: m.media_url_https,
                width: m.original_info?.width,
                height: m.original_info?.height,
            };
            if (m.video_info) {
                item.duration_ms = m.video_info.duration_ms;
                if (m.video_info.variants) {
                    item.variant_urls = m.video_info.variants
                        .filter((v) => v.url)
                        .map((v) => v.url);
                }
            }
            return item;
        });
        tweet.media_count = tweet.media?.length || 0;
    }
    // 4. Quote Tweet Expansion (Limit depth to 1)
    if (depth === 0) {
        const quotedResult = data.quoted_status_result || legacy.quoted_status_result;
        if (quotedResult) {
            const quotedTweet = parseTweetResult(quotedResult, 1);
            if (quotedTweet) {
                tweet.quoted_tweet = quotedTweet;
            }
        }
    }
    return tweet;
}
/**
 * Helper to find the first screen_name in a user-related sub-object.
 */
function findFirstScreenName(obj) {
    if (!obj || typeof obj !== 'object')
        return null;
    if (obj.screen_name)
        return obj.screen_name;
    for (const key in obj) {
        if (obj.hasOwnProperty(key)) {
            const found = findFirstScreenName(obj[key]);
            if (found)
                return found;
        }
    }
    return null;
}
/**
 * Helper to find the first 'name' in a user-related sub-object.
 */
function findFirstAuthorName(obj) {
    if (!obj || typeof obj !== 'object')
        return null;
    if (obj.name)
        return obj.name;
    for (const key in obj) {
        if (obj.hasOwnProperty(key)) {
            const found = findFirstAuthorName(obj[key]);
            if (found)
                return found;
        }
    }
    return null;
}


/***/ },

/***/ "./src/utils/entity-resolver.ts"
/*!**************************************!*\
  !*** ./src/utils/entity-resolver.ts ***!
  \**************************************/
(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   resolveTweetEntity: () => (/* binding */ resolveTweetEntity)
/* harmony export */ });
/* harmony import */ var _route_parser__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./route-parser */ "./src/utils/route-parser.ts");

function resolveTweetEntity(url, featuredTweet, activeAccountHandle) {
    const tweetId = (0,_route_parser__WEBPACK_IMPORTED_MODULE_0__.extractTweetId)(url);
    if (!tweetId)
        return null;
    let entity = {
        entityType: 'tweet',
        entityId: tweetId,
        authorHandle: null,
        authorName: null,
        authorId: null,
        text: null,
        createdAt: null,
        likeCount: null,
        replyCount: null,
        retweetCount: null,
        bookmarkCount: null,
        isOwnedByActiveAccount: false,
        source: 'url_only'
    };
    if (featuredTweet && (featuredTweet.id === tweetId || !featuredTweet.id)) {
        // Alignment with extractor fields
        entity.authorHandle = featuredTweet.authorHandle || null;
        entity.authorName = featuredTweet.authorName || null;
        entity.authorId = featuredTweet.authorId || null;
        entity.text = featuredTweet.text || null;
        entity.createdAt = featuredTweet.createdAt || null;
        entity.likeCount = featuredTweet.likeCount ?? null;
        entity.replyCount = featuredTweet.replyCount ?? null;
        entity.retweetCount = featuredTweet.repostCount ?? null;
        entity.bookmarkCount = featuredTweet.bookmarkCount ?? null;
        entity.source = 'merged';
    }
    if (activeAccountHandle && entity.authorHandle) {
        const cleanActive = activeAccountHandle.replace('@', '').toLowerCase();
        const cleanAuthor = entity.authorHandle.replace('@', '').toLowerCase();
        entity.isOwnedByActiveAccount = cleanActive === cleanAuthor;
    }
    return entity;
}


/***/ },

/***/ "./src/utils/route-parser.ts"
/*!***********************************!*\
  !*** ./src/utils/route-parser.ts ***!
  \***********************************/
(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   extractTweetId: () => (/* binding */ extractTweetId),
/* harmony export */   parseRouteKind: () => (/* binding */ parseRouteKind)
/* harmony export */ });
function parseRouteKind(url) {
    if (!url || !(url.includes('x.com') || url.includes('twitter.com')))
        return 'none';
    try {
        const u = new URL(url);
        const path = u.pathname;
        if (path === '/home' || path === '/')
            return 'home';
        if (path.includes('/search'))
            return 'search';
        if (path.includes('/status/'))
            return 'thread';
        if (path.includes('/notifications'))
            return 'notification';
        return 'profile';
    }
    catch {
        return 'unknown';
    }
}
function extractTweetId(url) {
    if (!url)
        return null;
    try {
        const u = new URL(url);
        const match = u.pathname.match(/\/status\/(\d+)/);
        return match ? match[1] : null;
    }
    catch {
        return null;
    }
}


/***/ },

/***/ "./src/utils/scene-parser.ts"
/*!***********************************!*\
  !*** ./src/utils/scene-parser.ts ***!
  \***********************************/
(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   derivePageContext: () => (/* binding */ derivePageContext)
/* harmony export */ });
/* harmony import */ var _route_parser__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./route-parser */ "./src/utils/route-parser.ts");
/* harmony import */ var _entity_resolver__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./entity-resolver */ "./src/utils/entity-resolver.ts");


function derivePageContext(url, hasSession, isLoggedIn = false, featuredTweet = null, activeAccountHandle = null) {
    if (!url) {
        return {
            scene: 'no_tab',
            routeKind: 'none',
            currentUrl: '',
            entityType: null,
            entityId: null,
            availableActions: ['open_x_tab'],
            currentEntity: null
        };
    }
    const routeKind = (0,_route_parser__WEBPACK_IMPORTED_MODULE_0__.parseRouteKind)(url);
    if (routeKind === 'none') {
        return {
            scene: 'not_x',
            routeKind: 'none',
            currentUrl: url,
            entityType: null,
            entityId: null,
            availableActions: ['open_x_tab'],
            currentEntity: null
        };
    }
    if (!isLoggedIn) {
        return {
            scene: 'login_required',
            routeKind,
            currentUrl: url,
            entityType: null,
            entityId: null,
            availableActions: ['open_x_tab', 'refresh_session'],
            currentEntity: null
        };
    }
    let scene = 'unknown_x_scene';
    let actions = [];
    let currentEntity = null;
    switch (routeKind) {
        case 'home':
            scene = 'home';
            actions = ['read_home_timeline'];
            break;
        case 'profile':
            scene = 'profile';
            actions = ['list_profile_tweets'];
            break;
        case 'thread':
            scene = 'tweet_detail';
            actions = ['get_current_tweet', 'list_tweet_replies', 'like_tweet', 'repost_tweet', 'reply_to_tweet'];
            currentEntity = (0,_entity_resolver__WEBPACK_IMPORTED_MODULE_1__.resolveTweetEntity)(url, featuredTweet, activeAccountHandle);
            break;
        case 'search':
            scene = 'search';
            actions = ['search_tweets'];
            break;
        case 'notification':
            scene = 'notification';
            actions = ['read_notifications'];
            break;
    }
    // If identity is unresolved but we are on a known scene, prioritize the scene.
    // If we are on an unknown scene and identity is unresolved, use identity_resolving.
    let finalScene = scene;
    if (!hasSession && isLoggedIn && scene === 'unknown_x_scene') {
        finalScene = 'identity_resolving';
    }
    return {
        scene: finalScene,
        routeKind,
        currentUrl: url,
        entityType: currentEntity ? currentEntity.entityType : null,
        entityId: currentEntity ? currentEntity.entityId : (0,_route_parser__WEBPACK_IMPORTED_MODULE_0__.extractTweetId)(url),
        availableActions: actions.length > 0 ? actions : (finalScene === 'identity_resolving' ? ['refresh_session'] : []),
        currentEntity
    };
}


/***/ }

/******/ 	});
/************************************************************************/
/******/ 	// The module cache
/******/ 	var __webpack_module_cache__ = {};
/******/ 	
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/ 		// Check if module is in cache
/******/ 		var cachedModule = __webpack_module_cache__[moduleId];
/******/ 		if (cachedModule !== undefined) {
/******/ 			return cachedModule.exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = __webpack_module_cache__[moduleId] = {
/******/ 			// no module.id needed
/******/ 			// no module.loaded needed
/******/ 			exports: {}
/******/ 		};
/******/ 	
/******/ 		// Execute the module function
/******/ 		if (!(moduleId in __webpack_modules__)) {
/******/ 			delete __webpack_module_cache__[moduleId];
/******/ 			var e = new Error("Cannot find module '" + moduleId + "'");
/******/ 			e.code = 'MODULE_NOT_FOUND';
/******/ 			throw e;
/******/ 		}
/******/ 		__webpack_modules__[moduleId](module, module.exports, __webpack_require__);
/******/ 	
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/ 	
/************************************************************************/
/******/ 	/* webpack/runtime/define property getters */
/******/ 	(() => {
/******/ 		// define getter functions for harmony exports
/******/ 		__webpack_require__.d = (exports, definition) => {
/******/ 			for(var key in definition) {
/******/ 				if(__webpack_require__.o(definition, key) && !__webpack_require__.o(exports, key)) {
/******/ 					Object.defineProperty(exports, key, { enumerable: true, get: definition[key] });
/******/ 				}
/******/ 			}
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/hasOwnProperty shorthand */
/******/ 	(() => {
/******/ 		__webpack_require__.o = (obj, prop) => (Object.prototype.hasOwnProperty.call(obj, prop))
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/make namespace object */
/******/ 	(() => {
/******/ 		// define __esModule on exports
/******/ 		__webpack_require__.r = (exports) => {
/******/ 			if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 				Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 			}
/******/ 			Object.defineProperty(exports, '__esModule', { value: true });
/******/ 		};
/******/ 	})();
/******/ 	
/************************************************************************/
var __webpack_exports__ = {};
// This entry needs to be wrapped in an IIFE because it needs to be isolated against other modules in the chunk.
(() => {
/*!****************************************!*\
  !*** ./src/service_work/background.ts ***!
  \****************************************/
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   closeXTab: () => (/* binding */ closeXTab),
/* harmony export */   execAction: () => (/* binding */ execAction),
/* harmony export */   navigateXTab: () => (/* binding */ navigateXTab),
/* harmony export */   openXTab: () => (/* binding */ openXTab),
/* harmony export */   queryHomeTimeline: () => (/* binding */ queryHomeTimeline),
/* harmony export */   querySearchTimeline: () => (/* binding */ querySearchTimeline),
/* harmony export */   queryTweetDetail: () => (/* binding */ queryTweetDetail),
/* harmony export */   queryUserProfile: () => (/* binding */ queryUserProfile),
/* harmony export */   queryXBasicInfo: () => (/* binding */ queryXBasicInfo),
/* harmony export */   queryXTabsStatus: () => (/* binding */ queryXTabsStatus)
/* harmony export */ });
/* harmony import */ var _capture_consts__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../capture/consts */ "./src/capture/consts.ts");
/* harmony import */ var _capture_extractor__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../capture/extractor */ "./src/capture/extractor.ts");
/* harmony import */ var _utils_scene_parser__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../utils/scene-parser */ "./src/utils/scene-parser.ts");
/* harmony import */ var _utils_route_parser__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../utils/route-parser */ "./src/utils/route-parser.ts");
/* harmony import */ var _bridge_local_bridge_socket__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../bridge/local-bridge-socket */ "./src/bridge/local-bridge-socket.ts");





// Initialize LocalBridge WebSocket Client
const localBridge = new _bridge_local_bridge_socket__WEBPACK_IMPORTED_MODULE_4__.LocalBridgeSocket();
localBridge.queryXTabsHandler = queryXTabsStatus;
localBridge.queryXBasicInfoHandler = queryXBasicInfo;
localBridge.openTabHandler = openXTab;
localBridge.closeTabHandler = closeXTab;
localBridge.navigateTabHandler = navigateXTab;
localBridge.execActionHandler = execAction;
localBridge.queryHomeTimelineHandler = queryHomeTimeline;
localBridge.queryTweetDetailHandler = queryTweetDetail;
localBridge.queryUserProfileHandler = queryUserProfile;
localBridge.querySearchTimelineHandler = querySearchTimeline;
let tabDataStore = new Map();
// ── 持久化 ──────────────────────────────────────────────────────────
function saveStore() {
    const obj = Object.fromEntries(tabDataStore);
    chrome.storage.local.set({ '_tc_v4_store': obj });
}
chrome.storage.local.get('_tc_v4_store').then(res => {
    if (res._tc_v4_store) {
        tabDataStore = new Map(Object.entries(res._tc_v4_store).map(([k, v]) => [parseInt(k), v]));
    }
});
// ── 初始化默认哈希表 ───────────────────────────────────────────────
async function initDefaultQueryKeys() {
    const res = await chrome.storage.local.get(_capture_consts__WEBPACK_IMPORTED_MODULE_0__.__DBK_query_id_map);
    let map = (res[_capture_consts__WEBPACK_IMPORTED_MODULE_0__.__DBK_query_id_map] || {});
    let changed = false;
    for (const [op, id] of Object.entries(_capture_consts__WEBPACK_IMPORTED_MODULE_0__.defaultQueryKeyMap)) {
        if (!map[op]) {
            map[op] = id;
            changed = true;
        }
    }
    if (changed) {
        await chrome.storage.local.set({ [_capture_consts__WEBPACK_IMPORTED_MODULE_0__.__DBK_query_id_map]: map });
        console.log("%c[TweetClaw-BG] 🛠️ Default QueryIDs initialized/updated.", "color:#cbd5e0; font-style:italic");
    }
}
// 首次运行或安装时初始化
chrome.runtime.onInstalled.addListener(() => {
    initDefaultQueryKeys();
    console.log("%c[TweetClaw-BG] 🚀 Extension installed/updated.", "color:#1DA1F2; font-weight:bold");
});
async function getAuthenticUid() {
    return new Promise(resolve => {
        chrome.cookies.get({ url: 'https://x.com', name: 'twid' }, cookie => {
            if (cookie?.value) {
                const decoded = decodeURIComponent(cookie.value);
                const match = decoded.match(/u=(\d+)/);
                resolve(match ? match[1] : decoded);
            }
            else {
                resolve(null);
            }
        });
    });
}
function getOrCreateState(tabId, url = '') {
    let state = tabDataStore.get(tabId);
    if (!state) {
        state = {
            id: tabId, url, lastOp: 'initialized',
            data: {}, apiHits: [], stats: {},
            account: null, featuredTweet: null, repliesSnapshot: [],
            profileTweetsSnapshot: [], uid: null,
            timestamp: Date.now(), lastBgSync: Date.now()
        };
        tabDataStore.set(tabId, state);
    }
    return state;
}
/**
 * 重置指定 Tab 的 Session 相关数据（用于登出或 Session 失效）
 */
function invalidateTabSession(tabId) {
    const state = tabDataStore.get(tabId);
    if (state) {
        state.account = null;
        state.uid = null;
        state.featuredTweet = null;
        state.repliesSnapshot = [];
        state.profileTweetsSnapshot = [];
        state.apiHits = [];
        state.stats = {};
        state.data = {};
        state.lastOp = 'session_invalidated';
        saveStore();
        notifyDebugPages(tabId, 'STATUS');
        console.log(`[TweetClaw-BG] 🔒 Session invalidated for tab ${tabId}`);
    }
}
/**
 * 重置全局 Session（用于全局登出）
 */
function invalidateAllSessions() {
    for (const tabId of tabDataStore.keys()) {
        const state = tabDataStore.get(tabId);
        if (state) {
            state.account = null;
            state.uid = null;
            state.featuredTweet = null;
            state.repliesSnapshot = [];
            state.profileTweetsSnapshot = [];
            state.apiHits = [];
            state.stats = {};
            state.data = {};
            state.lastOp = 'session_cleared';
            notifyDebugPages(tabId, 'STATUS');
        }
    }
    saveStore();
    console.log('[TweetClaw-BG] 🔒 Global session invalidated');
}
/**
 * 通知所有已打开的 debug tab 有数据更新。
 * debug tab 的 URL 匹配 chrome-extension://.../debug.html
 */
function notifyDebugPages(xTabId, type) {
    chrome.tabs.query({ url: chrome.runtime.getURL('debug.html') }).then(debugTabs => {
        for (const dt of debugTabs) {
            if (dt.id) {
                chrome.tabs.sendMessage(dt.id, {
                    type: 'DEBUG_UPDATE_PUSH',
                    updateType: type,
                    tabId: xTabId
                }).catch(() => { });
            }
        }
    }).catch(() => {
        // 若 debug 页未打开则静默忽略
    });
}
async function harvestQueryId(op, apiUrl) {
    if (!apiUrl)
        return;
    const match = apiUrl.match(/\/graphql\/([^/?#\s]+)\/([^/?#\s]+)/);
    if (!match)
        return;
    const [, queryId, opFromUrl] = match;
    const key = op || opFromUrl;
    if (!key || !queryId)
        return;
    const res = await chrome.storage.local.get(_capture_consts__WEBPACK_IMPORTED_MODULE_0__.__DBK_query_id_map);
    const map = (res[_capture_consts__WEBPACK_IMPORTED_MODULE_0__.__DBK_query_id_map] || {});
    if (map[key] !== queryId) {
        map[key] = queryId;
        await chrome.storage.local.set({ [_capture_consts__WEBPACK_IMPORTED_MODULE_0__.__DBK_query_id_map]: map });
        console.log(`%c[TweetClaw-BG] 🎯 HARVEST SUCCESS (Hook): ${key} → ${queryId}`, "color:#4ade80; font-weight:bold; border:1px solid #4ade80; padding:2px 4px; border-radius:4px;");
    }
}
async function harvestBearer(bearer) {
    if (!bearer || !bearer.startsWith('Bearer '))
        return;
    const res = await chrome.storage.local.get(_capture_consts__WEBPACK_IMPORTED_MODULE_0__.__DBK_bearer_token);
    if (res[_capture_consts__WEBPACK_IMPORTED_MODULE_0__.__DBK_bearer_token] !== bearer) {
        await chrome.storage.local.set({ [_capture_consts__WEBPACK_IMPORTED_MODULE_0__.__DBK_bearer_token]: bearer });
        console.log('[TweetClaw-BG] ✅ Harvested bearer token');
    }
}
// ── 移除旧的 action.onClicked ──────────────────────────────
// 已交由 popup 控制
// ── 消息中枢 ─────────────────────────────────────────────────────────
//
// 重要架构说明：
//   sender.tab 只对 content script 消息有值。
//   debug 页面是 extension page，sender.tab === undefined。
//   因此 tabId guard 不能全局提前，必须按消息类型分别处理。
//
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    // ── WS_PORT_CHANGED 配置更新 ───────────────────────────────────
    if (message.type === 'WS_PORT_CHANGED') {
        localBridge.reconnectWithNewPort(message.port);
        if (sendResponse)
            sendResponse({ ok: true });
        return;
    }
    // ── GET_BRIDGE_STATUS: popup queries live connection state ────────
    if (message.type === 'GET_BRIDGE_STATUS') {
        const connected = localBridge.isConnected();
        const serverInfo = localBridge.getServerInfo();
        const wsUrl = localBridge.getCurrentUrl();
        if (sendResponse)
            sendResponse({ connected, serverInfo, wsUrl });
        return true;
    }
    // ── 来自 content script 的 API 拦截数据 ────────────────────────
    if (message.type === 'CAPTURED_DATA') {
        const tabId = sender.tab?.id;
        if (!tabId)
            return; // 必须来自 content script
        (async () => {
            const state = getOrCreateState(tabId, message.pageUrl);
            const confirmedUid = await getAuthenticUid();
            state.lastOp = message.op;
            state.url = message.pageUrl || state.url;
            // 每个 op 只保留最新一份数据（覆盖旧的）
            state.data[message.op] = message.data;
            // 核心改进：对于详情页，额外按 tweetId 缓存一份，防止在 thread 中深入跳转时覆盖掉主贴数据
            if (message.op === 'TweetDetail' && message.pageUrl) {
                const focalId = (0,_utils_route_parser__WEBPACK_IMPORTED_MODULE_3__.extractTweetId)(message.pageUrl);
                if (focalId) {
                    state.data[`TweetDetail_${focalId}`] = message.data;
                }
            }
            state.lastBgSync = Date.now();
            if (!state.stats[message.op])
                state.stats[message.op] = { count: 0, lastHit: 0 };
            state.stats[message.op].count++;
            state.stats[message.op].lastHit = Date.now();
            // 去除非重复的同名 op，保持网格界面清爽，每个 op 只留最新一次记录，方便调试
            state.apiHits = state.apiHits.filter(h => h.op !== message.op);
            // 加入最新的记录
            state.apiHits.unshift({
                op: message.op,
                apiUrl: message.apiUrl || '',
                pageUrl: message.pageUrl || '',
                method: message.method || 'POST',
                timestamp: Date.now(),
                requestBody: message.requestBody,
                responseBody: message.data
            });
            // 最多保留 30 种不同 op 的详情
            if (state.apiHits.length > 30)
                state.apiHits.pop();
            // 身份提取
            const summary = (0,_capture_extractor__WEBPACK_IMPORTED_MODULE_1__.findViewerSummary)(message.data, confirmedUid || undefined);
            if (summary) {
                state.account = { ...state.account, ...summary };
                state.uid = summary.userId;
                // 将最新身份写入会话级全局存储，确保其他所有模块能快速访问
                chrome.storage.session.set({
                    '_tc_global_session_account': {
                        ...summary,
                        _updatedAt: Date.now()
                    }
                }).catch(() => { });
                // 同时保存到 local storage 供 content script fetch 使用
                chrome.storage.local.set({
                    screenName: summary.handle.replace('@', ''),
                    userId: summary.userId
                }).catch(() => { });
            }
            // 推文提取
            const tweet = (0,_capture_extractor__WEBPACK_IMPORTED_MODULE_1__.findFeaturedTweet)(message.data, message.pageUrl);
            if (tweet) {
                state.featuredTweet = tweet;
                // 当提取到新的主推文时，同时提取一次回复快照
                state.repliesSnapshot = (0,_capture_extractor__WEBPACK_IMPORTED_MODULE_1__.findRepliesSnapshot)(message.data, message.pageUrl, state.account?.handle);
            }
            else if (message.op === 'TweetDetail') {
                // 特殊场景：如果是 TweetDetail 响应但没找到主推文（可能网络包只有回复），也尝试提取
                const snapshot = (0,_capture_extractor__WEBPACK_IMPORTED_MODULE_1__.findRepliesSnapshot)(message.data, message.pageUrl, state.account?.handle);
                if (snapshot.length > 0)
                    state.repliesSnapshot = snapshot;
            }
            // Profile 推文快照提取
            if (message.op === 'UserTweets' || message.op === 'UserTweetsAndReplies') {
                const newProfileTweets = (0,_capture_extractor__WEBPACK_IMPORTED_MODULE_1__.findProfileTweetsSnapshot)(message.data, state.account?.handle);
                if (newProfileTweets.length > 0) {
                    // 如果 URL 指向不同的 profile，则清除旧快照（简单根据路径名判断）
                    const currentProfile = state.url.split('?')[0].split('/').filter(Boolean).pop();
                    const lastProfile = (state.data['last_profile_handle'] || '');
                    if (currentProfile && currentProfile !== lastProfile) {
                        state.profileTweetsSnapshot = [];
                        state.data['last_profile_handle'] = currentProfile;
                    }
                    const existingMap = new Map((state.profileTweetsSnapshot || []).map(t => [t.tweetId, t]));
                    for (const t of newProfileTweets) {
                        existingMap.set(t.tweetId, t);
                    }
                    // 将 Map 转回数组，保留在列表中的顺序
                    state.profileTweetsSnapshot = Array.from(existingMap.values());
                }
            }
            // 自动收割
            await harvestQueryId(message.op, message.apiUrl);
            await harvestBearer(message.bearerToken);
            saveStore();
            notifyDebugPages(tabId, 'DATA');
        })();
        return; // 异步，不需要 return true（不使用 sendResponse）
    }
    // ── 来自 content script 的 hook 状态上报 ───────────────────────
    if (message.type === 'REPORT_HOOK_STATUS') {
        const tabId = sender.tab?.id;
        if (!tabId)
            return;
        const state = getOrCreateState(tabId);
        state.hookStatus = message.status;
        state.lastBgSync = Date.now();
        saveStore();
        notifyDebugPages(tabId, 'STATUS');
        return;
    }
    // ── 以下消息来自 debug 页面（sender.tab 为 undefined）─────────
    // 查询所有 x.com tab 列表
    if (message.type === 'LIST_ALL_X_TABS') {
        chrome.tabs.query({ url: ['*://twitter.com/*', '*://x.com/*'] }).then(tabs => {
            const result = tabs.map(t => {
                const s = tabDataStore.get(t.id);
                return {
                    id: t.id,
                    url: t.url || s?.url || '',
                    active: t.active,
                    lastOp: s?.lastOp || 'pending',
                    account: s?.account || null,
                    hookStatus: s?.hookStatus || null,
                    lastBgSync: s?.lastBgSync || 0
                };
            });
            sendResponse(result);
        });
        return true; // 异步 sendResponse
    }
    if (message.type === 'CREATE_X_TAB') {
        chrome.tabs.create({ url: message.url || 'https://x.com/' }).then(tab => {
            sendResponse({ ok: true, tabId: tab.id });
        }).catch(err => {
            sendResponse({ ok: false, error: err.message });
        });
        return true;
    }
    if (message.type === 'FOCUS_X_TAB') {
        chrome.tabs.update(message.tabId, { active: true }).then(tab => {
            if (tab && tab.windowId) {
                chrome.windows.update(tab.windowId, { focused: true }).catch(() => { });
            }
            sendResponse({ ok: true });
        }).catch(err => {
            sendResponse({ ok: false, error: err.message });
        });
        return true;
    }
    if (message.type === 'CLOSE_X_TAB') {
        chrome.tabs.remove(message.tabId).then(() => {
            sendResponse({ ok: true });
        }).catch(err => {
            // If tab already closed, we consider it success for the intended state
            if (err.message.includes('No tab with id')) {
                sendResponse({ ok: true, warning: 'Tab already closed' });
            }
            else {
                sendResponse({ ok: false, error: err.message });
            }
        });
        return true;
    }
    if (message.type === 'NAVIGATE_X_TAB') {
        const { tabId, url } = message;
        if (!tabId || !url) {
            sendResponse({ ok: false, error: 'Missing tabId or url' });
            return true;
        }
        const isX = url.includes('x.com') || url.includes('twitter.com');
        if (!isX) {
            sendResponse({ ok: false, error: 'Navigation restricted to X domains' });
            return true;
        }
        chrome.tabs.update(tabId, { url }).then(() => {
            sendResponse({ ok: true, tabId, url });
        }).catch(err => {
            sendResponse({ ok: false, error: err.message });
        });
        return true;
    }
    // 查询指定 tab 的完整截获数据
    if (message.type === 'GET_TAB_DATA') {
        const tabId = message.tabId; // 必须由 debug 页面显式传入
        if (!tabId) {
            sendResponse(null);
            return true;
        }
        getAuthenticUid().then(uid => {
            let s = tabDataStore.get(tabId);
            // 如果实时的 cookie 已经没了，而内存里还觉得有账号，则触发失效
            if (!uid && s?.account) {
                invalidateTabSession(tabId);
                s = tabDataStore.get(tabId);
            }
            // 如果已经登录但 Last Op 还没更新（停留在 session 清理标记上），则标记为正在等待身份
            if (uid && s && (s.lastOp === 'session_cleared' || s.lastOp === 'session_invalidated')) {
                s.lastOp = 'awaiting_identity';
            }
            const data = s || {
                id: tabId,
                url: '',
                lastOp: 'unknown',
                data: {},
                apiHits: [],
                stats: {},
                account: null,
                featuredTweet: null,
                uid: null,
                timestamp: Date.now(),
                lastBgSync: 0
            };
            sendResponse({
                ...data,
                allWatchedOps: _capture_consts__WEBPACK_IMPORTED_MODULE_0__.watchedOps
            });
        });
        return true;
    }
    // 查询 session 状态（SessionManager 使用）
    if (message.type === 'GET_SESSION_STATUS') {
        const tabId = message.tabId || sender.tab?.id;
        if (!tabId) {
            sendResponse({ account: null, hookStatus: null, lastBgSync: 0 });
            return true;
        }
        const s = tabDataStore.get(tabId);
        sendResponse({
            account: s?.account || null,
            hookStatus: s?.hookStatus || null,
            lastBgSync: s?.lastBgSync || 0
        });
        return true;
    }
    // 获取当前页面 Scene 上下文
    if (message.type === 'GET_PAGE_CONTEXT') {
        const tabId = message.tabId || sender.tab?.id;
        if (!tabId) {
            sendResponse((0,_utils_scene_parser__WEBPACK_IMPORTED_MODULE_2__.derivePageContext)(undefined, false, false));
            return true;
        }
        getAuthenticUid().then(uid => {
            const isLoggedIn = !!uid;
            const s = tabDataStore.get(tabId);
            const hasSession = !!s?.account?.handle;
            const featuredTweet = s?.featuredTweet || null;
            const activeAccountHandle = s?.account?.handle || null;
            const repliesSnapshot = s?.repliesSnapshot || [];
            const profileTweetsSnapshot = s?.profileTweetsSnapshot || [];
            chrome.tabs.get(tabId).then(tab => {
                const currentUrl = tab.url || s?.url || '';
                const targetId = (0,_utils_route_parser__WEBPACK_IMPORTED_MODULE_3__.extractTweetId)(currentUrl);
                let featuredTweet = s?.featuredTweet || null;
                let repliesSnapshot = s?.repliesSnapshot || [];
                // 核心修复逻辑：
                // 如果当前是 tweet_detail 场景，尝试从缓存中找回与当前 URL 匹配的数据
                // 优先使用按 ID 索引的缓存，避免在 thread 中由于深入跳转导致的覆盖问题
                if (targetId) {
                    const cachedData = s?.data[`TweetDetail_${targetId}`] || s?.data['TweetDetail'];
                    if (cachedData) {
                        if (featuredTweet?.id !== targetId) {
                            const refitted = (0,_capture_extractor__WEBPACK_IMPORTED_MODULE_1__.findTweetById)(cachedData, targetId);
                            if (refitted) {
                                featuredTweet = refitted;
                                s.featuredTweet = refitted;
                            }
                        }
                        // 重新计算回复列表
                        repliesSnapshot = (0,_capture_extractor__WEBPACK_IMPORTED_MODULE_1__.findRepliesSnapshot)(cachedData, currentUrl, activeAccountHandle);
                        s.repliesSnapshot = repliesSnapshot;
                    }
                }
                sendResponse({
                    ...(0,_utils_scene_parser__WEBPACK_IMPORTED_MODULE_2__.derivePageContext)(currentUrl, hasSession, isLoggedIn, featuredTweet, activeAccountHandle),
                    repliesSnapshot,
                    profileTweetsSnapshot
                });
            }).catch(() => {
                const currentUrl = s?.url || '';
                const targetId = (0,_utils_route_parser__WEBPACK_IMPORTED_MODULE_3__.extractTweetId)(currentUrl);
                let featuredTweet = s?.featuredTweet || null;
                let repliesSnapshot = s?.repliesSnapshot || [];
                if (targetId) {
                    const cachedData = s?.data[`TweetDetail_${targetId}`] || s?.data['TweetDetail'];
                    if (cachedData) {
                        if (featuredTweet?.id !== targetId) {
                            const refitted = (0,_capture_extractor__WEBPACK_IMPORTED_MODULE_1__.findTweetById)(cachedData, targetId);
                            if (refitted) {
                                featuredTweet = refitted;
                                s.featuredTweet = refitted;
                            }
                        }
                        repliesSnapshot = (0,_capture_extractor__WEBPACK_IMPORTED_MODULE_1__.findRepliesSnapshot)(cachedData, currentUrl, activeAccountHandle);
                        s.repliesSnapshot = repliesSnapshot;
                    }
                }
                sendResponse({
                    ...(0,_utils_scene_parser__WEBPACK_IMPORTED_MODULE_2__.derivePageContext)(currentUrl, hasSession, isLoggedIn, featuredTweet, activeAccountHandle),
                    repliesSnapshot,
                    profileTweetsSnapshot
                });
            });
        });
        return true;
    }
    // 写操作代理（debug 页面 → background → content script 执行）
    if (message.type === 'EXEC_PROXY_ACTION') {
        const targetTabId = message.tabId;
        if (!targetTabId) {
            sendResponse({ ok: false, error: 'No tabId' });
            return true;
        }
        chrome.tabs.sendMessage(targetTabId, {
            type: _capture_consts__WEBPACK_IMPORTED_MODULE_0__.MsgType.EXECUTE_ACTION,
            action: message.action,
            tweetId: message.tweetId,
            userId: message.userId
        }).then(r => sendResponse(r))
            .catch(e => sendResponse({ ok: false, error: e.message }));
        return true;
    }
});
// ── tab 状态监听 ──────────────────────────────────────────────────
// 监听 URL 变化，确保 debug 页面能实时反映 routeKind 变化
chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
    if (changeInfo.url) {
        const url = changeInfo.url;
        const isX = url.includes('x.com') || url.includes('twitter.com');
        // 识别登出行为或登录流页面
        const isLogout = url.includes('/logout') || url.includes('/i/flow/login') || url.includes('?logged_out=1');
        if (isX) {
            const state = tabDataStore.get(tabId);
            if (state)
                state.url = url;
            if (isLogout) {
                invalidateTabSession(tabId);
            }
            else {
                notifyDebugPages(tabId, 'STATUS');
            }
        }
    }
});
// ── tab 关闭时清理内存（storage 里留着供 SW 重启恢复）─────────────
chrome.tabs.onRemoved.addListener(tabId => {
    tabDataStore.delete(tabId);
    saveStore();
    // 通知 debug 页面 tab 列表已变动
    notifyDebugPages(tabId, 'STATUS');
});
// ── Cookie 监听：捕捉登录状态变化 ──────────────────────────────────
chrome.cookies.onChanged.addListener((changeInfo) => {
    if (changeInfo.cookie.domain.includes('x.com') || changeInfo.cookie.domain.includes('twitter.com')) {
        if (changeInfo.cookie.name === 'twid') {
            if (changeInfo.removed) {
                // 再次确认是否真的没了（防止 X 在同一毫秒内更新 cookie 导致频繁清理）
                getAuthenticUid().then(uid => {
                    if (!uid) {
                        invalidateAllSessions();
                    }
                });
            }
            else {
                // Cookie 更新 -> 重新探测
                chrome.tabs.query({ url: ['*://twitter.com/*', '*://x.com/*'] }).then(tabs => {
                    for (const t of tabs) {
                        if (t.id)
                            notifyDebugPages(t.id, 'STATUS');
                    }
                });
            }
        }
    }
});
// ── 全局请求级 QueryID 及 Bearer 拦截（参照 TweetCat）────────────
chrome.webRequest.onBeforeSendHeaders.addListener((details) => {
    const headers = details.requestHeaders || [];
    const authHeader = headers.find(h => h.name.toLowerCase() === 'authorization');
    if (authHeader && authHeader.value?.startsWith('Bearer ')) {
        const token = authHeader.value;
        chrome.storage.local.get(_capture_consts__WEBPACK_IMPORTED_MODULE_0__.__DBK_bearer_token).then(res => {
            if (res[_capture_consts__WEBPACK_IMPORTED_MODULE_0__.__DBK_bearer_token] !== token) {
                chrome.storage.local.set({ [_capture_consts__WEBPACK_IMPORTED_MODULE_0__.__DBK_bearer_token]: token }).then(() => {
                    console.log("[TweetClaw-BG] 🌐 Global Intercept Update Bearer Token");
                });
            }
        });
    }
    return { requestHeaders: headers };
}, { urls: ["https://x.com/i/api/graphql/*"] }, ["requestHeaders"]);
chrome.webRequest.onBeforeRequest.addListener((details) => {
    const url = new URL(details.url);
    const match = url.pathname.match(/^\/i\/api\/graphql\/([^/]+)\/([^/]+)/);
    if (!match)
        return;
    const queryId = match[1];
    const operationName = match[2];
    if (!_capture_consts__WEBPACK_IMPORTED_MODULE_0__.watchedOps.includes(operationName)) {
        return;
    }
    chrome.storage.local.get(_capture_consts__WEBPACK_IMPORTED_MODULE_0__.__DBK_query_id_map).then(data => {
        const existingMap = data[_capture_consts__WEBPACK_IMPORTED_MODULE_0__.__DBK_query_id_map] || {};
        if (existingMap[operationName] !== queryId) {
            existingMap[operationName] = queryId;
            chrome.storage.local.set({ [_capture_consts__WEBPACK_IMPORTED_MODULE_0__.__DBK_query_id_map]: existingMap }).then(() => {
                console.log(`%c[TweetClaw-BG] 🛰️ GLOBAL INTERCEPT (WebRequest): ${operationName} → ${queryId}`, "color:#60a5fa; font-weight:bold; border:1px solid #60a5fa; padding:2px 4px; border-radius:4px;");
            });
        }
    });
    return {};
}, {
    urls: ["https://x.com/i/api/*"], // 扩大匹配范围到所有 API 子路径
    types: ["xmlhttprequest", "other", "ping"]
});
// ── 临时调试监听：捕捉一切非 GraphQL 的关注请求 ──────────────────────
chrome.webRequest.onBeforeRequest.addListener((details) => {
    const url = new URL(details.url);
    if (url.pathname.includes('friendships') || url.pathname.includes('follow')) {
        console.log(`%c[TweetClaw-DEBUG] 🔍 DETECTED POTENTIAL FOLLOW API: ${url.pathname}`, "color: #fbbf24; font-weight: bold;");
    }
    return {};
}, { urls: ["https://x.com/i/api/*"] });
// ── LocalBridge 业务逻辑 ──────────────────────────────────────────
async function queryXTabsStatus() {
    console.log('[TweetClaw-BG] queryXTabsStatus called');
    // 1. Query all X tabs
    const tabs = await chrome.tabs.query({ url: ["*://x.com/*", "*://twitter.com/*"] });
    // 2. Query active tab in current window
    const [activeTab] = await chrome.tabs.query({ active: true, currentWindow: true });
    // 3. Find if active tab is an X tab
    const isXTabNative = (url) => {
        if (!url)
            return false;
        return url.includes('x.com') || url.includes('twitter.com');
    };
    let activeXTabId = null;
    let activeXUrl = null;
    if (activeTab && isXTabNative(activeTab.url)) {
        activeXTabId = activeTab.id || null;
        activeXUrl = activeTab.url || null;
    }
    // 4. Check login status (twid cookie)
    const uid = await getAuthenticUid();
    const isLoggedIn = !!uid;
    // 5. Map tabs to XTabInfo
    const tabInfos = tabs.map(t => ({
        tabId: t.id || 0,
        url: t.url || '',
        active: t.active
    }));
    const payload = {
        hasXTabs: tabs.length > 0,
        isLoggedIn: isLoggedIn,
        activeXTabId: activeXTabId,
        activeXUrl: activeXUrl,
        tabs: tabInfos
    };
    console.log('[TweetClaw-BG] queryXTabsStatus result:', payload);
    return payload;
}
/**
 * 从 raw user result 对象中组装标准 profile（不依赖 findViewerSummary）
 */
function buildProfileFromRaw(raw, uid) {
    const legacy = raw?.legacy ?? {};
    // X 的 GraphQL 响应中，screen_name 和 name 可能在多个位置：
    // 1. legacy.screen_name （标准路径）
    // 2. core.screen_name （新版本 API 把基础字段收紧到 core 顶层）
    // 3. core.user_results.result.legacy.screen_name （嵌套引用）
    const screenName = legacy.screen_name ||
        raw?.core?.screen_name ||
        raw?.core?.user_results?.result?.legacy?.screen_name ||
        '';
    const name = legacy.name ||
        raw?.core?.name ||
        raw?.core?.user_results?.result?.legacy?.name ||
        screenName;
    const createdAt = legacy.created_at || raw?.core?.created_at || '';
    const avatar = legacy.profile_image_url_https
        // X 有时返回 _normal 缩略图，换成原图
        ? legacy.profile_image_url_https.replace('_normal', '')
        : undefined;
    return {
        isLoggedIn: true,
        twitterId: uid || raw?.rest_id || '',
        name,
        screenName: screenName ? `@${screenName}` : '',
        verified: raw?.is_blue_verified || legacy.verified || false,
        followersCount: legacy.followers_count,
        friendsCount: legacy.friends_count,
        statusesCount: legacy.statuses_count,
        avatar,
        description: legacy.description,
        createdAt,
        raw, // 完整原始数据透传给 Mac App
        updatedAt: Date.now()
    };
}
async function queryXBasicInfo() {
    console.log('[TweetClaw-BG] queryXBasicInfo called');
    // 1. 找活跃的 x.com 标签页
    const xTabs = await chrome.tabs.query({ url: ['*://x.com/*', '*://twitter.com/*'] });
    const targetTab = xTabs.find(t => t.active) || xTabs[0];
    if (!targetTab?.id)
        throw new Error('No active x.com tab found');
    const uid = await getAuthenticUid();
    // 2. 委托 Content Script 在页面上下文执行 fetchUserByScreenName
    console.log('[TweetClaw-BG] queryXBasicInfo: delegating to content script, tab', targetTab.id);
    const messagePromise = chrome.tabs.sendMessage(targetTab.id, {
        type: 'FETCH_SETTINGS_AND_PROFILE',
    }).catch((e) => {
        console.warn('[TweetClaw-BG] sendMessage error:', e?.message);
        return null;
    });
    const timeoutPromise = new Promise(resolve => setTimeout(() => resolve(null), 15000));
    const result = await Promise.race([messagePromise, timeoutPromise]);
    // 3. Content Script 成功返回
    if (result?.success && result?.raw) {
        console.log('[TweetClaw-BG] queryXBasicInfo: success from content script');
        return buildProfileFromRaw(result.raw, uid);
    }
    // 4. Fallback：tabDataStore 里找 uid 匹配 of UserByScreenName
    console.warn('[TweetClaw-BG] queryXBasicInfo: content script failed/timeout, trying tabDataStore fallback');
    if (uid) {
        const capturedData = tabDataStore.get(targetTab.id)?.data?.['UserByScreenName'];
        if (capturedData) {
            const rawFromStore = (0,_capture_extractor__WEBPACK_IMPORTED_MODULE_1__.findDeepUser)(capturedData);
            if (rawFromStore?.rest_id === uid) {
                console.log('[TweetClaw-BG] queryXBasicInfo: fallback ok from tabDataStore');
                return buildProfileFromRaw(rawFromStore, uid);
            }
            console.warn('[TweetClaw-BG] queryXBasicInfo: tabDataStore uid mismatch, skipping');
        }
    }
    // 5. 最终兜底：返回基础登录信息
    console.error('[TweetClaw-BG] queryXBasicInfo: all strategies failed, returning minimal profile');
    const storedScreenName = (await chrome.storage.local.get('screenName')).screenName;
    return {
        isLoggedIn: true,
        twitterId: uid || '',
        name: storedScreenName || '',
        screenName: storedScreenName ? `@${storedScreenName}` : '',
        verified: false,
        raw: null,
        updatedAt: Date.now()
    };
}
async function openXTab(payload) {
    const path = payload.path || "home";
    const url = "https://x.com/" + (path.startsWith("/") ? path.substring(1) : path);
    return new Promise((resolve) => {
        chrome.tabs.create({ url }, (tab) => {
            if (chrome.runtime.lastError) {
                resolve({ success: false, error: chrome.runtime.lastError.message });
            }
            else {
                resolve({
                    success: true,
                    tabId: tab.id,
                    url: tab.url || url
                });
            }
        });
    });
}
async function closeXTab(payload) {
    const tabId = payload.tabId;
    return new Promise((resolve) => {
        chrome.tabs.get(tabId, (tab) => {
            if (chrome.runtime.lastError || !tab) {
                resolve({ success: false, reason: "not_found" });
                return;
            }
            // Check if it's an x.com tab
            const url = tab.url || "";
            if (!url.includes("x.com") && !url.includes("twitter.com")) {
                resolve({ success: false, reason: "not_found" });
                return;
            }
            chrome.tabs.remove(tabId, () => {
                if (chrome.runtime.lastError) {
                    resolve({
                        success: false,
                        reason: "failed",
                        error: chrome.runtime.lastError.message
                    });
                }
                else {
                    resolve({ success: true, reason: "success" });
                }
            });
        });
    });
}
async function navigateXTab(payload) {
    let tabId = payload.tabId;
    const path = payload.path || "home";
    const url = "https://x.com/" + (path.startsWith("/") ? path.substring(1) : path);
    if (!tabId) {
        // Find the first x.com tab
        const tabs = await chrome.tabs.query({ url: ["*://x.com/*", "*://twitter.com/*"] });
        if (tabs.length === 0) {
            throw new Error("No x.com tabs found to navigate");
        }
        tabId = tabs[0].id;
    }
    if (!tabId) {
        throw new Error("Invalid tabId");
    }
    const targetTabId = tabId;
    return new Promise((resolve) => {
        chrome.tabs.update(targetTabId, { url }, (tab) => {
            if (chrome.runtime.lastError) {
                resolve({ success: false, tabId: targetTabId, url, error: chrome.runtime.lastError.message });
            }
            else {
                resolve({
                    success: true,
                    tabId: targetTabId,
                    url: tab?.url || url
                });
            }
        });
    });
}
async function execAction(payload) {
    const { action, tweetId, userId, tabId } = payload;
    console.log(`[TweetClaw-BG] execAction called: ${action}`, { tweetId, userId, tabId });
    let targetTabId = tabId;
    if (!targetTabId) {
        const xTabs = await chrome.tabs.query({ url: ['*://x.com/*', '*://twitter.com/*'] });
        const targetTab = xTabs.find(t => t.active) || xTabs[0];
        targetTabId = targetTab?.id;
    }
    if (!targetTabId) {
        throw new Error('No target tab found for action');
    }
    return new Promise((resolve, reject) => {
        const timer = setTimeout(() => {
            reject(new Error('Content script response timeout'));
        }, 8000);
        chrome.tabs.sendMessage(targetTabId, {
            type: _capture_consts__WEBPACK_IMPORTED_MODULE_0__.MsgType.EXECUTE_ACTION,
            action,
            tweetId,
            userId,
            text: payload?.text || null // 新增：透传 text 字段给 content script
        }).then(res => {
            clearTimeout(timer);
            resolve(res);
        }).catch(err => {
            clearTimeout(timer);
            reject(err);
        });
    });
}
// 启动时确保存储已就绪
initDefaultQueryKeys();
// B1: 读取主页时间线
async function queryHomeTimeline(payload) {
    const xTabs = await chrome.tabs.query({ url: ['*://x.com/*', '*://twitter.com/*'] });
    let targetTabId = payload?.tabId;
    if (!targetTabId) {
        const activeTab = xTabs.find(t => t.active) || xTabs[0];
        targetTabId = activeTab?.id;
    }
    if (!targetTabId)
        return { ok: false, error: 'No x.com tab found', data: null };
    const state = tabDataStore.get(targetTabId);
    const rawTimeline = state?.data?.['HomeLatestTimeline']
        || state?.data?.['HomeTimeline']
        || state?.data?.['TimelineHome'];
    if (!rawTimeline) {
        return {
            ok: false,
            error: 'Home timeline not yet captured. Navigate to x.com/home and wait for the page to load.',
            data: null
        };
    }
    const { extractTweetsFromTimeline } = await Promise.resolve(/*! import() */).then(__webpack_require__.bind(__webpack_require__, /*! ../capture/timeline-extractor */ "./src/capture/timeline-extractor.ts"));
    const tweets = extractTweetsFromTimeline(rawTimeline);
    return { ok: true, data: { tweets, count: tweets.length }, error: null };
}
// B2: 读取推文详情及回复
async function queryTweetDetail(payload) {
    const { tweetId, tabId } = payload;
    const xTabs = await chrome.tabs.query({ url: ['*://x.com/*', '*://twitter.com/*'] });
    let targetTabId = tabId;
    if (!targetTabId) {
        const activeTab = xTabs.find(t => t.active) || xTabs[0];
        targetTabId = activeTab?.id;
    }
    if (!targetTabId)
        return { ok: false, error: 'No x.com tab found', data: null };
    const state = tabDataStore.get(targetTabId);
    const rawDetail = (tweetId && state?.data?.[`TweetDetail_${tweetId}`])
        || state?.data?.['TweetDetail'];
    if (!rawDetail) {
        return {
            ok: false,
            error: `TweetDetail not captured yet. Navigate to the tweet detail page first.`,
            data: null
        };
    }
    const { extractTweetsFromTimeline } = await Promise.resolve(/*! import() */).then(__webpack_require__.bind(__webpack_require__, /*! ../capture/timeline-extractor */ "./src/capture/timeline-extractor.ts"));
    const tweets = extractTweetsFromTimeline(rawDetail);
    return {
        ok: true,
        data: {
            featuredTweet: state?.featuredTweet || null,
            replies: state?.repliesSnapshot || [],
            allTweets: tweets,
            count: tweets.length
        },
        error: null
    };
}
// B3: 获取指定用户的 Profile（主动调用，不依赖页面导航）
async function queryUserProfile(payload) {
    const { screenName, tabId } = payload;
    if (!screenName)
        return { ok: false, error: 'screenName is required', data: null };
    const xTabs = await chrome.tabs.query({ url: ['*://x.com/*', '*://twitter.com/*'] });
    let targetTabId = tabId;
    if (!targetTabId) {
        const activeTab = xTabs.find(t => t.active) || xTabs[0];
        targetTabId = activeTab?.id;
    }
    if (!targetTabId)
        return { ok: false, error: 'No x.com tab found', data: null };
    const result = await new Promise(resolve => {
        chrome.tabs.sendMessage(targetTabId, {
            type: 'FETCH_USER_PROFILE_BY_SCREEN_NAME',
            screenName: screenName.replace('@', '')
        }, (resp) => resolve(resp || { success: false, error: 'No response' }));
    });
    if (result?.success && result?.data)
        return { ok: true, data: result.data, error: null };
    return { ok: false, error: result?.error || 'Failed to fetch user profile', data: null };
}
// B4: 读取搜索结果
async function querySearchTimeline(payload) {
    const xTabs = await chrome.tabs.query({ url: ['*://x.com/*', '*://twitter.com/*'] });
    let targetTabId = payload?.tabId;
    if (!targetTabId) {
        const activeTab = xTabs.find(t => t.active) || xTabs[0];
        targetTabId = activeTab?.id;
    }
    if (!targetTabId)
        return { ok: false, error: 'No x.com tab found', data: null };
    const state = tabDataStore.get(targetTabId);
    const rawSearch = state?.data?.['SearchTimeline'];
    if (!rawSearch) {
        return {
            ok: false,
            error: 'Search results not captured. Navigate to x.com/search?q=... first.',
            data: null
        };
    }
    const { extractTweetsFromTimeline } = await Promise.resolve(/*! import() */).then(__webpack_require__.bind(__webpack_require__, /*! ../capture/timeline-extractor */ "./src/capture/timeline-extractor.ts"));
    const tweets = extractTweetsFromTimeline(rawSearch);
    return { ok: true, data: { tweets, count: tweets.length }, error: null };
}

})();

/******/ })()
;
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoianMvYmFja2dyb3VuZC5qcyIsIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7OztBQUFBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNPO0FBQ1A7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSx5Q0FBeUMsMEJBQTBCO0FBQ25FO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7Ozs7Ozs7Ozs7Ozs7Ozs7QUN2QitFO0FBQ3pCO0FBQy9DO0FBQ1A7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsaURBQWlEO0FBQ2pEO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSw2REFBNkQsS0FBSztBQUNsRSx3Q0FBd0MsS0FBSztBQUM3QztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxvQ0FBb0M7QUFDcEM7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLG9EQUFvRCxXQUFXO0FBQy9EO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsMkRBQTJELFlBQVk7QUFDdkU7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsNENBQTRDLG1FQUFxQjtBQUNqRTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0Esb0VBQW9FLE1BQU07QUFDMUU7QUFDQTtBQUNBO0FBQ0E7QUFDQSxTQUFTO0FBQ1Q7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLHlCQUF5QixXQUFXO0FBQ3BDLGtCQUFrQix1REFBYTtBQUMvQjtBQUNBO0FBQ0E7QUFDQTtBQUNBLDhCQUE4Qix1REFBYTtBQUMzQyxpQ0FBaUMsMERBQWdCO0FBQ2pEO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EseURBQXlELFNBQVM7QUFDbEU7QUFDQSxxQkFBcUIsdURBQWE7QUFDbEM7QUFDQTtBQUNBLHFCQUFxQix1REFBYTtBQUNsQztBQUNBO0FBQ0E7QUFDQSxxQkFBcUIsdURBQWE7QUFDbEM7QUFDQTtBQUNBLHFCQUFxQix1REFBYTtBQUNsQztBQUNBO0FBQ0EscUJBQXFCLHVEQUFhO0FBQ2xDO0FBQ0E7QUFDQSxxQkFBcUIsdURBQWE7QUFDbEM7QUFDQTtBQUNBLHFCQUFxQix1REFBYTtBQUNsQztBQUNBO0FBQ0EscUJBQXFCLHVEQUFhO0FBQ2xDO0FBQ0E7QUFDQSxxQkFBcUIsdURBQWE7QUFDbEMsZ0ZBQWdGLHVEQUFhO0FBQzdGO0FBQ0EscUJBQXFCLHVEQUFhO0FBQ2xDLCtFQUErRSx1REFBYTtBQUM1RjtBQUNBLHFCQUFxQix1REFBYTtBQUNsQywrRUFBK0UsdURBQWE7QUFDNUY7QUFDQSxxQkFBcUIsdURBQWE7QUFDbEMsa0ZBQWtGLHVEQUFhO0FBQy9GO0FBQ0E7QUFDQSxzRUFBc0UsU0FBUztBQUMvRTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxzQkFBc0IsdURBQWE7QUFDbkM7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLHNCQUFzQix1REFBYTtBQUNuQztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLHNCQUFzQix1REFBYTtBQUNuQztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0Esc0JBQXNCLHVEQUFhO0FBQ25DO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0Esc0JBQXNCLHVEQUFhO0FBQ25DO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0Esc0JBQXNCLHVEQUFhO0FBQ25DO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0Esc0JBQXNCLHVEQUFhO0FBQ25DO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0Esc0JBQXNCLHVEQUFhO0FBQ25DO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0Esc0JBQXNCLHVEQUFhO0FBQ25DO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0Esc0JBQXNCLHVEQUFhO0FBQ25DO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0Esc0JBQXNCLHVEQUFhO0FBQ25DO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0Esc0JBQXNCLHVEQUFhO0FBQ25DO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSx3REFBd0QsYUFBYTtBQUNyRTtBQUNBO0FBQ0Esc0JBQXNCLHVEQUFhO0FBQ25DO0FBQ0E7QUFDQTtBQUNBLDJCQUEyQjtBQUMzQixhQUFhO0FBQ2I7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLGFBQWE7QUFDYjtBQUNBO0FBQ0E7QUFDQTtBQUNBLHNCQUFzQix1REFBYTtBQUNuQztBQUNBO0FBQ0E7QUFDQSwyQkFBMkI7QUFDM0IsYUFBYTtBQUNiO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsNERBQTRELFNBQVM7QUFDckU7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsU0FBUztBQUNUO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLHdCQUF3QixXQUFXO0FBQ25DLGtCQUFrQix1REFBYTtBQUMvQjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxxREFBcUQsU0FBUztBQUM5RDtBQUNBO0FBQ0EsNEVBQTRFLG9CQUFvQjtBQUNoRztBQUNBO0FBQ0E7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQ25lTztBQUNBO0FBQ0E7QUFDUDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ087QUFDUDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUNyQ087QUFDQTtBQUNBO0FBQ0E7QUFDUDtBQUNBO0FBQ0E7QUFDQSxDQUFDLDBCQUEwQjtBQUNwQjtBQUNQO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDTztBQUNQO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ087QUFDUDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDM0Z5QztBQUN3QjtBQUNWO0FBQ3ZEO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ087QUFDUDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ087QUFDUDtBQUNBO0FBQ0EsZ0NBQWdDLFFBQVEsRUFBRSxjQUFjO0FBQ3hEO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ087QUFDUDtBQUNBO0FBQ0EsZ0RBQWdELHNEQUFhO0FBQzdEO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNPO0FBQ1A7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLFlBQVksc0RBQWE7QUFDekI7QUFDQTtBQUNBO0FBQ0E7QUFDQSx3QkFBd0IsT0FBTztBQUMvQjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsWUFBWSxzREFBYTtBQUN6QjtBQUNBO0FBQ0EseUJBQXlCO0FBQ3pCO0FBQ0Esd0JBQXdCLGlCQUFpQjtBQUN6QztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxvQ0FBb0M7QUFDcEM7QUFDQSxLQUFLO0FBQ0w7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNPO0FBQ1A7QUFDQSx1QkFBdUIsOEVBQXlCO0FBQ2hEO0FBQ0E7QUFDQTtBQUNBLG1DQUFtQyxtRUFBYztBQUNqRDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ087QUFDUDtBQUNBLHVCQUF1Qiw4RUFBeUI7QUFDaEQ7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ087QUFDUDtBQUNBLHVCQUF1Qiw4RUFBeUI7QUFDaEQ7QUFDQTtBQUNBLG1DQUFtQyxtRUFBYztBQUNqRDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLFNBQVM7QUFDVDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDTztBQUNQO0FBQ0EsdUJBQXVCLDhFQUF5QjtBQUNoRDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxTQUFTO0FBQ1Q7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDTztBQUNQO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxzQkFBc0I7QUFDdEI7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOzs7Ozs7Ozs7Ozs7Ozs7QUM3UkE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDTztBQUNQO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSwyQkFBMkIsdUJBQXVCO0FBQ2xEO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSwrQkFBK0IsWUFBWTtBQUMzQztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxTQUFTO0FBQ1Q7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOzs7Ozs7Ozs7Ozs7Ozs7O0FDekxnRDtBQUN6QztBQUNQLG9CQUFvQiw2REFBYztBQUNsQztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7Ozs7Ozs7Ozs7Ozs7OztBQ3ZDTztBQUNQO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ087QUFDUDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOzs7Ozs7Ozs7Ozs7Ozs7OztBQy9CZ0U7QUFDVDtBQUNoRDtBQUNQO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxzQkFBc0IsNkRBQWM7QUFDcEM7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSw0QkFBNEIsb0VBQWtCO0FBQzlDO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLDJEQUEyRCw2REFBYztBQUN6RTtBQUNBO0FBQ0E7QUFDQTs7Ozs7OztVQzlFQTtVQUNBOztVQUVBO1VBQ0E7VUFDQTtVQUNBO1VBQ0E7VUFDQTtVQUNBO1VBQ0E7VUFDQTtVQUNBO1VBQ0E7VUFDQTtVQUNBOztVQUVBO1VBQ0E7VUFDQTtVQUNBO1VBQ0E7VUFDQTtVQUNBO1VBQ0E7O1VBRUE7VUFDQTtVQUNBOzs7OztXQzVCQTtXQUNBO1dBQ0E7V0FDQTtXQUNBLHlDQUF5Qyx3Q0FBd0M7V0FDakY7V0FDQTtXQUNBLEU7Ozs7O1dDUEEsd0Y7Ozs7O1dDQUE7V0FDQTtXQUNBO1dBQ0EsdURBQXVELGlCQUFpQjtXQUN4RTtXQUNBLGdEQUFnRCxhQUFhO1dBQzdELEU7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUNOb0g7QUFDcUM7QUFDL0Y7QUFDSDtBQUNXO0FBQ2xFO0FBQ0Esd0JBQXdCLDBFQUFpQjtBQUN6QztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsK0JBQStCLHFCQUFxQjtBQUNwRDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsQ0FBQztBQUNEO0FBQ0E7QUFDQSwrQ0FBK0MsK0RBQWtCO0FBQ2pFLG1CQUFtQiwrREFBa0IsT0FBTztBQUM1QztBQUNBLDBDQUEwQywrREFBa0I7QUFDNUQ7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EseUNBQXlDLENBQUMsK0RBQWtCLFFBQVE7QUFDcEUsa0dBQWtHO0FBQ2xHO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxvRkFBb0Y7QUFDcEYsQ0FBQztBQUNEO0FBQ0E7QUFDQSw2QkFBNkIsb0NBQW9DO0FBQ2pFO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxTQUFTO0FBQ1QsS0FBSztBQUNMO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLG9CQUFvQix3QkFBd0I7QUFDNUM7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxxRUFBcUUsTUFBTTtBQUMzRTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0Esd0JBQXdCLDBDQUEwQztBQUNsRTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxpQkFBaUIsaUJBQWlCO0FBQ2xDO0FBQ0E7QUFDQSxLQUFLO0FBQ0w7QUFDQSxLQUFLO0FBQ0w7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLCtDQUErQywrREFBa0I7QUFDakUscUJBQXFCLCtEQUFrQixPQUFPO0FBQzlDO0FBQ0E7QUFDQSx5Q0FBeUMsQ0FBQywrREFBa0IsUUFBUTtBQUNwRSxtRUFBbUUsS0FBSyxJQUFJLFFBQVEsbUJBQW1CLGtCQUFrQiwwQkFBMEIsaUJBQWlCLGtCQUFrQjtBQUN0TDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsK0NBQStDLCtEQUFrQjtBQUNqRSxZQUFZLCtEQUFrQjtBQUM5Qix5Q0FBeUMsQ0FBQywrREFBa0IsV0FBVztBQUN2RTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsMkJBQTJCLFVBQVU7QUFDckM7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLDJCQUEyQiw4QkFBOEI7QUFDekQ7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0Esb0JBQW9CO0FBQ3BCO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLGdDQUFnQyxtRUFBYztBQUM5QztBQUNBLDhDQUE4QyxRQUFRO0FBQ3REO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsNENBQTRDO0FBQzVDO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsYUFBYTtBQUNiO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsNEJBQTRCLHFFQUFpQjtBQUM3QztBQUNBLGtDQUFrQztBQUNsQztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLGlCQUFpQixpQkFBaUI7QUFDbEM7QUFDQTtBQUNBO0FBQ0E7QUFDQSxpQkFBaUIsaUJBQWlCO0FBQ2xDO0FBQ0E7QUFDQSwwQkFBMEIscUVBQWlCO0FBQzNDO0FBQ0E7QUFDQTtBQUNBLHdDQUF3Qyx1RUFBbUI7QUFDM0Q7QUFDQTtBQUNBO0FBQ0EsaUNBQWlDLHVFQUFtQjtBQUNwRDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EseUNBQXlDLDZFQUF5QjtBQUNsRTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxTQUFTO0FBQ1QsZ0JBQWdCO0FBQ2hCO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsNEJBQTRCLDJDQUEyQztBQUN2RTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsYUFBYTtBQUNiO0FBQ0EsU0FBUztBQUNULHFCQUFxQjtBQUNyQjtBQUNBO0FBQ0EsNkJBQTZCLHNDQUFzQztBQUNuRSwyQkFBMkIseUJBQXlCO0FBQ3BELFNBQVM7QUFDVCwyQkFBMkIsK0JBQStCO0FBQzFELFNBQVM7QUFDVDtBQUNBO0FBQ0E7QUFDQSw0Q0FBNEMsY0FBYztBQUMxRDtBQUNBLHNEQUFzRCxlQUFlLGlCQUFpQjtBQUN0RjtBQUNBLDJCQUEyQixVQUFVO0FBQ3JDLFNBQVM7QUFDVCwyQkFBMkIsK0JBQStCO0FBQzFELFNBQVM7QUFDVDtBQUNBO0FBQ0E7QUFDQTtBQUNBLDJCQUEyQixVQUFVO0FBQ3JDLFNBQVM7QUFDVDtBQUNBO0FBQ0EsK0JBQStCLHlDQUF5QztBQUN4RTtBQUNBO0FBQ0EsK0JBQStCLCtCQUErQjtBQUM5RDtBQUNBLFNBQVM7QUFDVDtBQUNBO0FBQ0E7QUFDQSxnQkFBZ0IsYUFBYTtBQUM3QjtBQUNBLDJCQUEyQiwwQ0FBMEM7QUFDckU7QUFDQTtBQUNBO0FBQ0E7QUFDQSwyQkFBMkIsd0RBQXdEO0FBQ25GO0FBQ0E7QUFDQSxvQ0FBb0MsS0FBSztBQUN6QywyQkFBMkIsc0JBQXNCO0FBQ2pELFNBQVM7QUFDVCwyQkFBMkIsK0JBQStCO0FBQzFELFNBQVM7QUFDVDtBQUNBO0FBQ0E7QUFDQTtBQUNBLHFDQUFxQztBQUNyQztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLHdCQUF3QjtBQUN4QjtBQUNBLHlCQUF5QjtBQUN6QjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsK0JBQStCLHVEQUFVO0FBQ3pDLGFBQWE7QUFDYixTQUFTO0FBQ1Q7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsMkJBQTJCLGdEQUFnRDtBQUMzRTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLFNBQVM7QUFDVDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSx5QkFBeUIsc0VBQWlCO0FBQzFDO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLGlDQUFpQyxtRUFBYztBQUMvQztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSw4REFBOEQsU0FBUztBQUN2RTtBQUNBO0FBQ0EsNkNBQTZDLGlFQUFhO0FBQzFEO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLDBDQUEwQyx1RUFBbUI7QUFDN0Q7QUFDQTtBQUNBO0FBQ0E7QUFDQSx1QkFBdUIsc0VBQWlCO0FBQ3hDO0FBQ0E7QUFDQSxpQkFBaUI7QUFDakIsYUFBYTtBQUNiO0FBQ0EsaUNBQWlDLG1FQUFjO0FBQy9DO0FBQ0E7QUFDQTtBQUNBLDhEQUE4RCxTQUFTO0FBQ3ZFO0FBQ0E7QUFDQSw2Q0FBNkMsaUVBQWE7QUFDMUQ7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLDBDQUEwQyx1RUFBbUI7QUFDN0Q7QUFDQTtBQUNBO0FBQ0E7QUFDQSx1QkFBdUIsc0VBQWlCO0FBQ3hDO0FBQ0E7QUFDQSxpQkFBaUI7QUFDakIsYUFBYTtBQUNiLFNBQVM7QUFDVDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSwyQkFBMkIsOEJBQThCO0FBQ3pEO0FBQ0E7QUFDQTtBQUNBLGtCQUFrQixvREFBTztBQUN6QjtBQUNBO0FBQ0E7QUFDQSxTQUFTO0FBQ1QsdUNBQXVDLDZCQUE2QjtBQUNwRTtBQUNBO0FBQ0EsQ0FBQztBQUNEO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxDQUFDO0FBQ0Q7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsQ0FBQztBQUNEO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsaUJBQWlCO0FBQ2pCO0FBQ0E7QUFDQTtBQUNBLG9DQUFvQywyQ0FBMkM7QUFDL0U7QUFDQTtBQUNBO0FBQ0E7QUFDQSxpQkFBaUI7QUFDakI7QUFDQTtBQUNBO0FBQ0EsQ0FBQztBQUNEO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLGlDQUFpQywrREFBa0I7QUFDbkQsb0JBQW9CLCtEQUFrQjtBQUN0QywyQ0FBMkMsQ0FBQywrREFBa0IsVUFBVTtBQUN4RTtBQUNBLGlCQUFpQjtBQUNqQjtBQUNBLFNBQVM7QUFDVDtBQUNBLGFBQWE7QUFDYixDQUFDLElBQUkseUNBQXlDO0FBQzlDO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsU0FBUyx1REFBVTtBQUNuQjtBQUNBO0FBQ0EsNkJBQTZCLCtEQUFrQjtBQUMvQyxpQ0FBaUMsK0RBQWtCO0FBQ25EO0FBQ0E7QUFDQSx1Q0FBdUMsQ0FBQywrREFBa0IsZ0JBQWdCO0FBQzFFLG1GQUFtRixlQUFlLElBQUksUUFBUSxtQkFBbUIsa0JBQWtCLDBCQUEwQixpQkFBaUIsa0JBQWtCO0FBQ2hOLGFBQWE7QUFDYjtBQUNBLEtBQUs7QUFDTDtBQUNBLENBQUM7QUFDRDtBQUNBO0FBQ0EsQ0FBQztBQUNEO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsNkVBQTZFLGFBQWEsb0JBQW9CLGtCQUFrQjtBQUNoSTtBQUNBO0FBQ0EsQ0FBQyxJQUFJLGlDQUFpQztBQUN0QztBQUNPO0FBQ1A7QUFDQTtBQUNBLDJDQUEyQywyQ0FBMkM7QUFDdEY7QUFDQSxrREFBa0QsbUNBQW1DO0FBQ3JGO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxLQUFLO0FBQ0w7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EscUNBQXFDLFdBQVc7QUFDaEQ7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNPO0FBQ1A7QUFDQTtBQUNBLDRDQUE0QywyQ0FBMkM7QUFDdkY7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLEtBQUs7QUFDTDtBQUNBO0FBQ0EsS0FBSztBQUNMO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLGlDQUFpQyxnRUFBWTtBQUM3QztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsMkNBQTJDLGlCQUFpQjtBQUM1RDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ087QUFDUDtBQUNBO0FBQ0E7QUFDQSw2QkFBNkIsS0FBSztBQUNsQztBQUNBLDBCQUEwQix5REFBeUQ7QUFDbkY7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsaUJBQWlCO0FBQ2pCO0FBQ0EsU0FBUztBQUNULEtBQUs7QUFDTDtBQUNPO0FBQ1A7QUFDQTtBQUNBO0FBQ0E7QUFDQSwwQkFBMEIscUNBQXFDO0FBQy9EO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSwwQkFBMEIscUNBQXFDO0FBQy9EO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxxQkFBcUI7QUFDckI7QUFDQTtBQUNBLDhCQUE4QixrQ0FBa0M7QUFDaEU7QUFDQSxhQUFhO0FBQ2IsU0FBUztBQUNULEtBQUs7QUFDTDtBQUNPO0FBQ1A7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLCtDQUErQywyQ0FBMkM7QUFDMUY7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSwwQ0FBMEMsS0FBSztBQUMvQztBQUNBLDBCQUEwQixrRkFBa0Y7QUFDNUc7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsaUJBQWlCO0FBQ2pCO0FBQ0EsU0FBUztBQUNULEtBQUs7QUFDTDtBQUNPO0FBQ1AsWUFBWSxpQ0FBaUM7QUFDN0MscURBQXFELE9BQU8sS0FBSyx3QkFBd0I7QUFDekY7QUFDQTtBQUNBLGdEQUFnRCwyQ0FBMkM7QUFDM0Y7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsU0FBUztBQUNUO0FBQ0Esa0JBQWtCLG9EQUFPO0FBQ3pCO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsU0FBUztBQUNUO0FBQ0E7QUFDQSxTQUFTO0FBQ1Q7QUFDQTtBQUNBLFNBQVM7QUFDVCxLQUFLO0FBQ0w7QUFDQTtBQUNBO0FBQ0E7QUFDTztBQUNQLDRDQUE0QywyQ0FBMkM7QUFDdkY7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsaUJBQWlCO0FBQ2pCO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxZQUFZLDRCQUE0QixRQUFRLGdLQUF1QztBQUN2RjtBQUNBLGFBQWEsa0JBQWtCLDhCQUE4QjtBQUM3RDtBQUNBO0FBQ087QUFDUCxZQUFZLGlCQUFpQjtBQUM3Qiw0Q0FBNEMsMkNBQTJDO0FBQ3ZGO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLGlCQUFpQjtBQUNqQjtBQUNBLCtEQUErRCxRQUFRO0FBQ3ZFO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxZQUFZLDRCQUE0QixRQUFRLGdLQUF1QztBQUN2RjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsU0FBUztBQUNUO0FBQ0E7QUFDQTtBQUNBO0FBQ087QUFDUCxZQUFZLG9CQUFvQjtBQUNoQztBQUNBLGlCQUFpQjtBQUNqQiw0Q0FBNEMsMkNBQTJDO0FBQ3ZGO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLGlCQUFpQjtBQUNqQjtBQUNBO0FBQ0E7QUFDQTtBQUNBLFNBQVMsOEJBQThCLHNDQUFzQztBQUM3RSxLQUFLO0FBQ0w7QUFDQSxpQkFBaUI7QUFDakIsYUFBYTtBQUNiO0FBQ0E7QUFDTztBQUNQLDRDQUE0QywyQ0FBMkM7QUFDdkY7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsaUJBQWlCO0FBQ2pCO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLFlBQVksNEJBQTRCLFFBQVEsZ0tBQXVDO0FBQ3ZGO0FBQ0EsYUFBYSxrQkFBa0IsOEJBQThCO0FBQzdEIiwic291cmNlcyI6WyJ3ZWJwYWNrOi8vVHdlZXRDbGF3Ly4vc3JjL2JyaWRnZS9pbnN0YW5jZS1pZC50cyIsIndlYnBhY2s6Ly9Ud2VldENsYXcvLi9zcmMvYnJpZGdlL2xvY2FsLWJyaWRnZS1zb2NrZXQudHMiLCJ3ZWJwYWNrOi8vVHdlZXRDbGF3Ly4vc3JjL2JyaWRnZS93cy1wcm90b2NvbC50cyIsIndlYnBhY2s6Ly9Ud2VldENsYXcvLi9zcmMvY2FwdHVyZS9jb25zdHMudHMiLCJ3ZWJwYWNrOi8vVHdlZXRDbGF3Ly4vc3JjL2NhcHR1cmUvZXh0cmFjdG9yLnRzIiwid2VicGFjazovL1R3ZWV0Q2xhdy8uL3NyYy9jYXB0dXJlL3RpbWVsaW5lLWV4dHJhY3Rvci50cyIsIndlYnBhY2s6Ly9Ud2VldENsYXcvLi9zcmMvdXRpbHMvZW50aXR5LXJlc29sdmVyLnRzIiwid2VicGFjazovL1R3ZWV0Q2xhdy8uL3NyYy91dGlscy9yb3V0ZS1wYXJzZXIudHMiLCJ3ZWJwYWNrOi8vVHdlZXRDbGF3Ly4vc3JjL3V0aWxzL3NjZW5lLXBhcnNlci50cyIsIndlYnBhY2s6Ly9Ud2VldENsYXcvd2VicGFjay9ib290c3RyYXAiLCJ3ZWJwYWNrOi8vVHdlZXRDbGF3L3dlYnBhY2svcnVudGltZS9kZWZpbmUgcHJvcGVydHkgZ2V0dGVycyIsIndlYnBhY2s6Ly9Ud2VldENsYXcvd2VicGFjay9ydW50aW1lL2hhc093blByb3BlcnR5IHNob3J0aGFuZCIsIndlYnBhY2s6Ly9Ud2VldENsYXcvd2VicGFjay9ydW50aW1lL21ha2UgbmFtZXNwYWNlIG9iamVjdCIsIndlYnBhY2s6Ly9Ud2VldENsYXcvLi9zcmMvc2VydmljZV93b3JrL2JhY2tncm91bmQudHMiXSwic291cmNlc0NvbnRlbnQiOlsiLyoqXG4gKiDojrflj5bmiJbliJvlu7rlvZPliY0gQ2hyb21lIFByb2ZpbGUg55qE56iz5a6a5ZSv5LiA5qCH6K+G56ym44CCXG4gKiDlrZjlgqjlnKggY2hyb21lLnN0b3JhZ2UubG9jYWwg5Lit77yMUHJvZmlsZSDpmpTnprvvvIzph43lkK/lkI7kv53mjIHkuI3lj5jjgIJcbiAqIOS7heWcqOaJqeWxleiiq+WNuOi9veWQjuaJjeS8muS4ouWkse+8iGNocm9tZS5zdG9yYWdlLmxvY2FsIOmaj+aJqeWxleaVsOaNrua4hemZpO+8ieOAglxuICovXG5jb25zdCBJTlNUQU5DRV9JRF9LRVkgPSAnYnJpZGdlLmluc3RhbmNlSWQnO1xuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGdldE9yQ3JlYXRlSW5zdGFuY2VJZCgpIHtcbiAgICB0cnkge1xuICAgICAgICBjb25zdCByZXN1bHQgPSBhd2FpdCBjaHJvbWUuc3RvcmFnZS5sb2NhbC5nZXQoSU5TVEFOQ0VfSURfS0VZKTtcbiAgICAgICAgaWYgKHJlc3VsdFtJTlNUQU5DRV9JRF9LRVldICYmIHR5cGVvZiByZXN1bHRbSU5TVEFOQ0VfSURfS0VZXSA9PT0gJ3N0cmluZycpIHtcbiAgICAgICAgICAgIHJldHVybiByZXN1bHRbSU5TVEFOQ0VfSURfS0VZXTtcbiAgICAgICAgfVxuICAgICAgICAvLyDpppbmrKHov5DooYzvvJrnlJ/miJDmlrAgVVVJRCDlubbmjIHkuYXljJZcbiAgICAgICAgY29uc3QgbmV3SWQgPSBjcnlwdG8ucmFuZG9tVVVJRCgpO1xuICAgICAgICBhd2FpdCBjaHJvbWUuc3RvcmFnZS5sb2NhbC5zZXQoeyBbSU5TVEFOQ0VfSURfS0VZXTogbmV3SWQgfSk7XG4gICAgICAgIGNvbnNvbGUubG9nKCdbdHdlZXRDbGF3XSBnZW5lcmF0ZWQgbmV3IGluc3RhbmNlSWQ6JywgbmV3SWQpO1xuICAgICAgICByZXR1cm4gbmV3SWQ7XG4gICAgfVxuICAgIGNhdGNoIChlKSB7XG4gICAgICAgIC8vIOmZjee6p++8mui/lOWbnuepuuWtl+espuS4su+8jFNlcnZlciDnq6/kvJrnlJ/miJAgdG1wLSDliY3nvIDnmoTkuLTml7YgSUQg5YWc5bqVXG4gICAgICAgIGNvbnNvbGUud2FybignW3R3ZWV0Q2xhd10gZmFpbGVkIHRvIHJlYWQvd3JpdGUgc3RvcmFnZSBmb3IgaW5zdGFuY2VJZDonLCBlKTtcbiAgICAgICAgcmV0dXJuICcnO1xuICAgIH1cbn1cbiIsImltcG9ydCB7IE1FU1NBR0VfVFlQRVMsIFBST1RPQ09MX05BTUUsIFBST1RPQ09MX1ZFUlNJT04gfSBmcm9tICcuL3dzLXByb3RvY29sJztcbmltcG9ydCB7IGdldE9yQ3JlYXRlSW5zdGFuY2VJZCB9IGZyb20gJy4vaW5zdGFuY2UtaWQnO1xuZXhwb3J0IGNsYXNzIExvY2FsQnJpZGdlU29ja2V0IHtcbiAgICBjb25zdHJ1Y3RvcigpIHtcbiAgICAgICAgdGhpcy53cyA9IG51bGw7XG4gICAgICAgIHRoaXMucmVjb25uZWN0QXR0ZW1wdHMgPSAwO1xuICAgICAgICB0aGlzLnJlY29ubmVjdFRpbWVyID0gbnVsbDtcbiAgICAgICAgdGhpcy5oZWFydGJlYXRJbnRlcnZhbCA9IG51bGw7XG4gICAgICAgIHRoaXMuc2VydmVySW5mbyA9IG51bGw7XG4gICAgICAgIHRoaXMubGFzdFBvbmdUaW1lc3RhbXAgPSAwO1xuICAgICAgICB0aGlzLmluc3RhbmNlSWQgPSAnJztcbiAgICAgICAgdGhpcy5xdWVyeVhUYWJzSGFuZGxlciA9IG51bGw7XG4gICAgICAgIHRoaXMucXVlcnlYQmFzaWNJbmZvSGFuZGxlciA9IG51bGw7XG4gICAgICAgIHRoaXMub3BlblRhYkhhbmRsZXIgPSBudWxsO1xuICAgICAgICB0aGlzLmNsb3NlVGFiSGFuZGxlciA9IG51bGw7XG4gICAgICAgIHRoaXMubmF2aWdhdGVUYWJIYW5kbGVyID0gbnVsbDtcbiAgICAgICAgdGhpcy5leGVjQWN0aW9uSGFuZGxlciA9IG51bGw7XG4gICAgICAgIHRoaXMucXVlcnlIb21lVGltZWxpbmVIYW5kbGVyID0gbnVsbDtcbiAgICAgICAgdGhpcy5xdWVyeVR3ZWV0RGV0YWlsSGFuZGxlciA9IG51bGw7XG4gICAgICAgIHRoaXMucXVlcnlVc2VyUHJvZmlsZUhhbmRsZXIgPSBudWxsO1xuICAgICAgICB0aGlzLnF1ZXJ5U2VhcmNoVGltZWxpbmVIYW5kbGVyID0gbnVsbDtcbiAgICAgICAgdGhpcy5XU19VUkwgPSAnd3M6Ly8xMjcuMC4wLjE6MTAwODYvd3MnOyAvLyBEZWZhdWx0XG4gICAgICAgIHRoaXMuaXNDb25uZWN0aW5nID0gZmFsc2U7XG4gICAgICAgIHRoaXMuY29ubmVjdCgpO1xuICAgIH1cbiAgICAvLyDilIDilIAgUHVibGljIHN0YXR1cyBhY2Nlc3NvcnMgKHVzZWQgYnkgcG9wdXApIOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgFxuICAgIGlzQ29ubmVjdGVkKCkge1xuICAgICAgICByZXR1cm4gdGhpcy53cyAhPT0gbnVsbCAmJiB0aGlzLndzLnJlYWR5U3RhdGUgPT09IFdlYlNvY2tldC5PUEVOO1xuICAgIH1cbiAgICBnZXRTZXJ2ZXJJbmZvKCkge1xuICAgICAgICByZXR1cm4gdGhpcy5zZXJ2ZXJJbmZvO1xuICAgIH1cbiAgICBnZXRDdXJyZW50VXJsKCkge1xuICAgICAgICByZXR1cm4gdGhpcy5XU19VUkw7XG4gICAgfVxuICAgIHJlY29ubmVjdFdpdGhOZXdQb3J0KHBvcnQpIHtcbiAgICAgICAgY29uc29sZS5sb2coYFt0d2VldENsYXddIHJlY29ubmVjdGluZyB0byBuZXcgcG9ydDogJHtwb3J0fWApO1xuICAgICAgICB0aGlzLldTX1VSTCA9IGB3czovLzEyNy4wLjAuMToke3BvcnR9L3dzYDtcbiAgICAgICAgdGhpcy5pc0Nvbm5lY3RpbmcgPSBmYWxzZTtcbiAgICAgICAgaWYgKHRoaXMucmVjb25uZWN0VGltZXIpIHtcbiAgICAgICAgICAgIGNsZWFyVGltZW91dCh0aGlzLnJlY29ubmVjdFRpbWVyKTtcbiAgICAgICAgICAgIHRoaXMucmVjb25uZWN0VGltZXIgPSBudWxsO1xuICAgICAgICB9XG4gICAgICAgIGlmICh0aGlzLndzKSB7XG4gICAgICAgICAgICB0aGlzLndzLm9uY2xvc2UgPSBudWxsOyAvLyBwcmV2ZW50IHN0YW5kYXJkIHJlY29ubmVjdCBsb29wXG4gICAgICAgICAgICB0aGlzLndzLmNsb3NlKCk7XG4gICAgICAgICAgICB0aGlzLndzID0gbnVsbDtcbiAgICAgICAgfVxuICAgICAgICB0aGlzLnJlY29ubmVjdEF0dGVtcHRzID0gMDtcbiAgICAgICAgdGhpcy5jb25uZWN0KCk7XG4gICAgfVxuICAgIGFzeW5jIGNvbm5lY3QoKSB7XG4gICAgICAgIGlmICh0aGlzLmlzQ29ubmVjdGluZylcbiAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgaWYgKHRoaXMud3MgJiYgKHRoaXMud3MucmVhZHlTdGF0ZSA9PT0gV2ViU29ja2V0LkNPTk5FQ1RJTkcgfHwgdGhpcy53cy5yZWFkeVN0YXRlID09PSBXZWJTb2NrZXQuT1BFTikpIHtcbiAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgfVxuICAgICAgICAvLyBDaGVjayBkeW5hbWljIHBvcnRcbiAgICAgICAgdHJ5IHtcbiAgICAgICAgICAgIGlmICh0eXBlb2YgY2hyb21lICE9PSAndW5kZWZpbmVkJyAmJiBjaHJvbWUuc3RvcmFnZSkge1xuICAgICAgICAgICAgICAgIGNvbnN0IHJlcyA9IGF3YWl0IGNocm9tZS5zdG9yYWdlLmxvY2FsLmdldCgnd3NQb3J0Jyk7XG4gICAgICAgICAgICAgICAgaWYgKHJlcy53c1BvcnQpIHtcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5XU19VUkwgPSBgd3M6Ly8xMjcuMC4wLjE6JHtyZXMud3NQb3J0fS93c2A7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICAgIGNhdGNoIChlKSB7XG4gICAgICAgICAgICBjb25zb2xlLndhcm4oJ1t0d2VldENsYXddIGZhaWxlZCB0byBnZXQgZHluYW1pYyBwb3J0JywgZSk7XG4gICAgICAgIH1cbiAgICAgICAgdGhpcy5pc0Nvbm5lY3RpbmcgPSB0cnVlO1xuICAgICAgICBjb25zb2xlLmxvZyhgW3R3ZWV0Q2xhd10gd2Vic29ja2V0IGNvbm5lY3RpbmcgdG8gJHt0aGlzLldTX1VSTH0uLi5gKTtcbiAgICAgICAgdHJ5IHtcbiAgICAgICAgICAgIHRoaXMud3MgPSBuZXcgV2ViU29ja2V0KHRoaXMuV1NfVVJMKTtcbiAgICAgICAgICAgIHRoaXMud3Mub25vcGVuID0gYXN5bmMgKCkgPT4ge1xuICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKCdbdHdlZXRDbGF3XSB3ZWJzb2NrZXQgb3BlbicpO1xuICAgICAgICAgICAgICAgIHRoaXMuaXNDb25uZWN0aW5nID0gZmFsc2U7XG4gICAgICAgICAgICAgICAgdGhpcy5yZWNvbm5lY3RBdHRlbXB0cyA9IDA7XG4gICAgICAgICAgICAgICAgdGhpcy5sYXN0UG9uZ1RpbWVzdGFtcCA9IERhdGUubm93KCk7XG4gICAgICAgICAgICAgICAgLy8g56Gu5L+dIGluc3RhbmNlSWQg5bey5Yqg6L2977yI5ZCM5LiAIFByb2ZpbGUg5YaF5aSa5qyh6YeN6L+e5aSN55So5ZCM5LiA5Liq5YC877yJXG4gICAgICAgICAgICAgICAgaWYgKCF0aGlzLmluc3RhbmNlSWQpIHtcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5pbnN0YW5jZUlkID0gYXdhaXQgZ2V0T3JDcmVhdGVJbnN0YW5jZUlkKCk7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIHRoaXMuc2VuZEhlbGxvKCk7XG4gICAgICAgICAgICB9O1xuICAgICAgICAgICAgdGhpcy53cy5vbmNsb3NlID0gKCkgPT4ge1xuICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKCdbdHdlZXRDbGF3XSB3ZWJzb2NrZXQgY2xvc2VkJyk7XG4gICAgICAgICAgICAgICAgdGhpcy5pc0Nvbm5lY3RpbmcgPSBmYWxzZTtcbiAgICAgICAgICAgICAgICB0aGlzLnNlcnZlckluZm8gPSBudWxsO1xuICAgICAgICAgICAgICAgIHRoaXMuc3RvcEhlYXJ0YmVhdCgpO1xuICAgICAgICAgICAgICAgIHRoaXMuc2NoZWR1bGVSZWNvbm5lY3QoKTtcbiAgICAgICAgICAgIH07XG4gICAgICAgICAgICB0aGlzLndzLm9uZXJyb3IgPSAoKSA9PiB7XG4gICAgICAgICAgICAgICAgLy8gVXNlIHJlZ3VsYXIgbG9nIHRvIHN0YXkgc2lsZW50IGluIENocm9tZSBleHRlbnNpb24gZXJyb3IgbGlzdFxuICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKCdbdHdlZXRDbGF3XSBjb25uZWN0aW9uIG5vdGljZTogc2VydmVyIG9mZmxpbmUnKTtcbiAgICAgICAgICAgICAgICB0aGlzLmlzQ29ubmVjdGluZyA9IGZhbHNlO1xuICAgICAgICAgICAgfTtcbiAgICAgICAgICAgIHRoaXMud3Mub25tZXNzYWdlID0gKGV2ZW50KSA9PiB7XG4gICAgICAgICAgICAgICAgdGhpcy5oYW5kbGVNZXNzYWdlKGV2ZW50LmRhdGEpO1xuICAgICAgICAgICAgfTtcbiAgICAgICAgfVxuICAgICAgICBjYXRjaCAoZSkge1xuICAgICAgICAgICAgY29uc29sZS5sb2coJ1t0d2VldENsYXddIGluaXRpYWxpemF0aW9uIG5vdGljZTonLCBlKTtcbiAgICAgICAgICAgIHRoaXMuaXNDb25uZWN0aW5nID0gZmFsc2U7XG4gICAgICAgICAgICB0aGlzLnNjaGVkdWxlUmVjb25uZWN0KCk7XG4gICAgICAgIH1cbiAgICB9XG4gICAgc2NoZWR1bGVSZWNvbm5lY3QoKSB7XG4gICAgICAgIGlmICh0aGlzLnJlY29ubmVjdFRpbWVyKVxuICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICBjb25zdCBkZWxheSA9IHRoaXMuZ2V0UmVjb25uZWN0RGVsYXkoKTtcbiAgICAgICAgY29uc29sZS5sb2coYFt0d2VldENsYXddIHdlYnNvY2tldCByZWNvbm5lY3Qgc2NoZWR1bGVkIGluICR7ZGVsYXl9bXNgKTtcbiAgICAgICAgdGhpcy5yZWNvbm5lY3RUaW1lciA9IHNldFRpbWVvdXQoKCkgPT4ge1xuICAgICAgICAgICAgdGhpcy5yZWNvbm5lY3RUaW1lciA9IG51bGw7XG4gICAgICAgICAgICB0aGlzLnJlY29ubmVjdEF0dGVtcHRzKys7XG4gICAgICAgICAgICB0aGlzLmNvbm5lY3QoKTtcbiAgICAgICAgfSwgZGVsYXkpO1xuICAgIH1cbiAgICBnZXRSZWNvbm5lY3REZWxheSgpIHtcbiAgICAgICAgc3dpdGNoICh0aGlzLnJlY29ubmVjdEF0dGVtcHRzKSB7XG4gICAgICAgICAgICBjYXNlIDA6IHJldHVybiAxMDAwO1xuICAgICAgICAgICAgY2FzZSAxOiByZXR1cm4gMjAwMDtcbiAgICAgICAgICAgIGNhc2UgMjogcmV0dXJuIDUwMDA7XG4gICAgICAgICAgICBkZWZhdWx0OiByZXR1cm4gMTAwMDA7XG4gICAgICAgIH1cbiAgICB9XG4gICAgc2VuZEhlbGxvKCkge1xuICAgICAgICBjb25zdCBoZWxsbyA9IHtcbiAgICAgICAgICAgIGlkOiBgaGVsbG9fJHtEYXRlLm5vdygpfWAsXG4gICAgICAgICAgICB0eXBlOiBNRVNTQUdFX1RZUEVTLkNMSUVOVF9IRUxMTyxcbiAgICAgICAgICAgIHNvdXJjZTogJ3R3ZWV0Q2xhdycsXG4gICAgICAgICAgICB0YXJnZXQ6ICdMb2NhbEJyaWRnZU1hYycsXG4gICAgICAgICAgICB0aW1lc3RhbXA6IERhdGUubm93KCksXG4gICAgICAgICAgICBwYXlsb2FkOiB7XG4gICAgICAgICAgICAgICAgcHJvdG9jb2xOYW1lOiBQUk9UT0NPTF9OQU1FLFxuICAgICAgICAgICAgICAgIHByb3RvY29sVmVyc2lvbjogUFJPVE9DT0xfVkVSU0lPTixcbiAgICAgICAgICAgICAgICBjbGllbnROYW1lOiAndHdlZXRDbGF3JyxcbiAgICAgICAgICAgICAgICBjbGllbnRWZXJzaW9uOiAnMC4zLjE3JyxcbiAgICAgICAgICAgICAgICBicm93c2VyOiAnY2hyb21lJyxcbiAgICAgICAgICAgICAgICBjYXBhYmlsaXRpZXM6IFsncXVlcnlfeF90YWJzX3N0YXR1cycsICdxdWVyeV94X2Jhc2ljX2luZm8nXSxcbiAgICAgICAgICAgICAgICBpbnN0YW5jZUlkOiB0aGlzLmluc3RhbmNlSWQgfHwgdW5kZWZpbmVkLCAvLyDmlrDlop5cbiAgICAgICAgICAgICAgICBpbmNvZ25pdG86IGNocm9tZS5leHRlbnNpb24uaW5JbmNvZ25pdG9Db250ZXh0IC8vIOaWsOWinlxuICAgICAgICAgICAgfVxuICAgICAgICB9O1xuICAgICAgICB0aGlzLnNlbmQoaGVsbG8pO1xuICAgIH1cbiAgICBoYW5kbGVNZXNzYWdlKGRhdGEpIHtcbiAgICAgICAgdHJ5IHtcbiAgICAgICAgICAgIGNvbnN0IG1zZyA9IEpTT04ucGFyc2UoZGF0YSk7XG4gICAgICAgICAgICBjb25zb2xlLmxvZyhgW3R3ZWV0Q2xhd10gcmVjZWl2ZWQgbWVzc2FnZTogJHttc2cudHlwZX1gKTtcbiAgICAgICAgICAgIHN3aXRjaCAobXNnLnR5cGUpIHtcbiAgICAgICAgICAgICAgICBjYXNlIE1FU1NBR0VfVFlQRVMuU0VSVkVSX0hFTExPX0FDSzpcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5oYW5kbGVIZWxsb0Fjayhtc2cpO1xuICAgICAgICAgICAgICAgICAgICBicmVhaztcbiAgICAgICAgICAgICAgICBjYXNlIE1FU1NBR0VfVFlQRVMuUE9ORzpcbiAgICAgICAgICAgICAgICAgICAgY29uc29sZS5sb2coJ1t0d2VldENsYXddIHJlY2VpdmVkIHBvbmcnKTtcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5sYXN0UG9uZ1RpbWVzdGFtcCA9IERhdGUubm93KCk7XG4gICAgICAgICAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICAgICAgICAgIGNhc2UgTUVTU0FHRV9UWVBFUy5SRVFVRVNUX1FVRVJZX1hfVEFCU19TVEFUVVM6XG4gICAgICAgICAgICAgICAgICAgIHRoaXMuaGFuZGxlUXVlcnlYVGFic1N0YXR1cyhtc2cpO1xuICAgICAgICAgICAgICAgICAgICBicmVhaztcbiAgICAgICAgICAgICAgICBjYXNlIE1FU1NBR0VfVFlQRVMuUkVRVUVTVF9RVUVSWV9YX0JBU0lDX0lORk86XG4gICAgICAgICAgICAgICAgICAgIHRoaXMuaGFuZGxlUXVlcnlYQmFzaWNJbmZvKG1zZyk7XG4gICAgICAgICAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICAgICAgICAgIGNhc2UgTUVTU0FHRV9UWVBFUy5SRVFVRVNUX09QRU5fVEFCOlxuICAgICAgICAgICAgICAgICAgICB0aGlzLmhhbmRsZU9wZW5UYWIobXNnKTtcbiAgICAgICAgICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgICAgICAgICAgY2FzZSBNRVNTQUdFX1RZUEVTLlJFUVVFU1RfQ0xPU0VfVEFCOlxuICAgICAgICAgICAgICAgICAgICB0aGlzLmhhbmRsZUNsb3NlVGFiKG1zZyk7XG4gICAgICAgICAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICAgICAgICAgIGNhc2UgTUVTU0FHRV9UWVBFUy5SRVFVRVNUX05BVklHQVRFX1RBQjpcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5oYW5kbGVOYXZpZ2F0ZVRhYihtc2cpO1xuICAgICAgICAgICAgICAgICAgICBicmVhaztcbiAgICAgICAgICAgICAgICBjYXNlIE1FU1NBR0VfVFlQRVMuUkVRVUVTVF9FWEVDX0FDVElPTjpcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5oYW5kbGVFeGVjQWN0aW9uKG1zZyk7XG4gICAgICAgICAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICAgICAgICAgIGNhc2UgTUVTU0FHRV9UWVBFUy5SRVFVRVNUX1FVRVJZX0hPTUVfVElNRUxJTkU6XG4gICAgICAgICAgICAgICAgICAgIHRoaXMuaGFuZGxlR2VuZXJpY1F1ZXJ5KG1zZywgdGhpcy5xdWVyeUhvbWVUaW1lbGluZUhhbmRsZXIsIE1FU1NBR0VfVFlQRVMuUkVTUE9OU0VfUVVFUllfSE9NRV9USU1FTElORSk7XG4gICAgICAgICAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICAgICAgICAgIGNhc2UgTUVTU0FHRV9UWVBFUy5SRVFVRVNUX1FVRVJZX1RXRUVUX0RFVEFJTDpcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5oYW5kbGVHZW5lcmljUXVlcnkobXNnLCB0aGlzLnF1ZXJ5VHdlZXREZXRhaWxIYW5kbGVyLCBNRVNTQUdFX1RZUEVTLlJFU1BPTlNFX1FVRVJZX1RXRUVUX0RFVEFJTCk7XG4gICAgICAgICAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICAgICAgICAgIGNhc2UgTUVTU0FHRV9UWVBFUy5SRVFVRVNUX1FVRVJZX1VTRVJfUFJPRklMRTpcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5oYW5kbGVHZW5lcmljUXVlcnkobXNnLCB0aGlzLnF1ZXJ5VXNlclByb2ZpbGVIYW5kbGVyLCBNRVNTQUdFX1RZUEVTLlJFU1BPTlNFX1FVRVJZX1VTRVJfUFJPRklMRSk7XG4gICAgICAgICAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICAgICAgICAgIGNhc2UgTUVTU0FHRV9UWVBFUy5SRVFVRVNUX1FVRVJZX1NFQVJDSF9USU1FTElORTpcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5oYW5kbGVHZW5lcmljUXVlcnkobXNnLCB0aGlzLnF1ZXJ5U2VhcmNoVGltZWxpbmVIYW5kbGVyLCBNRVNTQUdFX1RZUEVTLlJFU1BPTlNFX1FVRVJZX1NFQVJDSF9USU1FTElORSk7XG4gICAgICAgICAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICAgICAgICAgIGRlZmF1bHQ6XG4gICAgICAgICAgICAgICAgICAgIGNvbnNvbGUud2FybihgW3R3ZWV0Q2xhd10gdW5rbm93biBtZXNzYWdlIHR5cGU6ICR7bXNnLnR5cGV9YCk7XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgICAgY2F0Y2ggKGUpIHtcbiAgICAgICAgICAgIGNvbnNvbGUuZXJyb3IoJ1t0d2VldENsYXddIGZhaWxlZCB0byBwYXJzZSBtZXNzYWdlOicsIGUpO1xuICAgICAgICB9XG4gICAgfVxuICAgIGhhbmRsZUhlbGxvQWNrKG1zZykge1xuICAgICAgICBjb25zb2xlLmxvZygnW3R3ZWV0Q2xhd10gcmVjZWl2ZWQgc2VydmVyLmhlbGxvX2FjaycpO1xuICAgICAgICB0aGlzLnNlcnZlckluZm8gPSBtc2cucGF5bG9hZDtcbiAgICAgICAgdGhpcy5zdGFydEhlYXJ0YmVhdChtc2cucGF5bG9hZC5oZWFydGJlYXRJbnRlcnZhbE1zIHx8IDIwMDAwKTtcbiAgICB9XG4gICAgYXN5bmMgaGFuZGxlUXVlcnlYVGFic1N0YXR1cyhyZXEpIHtcbiAgICAgICAgY29uc29sZS5sb2coJ1t0d2VldENsYXddIGhhbmRsaW5nIHJlcXVlc3QucXVlcnlfeF90YWJzX3N0YXR1cycpO1xuICAgICAgICBpZiAoIXRoaXMucXVlcnlYVGFic0hhbmRsZXIpIHtcbiAgICAgICAgICAgIGNvbnNvbGUuZXJyb3IoJ1t0d2VldENsYXddIG5vIGhhbmRsZXIgZm9yIHF1ZXJ5X3hfdGFic19zdGF0dXMnKTtcbiAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgfVxuICAgICAgICB0cnkge1xuICAgICAgICAgICAgY29uc3QgcmVzdWx0ID0gYXdhaXQgdGhpcy5xdWVyeVhUYWJzSGFuZGxlcigpO1xuICAgICAgICAgICAgY29uc3QgcmVzcCA9IHtcbiAgICAgICAgICAgICAgICBpZDogcmVxLmlkLFxuICAgICAgICAgICAgICAgIHR5cGU6IE1FU1NBR0VfVFlQRVMuUkVTUE9OU0VfUVVFUllfWF9UQUJTX1NUQVRVUyxcbiAgICAgICAgICAgICAgICBzb3VyY2U6ICd0d2VldENsYXcnLFxuICAgICAgICAgICAgICAgIHRhcmdldDogJ0xvY2FsQnJpZGdlTWFjJyxcbiAgICAgICAgICAgICAgICB0aW1lc3RhbXA6IERhdGUubm93KCksXG4gICAgICAgICAgICAgICAgcGF5bG9hZDogcmVzdWx0XG4gICAgICAgICAgICB9O1xuICAgICAgICAgICAgdGhpcy5zZW5kKHJlc3ApO1xuICAgICAgICB9XG4gICAgICAgIGNhdGNoIChlKSB7XG4gICAgICAgICAgICAvLyBTZW5kIGFuIGVycm9yIHJlc3BvbnNlXG4gICAgICAgICAgICBjb25zdCBlcnJSZXNwID0ge1xuICAgICAgICAgICAgICAgIGlkOiByZXEuaWQsXG4gICAgICAgICAgICAgICAgdHlwZTogTUVTU0FHRV9UWVBFUy5SRVNQT05TRV9FUlJPUixcbiAgICAgICAgICAgICAgICBzb3VyY2U6ICd0d2VldENsYXcnLFxuICAgICAgICAgICAgICAgIHRhcmdldDogJ0xvY2FsQnJpZGdlTWFjJyxcbiAgICAgICAgICAgICAgICB0aW1lc3RhbXA6IERhdGUubm93KCksXG4gICAgICAgICAgICAgICAgcGF5bG9hZDoge1xuICAgICAgICAgICAgICAgICAgICBjb2RlOiAnSU5URVJOQUxfRVJST1InLFxuICAgICAgICAgICAgICAgICAgICBtZXNzYWdlOiBlIGluc3RhbmNlb2YgRXJyb3IgPyBlLm1lc3NhZ2UgOiBTdHJpbmcoZSksXG4gICAgICAgICAgICAgICAgICAgIGRldGFpbHM6IG51bGxcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9O1xuICAgICAgICAgICAgdGhpcy5zZW5kKGVyclJlc3ApO1xuICAgICAgICB9XG4gICAgfVxuICAgIGFzeW5jIGhhbmRsZVF1ZXJ5WEJhc2ljSW5mbyhyZXEpIHtcbiAgICAgICAgY29uc29sZS5sb2coJ1t0d2VldENsYXddIGhhbmRsaW5nIHJlcXVlc3QucXVlcnlfeF9iYXNpY19pbmZvJyk7XG4gICAgICAgIGlmICghdGhpcy5xdWVyeVhCYXNpY0luZm9IYW5kbGVyKSB7XG4gICAgICAgICAgICBjb25zb2xlLmVycm9yKCdbdHdlZXRDbGF3XSBubyBoYW5kbGVyIGZvciBxdWVyeV94X2Jhc2ljX2luZm8nKTtcbiAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgfVxuICAgICAgICB0cnkge1xuICAgICAgICAgICAgY29uc3QgcmVzdWx0ID0gYXdhaXQgdGhpcy5xdWVyeVhCYXNpY0luZm9IYW5kbGVyKCk7XG4gICAgICAgICAgICBjb25zdCByZXNwID0ge1xuICAgICAgICAgICAgICAgIGlkOiByZXEuaWQsXG4gICAgICAgICAgICAgICAgdHlwZTogTUVTU0FHRV9UWVBFUy5SRVNQT05TRV9RVUVSWV9YX0JBU0lDX0lORk8sXG4gICAgICAgICAgICAgICAgc291cmNlOiAndHdlZXRDbGF3JyxcbiAgICAgICAgICAgICAgICB0YXJnZXQ6ICdMb2NhbEJyaWRnZU1hYycsXG4gICAgICAgICAgICAgICAgdGltZXN0YW1wOiBEYXRlLm5vdygpLFxuICAgICAgICAgICAgICAgIHBheWxvYWQ6IHJlc3VsdFxuICAgICAgICAgICAgfTtcbiAgICAgICAgICAgIHRoaXMuc2VuZChyZXNwKTtcbiAgICAgICAgfVxuICAgICAgICBjYXRjaCAoZSkge1xuICAgICAgICAgICAgLy8gU2VuZCBhbiBlcnJvciByZXNwb25zZVxuICAgICAgICAgICAgY29uc3QgZXJyUmVzcCA9IHtcbiAgICAgICAgICAgICAgICBpZDogcmVxLmlkLFxuICAgICAgICAgICAgICAgIHR5cGU6IE1FU1NBR0VfVFlQRVMuUkVTUE9OU0VfRVJST1IsXG4gICAgICAgICAgICAgICAgc291cmNlOiAndHdlZXRDbGF3JyxcbiAgICAgICAgICAgICAgICB0YXJnZXQ6ICdMb2NhbEJyaWRnZU1hYycsXG4gICAgICAgICAgICAgICAgdGltZXN0YW1wOiBEYXRlLm5vdygpLFxuICAgICAgICAgICAgICAgIHBheWxvYWQ6IHtcbiAgICAgICAgICAgICAgICAgICAgY29kZTogJ0lOVEVSTkFMX0VSUk9SJyxcbiAgICAgICAgICAgICAgICAgICAgbWVzc2FnZTogZSBpbnN0YW5jZW9mIEVycm9yID8gZS5tZXNzYWdlIDogU3RyaW5nKGUpLFxuICAgICAgICAgICAgICAgICAgICBkZXRhaWxzOiBudWxsXG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfTtcbiAgICAgICAgICAgIHRoaXMuc2VuZChlcnJSZXNwKTtcbiAgICAgICAgfVxuICAgIH1cbiAgICBhc3luYyBoYW5kbGVPcGVuVGFiKHJlcSkge1xuICAgICAgICBjb25zb2xlLmxvZygnW3R3ZWV0Q2xhd10gaGFuZGxpbmcgcmVxdWVzdC5vcGVuX3RhYicpO1xuICAgICAgICBpZiAoIXRoaXMub3BlblRhYkhhbmRsZXIpIHtcbiAgICAgICAgICAgIGNvbnNvbGUuZXJyb3IoJ1t0d2VldENsYXddIG5vIGhhbmRsZXIgZm9yIG9wZW5fdGFiJyk7XG4gICAgICAgICAgICByZXR1cm47XG4gICAgICAgIH1cbiAgICAgICAgdHJ5IHtcbiAgICAgICAgICAgIGNvbnN0IHJlc3VsdCA9IGF3YWl0IHRoaXMub3BlblRhYkhhbmRsZXIocmVxLnBheWxvYWQpO1xuICAgICAgICAgICAgY29uc3QgcmVzcCA9IHtcbiAgICAgICAgICAgICAgICBpZDogcmVxLmlkLFxuICAgICAgICAgICAgICAgIHR5cGU6IE1FU1NBR0VfVFlQRVMuUkVTUE9OU0VfT1BFTl9UQUIsXG4gICAgICAgICAgICAgICAgc291cmNlOiAndHdlZXRDbGF3JyxcbiAgICAgICAgICAgICAgICB0YXJnZXQ6ICdMb2NhbEJyaWRnZU1hYycsXG4gICAgICAgICAgICAgICAgdGltZXN0YW1wOiBEYXRlLm5vdygpLFxuICAgICAgICAgICAgICAgIHBheWxvYWQ6IHJlc3VsdFxuICAgICAgICAgICAgfTtcbiAgICAgICAgICAgIHRoaXMuc2VuZChyZXNwKTtcbiAgICAgICAgfVxuICAgICAgICBjYXRjaCAoZSkge1xuICAgICAgICAgICAgY29uc3QgZXJyUmVzcCA9IHtcbiAgICAgICAgICAgICAgICBpZDogcmVxLmlkLFxuICAgICAgICAgICAgICAgIHR5cGU6IE1FU1NBR0VfVFlQRVMuUkVTUE9OU0VfRVJST1IsXG4gICAgICAgICAgICAgICAgc291cmNlOiAndHdlZXRDbGF3JyxcbiAgICAgICAgICAgICAgICB0YXJnZXQ6ICdMb2NhbEJyaWRnZU1hYycsXG4gICAgICAgICAgICAgICAgdGltZXN0YW1wOiBEYXRlLm5vdygpLFxuICAgICAgICAgICAgICAgIHBheWxvYWQ6IHtcbiAgICAgICAgICAgICAgICAgICAgY29kZTogJ0lOVEVSTkFMX0VSUk9SJyxcbiAgICAgICAgICAgICAgICAgICAgbWVzc2FnZTogZSBpbnN0YW5jZW9mIEVycm9yID8gZS5tZXNzYWdlIDogU3RyaW5nKGUpLFxuICAgICAgICAgICAgICAgICAgICBkZXRhaWxzOiBudWxsXG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfTtcbiAgICAgICAgICAgIHRoaXMuc2VuZChlcnJSZXNwKTtcbiAgICAgICAgfVxuICAgIH1cbiAgICBhc3luYyBoYW5kbGVDbG9zZVRhYihyZXEpIHtcbiAgICAgICAgY29uc29sZS5sb2coJ1t0d2VldENsYXddIGhhbmRsaW5nIHJlcXVlc3QuY2xvc2VfdGFiJyk7XG4gICAgICAgIGlmICghdGhpcy5jbG9zZVRhYkhhbmRsZXIpIHtcbiAgICAgICAgICAgIGNvbnNvbGUuZXJyb3IoJ1t0d2VldENsYXddIG5vIGhhbmRsZXIgZm9yIGNsb3NlX3RhYicpO1xuICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICB9XG4gICAgICAgIHRyeSB7XG4gICAgICAgICAgICBjb25zdCByZXN1bHQgPSBhd2FpdCB0aGlzLmNsb3NlVGFiSGFuZGxlcihyZXEucGF5bG9hZCk7XG4gICAgICAgICAgICBjb25zdCByZXNwID0ge1xuICAgICAgICAgICAgICAgIGlkOiByZXEuaWQsXG4gICAgICAgICAgICAgICAgdHlwZTogTUVTU0FHRV9UWVBFUy5SRVNQT05TRV9DTE9TRV9UQUIsXG4gICAgICAgICAgICAgICAgc291cmNlOiAndHdlZXRDbGF3JyxcbiAgICAgICAgICAgICAgICB0YXJnZXQ6ICdMb2NhbEJyaWRnZU1hYycsXG4gICAgICAgICAgICAgICAgdGltZXN0YW1wOiBEYXRlLm5vdygpLFxuICAgICAgICAgICAgICAgIHBheWxvYWQ6IHJlc3VsdFxuICAgICAgICAgICAgfTtcbiAgICAgICAgICAgIHRoaXMuc2VuZChyZXNwKTtcbiAgICAgICAgfVxuICAgICAgICBjYXRjaCAoZSkge1xuICAgICAgICAgICAgY29uc3QgZXJyUmVzcCA9IHtcbiAgICAgICAgICAgICAgICBpZDogcmVxLmlkLFxuICAgICAgICAgICAgICAgIHR5cGU6IE1FU1NBR0VfVFlQRVMuUkVTUE9OU0VfRVJST1IsXG4gICAgICAgICAgICAgICAgc291cmNlOiAndHdlZXRDbGF3JyxcbiAgICAgICAgICAgICAgICB0YXJnZXQ6ICdMb2NhbEJyaWRnZU1hYycsXG4gICAgICAgICAgICAgICAgdGltZXN0YW1wOiBEYXRlLm5vdygpLFxuICAgICAgICAgICAgICAgIHBheWxvYWQ6IHtcbiAgICAgICAgICAgICAgICAgICAgY29kZTogJ0lOVEVSTkFMX0VSUk9SJyxcbiAgICAgICAgICAgICAgICAgICAgbWVzc2FnZTogZSBpbnN0YW5jZW9mIEVycm9yID8gZS5tZXNzYWdlIDogU3RyaW5nKGUpLFxuICAgICAgICAgICAgICAgICAgICBkZXRhaWxzOiBudWxsXG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfTtcbiAgICAgICAgICAgIHRoaXMuc2VuZChlcnJSZXNwKTtcbiAgICAgICAgfVxuICAgIH1cbiAgICBhc3luYyBoYW5kbGVOYXZpZ2F0ZVRhYihyZXEpIHtcbiAgICAgICAgY29uc29sZS5sb2coJ1t0d2VldENsYXddIGhhbmRsaW5nIHJlcXVlc3QubmF2aWdhdGVfdGFiJyk7XG4gICAgICAgIGlmICghdGhpcy5uYXZpZ2F0ZVRhYkhhbmRsZXIpIHtcbiAgICAgICAgICAgIGNvbnNvbGUuZXJyb3IoJ1t0d2VldENsYXddIG5vIGhhbmRsZXIgZm9yIG5hdmlnYXRlX3RhYicpO1xuICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICB9XG4gICAgICAgIHRyeSB7XG4gICAgICAgICAgICBjb25zdCByZXN1bHQgPSBhd2FpdCB0aGlzLm5hdmlnYXRlVGFiSGFuZGxlcihyZXEucGF5bG9hZCk7XG4gICAgICAgICAgICBjb25zdCByZXNwID0ge1xuICAgICAgICAgICAgICAgIGlkOiByZXEuaWQsXG4gICAgICAgICAgICAgICAgdHlwZTogTUVTU0FHRV9UWVBFUy5SRVNQT05TRV9OQVZJR0FURV9UQUIsXG4gICAgICAgICAgICAgICAgc291cmNlOiAndHdlZXRDbGF3JyxcbiAgICAgICAgICAgICAgICB0YXJnZXQ6ICdMb2NhbEJyaWRnZU1hYycsXG4gICAgICAgICAgICAgICAgdGltZXN0YW1wOiBEYXRlLm5vdygpLFxuICAgICAgICAgICAgICAgIHBheWxvYWQ6IHJlc3VsdFxuICAgICAgICAgICAgfTtcbiAgICAgICAgICAgIHRoaXMuc2VuZChyZXNwKTtcbiAgICAgICAgfVxuICAgICAgICBjYXRjaCAoZSkge1xuICAgICAgICAgICAgY29uc3QgZXJyUmVzcCA9IHtcbiAgICAgICAgICAgICAgICBpZDogcmVxLmlkLFxuICAgICAgICAgICAgICAgIHR5cGU6IE1FU1NBR0VfVFlQRVMuUkVTUE9OU0VfRVJST1IsXG4gICAgICAgICAgICAgICAgc291cmNlOiAndHdlZXRDbGF3JyxcbiAgICAgICAgICAgICAgICB0YXJnZXQ6ICdMb2NhbEJyaWRnZU1hYycsXG4gICAgICAgICAgICAgICAgdGltZXN0YW1wOiBEYXRlLm5vdygpLFxuICAgICAgICAgICAgICAgIHBheWxvYWQ6IHtcbiAgICAgICAgICAgICAgICAgICAgY29kZTogJ0lOVEVSTkFMX0VSUk9SJyxcbiAgICAgICAgICAgICAgICAgICAgbWVzc2FnZTogZSBpbnN0YW5jZW9mIEVycm9yID8gZS5tZXNzYWdlIDogU3RyaW5nKGUpLFxuICAgICAgICAgICAgICAgICAgICBkZXRhaWxzOiBudWxsXG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfTtcbiAgICAgICAgICAgIHRoaXMuc2VuZChlcnJSZXNwKTtcbiAgICAgICAgfVxuICAgIH1cbiAgICBhc3luYyBoYW5kbGVFeGVjQWN0aW9uKHJlcSkge1xuICAgICAgICBjb25zb2xlLmxvZygnW3R3ZWV0Q2xhd10gaGFuZGxpbmcgcmVxdWVzdC5leGVjX2FjdGlvbicpO1xuICAgICAgICBpZiAoIXRoaXMuZXhlY0FjdGlvbkhhbmRsZXIpIHtcbiAgICAgICAgICAgIGNvbnNvbGUuZXJyb3IoJ1t0d2VldENsYXddIG5vIGhhbmRsZXIgZm9yIGV4ZWNfYWN0aW9uJyk7XG4gICAgICAgICAgICByZXR1cm47XG4gICAgICAgIH1cbiAgICAgICAgdHJ5IHtcbiAgICAgICAgICAgIGNvbnN0IHJlc3VsdCA9IGF3YWl0IHRoaXMuZXhlY0FjdGlvbkhhbmRsZXIocmVxLnBheWxvYWQpO1xuICAgICAgICAgICAgY29uc3QgcmVzcCA9IHtcbiAgICAgICAgICAgICAgICBpZDogcmVxLmlkLFxuICAgICAgICAgICAgICAgIHR5cGU6IE1FU1NBR0VfVFlQRVMuUkVTUE9OU0VfRVhFQ19BQ1RJT04sXG4gICAgICAgICAgICAgICAgc291cmNlOiAndHdlZXRDbGF3JyxcbiAgICAgICAgICAgICAgICB0YXJnZXQ6ICdMb2NhbEJyaWRnZU1hYycsXG4gICAgICAgICAgICAgICAgdGltZXN0YW1wOiBEYXRlLm5vdygpLFxuICAgICAgICAgICAgICAgIHBheWxvYWQ6IHJlc3VsdFxuICAgICAgICAgICAgfTtcbiAgICAgICAgICAgIHRoaXMuc2VuZChyZXNwKTtcbiAgICAgICAgfVxuICAgICAgICBjYXRjaCAoZSkge1xuICAgICAgICAgICAgY29uc3QgZXJyUmVzcCA9IHtcbiAgICAgICAgICAgICAgICBpZDogcmVxLmlkLFxuICAgICAgICAgICAgICAgIHR5cGU6IE1FU1NBR0VfVFlQRVMuUkVTUE9OU0VfRVJST1IsXG4gICAgICAgICAgICAgICAgc291cmNlOiAndHdlZXRDbGF3JyxcbiAgICAgICAgICAgICAgICB0YXJnZXQ6ICdMb2NhbEJyaWRnZU1hYycsXG4gICAgICAgICAgICAgICAgdGltZXN0YW1wOiBEYXRlLm5vdygpLFxuICAgICAgICAgICAgICAgIHBheWxvYWQ6IHtcbiAgICAgICAgICAgICAgICAgICAgY29kZTogJ0lOVEVSTkFMX0VSUk9SJyxcbiAgICAgICAgICAgICAgICAgICAgbWVzc2FnZTogZSBpbnN0YW5jZW9mIEVycm9yID8gZS5tZXNzYWdlIDogU3RyaW5nKGUpLFxuICAgICAgICAgICAgICAgICAgICBkZXRhaWxzOiBudWxsXG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfTtcbiAgICAgICAgICAgIHRoaXMuc2VuZChlcnJSZXNwKTtcbiAgICAgICAgfVxuICAgIH1cbiAgICBhc3luYyBoYW5kbGVHZW5lcmljUXVlcnkocmVxLCBoYW5kbGVyLCByZXNwb25zZVR5cGUpIHtcbiAgICAgICAgaWYgKCFoYW5kbGVyKSB7XG4gICAgICAgICAgICBjb25zb2xlLmVycm9yKGBbdHdlZXRDbGF3XSBubyBoYW5kbGVyIGZvciAke3Jlc3BvbnNlVHlwZX1gKTtcbiAgICAgICAgICAgIHRoaXMuc2VuZCh7XG4gICAgICAgICAgICAgICAgaWQ6IHJlcS5pZCxcbiAgICAgICAgICAgICAgICB0eXBlOiBNRVNTQUdFX1RZUEVTLlJFU1BPTlNFX0VSUk9SLFxuICAgICAgICAgICAgICAgIHNvdXJjZTogJ3R3ZWV0Q2xhdycsXG4gICAgICAgICAgICAgICAgdGFyZ2V0OiAnTG9jYWxCcmlkZ2VNYWMnLFxuICAgICAgICAgICAgICAgIHRpbWVzdGFtcDogRGF0ZS5ub3coKSxcbiAgICAgICAgICAgICAgICBwYXlsb2FkOiB7IGNvZGU6ICdJTlRFUk5BTF9FUlJPUicsIG1lc3NhZ2U6ICdIYW5kbGVyIG5vdCByZWdpc3RlcmVkJywgZGV0YWlsczogbnVsbCB9XG4gICAgICAgICAgICB9KTtcbiAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgfVxuICAgICAgICB0cnkge1xuICAgICAgICAgICAgY29uc3QgcmVzdWx0ID0gYXdhaXQgaGFuZGxlcihyZXEucGF5bG9hZCk7XG4gICAgICAgICAgICB0aGlzLnNlbmQoe1xuICAgICAgICAgICAgICAgIGlkOiByZXEuaWQsXG4gICAgICAgICAgICAgICAgdHlwZTogcmVzcG9uc2VUeXBlLFxuICAgICAgICAgICAgICAgIHNvdXJjZTogJ3R3ZWV0Q2xhdycsXG4gICAgICAgICAgICAgICAgdGFyZ2V0OiAnTG9jYWxCcmlkZ2VNYWMnLFxuICAgICAgICAgICAgICAgIHRpbWVzdGFtcDogRGF0ZS5ub3coKSxcbiAgICAgICAgICAgICAgICBwYXlsb2FkOiByZXN1bHRcbiAgICAgICAgICAgIH0pO1xuICAgICAgICB9XG4gICAgICAgIGNhdGNoIChlKSB7XG4gICAgICAgICAgICB0aGlzLnNlbmQoe1xuICAgICAgICAgICAgICAgIGlkOiByZXEuaWQsXG4gICAgICAgICAgICAgICAgdHlwZTogTUVTU0FHRV9UWVBFUy5SRVNQT05TRV9FUlJPUixcbiAgICAgICAgICAgICAgICBzb3VyY2U6ICd0d2VldENsYXcnLFxuICAgICAgICAgICAgICAgIHRhcmdldDogJ0xvY2FsQnJpZGdlTWFjJyxcbiAgICAgICAgICAgICAgICB0aW1lc3RhbXA6IERhdGUubm93KCksXG4gICAgICAgICAgICAgICAgcGF5bG9hZDogeyBjb2RlOiAnSU5URVJOQUxfRVJST1InLCBtZXNzYWdlOiBlLm1lc3NhZ2UsIGRldGFpbHM6IG51bGwgfVxuICAgICAgICAgICAgfSk7XG4gICAgICAgIH1cbiAgICB9XG4gICAgc3RhcnRIZWFydGJlYXQoaW50ZXJ2YWwpIHtcbiAgICAgICAgdGhpcy5zdG9wSGVhcnRiZWF0KCk7XG4gICAgICAgIGNvbnNvbGUubG9nKGBbdHdlZXRDbGF3XSBzdGFydGluZyBoZWFydGJlYXQgZXZlcnkgJHtpbnRlcnZhbH1tc2ApO1xuICAgICAgICB0aGlzLmhlYXJ0YmVhdEludGVydmFsID0gc2V0SW50ZXJ2YWwoKCkgPT4ge1xuICAgICAgICAgICAgLy8gQ2hlY2sgZm9yIHRpbWVvdXQgKDYwIHNlY29uZHMpXG4gICAgICAgICAgICBjb25zdCBub3cgPSBEYXRlLm5vdygpO1xuICAgICAgICAgICAgaWYgKHRoaXMubGFzdFBvbmdUaW1lc3RhbXAgPiAwICYmIG5vdyAtIHRoaXMubGFzdFBvbmdUaW1lc3RhbXAgPiA2MDAwMCkge1xuICAgICAgICAgICAgICAgIGNvbnNvbGUuZXJyb3IoJ1t0d2VldENsYXddIHBvbmcgdGltZW91dCwgY2xvc2luZyBzb2NrZXQnKTtcbiAgICAgICAgICAgICAgICB0aGlzLndzPy5jbG9zZSgpO1xuICAgICAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIHRoaXMuc2VuZFBpbmcoKTtcbiAgICAgICAgfSwgaW50ZXJ2YWwpO1xuICAgIH1cbiAgICBzdG9wSGVhcnRiZWF0KCkge1xuICAgICAgICBpZiAodGhpcy5oZWFydGJlYXRJbnRlcnZhbCkge1xuICAgICAgICAgICAgY2xlYXJJbnRlcnZhbCh0aGlzLmhlYXJ0YmVhdEludGVydmFsKTtcbiAgICAgICAgICAgIHRoaXMuaGVhcnRiZWF0SW50ZXJ2YWwgPSBudWxsO1xuICAgICAgICB9XG4gICAgfVxuICAgIHNlbmRQaW5nKCkge1xuICAgICAgICBjb25zdCBwaW5nID0ge1xuICAgICAgICAgICAgaWQ6IGBwaW5nXyR7RGF0ZS5ub3coKX1gLFxuICAgICAgICAgICAgdHlwZTogTUVTU0FHRV9UWVBFUy5QSU5HLFxuICAgICAgICAgICAgc291cmNlOiAndHdlZXRDbGF3JyxcbiAgICAgICAgICAgIHRhcmdldDogJ0xvY2FsQnJpZGdlTWFjJyxcbiAgICAgICAgICAgIHRpbWVzdGFtcDogRGF0ZS5ub3coKSxcbiAgICAgICAgICAgIHBheWxvYWQ6IHtcbiAgICAgICAgICAgICAgICBoZWFydGJlYXRJbnRlcnZhbE1zOiAyMDAwMFxuICAgICAgICAgICAgfVxuICAgICAgICB9O1xuICAgICAgICB0aGlzLnNlbmQocGluZyk7XG4gICAgfVxuICAgIHNlbmQobXNnKSB7XG4gICAgICAgIGlmICh0aGlzLndzICYmIHRoaXMud3MucmVhZHlTdGF0ZSA9PT0gV2ViU29ja2V0Lk9QRU4pIHtcbiAgICAgICAgICAgIHRoaXMud3Muc2VuZChKU09OLnN0cmluZ2lmeShtc2cpKTtcbiAgICAgICAgICAgIGNvbnNvbGUubG9nKGBbdHdlZXRDbGF3XSBzZW50IG1lc3NhZ2U6ICR7bXNnLnR5cGV9YCk7XG4gICAgICAgIH1cbiAgICAgICAgZWxzZSB7XG4gICAgICAgICAgICBjb25zb2xlLndhcm4oYFt0d2VldENsYXddIGNhbm5vdCBzZW5kIG1lc3NhZ2UsIHNvY2tldCBzdGF0dXM6ICR7dGhpcy53cz8ucmVhZHlTdGF0ZX1gKTtcbiAgICAgICAgfVxuICAgIH1cbn1cbiIsImV4cG9ydCBjb25zdCBQUk9UT0NPTF9OQU1FID0gJ2FpaHViLWxvY2FsYnJpZGdlJztcbmV4cG9ydCBjb25zdCBQUk9UT0NPTF9WRVJTSU9OID0gJ3YxJztcbmV4cG9ydCBjb25zdCBNRVNTQUdFX1RZUEVTID0ge1xuICAgIENMSUVOVF9IRUxMTzogJ2NsaWVudC5oZWxsbycsXG4gICAgU0VSVkVSX0hFTExPX0FDSzogJ3NlcnZlci5oZWxsb19hY2snLFxuICAgIFBJTkc6ICdwaW5nJyxcbiAgICBQT05HOiAncG9uZycsXG4gICAgUkVRVUVTVF9RVUVSWV9YX1RBQlNfU1RBVFVTOiAncmVxdWVzdC5xdWVyeV94X3RhYnNfc3RhdHVzJyxcbiAgICBSRVNQT05TRV9RVUVSWV9YX1RBQlNfU1RBVFVTOiAncmVzcG9uc2UucXVlcnlfeF90YWJzX3N0YXR1cycsXG4gICAgUkVRVUVTVF9RVUVSWV9YX0JBU0lDX0lORk86ICdyZXF1ZXN0LnF1ZXJ5X3hfYmFzaWNfaW5mbycsXG4gICAgUkVTUE9OU0VfUVVFUllfWF9CQVNJQ19JTkZPOiAncmVzcG9uc2UucXVlcnlfeF9iYXNpY19pbmZvJyxcbiAgICBSRVFVRVNUX09QRU5fVEFCOiAncmVxdWVzdC5vcGVuX3RhYicsXG4gICAgUkVTUE9OU0VfT1BFTl9UQUI6ICdyZXNwb25zZS5vcGVuX3RhYicsXG4gICAgUkVRVUVTVF9DTE9TRV9UQUI6ICdyZXF1ZXN0LmNsb3NlX3RhYicsXG4gICAgUkVTUE9OU0VfQ0xPU0VfVEFCOiAncmVzcG9uc2UuY2xvc2VfdGFiJyxcbiAgICBSRVFVRVNUX05BVklHQVRFX1RBQjogJ3JlcXVlc3QubmF2aWdhdGVfdGFiJyxcbiAgICBSRVNQT05TRV9OQVZJR0FURV9UQUI6ICdyZXNwb25zZS5uYXZpZ2F0ZV90YWInLFxuICAgIFJFUVVFU1RfRVhFQ19BQ1RJT046ICdyZXF1ZXN0LmV4ZWNfYWN0aW9uJyxcbiAgICBSRVNQT05TRV9FWEVDX0FDVElPTjogJ3Jlc3BvbnNlLmV4ZWNfYWN0aW9uJyxcbiAgICBSRVFVRVNUX1FVRVJZX0hPTUVfVElNRUxJTkU6ICdyZXF1ZXN0LnF1ZXJ5X2hvbWVfdGltZWxpbmUnLFxuICAgIFJFU1BPTlNFX1FVRVJZX0hPTUVfVElNRUxJTkU6ICdyZXNwb25zZS5xdWVyeV9ob21lX3RpbWVsaW5lJyxcbiAgICBSRVFVRVNUX1FVRVJZX1RXRUVUX0RFVEFJTDogJ3JlcXVlc3QucXVlcnlfdHdlZXRfZGV0YWlsJyxcbiAgICBSRVNQT05TRV9RVUVSWV9UV0VFVF9ERVRBSUw6ICdyZXNwb25zZS5xdWVyeV90d2VldF9kZXRhaWwnLFxuICAgIFJFUVVFU1RfUVVFUllfVVNFUl9QUk9GSUxFOiAncmVxdWVzdC5xdWVyeV91c2VyX3Byb2ZpbGUnLFxuICAgIFJFU1BPTlNFX1FVRVJZX1VTRVJfUFJPRklMRTogJ3Jlc3BvbnNlLnF1ZXJ5X3VzZXJfcHJvZmlsZScsXG4gICAgUkVRVUVTVF9RVUVSWV9TRUFSQ0hfVElNRUxJTkU6ICdyZXF1ZXN0LnF1ZXJ5X3NlYXJjaF90aW1lbGluZScsXG4gICAgUkVTUE9OU0VfUVVFUllfU0VBUkNIX1RJTUVMSU5FOiAncmVzcG9uc2UucXVlcnlfc2VhcmNoX3RpbWVsaW5lJyxcbiAgICBSRVNQT05TRV9FUlJPUjogJ3Jlc3BvbnNlLmVycm9yJyxcbn07XG5leHBvcnQgY29uc3QgRVJST1JfQ09ERVMgPSB7XG4gICAgSU5WQUxJRF9KU09OOiAnSU5WQUxJRF9KU09OJyxcbiAgICBJTlZBTElEX01FU1NBR0VfU0hBUEU6ICdJTlZBTElEX01FU1NBR0VfU0hBUEUnLFxuICAgIFVOU1VQUE9SVEVEX01FU1NBR0VfVFlQRTogJ1VOU1VQUE9SVEVEX01FU1NBR0VfVFlQRScsXG4gICAgUFJPVE9DT0xfVkVSU0lPTl9NSVNNQVRDSDogJ1BST1RPQ09MX1ZFUlNJT05fTUlTTUFUQ0gnLFxuICAgIE5PVF9DT05ORUNURUQ6ICdOT1RfQ09OTkVDVEVEJyxcbiAgICBSRVFVRVNUX1RJTUVPVVQ6ICdSRVFVRVNUX1RJTUVPVVQnLFxuICAgIElOVEVSTkFMX0VSUk9SOiAnSU5URVJOQUxfRVJST1InLFxufTtcbiIsImV4cG9ydCBjb25zdCBfX0RCS19xdWVyeV9pZF9tYXAgPSAndGNfcXVlcnlfaWRfbWFwJztcbmV4cG9ydCBjb25zdCBfX0RCS19iZWFyZXJfdG9rZW4gPSAndGNfYmVhcmVyX3Rva2VuJztcbmV4cG9ydCBjb25zdCBfX0RCS19keW5hbWljX2ZlYXR1cmVzID0gJ3RjX2R5bmFtaWNfZmVhdHVyZXMnO1xuZXhwb3J0IHZhciBNc2dUeXBlO1xuKGZ1bmN0aW9uIChNc2dUeXBlKSB7XG4gICAgTXNnVHlwZVtcIlBJTkdcIl0gPSBcIlBJTkdcIjtcbiAgICBNc2dUeXBlW1wiRVhFQ1VURV9BQ1RJT05cIl0gPSBcIkVYRUNVVEVfQUNUSU9OXCI7XG59KShNc2dUeXBlIHx8IChNc2dUeXBlID0ge30pKTtcbmV4cG9ydCBjb25zdCB3YXRjaGVkT3BzID0gW1xuICAgICdVc2VyVHdlZXRzJyxcbiAgICAnSG9tZVRpbWVsaW5lJyxcbiAgICAnSG9tZUxhdGVzdFRpbWVsaW5lJyxcbiAgICAnVHdlZXREZXRhaWwnLFxuICAgICdVc2VyQnlTY3JlZW5OYW1lJyxcbiAgICAnUHJvZmlsZVNwb3RsaWdodHNRdWVyeScsXG4gICAgJ0FjY291bnRTZXR0aW5ncycsXG4gICAgJ0F1dGhlbnRpY2F0ZWRVc2VyUXVlcnknLFxuICAgICdWaWV3ZXInLFxuICAgICdWZXJpZnlDcmVkZW50aWFscycsXG4gICAgJ0NyZWF0ZUZyaWVuZHNoaXAnLFxuICAgICdEZXN0cm95RnJpZW5kc2hpcCcsXG4gICAgJ0NyZWF0ZUJvb2ttYXJrJyxcbiAgICAnRGVsZXRlQm9va21hcmsnLFxuICAgICdGb2xsb3dlcnMnLFxuICAgICdGb2xsb3dpbmcnLFxuICAgICdTZWFyY2hUaW1lbGluZScsXG4gICAgJ0Zhdm9yaXRlVHdlZXQnLFxuICAgICdVbmZhdm9yaXRlVHdlZXQnLFxuICAgICdDcmVhdGVSZXR3ZWV0JyxcbiAgICAnRGVsZXRlUmV0d2VldCcsXG4gICAgJ0xpc3RMYXRlc3RUd2VldHNUaW1lbGluZScsXG4gICAgJ1RpbWVsaW5lSG9tZScsXG4gICAgJ0FjY291bnRVc2VyUXVlcnknLFxuICAgICdVc2VyQnlSZXN0SWQnLFxuICAgICdDcmVhdGVUd2VldCcsIC8vIOaWsOWinu+8muWPkeaOqOaWh++8iOWQq+WbnuWkje+8iVxuICAgICdEZWxldGVUd2VldCcsIC8vIOaWsOWinu+8muWIoOmZpOaOqOaWh1xuICAgICdEZWxldGVSZXR3ZWV0JyAvLyDmlrDlop7vvJrlj5bmtojovazlj5Fcbl07XG5leHBvcnQgY29uc3QgZGVmYXVsdFF1ZXJ5S2V5TWFwID0ge1xuICAgICdVc2VyQnlTY3JlZW5OYW1lJzogJ2NrNUtrWjh0NWNPbW9Mc3NvcE45OVEnLFxuICAgICdVc2VyVHdlZXRzJzogJ0U4V3EtX2pGU2FVN2h4VmN1T1BSOWcnLFxuICAgICdIb21lTGF0ZXN0VGltZWxpbmUnOiAnU0Z4bU5LV2ZOOXlTSmNYR190alg4ZycsXG4gICAgJ0hvbWVUaW1lbGluZSc6ICdEWG1nUVltSWZ0MW9MUDZ2TWtKaXh3JyxcbiAgICAnVHdlZXREZXRhaWwnOiAnaUZFcjVBY1AxMjFPZzR3eDlZcW8zdycsXG4gICAgJ1NlYXJjaFRpbWVsaW5lJzogJzRmcGNlWVo2LVlRQ3hfSlNsX0NuX0EnLFxuICAgICdDcmVhdGVCb29rbWFyayc6ICdhb0RidTNSSHpudWlTa1E5YU5NNjdRJyxcbiAgICAnRGVsZXRlQm9va21hcmsnOiAnV2xtbGoyLXh6eVMxR04zYTZjai1tUScsXG4gICAgJ0ZvbGxvd2luZyc6ICdTYVdxencwVEZBV014MW5YV2pYb2FRJyxcbiAgICAnRm9sbG93ZXJzJzogJ2k2UFBkSU1tMU1PN0NwQXFqYXU3c3cnLFxuICAgICdGYXZvcml0ZVR3ZWV0JzogJ2xJMDdONk90d3YxUGhuRWdYSUxNN0EnLFxuICAgICdVbmZhdm9yaXRlVHdlZXQnOiAnWllLU2UtdzdLRXNseDNKaFNJazVMQScsXG4gICAgJ0NyZWF0ZVJldHdlZXQnOiAnbWJSTzc0R3JPdlNmUmNKbmxNYXBuUScsXG4gICAgJ0NyZWF0ZUZyaWVuZHNoaXAnOiAnNjZ2OV9TX3ZUaGhBcmV3Xzk5djlfdjknLFxuICAgICdEZXN0cm95RnJpZW5kc2hpcCc6ICdPcHY3X3A4QXVuTWhKdkQ4WDhjOXJ3JyxcbiAgICAnVXNlckJ5UmVzdElkJzogJ0xKWUlfVnZURkFaZjdQQWRUMGVXbUEnLFxuICAgICdDcmVhdGVUd2VldCc6ICd6a2NGYzZGLVJLUmdXTjhIVWtKZlpnJywgLy8g5paw5aKe77ya5bey56Gu6K6k77yIMjAyNS0wNe+8iVxuICAgICdEZWxldGVUd2VldCc6ICdueHBaQ1kySy1JNlFvRkhBSGVvakZRJywgLy8g5paw5aKe77ya5bey56Gu6K6k77yIMjAyNS0wNe+8iVxuICAgICdEZWxldGVSZXR3ZWV0JzogJ1p5WmlnVnNOaUZPNnYxZEVrczFlV2cnIC8vIOaWsOWinu+8muW3suehruiupO+8iDIwMjUtMDXvvIlcbn07XG4vKipcbiAqIOivhuWIqyBYIOa4uOWuoui0puWPt++8iEd1ZXN0IFRva2Vu77yJXG4gKlxuICogWCDnmoQgZ3Vlc3QgdG9rZW4gaGFuZGxlIOeJueW+ge+8mlxuICogICAtIOaBsOWlvSAxNSDkuKrlrZfnrKZcbiAqICAgLSDlhajpg6jmmK/lsI/lhpnlrZfmr40gKyDmlbDlrZfvvIjml6DlpKflhpnlrZfmr43jgIHml6DkuIvliJLnur/vvIlcbiAqICAgLSDlkKvmnInoh7PlsJHkuIDkuKrmlbDlrZdcbiAqXG4gKiDnnJ/lrp7nlKjmiLcgaGFuZGxlIOWPr+S7peWMheWQq+Wkp+WGmeWtl+avjeaIluS4i+WIkue6v++8jOS4jeS8muiiq+ivr+WIpOOAglxuICog5L6L5aaC6K+v5Yik5qGI5L6L77yaMURVMUdmN29FbFIyaDI4IOKGkiDlkKvlpKflhpkg4oaSIOS4jeaYryBndWVzdCDinJNcbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIGlzR3Vlc3RIYW5kbGUoaCkge1xuICAgIGlmICghaClcbiAgICAgICAgcmV0dXJuIGZhbHNlO1xuICAgIGNvbnN0IGNsZWFuID0gaC5zdGFydHNXaXRoKCdAJykgPyBoLnN1YnN0cmluZygxKSA6IGg7XG4gICAgLy8gR3Vlc3QgaGFuZGxlcyBhcmUgcmFuZG9tIDE1LWNoYXIgc3RyaW5ncyAoZS5nLiwgJ3h5ejEyMzRhYmM1Njc4eicgb3IgJzEyMzQ1Njc4OTAxMjM0NScpXG4gICAgLy8gUmVhbCB1c2VycyBsaWtlICd3ZWIzYnJpZGdlbmluamEnICgxNSBjaGFycywgbG93ZXJjYXNlLCAxIGRpZ2l0KSBhcmUgY29tbW9uIGZhbHNlIHBvc2l0aXZlcy5cbiAgICBpZiAoY2xlYW4ubGVuZ3RoICE9PSAxNSB8fCAhL15bYS16MC05XSskLy50ZXN0KGNsZWFuKSlcbiAgICAgICAgcmV0dXJuIGZhbHNlO1xuICAgIGNvbnN0IGRpZ2l0cyA9IChjbGVhbi5tYXRjaCgvXFxkL2cpIHx8IFtdKS5sZW5ndGg7XG4gICAgY29uc3QgaGFzVm93ZWxzID0gL1thZWlvdV0vLnRlc3QoY2xlYW4pO1xuICAgIC8vIEhldXJpc3RpY3M6XG4gICAgLy8gMS4gQWxsIG51bWVyaWMgaXMgZGVmaW5pdGVseSBhIGd1ZXN0IHRva2VuXG4gICAgaWYgKC9eXFxkKyQvLnRlc3QoY2xlYW4pKVxuICAgICAgICByZXR1cm4gdHJ1ZTtcbiAgICAvLyAyLiBBbHBoYW51bWVyaWMgd2l0aCBoaWdoIGRpZ2l0IGNvdW50ICg+PSAzKSBhbmQgbm8gdm93ZWxzIGlzIHZlcnkgbGlrZWx5IGEgZ3Vlc3RcbiAgICBpZiAoZGlnaXRzID49IDIgJiYgIWhhc1Zvd2VscylcbiAgICAgICAgcmV0dXJuIHRydWU7XG4gICAgLy8gMy4gVmVyeSBoaWdoIGRpZ2l0IGNvdW50ICg+PSA1KSBpcyBhbHNvIGEgcmVkIGZsYWcgZXZlbiB3aXRoIHZvd2Vsc1xuICAgIGlmIChkaWdpdHMgPj0gNSlcbiAgICAgICAgcmV0dXJuIHRydWU7XG4gICAgcmV0dXJuIGZhbHNlO1xufVxuIiwiaW1wb3J0IHsgaXNHdWVzdEhhbmRsZSB9IGZyb20gJy4vY29uc3RzJztcbmltcG9ydCB7IGV4dHJhY3RUd2VldHNGcm9tVGltZWxpbmUgfSBmcm9tICcuL3RpbWVsaW5lLWV4dHJhY3Rvcic7XG5pbXBvcnQgeyBleHRyYWN0VHdlZXRJZCB9IGZyb20gJy4uL3V0aWxzL3JvdXRlLXBhcnNlcic7XG4vLyDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIBcbi8vIOS7heWPl+S/oeS7u+eahCBpZGVudGl0eSDmk43kvZzvvIjkuI3mjqXlj5fmma7pgJrnlKjmiLfkuLvpobUgZmV0Y2gg5L2c5Li66Lqr5Lu95p2l5rqQ77yJXG4vLyDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIBcbmNvbnN0IFRSVVNURURfSURFTlRJVFlfT1BTID0gbmV3IFNldChbXG4gICAgJ0F1dGhlbnRpY2F0ZWRVc2VyUXVlcnknLFxuICAgICdWaWV3ZXInLFxuICAgICdBY2NvdW50U2V0dGluZ3MnLFxuICAgICdzZXR0aW5ncy5qc29uJyxcbiAgICAnVmVyaWZ5Q3JlZGVudGlhbHMnXG5dKTtcbmV4cG9ydCBmdW5jdGlvbiBpc1RydXN0YWJsZUlkZW50aXR5T3Aob3ApIHtcbiAgICByZXR1cm4gVFJVU1RFRF9JREVOVElUWV9PUFMuaGFzKG9wKTtcbn1cbi8vIOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgFxuLy8gZ2V0T3BOYW1lOiDku44gQVBJIFVSTCDop6PmnpAgb3BlcmF0aW9uTmFtZVxuLy8g4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSAXG5leHBvcnQgZnVuY3Rpb24gZ2V0T3BOYW1lKHVybCkge1xuICAgIGlmICghdXJsKVxuICAgICAgICByZXR1cm4gbnVsbDtcbiAgICAvLyBHcmFwaFFMOiAvaS9hcGkvZ3JhcGhxbC97cXVlcnlJZH0ve09wZXJhdGlvbk5hbWV9Wz8uLi5dXG4gICAgY29uc3QgZ3FsTWF0Y2ggPSB1cmwubWF0Y2goL1xcL2dyYXBocWxcXC9bXlxcL10rXFwvKFtePyYvXFxzXSspLyk7XG4gICAgaWYgKGdxbE1hdGNoKVxuICAgICAgICByZXR1cm4gZ3FsTWF0Y2hbMV07XG4gICAgLy8gUkVTVCAxLjEg54m55q6K5pig5bCEXG4gICAgaWYgKHVybC5pbmNsdWRlcygnL2FjY291bnQvc2V0dGluZ3MuanNvbicpKVxuICAgICAgICByZXR1cm4gJ3NldHRpbmdzLmpzb24nO1xuICAgIGlmICh1cmwuaW5jbHVkZXMoJy9hY2NvdW50L3ZlcmlmeV9jcmVkZW50aWFscy5qc29uJykpXG4gICAgICAgIHJldHVybiAnVmVyaWZ5Q3JlZGVudGlhbHMnO1xuICAgIHJldHVybiBudWxsO1xufVxuLy8g4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSAXG4vLyBmaW5kU2NyZWVuTmFtZVJlY3Vyc2l2ZTog6YCS5b2S5pCc57SiIHNjcmVlbl9uYW1l77yI6Z2eIGd1ZXN077yJXG4vLyDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIBcbmV4cG9ydCBmdW5jdGlvbiBmaW5kU2NyZWVuTmFtZVJlY3Vyc2l2ZShvYmosIGRlcHRoID0gMCkge1xuICAgIGlmICghb2JqIHx8IHR5cGVvZiBvYmogIT09ICdvYmplY3QnIHx8IGRlcHRoID4gNilcbiAgICAgICAgcmV0dXJuIG51bGw7XG4gICAgaWYgKHR5cGVvZiBvYmouc2NyZWVuX25hbWUgPT09ICdzdHJpbmcnICYmICFpc0d1ZXN0SGFuZGxlKG9iai5zY3JlZW5fbmFtZSkpIHtcbiAgICAgICAgcmV0dXJuIG9iai5zY3JlZW5fbmFtZTtcbiAgICB9XG4gICAgZm9yIChjb25zdCBrZXkgb2YgT2JqZWN0LmtleXMob2JqKSkge1xuICAgICAgICBjb25zdCB2YWwgPSBvYmpba2V5XTtcbiAgICAgICAgaWYgKHZhbCAmJiB0eXBlb2YgdmFsID09PSAnb2JqZWN0Jykge1xuICAgICAgICAgICAgY29uc3QgZm91bmQgPSBmaW5kU2NyZWVuTmFtZVJlY3Vyc2l2ZSh2YWwsIGRlcHRoICsgMSk7XG4gICAgICAgICAgICBpZiAoZm91bmQpXG4gICAgICAgICAgICAgICAgcmV0dXJuIGZvdW5kO1xuICAgICAgICB9XG4gICAgfVxuICAgIHJldHVybiBudWxsO1xufVxuZXhwb3J0IGZ1bmN0aW9uIGZpbmRWaWV3ZXJTdW1tYXJ5KGRhdGEsIHRhcmdldFVpZCkge1xuICAgIGlmICghZGF0YSlcbiAgICAgICAgcmV0dXJuIG51bGw7XG4gICAgY29uc3QgZXh0cmFjdCA9IChvYmopID0+IHtcbiAgICAgICAgaWYgKCFvYmogfHwgIW9iai5sZWdhY3kpXG4gICAgICAgICAgICByZXR1cm4gbnVsbDtcbiAgICAgICAgY29uc3QgaGFuZGxlID0gb2JqLmxlZ2FjeS5zY3JlZW5fbmFtZTtcbiAgICAgICAgY29uc3QgdXNlcklkID0gb2JqLnJlc3RfaWQ7XG4gICAgICAgIGlmICghaGFuZGxlKVxuICAgICAgICAgICAgcmV0dXJuIG51bGw7XG4gICAgICAgIC8vIFNhZmV0eTogSWYgaXQgbWF0Y2hlcyBvdXIgY29uZmlybWVkIFVJRCAoZnJvbSB0d2lkIGNvb2tpZSksIGl0J3MgdGhlIHVzZXIsIG5vdCBhIGd1ZXN0XG4gICAgICAgIGNvbnN0IGlzQWN0dWFsbHlWaWV3ZXIgPSB0YXJnZXRVaWQgJiYgdXNlcklkID09PSB0YXJnZXRVaWQ7XG4gICAgICAgIGlmIChpc0d1ZXN0SGFuZGxlKGhhbmRsZSkgJiYgIWlzQWN0dWFsbHlWaWV3ZXIpXG4gICAgICAgICAgICByZXR1cm4gbnVsbDtcbiAgICAgICAgaWYgKHRhcmdldFVpZCAmJiB1c2VySWQgIT09IHRhcmdldFVpZClcbiAgICAgICAgICAgIHJldHVybiBudWxsO1xuICAgICAgICByZXR1cm4ge1xuICAgICAgICAgICAgaGFuZGxlOiBgQCR7aGFuZGxlfWAsXG4gICAgICAgICAgICB1c2VySWQ6IHVzZXJJZCxcbiAgICAgICAgICAgIGRpc3BsYXlOYW1lOiBvYmoubGVnYWN5Lm5hbWUsXG4gICAgICAgICAgICB2ZXJpZmllZDogb2JqLmxlZ2FjeS52ZXJpZmllZCB8fCBmYWxzZSxcbiAgICAgICAgICAgIGRlc2NyaXB0aW9uOiBvYmoubGVnYWN5LmRlc2NyaXB0aW9uLFxuICAgICAgICAgICAgYXZhdGFyOiBvYmoubGVnYWN5LnByb2ZpbGVfaW1hZ2VfdXJsX2h0dHBzLFxuICAgICAgICAgICAgZm9sbG93ZXJzQ291bnQ6IG9iai5sZWdhY3kuZm9sbG93ZXJzX2NvdW50LFxuICAgICAgICAgICAgZnJpZW5kc0NvdW50OiBvYmoubGVnYWN5LmZyaWVuZHNfY291bnQsXG4gICAgICAgICAgICBzdGF0dXNlc0NvdW50OiBvYmoubGVnYWN5LnN0YXR1c2VzX2NvdW50LFxuICAgICAgICAgICAgY3JlYXRlZEF0OiBvYmoubGVnYWN5LmNyZWF0ZWRfYXQsXG4gICAgICAgICAgICByYXc6IG9iaiAvLyDpmYTliqDljp/lp4vlr7nosaFcbiAgICAgICAgfTtcbiAgICB9O1xuICAgIC8vIDEuIHYxLjEgUkVTVCDmiYHlubPnu5PmnoTvvIhzZXR0aW5ncy5qc29uIC8gdmVyaWZ5X2NyZWRlbnRpYWxzLmpzb27vvIlcbiAgICAvLyAgICBzZXR0aW5ncy5qc29uIOS7heWcqOeZu+W9leWQjuWPr+inge+8jOmHjOmdoueahCBoYW5kbGUg5Y+q6KaB5a2Y5Zyo5bCx5piv55yf5a6e55qEXG4gICAgaWYgKGRhdGEuc2NyZWVuX25hbWUpIHtcbiAgICAgICAgY29uc3QgdXNlcklkID0gZGF0YS5pZF9zdHIgfHwgZGF0YS5pZD8udG9TdHJpbmcoKSB8fCAnJztcbiAgICAgICAgY29uc3QgaXNBY3R1YWxseVZpZXdlciA9IHRhcmdldFVpZCAmJiB1c2VySWQgPT09IHRhcmdldFVpZDtcbiAgICAgICAgaWYgKGlzR3Vlc3RIYW5kbGUoZGF0YS5zY3JlZW5fbmFtZSkgJiYgIWlzQWN0dWFsbHlWaWV3ZXIpXG4gICAgICAgICAgICByZXR1cm4gbnVsbDtcbiAgICAgICAgaWYgKHRhcmdldFVpZCAmJiB1c2VySWQgIT09IHRhcmdldFVpZClcbiAgICAgICAgICAgIHJldHVybiBudWxsOyAvLyDnoa7kv50gVUlEIOWMuemFjVxuICAgICAgICByZXR1cm4ge1xuICAgICAgICAgICAgaGFuZGxlOiBgQCR7ZGF0YS5zY3JlZW5fbmFtZX1gLFxuICAgICAgICAgICAgdXNlcklkOiB1c2VySWQsXG4gICAgICAgICAgICBkaXNwbGF5TmFtZTogZGF0YS5uYW1lIHx8IGRhdGEuc2NyZWVuX25hbWUgfHwgJycsIC8vIOehruS/nSBkaXNwbGF5TmFtZSDkuI3kuLrnqbpcbiAgICAgICAgICAgIHZlcmlmaWVkOiBkYXRhLnZlcmlmaWVkIHx8IGZhbHNlLFxuICAgICAgICAgICAgZGVzY3JpcHRpb246IGRhdGEuZGVzY3JpcHRpb24sXG4gICAgICAgICAgICBhdmF0YXI6IGRhdGEucHJvZmlsZV9pbWFnZV91cmxfaHR0cHMsXG4gICAgICAgICAgICBmb2xsb3dlcnNDb3VudDogZGF0YS5mb2xsb3dlcnNfY291bnQsXG4gICAgICAgICAgICBmcmllbmRzQ291bnQ6IGRhdGEuZnJpZW5kc19jb3VudCxcbiAgICAgICAgICAgIHN0YXR1c2VzQ291bnQ6IGRhdGEuc3RhdHVzZXNfY291bnQsXG4gICAgICAgICAgICBjcmVhdGVkQXQ6IGRhdGEuY3JlYXRlZF9hdCxcbiAgICAgICAgICAgIHJhdzogZGF0YSAvLyDpmYTliqDljp/lp4vmlbDmja5cbiAgICAgICAgfTtcbiAgICB9XG4gICAgY29uc3QgdSA9IGZpbmREZWVwVXNlcihkYXRhKTtcbiAgICBpZiAodSkge1xuICAgICAgICBjb25zb2xlLmxvZygnW1R3ZWV0Q2xhdy1FeHRyYWN0b3JdIGZpbmREZWVwVXNlciBmb3VuZCB2YWxpZCB1c2VyIG9iamVjdCcpO1xuICAgICAgICBjb25zdCBzdW1tYXJ5ID0gZXh0cmFjdCh1KTtcbiAgICAgICAgaWYgKHN1bW1hcnkpXG4gICAgICAgICAgICByZXR1cm4gc3VtbWFyeTtcbiAgICB9XG4gICAgY29uc29sZS53YXJuKCdbVHdlZXRDbGF3LUV4dHJhY3Rvcl0gZmluZFZpZXdlclN1bW1hcnkgZmFpbGVkIHRvIGZpbmQgYW55IHZhbGlkIHVzZXIgYmxvY2sgaW4gZGF0YTonLCB7XG4gICAgICAgIGhhc0RhdGE6ICEhZGF0YSxcbiAgICAgICAga2V5czogT2JqZWN0LmtleXMoZGF0YSB8fCB7fSksXG4gICAgICAgIHRhcmdldFVpZFxuICAgIH0pO1xuICAgIHJldHVybiBudWxsO1xufVxuLy8g4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSAXG4vLyBmaW5kRmVhdHVyZWRUd2VldDog5LuO5ZON5bqU5L2T5Lit5o+Q5Y+W5LiA5p2h5Luj6KGo5oCn5o6o5paH77yI55So5LqOIGRlYnVnIC8gcXVpY2sgYWN0aW9u77yJXG4vLyDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIBcbmV4cG9ydCBmdW5jdGlvbiBmaW5kRmVhdHVyZWRUd2VldChkYXRhLCBwYWdlVXJsKSB7XG4gICAgdHJ5IHtcbiAgICAgICAgY29uc3QgdHdlZXRzID0gZXh0cmFjdFR3ZWV0c0Zyb21UaW1lbGluZShkYXRhKTtcbiAgICAgICAgaWYgKHR3ZWV0cy5sZW5ndGggPT09IDApXG4gICAgICAgICAgICByZXR1cm4gbnVsbDtcbiAgICAgICAgLy8g5aaC5p6c5o+Q5L6b5LqGIHBhZ2VVcmzvvIzlsJ3or5XljLnphY0gc3RhdHVzIElEICjnlKjkuo4gdHdlZXRfZGV0YWlsIOWcuuaZr+mAieS4reS4u+aOqOaWhylcbiAgICAgICAgY29uc3QgdGFyZ2V0SWQgPSBwYWdlVXJsID8gZXh0cmFjdFR3ZWV0SWQocGFnZVVybCkgOiBudWxsO1xuICAgICAgICBsZXQgYmVzdCA9IHRhcmdldElkID8gdHdlZXRzLmZpbmQodCA9PiB0LnR3ZWV0SWQgPT09IHRhcmdldElkKSA6IG51bGw7XG4gICAgICAgIC8vIOWmguaenOayoeaJvuWIsOWMuemFjeeahO+8jOaIluiAheS4jeaYr+ivpuaDhemhte+8jOmAieesrOS4gOS4qlxuICAgICAgICBpZiAoIWJlc3QpIHtcbiAgICAgICAgICAgIGJlc3QgPSB0d2VldHNbMF07XG4gICAgICAgIH1cbiAgICAgICAgaWYgKCFiZXN0KVxuICAgICAgICAgICAgcmV0dXJuIG51bGw7XG4gICAgICAgIHJldHVybiB7XG4gICAgICAgICAgICBpZDogYmVzdC50d2VldElkLFxuICAgICAgICAgICAgdGV4dDogYmVzdC50ZXh0IHx8ICcnLFxuICAgICAgICAgICAgYXV0aG9ySGFuZGxlOiBiZXN0LmF1dGhvckhhbmRsZSB8fCAnJyxcbiAgICAgICAgICAgIGF1dGhvck5hbWU6IGJlc3QuYXV0aG9yTmFtZSB8fCAnJyxcbiAgICAgICAgICAgIGF1dGhvcklkOiBiZXN0LmF1dGhvcklkIHx8ICcnLFxuICAgICAgICAgICAgY3JlYXRlZEF0OiBiZXN0LmNyZWF0ZWRBdCB8fCAnJyxcbiAgICAgICAgICAgIGxpa2VDb3VudDogYmVzdC5saWtlQ291bnQgPz8gMCxcbiAgICAgICAgICAgIHJlcGx5Q291bnQ6IGJlc3QucmVwbHlDb3VudCA/PyAwLFxuICAgICAgICAgICAgcmVwb3N0Q291bnQ6IGJlc3QucmVwb3N0Q291bnQgPz8gMCxcbiAgICAgICAgICAgIGJvb2ttYXJrQ291bnQ6IGJlc3QuYm9va21hcmtDb3VudCA/PyAwXG4gICAgICAgIH07XG4gICAgfVxuICAgIGNhdGNoIChlKSB7XG4gICAgICAgIGNvbnNvbGUud2FybignW1R3ZWV0Q2xhdy1FeHRyYWN0b3JdIEVycm9yIGluIGZpbmRGZWF0dXJlZFR3ZWV0JywgZSk7XG4gICAgfVxuICAgIHJldHVybiBudWxsO1xufVxuLyoqXG4gKiDlr7vmib7lk43lupTkvZPkuK3nibnlrpogSUQg55qE5o6o5paHXG4gKiDnlKjkuo7lvZPlvZPliY0gVVJMIOS4juW3sue8k+WtmOeahCBmZWF0dXJlZFR3ZWV0IOS4jeWMuemFjeaXtu+8jOmHjeaWsOS7juWOn+Wni+WTjeW6lOS4reaJvuWbnuS4u+aOqOaWh1xuICovXG5leHBvcnQgZnVuY3Rpb24gZmluZFR3ZWV0QnlJZChkYXRhLCB0d2VldElkKSB7XG4gICAgdHJ5IHtcbiAgICAgICAgY29uc3QgdHdlZXRzID0gZXh0cmFjdFR3ZWV0c0Zyb21UaW1lbGluZShkYXRhKTtcbiAgICAgICAgY29uc3QgbWF0Y2ggPSB0d2VldHMuZmluZCh0ID0+IHQudHdlZXRJZCA9PT0gdHdlZXRJZCk7XG4gICAgICAgIGlmICghbWF0Y2gpXG4gICAgICAgICAgICByZXR1cm4gbnVsbDtcbiAgICAgICAgcmV0dXJuIHtcbiAgICAgICAgICAgIGlkOiBtYXRjaC50d2VldElkLFxuICAgICAgICAgICAgdGV4dDogbWF0Y2gudGV4dCB8fCAnJyxcbiAgICAgICAgICAgIGF1dGhvckhhbmRsZTogbWF0Y2guYXV0aG9ySGFuZGxlIHx8ICcnLFxuICAgICAgICAgICAgYXV0aG9yTmFtZTogbWF0Y2guYXV0aG9yTmFtZSB8fCAnJyxcbiAgICAgICAgICAgIGF1dGhvcklkOiBtYXRjaC5hdXRob3JJZCB8fCAnJyxcbiAgICAgICAgICAgIGNyZWF0ZWRBdDogbWF0Y2guY3JlYXRlZEF0IHx8ICcnLFxuICAgICAgICAgICAgbGlrZUNvdW50OiBtYXRjaC5saWtlQ291bnQgPz8gMCxcbiAgICAgICAgICAgIHJlcGx5Q291bnQ6IG1hdGNoLnJlcGx5Q291bnQgPz8gMCxcbiAgICAgICAgICAgIHJlcG9zdENvdW50OiBtYXRjaC5yZXBvc3RDb3VudCA/PyAwLFxuICAgICAgICAgICAgYm9va21hcmtDb3VudDogbWF0Y2guYm9va21hcmtDb3VudCA/PyAwXG4gICAgICAgIH07XG4gICAgfVxuICAgIGNhdGNoIChlKSB7XG4gICAgICAgIGNvbnNvbGUud2FybignW1R3ZWV0Q2xhdy1FeHRyYWN0b3JdIEVycm9yIGluIGZpbmRUd2VldEJ5SWQnLCBlKTtcbiAgICB9XG4gICAgcmV0dXJuIG51bGw7XG59XG4vKipcbiAqIOS7juWTjeW6lOS9k+S4reaPkOWPluWbnuWkjeWIl+ihqO+8iOW/q+eFp++8iVxuICovXG5leHBvcnQgZnVuY3Rpb24gZmluZFJlcGxpZXNTbmFwc2hvdChkYXRhLCBwYWdlVXJsLCBhY3RpdmVBY2NvdW50SGFuZGxlKSB7XG4gICAgdHJ5IHtcbiAgICAgICAgY29uc3QgdHdlZXRzID0gZXh0cmFjdFR3ZWV0c0Zyb21UaW1lbGluZShkYXRhKTtcbiAgICAgICAgaWYgKHR3ZWV0cy5sZW5ndGggPT09IDApXG4gICAgICAgICAgICByZXR1cm4gW107XG4gICAgICAgIGNvbnN0IHRhcmdldElkID0gcGFnZVVybCA/IGV4dHJhY3RUd2VldElkKHBhZ2VVcmwpIDogbnVsbDtcbiAgICAgICAgLy8g6L+H5ruk6YC76L6R77yaXG4gICAgICAgIC8vIDEuIOaOkumZpOS4u+aOqOaWhyAodGFyZ2V0SWQpXG4gICAgICAgIC8vIDIuIOi/memHjOeahCB0d2VldHMg5piv5ouN5bmz55qE5YiX6KGo77yMVGltZWxpbmVBZGRFbnRyaWVzIOmHjOeahOmhuuW6j+mAmuW4uOWwseaYr+WbnuWkjemhuuW6j1xuICAgICAgICAvLyAzLiDnu5PmnpzkuK3lj6/og73ljIXlkKvkuLvmjqjmlofmnKzouqvvvIjlpoLmnpzmnInnmoTor53vvInvvIzmiJHku6zopoHmjpLpmaTlroNcbiAgICAgICAgY29uc3QgcmVwbGllcyA9IHR3ZWV0cy5maWx0ZXIodCA9PiB0LnR3ZWV0SWQgIT09IHRhcmdldElkKTtcbiAgICAgICAgLy8g5Y676YeNXG4gICAgICAgIGNvbnN0IHNlZW4gPSBuZXcgU2V0KCk7XG4gICAgICAgIGNvbnN0IHVuaXF1ZSA9IFtdO1xuICAgICAgICBmb3IgKGNvbnN0IHQgb2YgcmVwbGllcykge1xuICAgICAgICAgICAgaWYgKCFzZWVuLmhhcyh0LnR3ZWV0SWQpKSB7XG4gICAgICAgICAgICAgICAgc2Vlbi5hZGQodC50d2VldElkKTtcbiAgICAgICAgICAgICAgICB1bmlxdWUucHVzaCh0KTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gdW5pcXVlLm1hcCh0ID0+ICh7XG4gICAgICAgICAgICB0d2VldElkOiB0LnR3ZWV0SWQsXG4gICAgICAgICAgICBhdXRob3JIYW5kbGU6IHQuYXV0aG9ySGFuZGxlLFxuICAgICAgICAgICAgYXV0aG9yTmFtZTogdC5hdXRob3JOYW1lLFxuICAgICAgICAgICAgYXV0aG9ySWQ6IHQuYXV0aG9ySWQsXG4gICAgICAgICAgICB0ZXh0OiB0LnRleHQsXG4gICAgICAgICAgICBjcmVhdGVkQXQ6IHQuY3JlYXRlZEF0LFxuICAgICAgICAgICAgbGlrZUNvdW50OiB0Lmxpa2VDb3VudCxcbiAgICAgICAgICAgIHJlcGx5Q291bnQ6IHQucmVwbHlDb3VudCxcbiAgICAgICAgICAgIHJlcG9zdENvdW50OiB0LnJlcG9zdENvdW50LFxuICAgICAgICAgICAgaXNCeUFjdGl2ZUFjY291bnQ6IGFjdGl2ZUFjY291bnRIYW5kbGUgPyB0LmF1dGhvckhhbmRsZSA9PT0gYWN0aXZlQWNjb3VudEhhbmRsZSA6IGZhbHNlXG4gICAgICAgIH0pKTtcbiAgICB9XG4gICAgY2F0Y2ggKGUpIHtcbiAgICAgICAgY29uc29sZS53YXJuKCdbVHdlZXRDbGF3LUV4dHJhY3Rvcl0gRXJyb3IgaW4gZmluZFJlcGxpZXNTbmFwc2hvdCcsIGUpO1xuICAgIH1cbiAgICByZXR1cm4gW107XG59XG4vKipcbiAqIOS7juWTjeW6lOS9k+S4reaPkOWPliBQcm9maWxlIOWcuuaZr+S4i+eahOaOqOaWh+WIl+ihqO+8iOW/q+eFp++8iVxuICovXG5leHBvcnQgZnVuY3Rpb24gZmluZFByb2ZpbGVUd2VldHNTbmFwc2hvdChkYXRhLCBhY3RpdmVBY2NvdW50SGFuZGxlKSB7XG4gICAgdHJ5IHtcbiAgICAgICAgY29uc3QgdHdlZXRzID0gZXh0cmFjdFR3ZWV0c0Zyb21UaW1lbGluZShkYXRhKTtcbiAgICAgICAgaWYgKHR3ZWV0cy5sZW5ndGggPT09IDApXG4gICAgICAgICAgICByZXR1cm4gW107XG4gICAgICAgIC8vIOWOu+mHjVxuICAgICAgICBjb25zdCBzZWVuID0gbmV3IFNldCgpO1xuICAgICAgICBjb25zdCB1bmlxdWUgPSBbXTtcbiAgICAgICAgZm9yIChjb25zdCB0IG9mIHR3ZWV0cykge1xuICAgICAgICAgICAgaWYgKCFzZWVuLmhhcyh0LnR3ZWV0SWQpKSB7XG4gICAgICAgICAgICAgICAgc2Vlbi5hZGQodC50d2VldElkKTtcbiAgICAgICAgICAgICAgICB1bmlxdWUucHVzaCh0KTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gdW5pcXVlLm1hcCh0ID0+ICh7XG4gICAgICAgICAgICB0d2VldElkOiB0LnR3ZWV0SWQsXG4gICAgICAgICAgICBhdXRob3JIYW5kbGU6IHQuYXV0aG9ySGFuZGxlLFxuICAgICAgICAgICAgYXV0aG9yTmFtZTogdC5hdXRob3JOYW1lLFxuICAgICAgICAgICAgdGV4dDogdC50ZXh0LFxuICAgICAgICAgICAgY3JlYXRlZEF0OiB0LmNyZWF0ZWRBdCxcbiAgICAgICAgICAgIGxpa2VDb3VudDogdC5saWtlQ291bnQsXG4gICAgICAgICAgICByZXBseUNvdW50OiB0LnJlcGx5Q291bnQsXG4gICAgICAgICAgICByZXBvc3RDb3VudDogdC5yZXBvc3RDb3VudCxcbiAgICAgICAgICAgIGlzT3duZWRCeUFjdGl2ZUFjY291bnQ6IGFjdGl2ZUFjY291bnRIYW5kbGUgPyB0LmF1dGhvckhhbmRsZSA9PT0gYWN0aXZlQWNjb3VudEhhbmRsZSA6IGZhbHNlXG4gICAgICAgIH0pKTtcbiAgICB9XG4gICAgY2F0Y2ggKGUpIHtcbiAgICAgICAgY29uc29sZS53YXJuKCdbVHdlZXRDbGF3LUV4dHJhY3Rvcl0gRXJyb3IgaW4gZmluZFByb2ZpbGVUd2VldHNTbmFwc2hvdCcsIGUpO1xuICAgIH1cbiAgICByZXR1cm4gW107XG59XG4vKipcbiAqIOmAkuW9kuWcqOS7u+aEj+a3seW6pueahCBKU09OIOWvueixoeS4reaJvuWIsCBUd2l0dGVyIFVzZXIg57uT5p6c5a+56LGh44CCXG4gKiDlhbzlrrkgVXNlckJ5U2NyZWVuTmFtZSAvIFVzZXJCeVJlc3RJZCDnrYnlpJrnp43lk43lupTnu5PmnoTlj5jkvZPjgIJcbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIGZpbmREZWVwVXNlcihvYmosIGRlcHRoID0gMCkge1xuICAgIGlmICghb2JqIHx8IHR5cGVvZiBvYmogIT09ICdvYmplY3QnIHx8IGRlcHRoID4gOClcbiAgICAgICAgcmV0dXJuIG51bGw7XG4gICAgLy8g5ZG95Lit5p2h5Lu277ya5piv5LiA5Liq5pyJIHJlc3RfaWQg5LiUIF9fdHlwZW5hbWUg5Li6IFVzZXIg55qE5a+56LGhXG4gICAgaWYgKG9iai5fX3R5cGVuYW1lID09PSAnVXNlcicgJiYgb2JqLnJlc3RfaWQpXG4gICAgICAgIHJldHVybiBvYmo7XG4gICAgLy8g5LyY5YWI5bCd6K+V6K+t5LmJ6Lev5b6EXG4gICAgY29uc3QgcHJpb3JpdHlLZXlzID0gWydyZXN1bHQnLCAndXNlcicsICd1c2VyX3Jlc3VsdCcsICdkYXRhJ107XG4gICAgZm9yIChjb25zdCBrZXkgb2YgcHJpb3JpdHlLZXlzKSB7XG4gICAgICAgIGlmIChvYmpba2V5XSkge1xuICAgICAgICAgICAgY29uc3QgZm91bmQgPSBmaW5kRGVlcFVzZXIob2JqW2tleV0sIGRlcHRoICsgMSk7XG4gICAgICAgICAgICBpZiAoZm91bmQpXG4gICAgICAgICAgICAgICAgcmV0dXJuIGZvdW5kO1xuICAgICAgICB9XG4gICAgfVxuICAgIC8vIOWFnOW6le+8mumBjeWOhuaJgOaciSBrZXlcbiAgICBmb3IgKGNvbnN0IGtleSBvZiBPYmplY3Qua2V5cyhvYmopKSB7XG4gICAgICAgIGlmIChwcmlvcml0eUtleXMuaW5jbHVkZXMoa2V5KSlcbiAgICAgICAgICAgIGNvbnRpbnVlOyAvLyDlt7LlpITnkIZcbiAgICAgICAgY29uc3QgZm91bmQgPSBmaW5kRGVlcFVzZXIob2JqW2tleV0sIGRlcHRoICsgMSk7XG4gICAgICAgIGlmIChmb3VuZClcbiAgICAgICAgICAgIHJldHVybiBmb3VuZDtcbiAgICB9XG4gICAgcmV0dXJuIG51bGw7XG59XG4iLCIvKipcbiAqIFRpbWVsaW5lIEV4dHJhY3Rpb24gTG9naWNcbiAqIFJvYnVzdCB2ZXJzaW9uIGZvciBBdXRob3IgSGFuZGxlLCBJbnRlcmFjdGlvbiBTdGF0cywgTWVkaWEsIGFuZCBRdW90ZXMuXG4gKi9cbi8qKlxuICogUmVjdXJzaXZlbHkgc2VhcmNoZXMgZm9yIHRoZSAnaW5zdHJ1Y3Rpb25zJyBhcnJheS5cbiAqL1xuZnVuY3Rpb24gZmluZEluc3RydWN0aW9uc1JlY3Vyc2l2ZShvYmopIHtcbiAgICBpZiAoIW9iaiB8fCB0eXBlb2Ygb2JqICE9PSAnb2JqZWN0JylcbiAgICAgICAgcmV0dXJuIG51bGw7XG4gICAgaWYgKEFycmF5LmlzQXJyYXkob2JqLmluc3RydWN0aW9ucykpXG4gICAgICAgIHJldHVybiBvYmouaW5zdHJ1Y3Rpb25zO1xuICAgIGZvciAoY29uc3Qga2V5IGluIG9iaikge1xuICAgICAgICBpZiAodHlwZW9mIG9ialtrZXldID09PSAnb2JqZWN0JyAmJiBvYmpba2V5XSAhPT0gbnVsbCkge1xuICAgICAgICAgICAgY29uc3QgZm91bmQgPSBmaW5kSW5zdHJ1Y3Rpb25zUmVjdXJzaXZlKG9ialtrZXldKTtcbiAgICAgICAgICAgIGlmIChmb3VuZClcbiAgICAgICAgICAgICAgICByZXR1cm4gZm91bmQ7XG4gICAgICAgIH1cbiAgICB9XG4gICAgcmV0dXJuIG51bGw7XG59XG4vKipcbiAqIEV4dHJhY3RzIGEgbGlzdCBvZiBub3JtYWxpemVkIHR3ZWV0cyBmcm9tIGFueSBUaW1lbGluZS1saWtlIEdyYXBoUUwgcmVzcG9uc2UuXG4gKiBXb3JrcyBmb3IgSG9tZSwgU2VhcmNoLCBhbmQgVHdlZXREZXRhaWwgKFRocmVhZCkuXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBleHRyYWN0VHdlZXRzRnJvbVRpbWVsaW5lKGpzb24pIHtcbiAgICBjb25zdCB0d2VldHMgPSBbXTtcbiAgICB0cnkge1xuICAgICAgICBjb25zdCBpbnN0cnVjdGlvbnMgPSBmaW5kSW5zdHJ1Y3Rpb25zUmVjdXJzaXZlKGpzb24pIHx8IFtdO1xuICAgICAgICBmb3IgKGNvbnN0IGluc3RyIG9mIGluc3RydWN0aW9ucykge1xuICAgICAgICAgICAgaWYgKGluc3RyLnR5cGUgPT09ICdUaW1lbGluZUFkZEVudHJpZXMnIHx8IGluc3RyLnR5cGUgPT09ICdUaW1lbGluZVJlcGxhY2VFbnRyeScpIHtcbiAgICAgICAgICAgICAgICBjb25zdCBlbnRyaWVzID0gaW5zdHIuZW50cmllcyB8fCAoaW5zdHIuZW50cnkgPyBbaW5zdHIuZW50cnldIDogW10pO1xuICAgICAgICAgICAgICAgIGZvciAoY29uc3QgZW50cnkgb2YgZW50cmllcykge1xuICAgICAgICAgICAgICAgICAgICAvLyBOb3JtYWwgSXRlbVxuICAgICAgICAgICAgICAgICAgICBjb25zdCByZXN1bHQgPSBlbnRyeT8uY29udGVudD8uaXRlbUNvbnRlbnQ/LnR3ZWV0X3Jlc3VsdHM/LnJlc3VsdFxuICAgICAgICAgICAgICAgICAgICAgICAgfHwgZW50cnk/LmNvbnRlbnQ/LmNvbnRlbnQ/LnR3ZWV0X3Jlc3VsdHM/LnJlc3VsdDtcbiAgICAgICAgICAgICAgICAgICAgaWYgKHJlc3VsdCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgY29uc3QgdHdlZXQgPSBwYXJzZVR3ZWV0UmVzdWx0KHJlc3VsdCk7XG4gICAgICAgICAgICAgICAgICAgICAgICBpZiAodHdlZXQpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB0d2VldHMucHVzaCh0d2VldCk7XG4gICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgLy8gTW9kdWxlIEl0ZW1zIChDb21tb24gaW4gVHdlZXREZXRhaWwgZm9yIHJlcGxpZXMpXG4gICAgICAgICAgICAgICAgICAgIGNvbnN0IGl0ZW1zID0gZW50cnk/LmNvbnRlbnQ/Lml0ZW1zO1xuICAgICAgICAgICAgICAgICAgICBpZiAoQXJyYXkuaXNBcnJheShpdGVtcykpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIGZvciAoY29uc3QgaXRlbSBvZiBpdGVtcykge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbnN0IGl0ZW1SZXN1bHQgPSBpdGVtLml0ZW0/Lml0ZW1Db250ZW50Py50d2VldF9yZXN1bHRzPy5yZXN1bHQ7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgaWYgKGl0ZW1SZXN1bHQpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY29uc3QgdCA9IHBhcnNlVHdlZXRSZXN1bHQoaXRlbVJlc3VsdCk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlmICh0KVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdHdlZXRzLnB1c2godCk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgfVxuICAgIGNhdGNoIChlKSB7XG4gICAgICAgIGNvbnNvbGUud2FybignW1R3ZWV0Q2xhdy1FeHRyYWN0b3JdIEVycm9yIGluIGV4dHJhY3RUd2VldHNGcm9tVGltZWxpbmUnLCBlKTtcbiAgICB9XG4gICAgcmV0dXJuIHR3ZWV0cztcbn1cbi8qKlxuICogTm9ybWFsaXplcyBhIHNpbmdsZSBUd2VldCByZXN1bHQgZnJvbSBYJ3MgR3JhcGhRTCByZXNwb25zZS5cbiAqIFN1cHBvcnRzIHJlY3Vyc2lvbiBmb3IgUXVvdGUgVHdlZXRzICgxIGxldmVsIGRlZXApLlxuICovXG5mdW5jdGlvbiBwYXJzZVR3ZWV0UmVzdWx0KHJlc3VsdCwgZGVwdGggPSAwKSB7XG4gICAgbGV0IGRhdGEgPSByZXN1bHQ7XG4gICAgLy8gSGFuZGxlIG5lc3RlZCByZXN1bHRzXG4gICAgaWYgKGRhdGEudHdlZXQpXG4gICAgICAgIGRhdGEgPSBkYXRhLnR3ZWV0O1xuICAgIGlmIChkYXRhLnJlc3VsdClcbiAgICAgICAgZGF0YSA9IGRhdGEucmVzdWx0O1xuICAgIGlmICghZGF0YSB8fCAhZGF0YS5sZWdhY3kpXG4gICAgICAgIHJldHVybiBudWxsO1xuICAgIC8vIEhhbmRsZSBSZXR3ZWV0czogUHJlZmVyIG9yaWdpbmFsIHR3ZWV0IGZvciB0ZXh0LCBtZXRyaWNzLCBhbmQgYXV0aG9yIGlmIGF2YWlsYWJsZVxuICAgIGxldCBsZWdhY3kgPSBkYXRhLmxlZ2FjeTtcbiAgICBsZXQgY29yZSA9IGRhdGEuY29yZTtcbiAgICBjb25zdCByZXR3ZWV0ZWRSZXN1bHQgPSBkYXRhLnJldHdlZXRlZF9zdGF0dXNfcmVzdWx0Py5yZXN1bHQgfHwgbGVnYWN5LnJldHdlZXRlZF9zdGF0dXNfcmVzdWx0Py5yZXN1bHQ7XG4gICAgaWYgKHJldHdlZXRlZFJlc3VsdCkge1xuICAgICAgICBjb25zdCByTGVnYWN5ID0gcmV0d2VldGVkUmVzdWx0LmxlZ2FjeSB8fCByZXR3ZWV0ZWRSZXN1bHQudHdlZXQ/LmxlZ2FjeTtcbiAgICAgICAgY29uc3QgckNvcmUgPSByZXR3ZWV0ZWRSZXN1bHQuY29yZSB8fCByZXR3ZWV0ZWRSZXN1bHQudHdlZXQ/LmNvcmU7XG4gICAgICAgIGlmIChyTGVnYWN5KVxuICAgICAgICAgICAgbGVnYWN5ID0gckxlZ2FjeTtcbiAgICAgICAgaWYgKHJDb3JlKVxuICAgICAgICAgICAgY29yZSA9IHJDb3JlO1xuICAgIH1cbiAgICAvLyAxLiBBdXRob3IgSW5mb1xuICAgIGxldCBhdXRob3JIYW5kbGUgPSAndW5rbm93bic7XG4gICAgbGV0IGF1dGhvck5hbWUgPSAndW5rbm93bic7XG4gICAgY29uc3QgdXNlclJlc3VsdCA9IGNvcmU/LnVzZXJfcmVzdWx0cz8ucmVzdWx0O1xuICAgIGNvbnN0IHVzZXJMZWdhY3kgPSB1c2VyUmVzdWx0Py5sZWdhY3kgfHwgdXNlclJlc3VsdD8udXNlcj8ubGVnYWN5IHx8IHVzZXJSZXN1bHQ/LnVzZXJfcmVzdWx0cz8ucmVzdWx0Py5sZWdhY3kgfHwgZGF0YS5jb3JlPy51c2VyX3Jlc3VsdHM/LnJlc3VsdD8ubGVnYWN5O1xuICAgIGlmICh1c2VyTGVnYWN5Py5zY3JlZW5fbmFtZSkge1xuICAgICAgICBhdXRob3JIYW5kbGUgPSBgQCR7dXNlckxlZ2FjeS5zY3JlZW5fbmFtZX1gO1xuICAgICAgICBhdXRob3JOYW1lID0gdXNlckxlZ2FjeS5uYW1lIHx8IGF1dGhvckhhbmRsZTtcbiAgICB9XG4gICAgZWxzZSB7XG4gICAgICAgIGNvbnN0IGZvdW5kSGFuZGxlID0gZmluZEZpcnN0U2NyZWVuTmFtZShkYXRhKSB8fCBmaW5kRmlyc3RTY3JlZW5OYW1lKGNvcmUpO1xuICAgICAgICBpZiAoZm91bmRIYW5kbGUpXG4gICAgICAgICAgICBhdXRob3JIYW5kbGUgPSBgQCR7Zm91bmRIYW5kbGV9YDtcbiAgICAgICAgY29uc3QgZm91bmROYW1lID0gZmluZEZpcnN0QXV0aG9yTmFtZShkYXRhKSB8fCBmaW5kRmlyc3RBdXRob3JOYW1lKGNvcmUpO1xuICAgICAgICBpZiAoZm91bmROYW1lKVxuICAgICAgICAgICAgYXV0aG9yTmFtZSA9IGZvdW5kTmFtZTtcbiAgICB9XG4gICAgLy8gMi4gSW50ZXJhY3Rpb24gTWV0cmljc1xuICAgIGNvbnN0IHR3ZWV0ID0ge1xuICAgICAgICB0d2VldElkOiBsZWdhY3kuaWRfc3RyIHx8IGRhdGEucmVzdF9pZCxcbiAgICAgICAgYXV0aG9ySGFuZGxlLFxuICAgICAgICBhdXRob3JOYW1lLFxuICAgICAgICBhdXRob3JJZDogdXNlclJlc3VsdD8ucmVzdF9pZCB8fCAndW5rbm93bicsXG4gICAgICAgIHRleHQ6IGxlZ2FjeS5mdWxsX3RleHQgfHwgJycsXG4gICAgICAgIGNyZWF0ZWRBdDogbGVnYWN5LmNyZWF0ZWRfYXQgfHwgbnVsbCxcbiAgICAgICAgcmVwbHlDb3VudDogbGVnYWN5LnJlcGx5X2NvdW50ID8/IGRhdGEucmVwbHlfY291bnQgPz8gbnVsbCxcbiAgICAgICAgcmVwb3N0Q291bnQ6IGxlZ2FjeS5yZXR3ZWV0X2NvdW50ID8/IGxlZ2FjeS5yZXBvc3RfY291bnQgPz8gZGF0YS5yZXR3ZWV0X2NvdW50ID8/IG51bGwsXG4gICAgICAgIGxpa2VDb3VudDogbGVnYWN5LmZhdm9yaXRlX2NvdW50ID8/IGRhdGEuZmF2b3JpdGVfY291bnQgPz8gbnVsbCxcbiAgICAgICAgYm9va21hcmtDb3VudDogbGVnYWN5LmJvb2ttYXJrX2NvdW50ID8/IGRhdGEuYm9va21hcmtfY291bnQgPz8gbnVsbCxcbiAgICB9O1xuICAgIC8vIDMuIE1lZGlhIEV4dHJhY3Rpb24gKFBob3RvcywgVmlkZW9zLCBHSUZzKVxuICAgIGNvbnN0IG1lZGlhSXRlbXMgPSBsZWdhY3kuZXh0ZW5kZWRfZW50aXRpZXM/Lm1lZGlhIHx8IGxlZ2FjeS5lbnRpdGllcz8ubWVkaWEgfHwgW107XG4gICAgaWYgKG1lZGlhSXRlbXMubGVuZ3RoID4gMCkge1xuICAgICAgICB0d2VldC5tZWRpYSA9IG1lZGlhSXRlbXMubWFwKChtKSA9PiB7XG4gICAgICAgICAgICBjb25zdCBpdGVtID0ge1xuICAgICAgICAgICAgICAgIHR5cGU6IG0udHlwZSA9PT0gJ3Bob3RvJyA/ICdwaG90bycgOiAobS50eXBlID09PSAndmlkZW8nID8gJ3ZpZGVvJyA6IChtLnR5cGUgPT09ICdhbmltYXRlZF9naWYnID8gJ2FuaW1hdGVkX2dpZicgOiAndW5rbm93bicpKSxcbiAgICAgICAgICAgICAgICB1cmw6IG0ubWVkaWFfdXJsX2h0dHBzLFxuICAgICAgICAgICAgICAgIHdpZHRoOiBtLm9yaWdpbmFsX2luZm8/LndpZHRoLFxuICAgICAgICAgICAgICAgIGhlaWdodDogbS5vcmlnaW5hbF9pbmZvPy5oZWlnaHQsXG4gICAgICAgICAgICB9O1xuICAgICAgICAgICAgaWYgKG0udmlkZW9faW5mbykge1xuICAgICAgICAgICAgICAgIGl0ZW0uZHVyYXRpb25fbXMgPSBtLnZpZGVvX2luZm8uZHVyYXRpb25fbXM7XG4gICAgICAgICAgICAgICAgaWYgKG0udmlkZW9faW5mby52YXJpYW50cykge1xuICAgICAgICAgICAgICAgICAgICBpdGVtLnZhcmlhbnRfdXJscyA9IG0udmlkZW9faW5mby52YXJpYW50c1xuICAgICAgICAgICAgICAgICAgICAgICAgLmZpbHRlcigodikgPT4gdi51cmwpXG4gICAgICAgICAgICAgICAgICAgICAgICAubWFwKCh2KSA9PiB2LnVybCk7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfVxuICAgICAgICAgICAgcmV0dXJuIGl0ZW07XG4gICAgICAgIH0pO1xuICAgICAgICB0d2VldC5tZWRpYV9jb3VudCA9IHR3ZWV0Lm1lZGlhPy5sZW5ndGggfHwgMDtcbiAgICB9XG4gICAgLy8gNC4gUXVvdGUgVHdlZXQgRXhwYW5zaW9uIChMaW1pdCBkZXB0aCB0byAxKVxuICAgIGlmIChkZXB0aCA9PT0gMCkge1xuICAgICAgICBjb25zdCBxdW90ZWRSZXN1bHQgPSBkYXRhLnF1b3RlZF9zdGF0dXNfcmVzdWx0IHx8IGxlZ2FjeS5xdW90ZWRfc3RhdHVzX3Jlc3VsdDtcbiAgICAgICAgaWYgKHF1b3RlZFJlc3VsdCkge1xuICAgICAgICAgICAgY29uc3QgcXVvdGVkVHdlZXQgPSBwYXJzZVR3ZWV0UmVzdWx0KHF1b3RlZFJlc3VsdCwgMSk7XG4gICAgICAgICAgICBpZiAocXVvdGVkVHdlZXQpIHtcbiAgICAgICAgICAgICAgICB0d2VldC5xdW90ZWRfdHdlZXQgPSBxdW90ZWRUd2VldDtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgIH1cbiAgICByZXR1cm4gdHdlZXQ7XG59XG4vKipcbiAqIEhlbHBlciB0byBmaW5kIHRoZSBmaXJzdCBzY3JlZW5fbmFtZSBpbiBhIHVzZXItcmVsYXRlZCBzdWItb2JqZWN0LlxuICovXG5mdW5jdGlvbiBmaW5kRmlyc3RTY3JlZW5OYW1lKG9iaikge1xuICAgIGlmICghb2JqIHx8IHR5cGVvZiBvYmogIT09ICdvYmplY3QnKVxuICAgICAgICByZXR1cm4gbnVsbDtcbiAgICBpZiAob2JqLnNjcmVlbl9uYW1lKVxuICAgICAgICByZXR1cm4gb2JqLnNjcmVlbl9uYW1lO1xuICAgIGZvciAoY29uc3Qga2V5IGluIG9iaikge1xuICAgICAgICBpZiAob2JqLmhhc093blByb3BlcnR5KGtleSkpIHtcbiAgICAgICAgICAgIGNvbnN0IGZvdW5kID0gZmluZEZpcnN0U2NyZWVuTmFtZShvYmpba2V5XSk7XG4gICAgICAgICAgICBpZiAoZm91bmQpXG4gICAgICAgICAgICAgICAgcmV0dXJuIGZvdW5kO1xuICAgICAgICB9XG4gICAgfVxuICAgIHJldHVybiBudWxsO1xufVxuLyoqXG4gKiBIZWxwZXIgdG8gZmluZCB0aGUgZmlyc3QgJ25hbWUnIGluIGEgdXNlci1yZWxhdGVkIHN1Yi1vYmplY3QuXG4gKi9cbmZ1bmN0aW9uIGZpbmRGaXJzdEF1dGhvck5hbWUob2JqKSB7XG4gICAgaWYgKCFvYmogfHwgdHlwZW9mIG9iaiAhPT0gJ29iamVjdCcpXG4gICAgICAgIHJldHVybiBudWxsO1xuICAgIGlmIChvYmoubmFtZSlcbiAgICAgICAgcmV0dXJuIG9iai5uYW1lO1xuICAgIGZvciAoY29uc3Qga2V5IGluIG9iaikge1xuICAgICAgICBpZiAob2JqLmhhc093blByb3BlcnR5KGtleSkpIHtcbiAgICAgICAgICAgIGNvbnN0IGZvdW5kID0gZmluZEZpcnN0QXV0aG9yTmFtZShvYmpba2V5XSk7XG4gICAgICAgICAgICBpZiAoZm91bmQpXG4gICAgICAgICAgICAgICAgcmV0dXJuIGZvdW5kO1xuICAgICAgICB9XG4gICAgfVxuICAgIHJldHVybiBudWxsO1xufVxuIiwiaW1wb3J0IHsgZXh0cmFjdFR3ZWV0SWQgfSBmcm9tICcuL3JvdXRlLXBhcnNlcic7XG5leHBvcnQgZnVuY3Rpb24gcmVzb2x2ZVR3ZWV0RW50aXR5KHVybCwgZmVhdHVyZWRUd2VldCwgYWN0aXZlQWNjb3VudEhhbmRsZSkge1xuICAgIGNvbnN0IHR3ZWV0SWQgPSBleHRyYWN0VHdlZXRJZCh1cmwpO1xuICAgIGlmICghdHdlZXRJZClcbiAgICAgICAgcmV0dXJuIG51bGw7XG4gICAgbGV0IGVudGl0eSA9IHtcbiAgICAgICAgZW50aXR5VHlwZTogJ3R3ZWV0JyxcbiAgICAgICAgZW50aXR5SWQ6IHR3ZWV0SWQsXG4gICAgICAgIGF1dGhvckhhbmRsZTogbnVsbCxcbiAgICAgICAgYXV0aG9yTmFtZTogbnVsbCxcbiAgICAgICAgYXV0aG9ySWQ6IG51bGwsXG4gICAgICAgIHRleHQ6IG51bGwsXG4gICAgICAgIGNyZWF0ZWRBdDogbnVsbCxcbiAgICAgICAgbGlrZUNvdW50OiBudWxsLFxuICAgICAgICByZXBseUNvdW50OiBudWxsLFxuICAgICAgICByZXR3ZWV0Q291bnQ6IG51bGwsXG4gICAgICAgIGJvb2ttYXJrQ291bnQ6IG51bGwsXG4gICAgICAgIGlzT3duZWRCeUFjdGl2ZUFjY291bnQ6IGZhbHNlLFxuICAgICAgICBzb3VyY2U6ICd1cmxfb25seSdcbiAgICB9O1xuICAgIGlmIChmZWF0dXJlZFR3ZWV0ICYmIChmZWF0dXJlZFR3ZWV0LmlkID09PSB0d2VldElkIHx8ICFmZWF0dXJlZFR3ZWV0LmlkKSkge1xuICAgICAgICAvLyBBbGlnbm1lbnQgd2l0aCBleHRyYWN0b3IgZmllbGRzXG4gICAgICAgIGVudGl0eS5hdXRob3JIYW5kbGUgPSBmZWF0dXJlZFR3ZWV0LmF1dGhvckhhbmRsZSB8fCBudWxsO1xuICAgICAgICBlbnRpdHkuYXV0aG9yTmFtZSA9IGZlYXR1cmVkVHdlZXQuYXV0aG9yTmFtZSB8fCBudWxsO1xuICAgICAgICBlbnRpdHkuYXV0aG9ySWQgPSBmZWF0dXJlZFR3ZWV0LmF1dGhvcklkIHx8IG51bGw7XG4gICAgICAgIGVudGl0eS50ZXh0ID0gZmVhdHVyZWRUd2VldC50ZXh0IHx8IG51bGw7XG4gICAgICAgIGVudGl0eS5jcmVhdGVkQXQgPSBmZWF0dXJlZFR3ZWV0LmNyZWF0ZWRBdCB8fCBudWxsO1xuICAgICAgICBlbnRpdHkubGlrZUNvdW50ID0gZmVhdHVyZWRUd2VldC5saWtlQ291bnQgPz8gbnVsbDtcbiAgICAgICAgZW50aXR5LnJlcGx5Q291bnQgPSBmZWF0dXJlZFR3ZWV0LnJlcGx5Q291bnQgPz8gbnVsbDtcbiAgICAgICAgZW50aXR5LnJldHdlZXRDb3VudCA9IGZlYXR1cmVkVHdlZXQucmVwb3N0Q291bnQgPz8gbnVsbDtcbiAgICAgICAgZW50aXR5LmJvb2ttYXJrQ291bnQgPSBmZWF0dXJlZFR3ZWV0LmJvb2ttYXJrQ291bnQgPz8gbnVsbDtcbiAgICAgICAgZW50aXR5LnNvdXJjZSA9ICdtZXJnZWQnO1xuICAgIH1cbiAgICBpZiAoYWN0aXZlQWNjb3VudEhhbmRsZSAmJiBlbnRpdHkuYXV0aG9ySGFuZGxlKSB7XG4gICAgICAgIGNvbnN0IGNsZWFuQWN0aXZlID0gYWN0aXZlQWNjb3VudEhhbmRsZS5yZXBsYWNlKCdAJywgJycpLnRvTG93ZXJDYXNlKCk7XG4gICAgICAgIGNvbnN0IGNsZWFuQXV0aG9yID0gZW50aXR5LmF1dGhvckhhbmRsZS5yZXBsYWNlKCdAJywgJycpLnRvTG93ZXJDYXNlKCk7XG4gICAgICAgIGVudGl0eS5pc093bmVkQnlBY3RpdmVBY2NvdW50ID0gY2xlYW5BY3RpdmUgPT09IGNsZWFuQXV0aG9yO1xuICAgIH1cbiAgICByZXR1cm4gZW50aXR5O1xufVxuIiwiZXhwb3J0IGZ1bmN0aW9uIHBhcnNlUm91dGVLaW5kKHVybCkge1xuICAgIGlmICghdXJsIHx8ICEodXJsLmluY2x1ZGVzKCd4LmNvbScpIHx8IHVybC5pbmNsdWRlcygndHdpdHRlci5jb20nKSkpXG4gICAgICAgIHJldHVybiAnbm9uZSc7XG4gICAgdHJ5IHtcbiAgICAgICAgY29uc3QgdSA9IG5ldyBVUkwodXJsKTtcbiAgICAgICAgY29uc3QgcGF0aCA9IHUucGF0aG5hbWU7XG4gICAgICAgIGlmIChwYXRoID09PSAnL2hvbWUnIHx8IHBhdGggPT09ICcvJylcbiAgICAgICAgICAgIHJldHVybiAnaG9tZSc7XG4gICAgICAgIGlmIChwYXRoLmluY2x1ZGVzKCcvc2VhcmNoJykpXG4gICAgICAgICAgICByZXR1cm4gJ3NlYXJjaCc7XG4gICAgICAgIGlmIChwYXRoLmluY2x1ZGVzKCcvc3RhdHVzLycpKVxuICAgICAgICAgICAgcmV0dXJuICd0aHJlYWQnO1xuICAgICAgICBpZiAocGF0aC5pbmNsdWRlcygnL25vdGlmaWNhdGlvbnMnKSlcbiAgICAgICAgICAgIHJldHVybiAnbm90aWZpY2F0aW9uJztcbiAgICAgICAgcmV0dXJuICdwcm9maWxlJztcbiAgICB9XG4gICAgY2F0Y2gge1xuICAgICAgICByZXR1cm4gJ3Vua25vd24nO1xuICAgIH1cbn1cbmV4cG9ydCBmdW5jdGlvbiBleHRyYWN0VHdlZXRJZCh1cmwpIHtcbiAgICBpZiAoIXVybClcbiAgICAgICAgcmV0dXJuIG51bGw7XG4gICAgdHJ5IHtcbiAgICAgICAgY29uc3QgdSA9IG5ldyBVUkwodXJsKTtcbiAgICAgICAgY29uc3QgbWF0Y2ggPSB1LnBhdGhuYW1lLm1hdGNoKC9cXC9zdGF0dXNcXC8oXFxkKykvKTtcbiAgICAgICAgcmV0dXJuIG1hdGNoID8gbWF0Y2hbMV0gOiBudWxsO1xuICAgIH1cbiAgICBjYXRjaCB7XG4gICAgICAgIHJldHVybiBudWxsO1xuICAgIH1cbn1cbiIsImltcG9ydCB7IHBhcnNlUm91dGVLaW5kLCBleHRyYWN0VHdlZXRJZCB9IGZyb20gJy4vcm91dGUtcGFyc2VyJztcbmltcG9ydCB7IHJlc29sdmVUd2VldEVudGl0eSB9IGZyb20gJy4vZW50aXR5LXJlc29sdmVyJztcbmV4cG9ydCBmdW5jdGlvbiBkZXJpdmVQYWdlQ29udGV4dCh1cmwsIGhhc1Nlc3Npb24sIGlzTG9nZ2VkSW4gPSBmYWxzZSwgZmVhdHVyZWRUd2VldCA9IG51bGwsIGFjdGl2ZUFjY291bnRIYW5kbGUgPSBudWxsKSB7XG4gICAgaWYgKCF1cmwpIHtcbiAgICAgICAgcmV0dXJuIHtcbiAgICAgICAgICAgIHNjZW5lOiAnbm9fdGFiJyxcbiAgICAgICAgICAgIHJvdXRlS2luZDogJ25vbmUnLFxuICAgICAgICAgICAgY3VycmVudFVybDogJycsXG4gICAgICAgICAgICBlbnRpdHlUeXBlOiBudWxsLFxuICAgICAgICAgICAgZW50aXR5SWQ6IG51bGwsXG4gICAgICAgICAgICBhdmFpbGFibGVBY3Rpb25zOiBbJ29wZW5feF90YWInXSxcbiAgICAgICAgICAgIGN1cnJlbnRFbnRpdHk6IG51bGxcbiAgICAgICAgfTtcbiAgICB9XG4gICAgY29uc3Qgcm91dGVLaW5kID0gcGFyc2VSb3V0ZUtpbmQodXJsKTtcbiAgICBpZiAocm91dGVLaW5kID09PSAnbm9uZScpIHtcbiAgICAgICAgcmV0dXJuIHtcbiAgICAgICAgICAgIHNjZW5lOiAnbm90X3gnLFxuICAgICAgICAgICAgcm91dGVLaW5kOiAnbm9uZScsXG4gICAgICAgICAgICBjdXJyZW50VXJsOiB1cmwsXG4gICAgICAgICAgICBlbnRpdHlUeXBlOiBudWxsLFxuICAgICAgICAgICAgZW50aXR5SWQ6IG51bGwsXG4gICAgICAgICAgICBhdmFpbGFibGVBY3Rpb25zOiBbJ29wZW5feF90YWInXSxcbiAgICAgICAgICAgIGN1cnJlbnRFbnRpdHk6IG51bGxcbiAgICAgICAgfTtcbiAgICB9XG4gICAgaWYgKCFpc0xvZ2dlZEluKSB7XG4gICAgICAgIHJldHVybiB7XG4gICAgICAgICAgICBzY2VuZTogJ2xvZ2luX3JlcXVpcmVkJyxcbiAgICAgICAgICAgIHJvdXRlS2luZCxcbiAgICAgICAgICAgIGN1cnJlbnRVcmw6IHVybCxcbiAgICAgICAgICAgIGVudGl0eVR5cGU6IG51bGwsXG4gICAgICAgICAgICBlbnRpdHlJZDogbnVsbCxcbiAgICAgICAgICAgIGF2YWlsYWJsZUFjdGlvbnM6IFsnb3Blbl94X3RhYicsICdyZWZyZXNoX3Nlc3Npb24nXSxcbiAgICAgICAgICAgIGN1cnJlbnRFbnRpdHk6IG51bGxcbiAgICAgICAgfTtcbiAgICB9XG4gICAgbGV0IHNjZW5lID0gJ3Vua25vd25feF9zY2VuZSc7XG4gICAgbGV0IGFjdGlvbnMgPSBbXTtcbiAgICBsZXQgY3VycmVudEVudGl0eSA9IG51bGw7XG4gICAgc3dpdGNoIChyb3V0ZUtpbmQpIHtcbiAgICAgICAgY2FzZSAnaG9tZSc6XG4gICAgICAgICAgICBzY2VuZSA9ICdob21lJztcbiAgICAgICAgICAgIGFjdGlvbnMgPSBbJ3JlYWRfaG9tZV90aW1lbGluZSddO1xuICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgIGNhc2UgJ3Byb2ZpbGUnOlxuICAgICAgICAgICAgc2NlbmUgPSAncHJvZmlsZSc7XG4gICAgICAgICAgICBhY3Rpb25zID0gWydsaXN0X3Byb2ZpbGVfdHdlZXRzJ107XG4gICAgICAgICAgICBicmVhaztcbiAgICAgICAgY2FzZSAndGhyZWFkJzpcbiAgICAgICAgICAgIHNjZW5lID0gJ3R3ZWV0X2RldGFpbCc7XG4gICAgICAgICAgICBhY3Rpb25zID0gWydnZXRfY3VycmVudF90d2VldCcsICdsaXN0X3R3ZWV0X3JlcGxpZXMnLCAnbGlrZV90d2VldCcsICdyZXBvc3RfdHdlZXQnLCAncmVwbHlfdG9fdHdlZXQnXTtcbiAgICAgICAgICAgIGN1cnJlbnRFbnRpdHkgPSByZXNvbHZlVHdlZXRFbnRpdHkodXJsLCBmZWF0dXJlZFR3ZWV0LCBhY3RpdmVBY2NvdW50SGFuZGxlKTtcbiAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICBjYXNlICdzZWFyY2gnOlxuICAgICAgICAgICAgc2NlbmUgPSAnc2VhcmNoJztcbiAgICAgICAgICAgIGFjdGlvbnMgPSBbJ3NlYXJjaF90d2VldHMnXTtcbiAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICBjYXNlICdub3RpZmljYXRpb24nOlxuICAgICAgICAgICAgc2NlbmUgPSAnbm90aWZpY2F0aW9uJztcbiAgICAgICAgICAgIGFjdGlvbnMgPSBbJ3JlYWRfbm90aWZpY2F0aW9ucyddO1xuICAgICAgICAgICAgYnJlYWs7XG4gICAgfVxuICAgIC8vIElmIGlkZW50aXR5IGlzIHVucmVzb2x2ZWQgYnV0IHdlIGFyZSBvbiBhIGtub3duIHNjZW5lLCBwcmlvcml0aXplIHRoZSBzY2VuZS5cbiAgICAvLyBJZiB3ZSBhcmUgb24gYW4gdW5rbm93biBzY2VuZSBhbmQgaWRlbnRpdHkgaXMgdW5yZXNvbHZlZCwgdXNlIGlkZW50aXR5X3Jlc29sdmluZy5cbiAgICBsZXQgZmluYWxTY2VuZSA9IHNjZW5lO1xuICAgIGlmICghaGFzU2Vzc2lvbiAmJiBpc0xvZ2dlZEluICYmIHNjZW5lID09PSAndW5rbm93bl94X3NjZW5lJykge1xuICAgICAgICBmaW5hbFNjZW5lID0gJ2lkZW50aXR5X3Jlc29sdmluZyc7XG4gICAgfVxuICAgIHJldHVybiB7XG4gICAgICAgIHNjZW5lOiBmaW5hbFNjZW5lLFxuICAgICAgICByb3V0ZUtpbmQsXG4gICAgICAgIGN1cnJlbnRVcmw6IHVybCxcbiAgICAgICAgZW50aXR5VHlwZTogY3VycmVudEVudGl0eSA/IGN1cnJlbnRFbnRpdHkuZW50aXR5VHlwZSA6IG51bGwsXG4gICAgICAgIGVudGl0eUlkOiBjdXJyZW50RW50aXR5ID8gY3VycmVudEVudGl0eS5lbnRpdHlJZCA6IGV4dHJhY3RUd2VldElkKHVybCksXG4gICAgICAgIGF2YWlsYWJsZUFjdGlvbnM6IGFjdGlvbnMubGVuZ3RoID4gMCA/IGFjdGlvbnMgOiAoZmluYWxTY2VuZSA9PT0gJ2lkZW50aXR5X3Jlc29sdmluZycgPyBbJ3JlZnJlc2hfc2Vzc2lvbiddIDogW10pLFxuICAgICAgICBjdXJyZW50RW50aXR5XG4gICAgfTtcbn1cbiIsIi8vIFRoZSBtb2R1bGUgY2FjaGVcbnZhciBfX3dlYnBhY2tfbW9kdWxlX2NhY2hlX18gPSB7fTtcblxuLy8gVGhlIHJlcXVpcmUgZnVuY3Rpb25cbmZ1bmN0aW9uIF9fd2VicGFja19yZXF1aXJlX18obW9kdWxlSWQpIHtcblx0Ly8gQ2hlY2sgaWYgbW9kdWxlIGlzIGluIGNhY2hlXG5cdHZhciBjYWNoZWRNb2R1bGUgPSBfX3dlYnBhY2tfbW9kdWxlX2NhY2hlX19bbW9kdWxlSWRdO1xuXHRpZiAoY2FjaGVkTW9kdWxlICE9PSB1bmRlZmluZWQpIHtcblx0XHRyZXR1cm4gY2FjaGVkTW9kdWxlLmV4cG9ydHM7XG5cdH1cblx0Ly8gQ3JlYXRlIGEgbmV3IG1vZHVsZSAoYW5kIHB1dCBpdCBpbnRvIHRoZSBjYWNoZSlcblx0dmFyIG1vZHVsZSA9IF9fd2VicGFja19tb2R1bGVfY2FjaGVfX1ttb2R1bGVJZF0gPSB7XG5cdFx0Ly8gbm8gbW9kdWxlLmlkIG5lZWRlZFxuXHRcdC8vIG5vIG1vZHVsZS5sb2FkZWQgbmVlZGVkXG5cdFx0ZXhwb3J0czoge31cblx0fTtcblxuXHQvLyBFeGVjdXRlIHRoZSBtb2R1bGUgZnVuY3Rpb25cblx0aWYgKCEobW9kdWxlSWQgaW4gX193ZWJwYWNrX21vZHVsZXNfXykpIHtcblx0XHRkZWxldGUgX193ZWJwYWNrX21vZHVsZV9jYWNoZV9fW21vZHVsZUlkXTtcblx0XHR2YXIgZSA9IG5ldyBFcnJvcihcIkNhbm5vdCBmaW5kIG1vZHVsZSAnXCIgKyBtb2R1bGVJZCArIFwiJ1wiKTtcblx0XHRlLmNvZGUgPSAnTU9EVUxFX05PVF9GT1VORCc7XG5cdFx0dGhyb3cgZTtcblx0fVxuXHRfX3dlYnBhY2tfbW9kdWxlc19fW21vZHVsZUlkXShtb2R1bGUsIG1vZHVsZS5leHBvcnRzLCBfX3dlYnBhY2tfcmVxdWlyZV9fKTtcblxuXHQvLyBSZXR1cm4gdGhlIGV4cG9ydHMgb2YgdGhlIG1vZHVsZVxuXHRyZXR1cm4gbW9kdWxlLmV4cG9ydHM7XG59XG5cbiIsIi8vIGRlZmluZSBnZXR0ZXIgZnVuY3Rpb25zIGZvciBoYXJtb255IGV4cG9ydHNcbl9fd2VicGFja19yZXF1aXJlX18uZCA9IChleHBvcnRzLCBkZWZpbml0aW9uKSA9PiB7XG5cdGZvcih2YXIga2V5IGluIGRlZmluaXRpb24pIHtcblx0XHRpZihfX3dlYnBhY2tfcmVxdWlyZV9fLm8oZGVmaW5pdGlvbiwga2V5KSAmJiAhX193ZWJwYWNrX3JlcXVpcmVfXy5vKGV4cG9ydHMsIGtleSkpIHtcblx0XHRcdE9iamVjdC5kZWZpbmVQcm9wZXJ0eShleHBvcnRzLCBrZXksIHsgZW51bWVyYWJsZTogdHJ1ZSwgZ2V0OiBkZWZpbml0aW9uW2tleV0gfSk7XG5cdFx0fVxuXHR9XG59OyIsIl9fd2VicGFja19yZXF1aXJlX18ubyA9IChvYmosIHByb3ApID0+IChPYmplY3QucHJvdG90eXBlLmhhc093blByb3BlcnR5LmNhbGwob2JqLCBwcm9wKSkiLCIvLyBkZWZpbmUgX19lc01vZHVsZSBvbiBleHBvcnRzXG5fX3dlYnBhY2tfcmVxdWlyZV9fLnIgPSAoZXhwb3J0cykgPT4ge1xuXHRpZih0eXBlb2YgU3ltYm9sICE9PSAndW5kZWZpbmVkJyAmJiBTeW1ib2wudG9TdHJpbmdUYWcpIHtcblx0XHRPYmplY3QuZGVmaW5lUHJvcGVydHkoZXhwb3J0cywgU3ltYm9sLnRvU3RyaW5nVGFnLCB7IHZhbHVlOiAnTW9kdWxlJyB9KTtcblx0fVxuXHRPYmplY3QuZGVmaW5lUHJvcGVydHkoZXhwb3J0cywgJ19fZXNNb2R1bGUnLCB7IHZhbHVlOiB0cnVlIH0pO1xufTsiLCJpbXBvcnQgeyB3YXRjaGVkT3BzLCBNc2dUeXBlLCBfX0RCS19xdWVyeV9pZF9tYXAsIF9fREJLX2JlYXJlcl90b2tlbiwgZGVmYXVsdFF1ZXJ5S2V5TWFwIH0gZnJvbSAnLi4vY2FwdHVyZS9jb25zdHMnO1xuaW1wb3J0IHsgZmluZFZpZXdlclN1bW1hcnksIGZpbmRGZWF0dXJlZFR3ZWV0LCBmaW5kUmVwbGllc1NuYXBzaG90LCBmaW5kUHJvZmlsZVR3ZWV0c1NuYXBzaG90LCBmaW5kVHdlZXRCeUlkLCBmaW5kRGVlcFVzZXIgfSBmcm9tICcuLi9jYXB0dXJlL2V4dHJhY3Rvcic7XG5pbXBvcnQgeyBkZXJpdmVQYWdlQ29udGV4dCB9IGZyb20gJy4uL3V0aWxzL3NjZW5lLXBhcnNlcic7XG5pbXBvcnQgeyBleHRyYWN0VHdlZXRJZCB9IGZyb20gJy4uL3V0aWxzL3JvdXRlLXBhcnNlcic7XG5pbXBvcnQgeyBMb2NhbEJyaWRnZVNvY2tldCB9IGZyb20gJy4uL2JyaWRnZS9sb2NhbC1icmlkZ2Utc29ja2V0Jztcbi8vIEluaXRpYWxpemUgTG9jYWxCcmlkZ2UgV2ViU29ja2V0IENsaWVudFxuY29uc3QgbG9jYWxCcmlkZ2UgPSBuZXcgTG9jYWxCcmlkZ2VTb2NrZXQoKTtcbmxvY2FsQnJpZGdlLnF1ZXJ5WFRhYnNIYW5kbGVyID0gcXVlcnlYVGFic1N0YXR1cztcbmxvY2FsQnJpZGdlLnF1ZXJ5WEJhc2ljSW5mb0hhbmRsZXIgPSBxdWVyeVhCYXNpY0luZm87XG5sb2NhbEJyaWRnZS5vcGVuVGFiSGFuZGxlciA9IG9wZW5YVGFiO1xubG9jYWxCcmlkZ2UuY2xvc2VUYWJIYW5kbGVyID0gY2xvc2VYVGFiO1xubG9jYWxCcmlkZ2UubmF2aWdhdGVUYWJIYW5kbGVyID0gbmF2aWdhdGVYVGFiO1xubG9jYWxCcmlkZ2UuZXhlY0FjdGlvbkhhbmRsZXIgPSBleGVjQWN0aW9uO1xubG9jYWxCcmlkZ2UucXVlcnlIb21lVGltZWxpbmVIYW5kbGVyID0gcXVlcnlIb21lVGltZWxpbmU7XG5sb2NhbEJyaWRnZS5xdWVyeVR3ZWV0RGV0YWlsSGFuZGxlciA9IHF1ZXJ5VHdlZXREZXRhaWw7XG5sb2NhbEJyaWRnZS5xdWVyeVVzZXJQcm9maWxlSGFuZGxlciA9IHF1ZXJ5VXNlclByb2ZpbGU7XG5sb2NhbEJyaWRnZS5xdWVyeVNlYXJjaFRpbWVsaW5lSGFuZGxlciA9IHF1ZXJ5U2VhcmNoVGltZWxpbmU7XG5sZXQgdGFiRGF0YVN0b3JlID0gbmV3IE1hcCgpO1xuLy8g4pSA4pSAIOaMgeS5heWMliDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIBcbmZ1bmN0aW9uIHNhdmVTdG9yZSgpIHtcbiAgICBjb25zdCBvYmogPSBPYmplY3QuZnJvbUVudHJpZXModGFiRGF0YVN0b3JlKTtcbiAgICBjaHJvbWUuc3RvcmFnZS5sb2NhbC5zZXQoeyAnX3RjX3Y0X3N0b3JlJzogb2JqIH0pO1xufVxuY2hyb21lLnN0b3JhZ2UubG9jYWwuZ2V0KCdfdGNfdjRfc3RvcmUnKS50aGVuKHJlcyA9PiB7XG4gICAgaWYgKHJlcy5fdGNfdjRfc3RvcmUpIHtcbiAgICAgICAgdGFiRGF0YVN0b3JlID0gbmV3IE1hcChPYmplY3QuZW50cmllcyhyZXMuX3RjX3Y0X3N0b3JlKS5tYXAoKFtrLCB2XSkgPT4gW3BhcnNlSW50KGspLCB2XSkpO1xuICAgIH1cbn0pO1xuLy8g4pSA4pSAIOWIneWni+WMlum7mOiupOWTiOW4jOihqCDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIBcbmFzeW5jIGZ1bmN0aW9uIGluaXREZWZhdWx0UXVlcnlLZXlzKCkge1xuICAgIGNvbnN0IHJlcyA9IGF3YWl0IGNocm9tZS5zdG9yYWdlLmxvY2FsLmdldChfX0RCS19xdWVyeV9pZF9tYXApO1xuICAgIGxldCBtYXAgPSAocmVzW19fREJLX3F1ZXJ5X2lkX21hcF0gfHwge30pO1xuICAgIGxldCBjaGFuZ2VkID0gZmFsc2U7XG4gICAgZm9yIChjb25zdCBbb3AsIGlkXSBvZiBPYmplY3QuZW50cmllcyhkZWZhdWx0UXVlcnlLZXlNYXApKSB7XG4gICAgICAgIGlmICghbWFwW29wXSkge1xuICAgICAgICAgICAgbWFwW29wXSA9IGlkO1xuICAgICAgICAgICAgY2hhbmdlZCA9IHRydWU7XG4gICAgICAgIH1cbiAgICB9XG4gICAgaWYgKGNoYW5nZWQpIHtcbiAgICAgICAgYXdhaXQgY2hyb21lLnN0b3JhZ2UubG9jYWwuc2V0KHsgW19fREJLX3F1ZXJ5X2lkX21hcF06IG1hcCB9KTtcbiAgICAgICAgY29uc29sZS5sb2coXCIlY1tUd2VldENsYXctQkddIPCfm6DvuI8gRGVmYXVsdCBRdWVyeUlEcyBpbml0aWFsaXplZC91cGRhdGVkLlwiLCBcImNvbG9yOiNjYmQ1ZTA7IGZvbnQtc3R5bGU6aXRhbGljXCIpO1xuICAgIH1cbn1cbi8vIOmmluasoei/kOihjOaIluWuieijheaXtuWIneWni+WMllxuY2hyb21lLnJ1bnRpbWUub25JbnN0YWxsZWQuYWRkTGlzdGVuZXIoKCkgPT4ge1xuICAgIGluaXREZWZhdWx0UXVlcnlLZXlzKCk7XG4gICAgY29uc29sZS5sb2coXCIlY1tUd2VldENsYXctQkddIPCfmoAgRXh0ZW5zaW9uIGluc3RhbGxlZC91cGRhdGVkLlwiLCBcImNvbG9yOiMxREExRjI7IGZvbnQtd2VpZ2h0OmJvbGRcIik7XG59KTtcbmFzeW5jIGZ1bmN0aW9uIGdldEF1dGhlbnRpY1VpZCgpIHtcbiAgICByZXR1cm4gbmV3IFByb21pc2UocmVzb2x2ZSA9PiB7XG4gICAgICAgIGNocm9tZS5jb29raWVzLmdldCh7IHVybDogJ2h0dHBzOi8veC5jb20nLCBuYW1lOiAndHdpZCcgfSwgY29va2llID0+IHtcbiAgICAgICAgICAgIGlmIChjb29raWU/LnZhbHVlKSB7XG4gICAgICAgICAgICAgICAgY29uc3QgZGVjb2RlZCA9IGRlY29kZVVSSUNvbXBvbmVudChjb29raWUudmFsdWUpO1xuICAgICAgICAgICAgICAgIGNvbnN0IG1hdGNoID0gZGVjb2RlZC5tYXRjaCgvdT0oXFxkKykvKTtcbiAgICAgICAgICAgICAgICByZXNvbHZlKG1hdGNoID8gbWF0Y2hbMV0gOiBkZWNvZGVkKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGVsc2Uge1xuICAgICAgICAgICAgICAgIHJlc29sdmUobnVsbCk7XG4gICAgICAgICAgICB9XG4gICAgICAgIH0pO1xuICAgIH0pO1xufVxuZnVuY3Rpb24gZ2V0T3JDcmVhdGVTdGF0ZSh0YWJJZCwgdXJsID0gJycpIHtcbiAgICBsZXQgc3RhdGUgPSB0YWJEYXRhU3RvcmUuZ2V0KHRhYklkKTtcbiAgICBpZiAoIXN0YXRlKSB7XG4gICAgICAgIHN0YXRlID0ge1xuICAgICAgICAgICAgaWQ6IHRhYklkLCB1cmwsIGxhc3RPcDogJ2luaXRpYWxpemVkJyxcbiAgICAgICAgICAgIGRhdGE6IHt9LCBhcGlIaXRzOiBbXSwgc3RhdHM6IHt9LFxuICAgICAgICAgICAgYWNjb3VudDogbnVsbCwgZmVhdHVyZWRUd2VldDogbnVsbCwgcmVwbGllc1NuYXBzaG90OiBbXSxcbiAgICAgICAgICAgIHByb2ZpbGVUd2VldHNTbmFwc2hvdDogW10sIHVpZDogbnVsbCxcbiAgICAgICAgICAgIHRpbWVzdGFtcDogRGF0ZS5ub3coKSwgbGFzdEJnU3luYzogRGF0ZS5ub3coKVxuICAgICAgICB9O1xuICAgICAgICB0YWJEYXRhU3RvcmUuc2V0KHRhYklkLCBzdGF0ZSk7XG4gICAgfVxuICAgIHJldHVybiBzdGF0ZTtcbn1cbi8qKlxuICog6YeN572u5oyH5a6aIFRhYiDnmoQgU2Vzc2lvbiDnm7jlhbPmlbDmja7vvIjnlKjkuo7nmbvlh7rmiJYgU2Vzc2lvbiDlpLHmlYjvvIlcbiAqL1xuZnVuY3Rpb24gaW52YWxpZGF0ZVRhYlNlc3Npb24odGFiSWQpIHtcbiAgICBjb25zdCBzdGF0ZSA9IHRhYkRhdGFTdG9yZS5nZXQodGFiSWQpO1xuICAgIGlmIChzdGF0ZSkge1xuICAgICAgICBzdGF0ZS5hY2NvdW50ID0gbnVsbDtcbiAgICAgICAgc3RhdGUudWlkID0gbnVsbDtcbiAgICAgICAgc3RhdGUuZmVhdHVyZWRUd2VldCA9IG51bGw7XG4gICAgICAgIHN0YXRlLnJlcGxpZXNTbmFwc2hvdCA9IFtdO1xuICAgICAgICBzdGF0ZS5wcm9maWxlVHdlZXRzU25hcHNob3QgPSBbXTtcbiAgICAgICAgc3RhdGUuYXBpSGl0cyA9IFtdO1xuICAgICAgICBzdGF0ZS5zdGF0cyA9IHt9O1xuICAgICAgICBzdGF0ZS5kYXRhID0ge307XG4gICAgICAgIHN0YXRlLmxhc3RPcCA9ICdzZXNzaW9uX2ludmFsaWRhdGVkJztcbiAgICAgICAgc2F2ZVN0b3JlKCk7XG4gICAgICAgIG5vdGlmeURlYnVnUGFnZXModGFiSWQsICdTVEFUVVMnKTtcbiAgICAgICAgY29uc29sZS5sb2coYFtUd2VldENsYXctQkddIPCflJIgU2Vzc2lvbiBpbnZhbGlkYXRlZCBmb3IgdGFiICR7dGFiSWR9YCk7XG4gICAgfVxufVxuLyoqXG4gKiDph43nva7lhajlsYAgU2Vzc2lvbu+8iOeUqOS6juWFqOWxgOeZu+WHuu+8iVxuICovXG5mdW5jdGlvbiBpbnZhbGlkYXRlQWxsU2Vzc2lvbnMoKSB7XG4gICAgZm9yIChjb25zdCB0YWJJZCBvZiB0YWJEYXRhU3RvcmUua2V5cygpKSB7XG4gICAgICAgIGNvbnN0IHN0YXRlID0gdGFiRGF0YVN0b3JlLmdldCh0YWJJZCk7XG4gICAgICAgIGlmIChzdGF0ZSkge1xuICAgICAgICAgICAgc3RhdGUuYWNjb3VudCA9IG51bGw7XG4gICAgICAgICAgICBzdGF0ZS51aWQgPSBudWxsO1xuICAgICAgICAgICAgc3RhdGUuZmVhdHVyZWRUd2VldCA9IG51bGw7XG4gICAgICAgICAgICBzdGF0ZS5yZXBsaWVzU25hcHNob3QgPSBbXTtcbiAgICAgICAgICAgIHN0YXRlLnByb2ZpbGVUd2VldHNTbmFwc2hvdCA9IFtdO1xuICAgICAgICAgICAgc3RhdGUuYXBpSGl0cyA9IFtdO1xuICAgICAgICAgICAgc3RhdGUuc3RhdHMgPSB7fTtcbiAgICAgICAgICAgIHN0YXRlLmRhdGEgPSB7fTtcbiAgICAgICAgICAgIHN0YXRlLmxhc3RPcCA9ICdzZXNzaW9uX2NsZWFyZWQnO1xuICAgICAgICAgICAgbm90aWZ5RGVidWdQYWdlcyh0YWJJZCwgJ1NUQVRVUycpO1xuICAgICAgICB9XG4gICAgfVxuICAgIHNhdmVTdG9yZSgpO1xuICAgIGNvbnNvbGUubG9nKCdbVHdlZXRDbGF3LUJHXSDwn5SSIEdsb2JhbCBzZXNzaW9uIGludmFsaWRhdGVkJyk7XG59XG4vKipcbiAqIOmAmuefpeaJgOacieW3suaJk+W8gOeahCBkZWJ1ZyB0YWIg5pyJ5pWw5o2u5pu05paw44CCXG4gKiBkZWJ1ZyB0YWIg55qEIFVSTCDljLnphY0gY2hyb21lLWV4dGVuc2lvbjovLy4uLi9kZWJ1Zy5odG1sXG4gKi9cbmZ1bmN0aW9uIG5vdGlmeURlYnVnUGFnZXMoeFRhYklkLCB0eXBlKSB7XG4gICAgY2hyb21lLnRhYnMucXVlcnkoeyB1cmw6IGNocm9tZS5ydW50aW1lLmdldFVSTCgnZGVidWcuaHRtbCcpIH0pLnRoZW4oZGVidWdUYWJzID0+IHtcbiAgICAgICAgZm9yIChjb25zdCBkdCBvZiBkZWJ1Z1RhYnMpIHtcbiAgICAgICAgICAgIGlmIChkdC5pZCkge1xuICAgICAgICAgICAgICAgIGNocm9tZS50YWJzLnNlbmRNZXNzYWdlKGR0LmlkLCB7XG4gICAgICAgICAgICAgICAgICAgIHR5cGU6ICdERUJVR19VUERBVEVfUFVTSCcsXG4gICAgICAgICAgICAgICAgICAgIHVwZGF0ZVR5cGU6IHR5cGUsXG4gICAgICAgICAgICAgICAgICAgIHRhYklkOiB4VGFiSWRcbiAgICAgICAgICAgICAgICB9KS5jYXRjaCgoKSA9PiB7IH0pO1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgfSkuY2F0Y2goKCkgPT4ge1xuICAgICAgICAvLyDoi6UgZGVidWcg6aG15pyq5omT5byA5YiZ6Z2Z6buY5b+955WlXG4gICAgfSk7XG59XG5hc3luYyBmdW5jdGlvbiBoYXJ2ZXN0UXVlcnlJZChvcCwgYXBpVXJsKSB7XG4gICAgaWYgKCFhcGlVcmwpXG4gICAgICAgIHJldHVybjtcbiAgICBjb25zdCBtYXRjaCA9IGFwaVVybC5tYXRjaCgvXFwvZ3JhcGhxbFxcLyhbXi8/I1xcc10rKVxcLyhbXi8/I1xcc10rKS8pO1xuICAgIGlmICghbWF0Y2gpXG4gICAgICAgIHJldHVybjtcbiAgICBjb25zdCBbLCBxdWVyeUlkLCBvcEZyb21VcmxdID0gbWF0Y2g7XG4gICAgY29uc3Qga2V5ID0gb3AgfHwgb3BGcm9tVXJsO1xuICAgIGlmICgha2V5IHx8ICFxdWVyeUlkKVxuICAgICAgICByZXR1cm47XG4gICAgY29uc3QgcmVzID0gYXdhaXQgY2hyb21lLnN0b3JhZ2UubG9jYWwuZ2V0KF9fREJLX3F1ZXJ5X2lkX21hcCk7XG4gICAgY29uc3QgbWFwID0gKHJlc1tfX0RCS19xdWVyeV9pZF9tYXBdIHx8IHt9KTtcbiAgICBpZiAobWFwW2tleV0gIT09IHF1ZXJ5SWQpIHtcbiAgICAgICAgbWFwW2tleV0gPSBxdWVyeUlkO1xuICAgICAgICBhd2FpdCBjaHJvbWUuc3RvcmFnZS5sb2NhbC5zZXQoeyBbX19EQktfcXVlcnlfaWRfbWFwXTogbWFwIH0pO1xuICAgICAgICBjb25zb2xlLmxvZyhgJWNbVHdlZXRDbGF3LUJHXSDwn46vIEhBUlZFU1QgU1VDQ0VTUyAoSG9vayk6ICR7a2V5fSDihpIgJHtxdWVyeUlkfWAsIFwiY29sb3I6IzRhZGU4MDsgZm9udC13ZWlnaHQ6Ym9sZDsgYm9yZGVyOjFweCBzb2xpZCAjNGFkZTgwOyBwYWRkaW5nOjJweCA0cHg7IGJvcmRlci1yYWRpdXM6NHB4O1wiKTtcbiAgICB9XG59XG5hc3luYyBmdW5jdGlvbiBoYXJ2ZXN0QmVhcmVyKGJlYXJlcikge1xuICAgIGlmICghYmVhcmVyIHx8ICFiZWFyZXIuc3RhcnRzV2l0aCgnQmVhcmVyICcpKVxuICAgICAgICByZXR1cm47XG4gICAgY29uc3QgcmVzID0gYXdhaXQgY2hyb21lLnN0b3JhZ2UubG9jYWwuZ2V0KF9fREJLX2JlYXJlcl90b2tlbik7XG4gICAgaWYgKHJlc1tfX0RCS19iZWFyZXJfdG9rZW5dICE9PSBiZWFyZXIpIHtcbiAgICAgICAgYXdhaXQgY2hyb21lLnN0b3JhZ2UubG9jYWwuc2V0KHsgW19fREJLX2JlYXJlcl90b2tlbl06IGJlYXJlciB9KTtcbiAgICAgICAgY29uc29sZS5sb2coJ1tUd2VldENsYXctQkddIOKchSBIYXJ2ZXN0ZWQgYmVhcmVyIHRva2VuJyk7XG4gICAgfVxufVxuLy8g4pSA4pSAIOenu+mZpOaXp+eahCBhY3Rpb24ub25DbGlja2VkIOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgFxuLy8g5bey5Lqk55SxIHBvcHVwIOaOp+WItlxuLy8g4pSA4pSAIOa2iOaBr+S4reaeoiDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIBcbi8vXG4vLyDph43opoHmnrbmnoTor7TmmI7vvJpcbi8vICAgc2VuZGVyLnRhYiDlj6rlr7kgY29udGVudCBzY3JpcHQg5raI5oGv5pyJ5YC844CCXG4vLyAgIGRlYnVnIOmhtemdouaYryBleHRlbnNpb24gcGFnZe+8jHNlbmRlci50YWIgPT09IHVuZGVmaW5lZOOAglxuLy8gICDlm6DmraQgdGFiSWQgZ3VhcmQg5LiN6IO95YWo5bGA5o+Q5YmN77yM5b+F6aG75oyJ5raI5oGv57G75Z6L5YiG5Yir5aSE55CG44CCXG4vL1xuY2hyb21lLnJ1bnRpbWUub25NZXNzYWdlLmFkZExpc3RlbmVyKChtZXNzYWdlLCBzZW5kZXIsIHNlbmRSZXNwb25zZSkgPT4ge1xuICAgIC8vIOKUgOKUgCBXU19QT1JUX0NIQU5HRUQg6YWN572u5pu05pawIOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgFxuICAgIGlmIChtZXNzYWdlLnR5cGUgPT09ICdXU19QT1JUX0NIQU5HRUQnKSB7XG4gICAgICAgIGxvY2FsQnJpZGdlLnJlY29ubmVjdFdpdGhOZXdQb3J0KG1lc3NhZ2UucG9ydCk7XG4gICAgICAgIGlmIChzZW5kUmVzcG9uc2UpXG4gICAgICAgICAgICBzZW5kUmVzcG9uc2UoeyBvazogdHJ1ZSB9KTtcbiAgICAgICAgcmV0dXJuO1xuICAgIH1cbiAgICAvLyDilIDilIAgR0VUX0JSSURHRV9TVEFUVVM6IHBvcHVwIHF1ZXJpZXMgbGl2ZSBjb25uZWN0aW9uIHN0YXRlIOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgFxuICAgIGlmIChtZXNzYWdlLnR5cGUgPT09ICdHRVRfQlJJREdFX1NUQVRVUycpIHtcbiAgICAgICAgY29uc3QgY29ubmVjdGVkID0gbG9jYWxCcmlkZ2UuaXNDb25uZWN0ZWQoKTtcbiAgICAgICAgY29uc3Qgc2VydmVySW5mbyA9IGxvY2FsQnJpZGdlLmdldFNlcnZlckluZm8oKTtcbiAgICAgICAgY29uc3Qgd3NVcmwgPSBsb2NhbEJyaWRnZS5nZXRDdXJyZW50VXJsKCk7XG4gICAgICAgIGlmIChzZW5kUmVzcG9uc2UpXG4gICAgICAgICAgICBzZW5kUmVzcG9uc2UoeyBjb25uZWN0ZWQsIHNlcnZlckluZm8sIHdzVXJsIH0pO1xuICAgICAgICByZXR1cm4gdHJ1ZTtcbiAgICB9XG4gICAgLy8g4pSA4pSAIOadpeiHqiBjb250ZW50IHNjcmlwdCDnmoQgQVBJIOaLpuaIquaVsOaNriDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIBcbiAgICBpZiAobWVzc2FnZS50eXBlID09PSAnQ0FQVFVSRURfREFUQScpIHtcbiAgICAgICAgY29uc3QgdGFiSWQgPSBzZW5kZXIudGFiPy5pZDtcbiAgICAgICAgaWYgKCF0YWJJZClcbiAgICAgICAgICAgIHJldHVybjsgLy8g5b+F6aG75p2l6IeqIGNvbnRlbnQgc2NyaXB0XG4gICAgICAgIChhc3luYyAoKSA9PiB7XG4gICAgICAgICAgICBjb25zdCBzdGF0ZSA9IGdldE9yQ3JlYXRlU3RhdGUodGFiSWQsIG1lc3NhZ2UucGFnZVVybCk7XG4gICAgICAgICAgICBjb25zdCBjb25maXJtZWRVaWQgPSBhd2FpdCBnZXRBdXRoZW50aWNVaWQoKTtcbiAgICAgICAgICAgIHN0YXRlLmxhc3RPcCA9IG1lc3NhZ2Uub3A7XG4gICAgICAgICAgICBzdGF0ZS51cmwgPSBtZXNzYWdlLnBhZ2VVcmwgfHwgc3RhdGUudXJsO1xuICAgICAgICAgICAgLy8g5q+P5LiqIG9wIOWPquS/neeVmeacgOaWsOS4gOS7veaVsOaNru+8iOimhuebluaXp+eahO+8iVxuICAgICAgICAgICAgc3RhdGUuZGF0YVttZXNzYWdlLm9wXSA9IG1lc3NhZ2UuZGF0YTtcbiAgICAgICAgICAgIC8vIOaguOW/g+aUuei/m++8muWvueS6juivpuaDhemhte+8jOmineWkluaMiSB0d2VldElkIOe8k+WtmOS4gOS7ve+8jOmYsuatouWcqCB0aHJlYWQg5Lit5rex5YWl6Lez6L2s5pe26KaG55uW5o6J5Li76LS05pWw5o2uXG4gICAgICAgICAgICBpZiAobWVzc2FnZS5vcCA9PT0gJ1R3ZWV0RGV0YWlsJyAmJiBtZXNzYWdlLnBhZ2VVcmwpIHtcbiAgICAgICAgICAgICAgICBjb25zdCBmb2NhbElkID0gZXh0cmFjdFR3ZWV0SWQobWVzc2FnZS5wYWdlVXJsKTtcbiAgICAgICAgICAgICAgICBpZiAoZm9jYWxJZCkge1xuICAgICAgICAgICAgICAgICAgICBzdGF0ZS5kYXRhW2BUd2VldERldGFpbF8ke2ZvY2FsSWR9YF0gPSBtZXNzYWdlLmRhdGE7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfVxuICAgICAgICAgICAgc3RhdGUubGFzdEJnU3luYyA9IERhdGUubm93KCk7XG4gICAgICAgICAgICBpZiAoIXN0YXRlLnN0YXRzW21lc3NhZ2Uub3BdKVxuICAgICAgICAgICAgICAgIHN0YXRlLnN0YXRzW21lc3NhZ2Uub3BdID0geyBjb3VudDogMCwgbGFzdEhpdDogMCB9O1xuICAgICAgICAgICAgc3RhdGUuc3RhdHNbbWVzc2FnZS5vcF0uY291bnQrKztcbiAgICAgICAgICAgIHN0YXRlLnN0YXRzW21lc3NhZ2Uub3BdLmxhc3RIaXQgPSBEYXRlLm5vdygpO1xuICAgICAgICAgICAgLy8g5Y676Zmk6Z2e6YeN5aSN55qE5ZCM5ZCNIG9w77yM5L+d5oyB572R5qC855WM6Z2i5riF54i977yM5q+P5LiqIG9wIOWPqueVmeacgOaWsOS4gOasoeiusOW9le+8jOaWueS+v+iwg+ivlVxuICAgICAgICAgICAgc3RhdGUuYXBpSGl0cyA9IHN0YXRlLmFwaUhpdHMuZmlsdGVyKGggPT4gaC5vcCAhPT0gbWVzc2FnZS5vcCk7XG4gICAgICAgICAgICAvLyDliqDlhaXmnIDmlrDnmoTorrDlvZVcbiAgICAgICAgICAgIHN0YXRlLmFwaUhpdHMudW5zaGlmdCh7XG4gICAgICAgICAgICAgICAgb3A6IG1lc3NhZ2Uub3AsXG4gICAgICAgICAgICAgICAgYXBpVXJsOiBtZXNzYWdlLmFwaVVybCB8fCAnJyxcbiAgICAgICAgICAgICAgICBwYWdlVXJsOiBtZXNzYWdlLnBhZ2VVcmwgfHwgJycsXG4gICAgICAgICAgICAgICAgbWV0aG9kOiBtZXNzYWdlLm1ldGhvZCB8fCAnUE9TVCcsXG4gICAgICAgICAgICAgICAgdGltZXN0YW1wOiBEYXRlLm5vdygpLFxuICAgICAgICAgICAgICAgIHJlcXVlc3RCb2R5OiBtZXNzYWdlLnJlcXVlc3RCb2R5LFxuICAgICAgICAgICAgICAgIHJlc3BvbnNlQm9keTogbWVzc2FnZS5kYXRhXG4gICAgICAgICAgICB9KTtcbiAgICAgICAgICAgIC8vIOacgOWkmuS/neeVmSAzMCDnp43kuI3lkIwgb3Ag55qE6K+m5oOFXG4gICAgICAgICAgICBpZiAoc3RhdGUuYXBpSGl0cy5sZW5ndGggPiAzMClcbiAgICAgICAgICAgICAgICBzdGF0ZS5hcGlIaXRzLnBvcCgpO1xuICAgICAgICAgICAgLy8g6Lqr5Lu95o+Q5Y+WXG4gICAgICAgICAgICBjb25zdCBzdW1tYXJ5ID0gZmluZFZpZXdlclN1bW1hcnkobWVzc2FnZS5kYXRhLCBjb25maXJtZWRVaWQgfHwgdW5kZWZpbmVkKTtcbiAgICAgICAgICAgIGlmIChzdW1tYXJ5KSB7XG4gICAgICAgICAgICAgICAgc3RhdGUuYWNjb3VudCA9IHsgLi4uc3RhdGUuYWNjb3VudCwgLi4uc3VtbWFyeSB9O1xuICAgICAgICAgICAgICAgIHN0YXRlLnVpZCA9IHN1bW1hcnkudXNlcklkO1xuICAgICAgICAgICAgICAgIC8vIOWwhuacgOaWsOi6q+S7veWGmeWFpeS8muivnee6p+WFqOWxgOWtmOWCqO+8jOehruS/neWFtuS7luaJgOacieaooeWdl+iDveW/q+mAn+iuv+mXrlxuICAgICAgICAgICAgICAgIGNocm9tZS5zdG9yYWdlLnNlc3Npb24uc2V0KHtcbiAgICAgICAgICAgICAgICAgICAgJ190Y19nbG9iYWxfc2Vzc2lvbl9hY2NvdW50Jzoge1xuICAgICAgICAgICAgICAgICAgICAgICAgLi4uc3VtbWFyeSxcbiAgICAgICAgICAgICAgICAgICAgICAgIF91cGRhdGVkQXQ6IERhdGUubm93KClcbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIH0pLmNhdGNoKCgpID0+IHsgfSk7XG4gICAgICAgICAgICAgICAgLy8g5ZCM5pe25L+d5a2Y5YiwIGxvY2FsIHN0b3JhZ2Ug5L6bIGNvbnRlbnQgc2NyaXB0IGZldGNoIOS9v+eUqFxuICAgICAgICAgICAgICAgIGNocm9tZS5zdG9yYWdlLmxvY2FsLnNldCh7XG4gICAgICAgICAgICAgICAgICAgIHNjcmVlbk5hbWU6IHN1bW1hcnkuaGFuZGxlLnJlcGxhY2UoJ0AnLCAnJyksXG4gICAgICAgICAgICAgICAgICAgIHVzZXJJZDogc3VtbWFyeS51c2VySWRcbiAgICAgICAgICAgICAgICB9KS5jYXRjaCgoKSA9PiB7IH0pO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgLy8g5o6o5paH5o+Q5Y+WXG4gICAgICAgICAgICBjb25zdCB0d2VldCA9IGZpbmRGZWF0dXJlZFR3ZWV0KG1lc3NhZ2UuZGF0YSwgbWVzc2FnZS5wYWdlVXJsKTtcbiAgICAgICAgICAgIGlmICh0d2VldCkge1xuICAgICAgICAgICAgICAgIHN0YXRlLmZlYXR1cmVkVHdlZXQgPSB0d2VldDtcbiAgICAgICAgICAgICAgICAvLyDlvZPmj5Dlj5bliLDmlrDnmoTkuLvmjqjmlofml7bvvIzlkIzml7bmj5Dlj5bkuIDmrKHlm57lpI3lv6vnhadcbiAgICAgICAgICAgICAgICBzdGF0ZS5yZXBsaWVzU25hcHNob3QgPSBmaW5kUmVwbGllc1NuYXBzaG90KG1lc3NhZ2UuZGF0YSwgbWVzc2FnZS5wYWdlVXJsLCBzdGF0ZS5hY2NvdW50Py5oYW5kbGUpO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgZWxzZSBpZiAobWVzc2FnZS5vcCA9PT0gJ1R3ZWV0RGV0YWlsJykge1xuICAgICAgICAgICAgICAgIC8vIOeJueauiuWcuuaZr++8muWmguaenOaYryBUd2VldERldGFpbCDlk43lupTkvYbmsqHmib7liLDkuLvmjqjmlofvvIjlj6/og73nvZHnu5zljIXlj6rmnInlm57lpI3vvInvvIzkuZ/lsJ3or5Xmj5Dlj5ZcbiAgICAgICAgICAgICAgICBjb25zdCBzbmFwc2hvdCA9IGZpbmRSZXBsaWVzU25hcHNob3QobWVzc2FnZS5kYXRhLCBtZXNzYWdlLnBhZ2VVcmwsIHN0YXRlLmFjY291bnQ/LmhhbmRsZSk7XG4gICAgICAgICAgICAgICAgaWYgKHNuYXBzaG90Lmxlbmd0aCA+IDApXG4gICAgICAgICAgICAgICAgICAgIHN0YXRlLnJlcGxpZXNTbmFwc2hvdCA9IHNuYXBzaG90O1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgLy8gUHJvZmlsZSDmjqjmloflv6vnhafmj5Dlj5ZcbiAgICAgICAgICAgIGlmIChtZXNzYWdlLm9wID09PSAnVXNlclR3ZWV0cycgfHwgbWVzc2FnZS5vcCA9PT0gJ1VzZXJUd2VldHNBbmRSZXBsaWVzJykge1xuICAgICAgICAgICAgICAgIGNvbnN0IG5ld1Byb2ZpbGVUd2VldHMgPSBmaW5kUHJvZmlsZVR3ZWV0c1NuYXBzaG90KG1lc3NhZ2UuZGF0YSwgc3RhdGUuYWNjb3VudD8uaGFuZGxlKTtcbiAgICAgICAgICAgICAgICBpZiAobmV3UHJvZmlsZVR3ZWV0cy5sZW5ndGggPiAwKSB7XG4gICAgICAgICAgICAgICAgICAgIC8vIOWmguaenCBVUkwg5oyH5ZCR5LiN5ZCM55qEIHByb2ZpbGXvvIzliJnmuIXpmaTml6flv6vnhafvvIjnroDljZXmoLnmja7ot6/lvoTlkI3liKTmlq3vvIlcbiAgICAgICAgICAgICAgICAgICAgY29uc3QgY3VycmVudFByb2ZpbGUgPSBzdGF0ZS51cmwuc3BsaXQoJz8nKVswXS5zcGxpdCgnLycpLmZpbHRlcihCb29sZWFuKS5wb3AoKTtcbiAgICAgICAgICAgICAgICAgICAgY29uc3QgbGFzdFByb2ZpbGUgPSAoc3RhdGUuZGF0YVsnbGFzdF9wcm9maWxlX2hhbmRsZSddIHx8ICcnKTtcbiAgICAgICAgICAgICAgICAgICAgaWYgKGN1cnJlbnRQcm9maWxlICYmIGN1cnJlbnRQcm9maWxlICE9PSBsYXN0UHJvZmlsZSkge1xuICAgICAgICAgICAgICAgICAgICAgICAgc3RhdGUucHJvZmlsZVR3ZWV0c1NuYXBzaG90ID0gW107XG4gICAgICAgICAgICAgICAgICAgICAgICBzdGF0ZS5kYXRhWydsYXN0X3Byb2ZpbGVfaGFuZGxlJ10gPSBjdXJyZW50UHJvZmlsZTtcbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICBjb25zdCBleGlzdGluZ01hcCA9IG5ldyBNYXAoKHN0YXRlLnByb2ZpbGVUd2VldHNTbmFwc2hvdCB8fCBbXSkubWFwKHQgPT4gW3QudHdlZXRJZCwgdF0pKTtcbiAgICAgICAgICAgICAgICAgICAgZm9yIChjb25zdCB0IG9mIG5ld1Byb2ZpbGVUd2VldHMpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIGV4aXN0aW5nTWFwLnNldCh0LnR3ZWV0SWQsIHQpO1xuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgIC8vIOWwhiBNYXAg6L2s5Zue5pWw57uE77yM5L+d55WZ5Zyo5YiX6KGo5Lit55qE6aG65bqPXG4gICAgICAgICAgICAgICAgICAgIHN0YXRlLnByb2ZpbGVUd2VldHNTbmFwc2hvdCA9IEFycmF5LmZyb20oZXhpc3RpbmdNYXAudmFsdWVzKCkpO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIC8vIOiHquWKqOaUtuWJslxuICAgICAgICAgICAgYXdhaXQgaGFydmVzdFF1ZXJ5SWQobWVzc2FnZS5vcCwgbWVzc2FnZS5hcGlVcmwpO1xuICAgICAgICAgICAgYXdhaXQgaGFydmVzdEJlYXJlcihtZXNzYWdlLmJlYXJlclRva2VuKTtcbiAgICAgICAgICAgIHNhdmVTdG9yZSgpO1xuICAgICAgICAgICAgbm90aWZ5RGVidWdQYWdlcyh0YWJJZCwgJ0RBVEEnKTtcbiAgICAgICAgfSkoKTtcbiAgICAgICAgcmV0dXJuOyAvLyDlvILmraXvvIzkuI3pnIDopoEgcmV0dXJuIHRydWXvvIjkuI3kvb/nlKggc2VuZFJlc3BvbnNl77yJXG4gICAgfVxuICAgIC8vIOKUgOKUgCDmnaXoh6ogY29udGVudCBzY3JpcHQg55qEIGhvb2sg54q25oCB5LiK5oqlIOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgFxuICAgIGlmIChtZXNzYWdlLnR5cGUgPT09ICdSRVBPUlRfSE9PS19TVEFUVVMnKSB7XG4gICAgICAgIGNvbnN0IHRhYklkID0gc2VuZGVyLnRhYj8uaWQ7XG4gICAgICAgIGlmICghdGFiSWQpXG4gICAgICAgICAgICByZXR1cm47XG4gICAgICAgIGNvbnN0IHN0YXRlID0gZ2V0T3JDcmVhdGVTdGF0ZSh0YWJJZCk7XG4gICAgICAgIHN0YXRlLmhvb2tTdGF0dXMgPSBtZXNzYWdlLnN0YXR1cztcbiAgICAgICAgc3RhdGUubGFzdEJnU3luYyA9IERhdGUubm93KCk7XG4gICAgICAgIHNhdmVTdG9yZSgpO1xuICAgICAgICBub3RpZnlEZWJ1Z1BhZ2VzKHRhYklkLCAnU1RBVFVTJyk7XG4gICAgICAgIHJldHVybjtcbiAgICB9XG4gICAgLy8g4pSA4pSAIOS7peS4i+a2iOaBr+adpeiHqiBkZWJ1ZyDpobXpnaLvvIhzZW5kZXIudGFiIOS4uiB1bmRlZmluZWTvvInilIDilIDilIDilIDilIDilIDilIDilIDilIBcbiAgICAvLyDmn6Xor6LmiYDmnIkgeC5jb20gdGFiIOWIl+ihqFxuICAgIGlmIChtZXNzYWdlLnR5cGUgPT09ICdMSVNUX0FMTF9YX1RBQlMnKSB7XG4gICAgICAgIGNocm9tZS50YWJzLnF1ZXJ5KHsgdXJsOiBbJyo6Ly90d2l0dGVyLmNvbS8qJywgJyo6Ly94LmNvbS8qJ10gfSkudGhlbih0YWJzID0+IHtcbiAgICAgICAgICAgIGNvbnN0IHJlc3VsdCA9IHRhYnMubWFwKHQgPT4ge1xuICAgICAgICAgICAgICAgIGNvbnN0IHMgPSB0YWJEYXRhU3RvcmUuZ2V0KHQuaWQpO1xuICAgICAgICAgICAgICAgIHJldHVybiB7XG4gICAgICAgICAgICAgICAgICAgIGlkOiB0LmlkLFxuICAgICAgICAgICAgICAgICAgICB1cmw6IHQudXJsIHx8IHM/LnVybCB8fCAnJyxcbiAgICAgICAgICAgICAgICAgICAgYWN0aXZlOiB0LmFjdGl2ZSxcbiAgICAgICAgICAgICAgICAgICAgbGFzdE9wOiBzPy5sYXN0T3AgfHwgJ3BlbmRpbmcnLFxuICAgICAgICAgICAgICAgICAgICBhY2NvdW50OiBzPy5hY2NvdW50IHx8IG51bGwsXG4gICAgICAgICAgICAgICAgICAgIGhvb2tTdGF0dXM6IHM/Lmhvb2tTdGF0dXMgfHwgbnVsbCxcbiAgICAgICAgICAgICAgICAgICAgbGFzdEJnU3luYzogcz8ubGFzdEJnU3luYyB8fCAwXG4gICAgICAgICAgICAgICAgfTtcbiAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgc2VuZFJlc3BvbnNlKHJlc3VsdCk7XG4gICAgICAgIH0pO1xuICAgICAgICByZXR1cm4gdHJ1ZTsgLy8g5byC5q2lIHNlbmRSZXNwb25zZVxuICAgIH1cbiAgICBpZiAobWVzc2FnZS50eXBlID09PSAnQ1JFQVRFX1hfVEFCJykge1xuICAgICAgICBjaHJvbWUudGFicy5jcmVhdGUoeyB1cmw6IG1lc3NhZ2UudXJsIHx8ICdodHRwczovL3guY29tLycgfSkudGhlbih0YWIgPT4ge1xuICAgICAgICAgICAgc2VuZFJlc3BvbnNlKHsgb2s6IHRydWUsIHRhYklkOiB0YWIuaWQgfSk7XG4gICAgICAgIH0pLmNhdGNoKGVyciA9PiB7XG4gICAgICAgICAgICBzZW5kUmVzcG9uc2UoeyBvazogZmFsc2UsIGVycm9yOiBlcnIubWVzc2FnZSB9KTtcbiAgICAgICAgfSk7XG4gICAgICAgIHJldHVybiB0cnVlO1xuICAgIH1cbiAgICBpZiAobWVzc2FnZS50eXBlID09PSAnRk9DVVNfWF9UQUInKSB7XG4gICAgICAgIGNocm9tZS50YWJzLnVwZGF0ZShtZXNzYWdlLnRhYklkLCB7IGFjdGl2ZTogdHJ1ZSB9KS50aGVuKHRhYiA9PiB7XG4gICAgICAgICAgICBpZiAodGFiICYmIHRhYi53aW5kb3dJZCkge1xuICAgICAgICAgICAgICAgIGNocm9tZS53aW5kb3dzLnVwZGF0ZSh0YWIud2luZG93SWQsIHsgZm9jdXNlZDogdHJ1ZSB9KS5jYXRjaCgoKSA9PiB7IH0pO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgc2VuZFJlc3BvbnNlKHsgb2s6IHRydWUgfSk7XG4gICAgICAgIH0pLmNhdGNoKGVyciA9PiB7XG4gICAgICAgICAgICBzZW5kUmVzcG9uc2UoeyBvazogZmFsc2UsIGVycm9yOiBlcnIubWVzc2FnZSB9KTtcbiAgICAgICAgfSk7XG4gICAgICAgIHJldHVybiB0cnVlO1xuICAgIH1cbiAgICBpZiAobWVzc2FnZS50eXBlID09PSAnQ0xPU0VfWF9UQUInKSB7XG4gICAgICAgIGNocm9tZS50YWJzLnJlbW92ZShtZXNzYWdlLnRhYklkKS50aGVuKCgpID0+IHtcbiAgICAgICAgICAgIHNlbmRSZXNwb25zZSh7IG9rOiB0cnVlIH0pO1xuICAgICAgICB9KS5jYXRjaChlcnIgPT4ge1xuICAgICAgICAgICAgLy8gSWYgdGFiIGFscmVhZHkgY2xvc2VkLCB3ZSBjb25zaWRlciBpdCBzdWNjZXNzIGZvciB0aGUgaW50ZW5kZWQgc3RhdGVcbiAgICAgICAgICAgIGlmIChlcnIubWVzc2FnZS5pbmNsdWRlcygnTm8gdGFiIHdpdGggaWQnKSkge1xuICAgICAgICAgICAgICAgIHNlbmRSZXNwb25zZSh7IG9rOiB0cnVlLCB3YXJuaW5nOiAnVGFiIGFscmVhZHkgY2xvc2VkJyB9KTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGVsc2Uge1xuICAgICAgICAgICAgICAgIHNlbmRSZXNwb25zZSh7IG9rOiBmYWxzZSwgZXJyb3I6IGVyci5tZXNzYWdlIH0pO1xuICAgICAgICAgICAgfVxuICAgICAgICB9KTtcbiAgICAgICAgcmV0dXJuIHRydWU7XG4gICAgfVxuICAgIGlmIChtZXNzYWdlLnR5cGUgPT09ICdOQVZJR0FURV9YX1RBQicpIHtcbiAgICAgICAgY29uc3QgeyB0YWJJZCwgdXJsIH0gPSBtZXNzYWdlO1xuICAgICAgICBpZiAoIXRhYklkIHx8ICF1cmwpIHtcbiAgICAgICAgICAgIHNlbmRSZXNwb25zZSh7IG9rOiBmYWxzZSwgZXJyb3I6ICdNaXNzaW5nIHRhYklkIG9yIHVybCcgfSk7XG4gICAgICAgICAgICByZXR1cm4gdHJ1ZTtcbiAgICAgICAgfVxuICAgICAgICBjb25zdCBpc1ggPSB1cmwuaW5jbHVkZXMoJ3guY29tJykgfHwgdXJsLmluY2x1ZGVzKCd0d2l0dGVyLmNvbScpO1xuICAgICAgICBpZiAoIWlzWCkge1xuICAgICAgICAgICAgc2VuZFJlc3BvbnNlKHsgb2s6IGZhbHNlLCBlcnJvcjogJ05hdmlnYXRpb24gcmVzdHJpY3RlZCB0byBYIGRvbWFpbnMnIH0pO1xuICAgICAgICAgICAgcmV0dXJuIHRydWU7XG4gICAgICAgIH1cbiAgICAgICAgY2hyb21lLnRhYnMudXBkYXRlKHRhYklkLCB7IHVybCB9KS50aGVuKCgpID0+IHtcbiAgICAgICAgICAgIHNlbmRSZXNwb25zZSh7IG9rOiB0cnVlLCB0YWJJZCwgdXJsIH0pO1xuICAgICAgICB9KS5jYXRjaChlcnIgPT4ge1xuICAgICAgICAgICAgc2VuZFJlc3BvbnNlKHsgb2s6IGZhbHNlLCBlcnJvcjogZXJyLm1lc3NhZ2UgfSk7XG4gICAgICAgIH0pO1xuICAgICAgICByZXR1cm4gdHJ1ZTtcbiAgICB9XG4gICAgLy8g5p+l6K+i5oyH5a6aIHRhYiDnmoTlrozmlbTmiKrojrfmlbDmja5cbiAgICBpZiAobWVzc2FnZS50eXBlID09PSAnR0VUX1RBQl9EQVRBJykge1xuICAgICAgICBjb25zdCB0YWJJZCA9IG1lc3NhZ2UudGFiSWQ7IC8vIOW/hemhu+eUsSBkZWJ1ZyDpobXpnaLmmL7lvI/kvKDlhaVcbiAgICAgICAgaWYgKCF0YWJJZCkge1xuICAgICAgICAgICAgc2VuZFJlc3BvbnNlKG51bGwpO1xuICAgICAgICAgICAgcmV0dXJuIHRydWU7XG4gICAgICAgIH1cbiAgICAgICAgZ2V0QXV0aGVudGljVWlkKCkudGhlbih1aWQgPT4ge1xuICAgICAgICAgICAgbGV0IHMgPSB0YWJEYXRhU3RvcmUuZ2V0KHRhYklkKTtcbiAgICAgICAgICAgIC8vIOWmguaenOWunuaXtueahCBjb29raWUg5bey57uP5rKh5LqG77yM6ICM5YaF5a2Y6YeM6L+Y6KeJ5b6X5pyJ6LSm5Y+377yM5YiZ6Kem5Y+R5aSx5pWIXG4gICAgICAgICAgICBpZiAoIXVpZCAmJiBzPy5hY2NvdW50KSB7XG4gICAgICAgICAgICAgICAgaW52YWxpZGF0ZVRhYlNlc3Npb24odGFiSWQpO1xuICAgICAgICAgICAgICAgIHMgPSB0YWJEYXRhU3RvcmUuZ2V0KHRhYklkKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIC8vIOWmguaenOW3sue7j+eZu+W9leS9hiBMYXN0IE9wIOi/mOayoeabtOaWsO+8iOWBnOeVmeWcqCBzZXNzaW9uIOa4heeQhuagh+iusOS4iu+8ie+8jOWImeagh+iusOS4uuato+WcqOetieW+hei6q+S7vVxuICAgICAgICAgICAgaWYgKHVpZCAmJiBzICYmIChzLmxhc3RPcCA9PT0gJ3Nlc3Npb25fY2xlYXJlZCcgfHwgcy5sYXN0T3AgPT09ICdzZXNzaW9uX2ludmFsaWRhdGVkJykpIHtcbiAgICAgICAgICAgICAgICBzLmxhc3RPcCA9ICdhd2FpdGluZ19pZGVudGl0eSc7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBjb25zdCBkYXRhID0gcyB8fCB7XG4gICAgICAgICAgICAgICAgaWQ6IHRhYklkLFxuICAgICAgICAgICAgICAgIHVybDogJycsXG4gICAgICAgICAgICAgICAgbGFzdE9wOiAndW5rbm93bicsXG4gICAgICAgICAgICAgICAgZGF0YToge30sXG4gICAgICAgICAgICAgICAgYXBpSGl0czogW10sXG4gICAgICAgICAgICAgICAgc3RhdHM6IHt9LFxuICAgICAgICAgICAgICAgIGFjY291bnQ6IG51bGwsXG4gICAgICAgICAgICAgICAgZmVhdHVyZWRUd2VldDogbnVsbCxcbiAgICAgICAgICAgICAgICB1aWQ6IG51bGwsXG4gICAgICAgICAgICAgICAgdGltZXN0YW1wOiBEYXRlLm5vdygpLFxuICAgICAgICAgICAgICAgIGxhc3RCZ1N5bmM6IDBcbiAgICAgICAgICAgIH07XG4gICAgICAgICAgICBzZW5kUmVzcG9uc2Uoe1xuICAgICAgICAgICAgICAgIC4uLmRhdGEsXG4gICAgICAgICAgICAgICAgYWxsV2F0Y2hlZE9wczogd2F0Y2hlZE9wc1xuICAgICAgICAgICAgfSk7XG4gICAgICAgIH0pO1xuICAgICAgICByZXR1cm4gdHJ1ZTtcbiAgICB9XG4gICAgLy8g5p+l6K+iIHNlc3Npb24g54q25oCB77yIU2Vzc2lvbk1hbmFnZXIg5L2/55So77yJXG4gICAgaWYgKG1lc3NhZ2UudHlwZSA9PT0gJ0dFVF9TRVNTSU9OX1NUQVRVUycpIHtcbiAgICAgICAgY29uc3QgdGFiSWQgPSBtZXNzYWdlLnRhYklkIHx8IHNlbmRlci50YWI/LmlkO1xuICAgICAgICBpZiAoIXRhYklkKSB7XG4gICAgICAgICAgICBzZW5kUmVzcG9uc2UoeyBhY2NvdW50OiBudWxsLCBob29rU3RhdHVzOiBudWxsLCBsYXN0QmdTeW5jOiAwIH0pO1xuICAgICAgICAgICAgcmV0dXJuIHRydWU7XG4gICAgICAgIH1cbiAgICAgICAgY29uc3QgcyA9IHRhYkRhdGFTdG9yZS5nZXQodGFiSWQpO1xuICAgICAgICBzZW5kUmVzcG9uc2Uoe1xuICAgICAgICAgICAgYWNjb3VudDogcz8uYWNjb3VudCB8fCBudWxsLFxuICAgICAgICAgICAgaG9va1N0YXR1czogcz8uaG9va1N0YXR1cyB8fCBudWxsLFxuICAgICAgICAgICAgbGFzdEJnU3luYzogcz8ubGFzdEJnU3luYyB8fCAwXG4gICAgICAgIH0pO1xuICAgICAgICByZXR1cm4gdHJ1ZTtcbiAgICB9XG4gICAgLy8g6I635Y+W5b2T5YmN6aG16Z2iIFNjZW5lIOS4iuS4i+aWh1xuICAgIGlmIChtZXNzYWdlLnR5cGUgPT09ICdHRVRfUEFHRV9DT05URVhUJykge1xuICAgICAgICBjb25zdCB0YWJJZCA9IG1lc3NhZ2UudGFiSWQgfHwgc2VuZGVyLnRhYj8uaWQ7XG4gICAgICAgIGlmICghdGFiSWQpIHtcbiAgICAgICAgICAgIHNlbmRSZXNwb25zZShkZXJpdmVQYWdlQ29udGV4dCh1bmRlZmluZWQsIGZhbHNlLCBmYWxzZSkpO1xuICAgICAgICAgICAgcmV0dXJuIHRydWU7XG4gICAgICAgIH1cbiAgICAgICAgZ2V0QXV0aGVudGljVWlkKCkudGhlbih1aWQgPT4ge1xuICAgICAgICAgICAgY29uc3QgaXNMb2dnZWRJbiA9ICEhdWlkO1xuICAgICAgICAgICAgY29uc3QgcyA9IHRhYkRhdGFTdG9yZS5nZXQodGFiSWQpO1xuICAgICAgICAgICAgY29uc3QgaGFzU2Vzc2lvbiA9ICEhcz8uYWNjb3VudD8uaGFuZGxlO1xuICAgICAgICAgICAgY29uc3QgZmVhdHVyZWRUd2VldCA9IHM/LmZlYXR1cmVkVHdlZXQgfHwgbnVsbDtcbiAgICAgICAgICAgIGNvbnN0IGFjdGl2ZUFjY291bnRIYW5kbGUgPSBzPy5hY2NvdW50Py5oYW5kbGUgfHwgbnVsbDtcbiAgICAgICAgICAgIGNvbnN0IHJlcGxpZXNTbmFwc2hvdCA9IHM/LnJlcGxpZXNTbmFwc2hvdCB8fCBbXTtcbiAgICAgICAgICAgIGNvbnN0IHByb2ZpbGVUd2VldHNTbmFwc2hvdCA9IHM/LnByb2ZpbGVUd2VldHNTbmFwc2hvdCB8fCBbXTtcbiAgICAgICAgICAgIGNocm9tZS50YWJzLmdldCh0YWJJZCkudGhlbih0YWIgPT4ge1xuICAgICAgICAgICAgICAgIGNvbnN0IGN1cnJlbnRVcmwgPSB0YWIudXJsIHx8IHM/LnVybCB8fCAnJztcbiAgICAgICAgICAgICAgICBjb25zdCB0YXJnZXRJZCA9IGV4dHJhY3RUd2VldElkKGN1cnJlbnRVcmwpO1xuICAgICAgICAgICAgICAgIGxldCBmZWF0dXJlZFR3ZWV0ID0gcz8uZmVhdHVyZWRUd2VldCB8fCBudWxsO1xuICAgICAgICAgICAgICAgIGxldCByZXBsaWVzU25hcHNob3QgPSBzPy5yZXBsaWVzU25hcHNob3QgfHwgW107XG4gICAgICAgICAgICAgICAgLy8g5qC45b+D5L+u5aSN6YC76L6R77yaXG4gICAgICAgICAgICAgICAgLy8g5aaC5p6c5b2T5YmN5pivIHR3ZWV0X2RldGFpbCDlnLrmma/vvIzlsJ3or5Xku47nvJPlrZjkuK3mib7lm57kuI7lvZPliY0gVVJMIOWMuemFjeeahOaVsOaNrlxuICAgICAgICAgICAgICAgIC8vIOS8mOWFiOS9v+eUqOaMiSBJRCDntKLlvJXnmoTnvJPlrZjvvIzpgb/lhY3lnKggdGhyZWFkIOS4reeUseS6jua3seWFpei3s+i9rOWvvOiHtOeahOimhueblumXrumimFxuICAgICAgICAgICAgICAgIGlmICh0YXJnZXRJZCkge1xuICAgICAgICAgICAgICAgICAgICBjb25zdCBjYWNoZWREYXRhID0gcz8uZGF0YVtgVHdlZXREZXRhaWxfJHt0YXJnZXRJZH1gXSB8fCBzPy5kYXRhWydUd2VldERldGFpbCddO1xuICAgICAgICAgICAgICAgICAgICBpZiAoY2FjaGVkRGF0YSkge1xuICAgICAgICAgICAgICAgICAgICAgICAgaWYgKGZlYXR1cmVkVHdlZXQ/LmlkICE9PSB0YXJnZXRJZCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbnN0IHJlZml0dGVkID0gZmluZFR3ZWV0QnlJZChjYWNoZWREYXRhLCB0YXJnZXRJZCk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgaWYgKHJlZml0dGVkKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGZlYXR1cmVkVHdlZXQgPSByZWZpdHRlZDtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcy5mZWF0dXJlZFR3ZWV0ID0gcmVmaXR0ZWQ7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgLy8g6YeN5paw6K6h566X5Zue5aSN5YiX6KGoXG4gICAgICAgICAgICAgICAgICAgICAgICByZXBsaWVzU25hcHNob3QgPSBmaW5kUmVwbGllc1NuYXBzaG90KGNhY2hlZERhdGEsIGN1cnJlbnRVcmwsIGFjdGl2ZUFjY291bnRIYW5kbGUpO1xuICAgICAgICAgICAgICAgICAgICAgICAgcy5yZXBsaWVzU25hcHNob3QgPSByZXBsaWVzU25hcHNob3Q7XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgc2VuZFJlc3BvbnNlKHtcbiAgICAgICAgICAgICAgICAgICAgLi4uZGVyaXZlUGFnZUNvbnRleHQoY3VycmVudFVybCwgaGFzU2Vzc2lvbiwgaXNMb2dnZWRJbiwgZmVhdHVyZWRUd2VldCwgYWN0aXZlQWNjb3VudEhhbmRsZSksXG4gICAgICAgICAgICAgICAgICAgIHJlcGxpZXNTbmFwc2hvdCxcbiAgICAgICAgICAgICAgICAgICAgcHJvZmlsZVR3ZWV0c1NuYXBzaG90XG4gICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICB9KS5jYXRjaCgoKSA9PiB7XG4gICAgICAgICAgICAgICAgY29uc3QgY3VycmVudFVybCA9IHM/LnVybCB8fCAnJztcbiAgICAgICAgICAgICAgICBjb25zdCB0YXJnZXRJZCA9IGV4dHJhY3RUd2VldElkKGN1cnJlbnRVcmwpO1xuICAgICAgICAgICAgICAgIGxldCBmZWF0dXJlZFR3ZWV0ID0gcz8uZmVhdHVyZWRUd2VldCB8fCBudWxsO1xuICAgICAgICAgICAgICAgIGxldCByZXBsaWVzU25hcHNob3QgPSBzPy5yZXBsaWVzU25hcHNob3QgfHwgW107XG4gICAgICAgICAgICAgICAgaWYgKHRhcmdldElkKSB7XG4gICAgICAgICAgICAgICAgICAgIGNvbnN0IGNhY2hlZERhdGEgPSBzPy5kYXRhW2BUd2VldERldGFpbF8ke3RhcmdldElkfWBdIHx8IHM/LmRhdGFbJ1R3ZWV0RGV0YWlsJ107XG4gICAgICAgICAgICAgICAgICAgIGlmIChjYWNoZWREYXRhKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICBpZiAoZmVhdHVyZWRUd2VldD8uaWQgIT09IHRhcmdldElkKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY29uc3QgcmVmaXR0ZWQgPSBmaW5kVHdlZXRCeUlkKGNhY2hlZERhdGEsIHRhcmdldElkKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZiAocmVmaXR0ZWQpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZmVhdHVyZWRUd2VldCA9IHJlZml0dGVkO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBzLmZlYXR1cmVkVHdlZXQgPSByZWZpdHRlZDtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICByZXBsaWVzU25hcHNob3QgPSBmaW5kUmVwbGllc1NuYXBzaG90KGNhY2hlZERhdGEsIGN1cnJlbnRVcmwsIGFjdGl2ZUFjY291bnRIYW5kbGUpO1xuICAgICAgICAgICAgICAgICAgICAgICAgcy5yZXBsaWVzU25hcHNob3QgPSByZXBsaWVzU25hcHNob3Q7XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgc2VuZFJlc3BvbnNlKHtcbiAgICAgICAgICAgICAgICAgICAgLi4uZGVyaXZlUGFnZUNvbnRleHQoY3VycmVudFVybCwgaGFzU2Vzc2lvbiwgaXNMb2dnZWRJbiwgZmVhdHVyZWRUd2VldCwgYWN0aXZlQWNjb3VudEhhbmRsZSksXG4gICAgICAgICAgICAgICAgICAgIHJlcGxpZXNTbmFwc2hvdCxcbiAgICAgICAgICAgICAgICAgICAgcHJvZmlsZVR3ZWV0c1NuYXBzaG90XG4gICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICB9KTtcbiAgICAgICAgfSk7XG4gICAgICAgIHJldHVybiB0cnVlO1xuICAgIH1cbiAgICAvLyDlhpnmk43kvZzku6PnkIbvvIhkZWJ1ZyDpobXpnaIg4oaSIGJhY2tncm91bmQg4oaSIGNvbnRlbnQgc2NyaXB0IOaJp+ihjO+8iVxuICAgIGlmIChtZXNzYWdlLnR5cGUgPT09ICdFWEVDX1BST1hZX0FDVElPTicpIHtcbiAgICAgICAgY29uc3QgdGFyZ2V0VGFiSWQgPSBtZXNzYWdlLnRhYklkO1xuICAgICAgICBpZiAoIXRhcmdldFRhYklkKSB7XG4gICAgICAgICAgICBzZW5kUmVzcG9uc2UoeyBvazogZmFsc2UsIGVycm9yOiAnTm8gdGFiSWQnIH0pO1xuICAgICAgICAgICAgcmV0dXJuIHRydWU7XG4gICAgICAgIH1cbiAgICAgICAgY2hyb21lLnRhYnMuc2VuZE1lc3NhZ2UodGFyZ2V0VGFiSWQsIHtcbiAgICAgICAgICAgIHR5cGU6IE1zZ1R5cGUuRVhFQ1VURV9BQ1RJT04sXG4gICAgICAgICAgICBhY3Rpb246IG1lc3NhZ2UuYWN0aW9uLFxuICAgICAgICAgICAgdHdlZXRJZDogbWVzc2FnZS50d2VldElkLFxuICAgICAgICAgICAgdXNlcklkOiBtZXNzYWdlLnVzZXJJZFxuICAgICAgICB9KS50aGVuKHIgPT4gc2VuZFJlc3BvbnNlKHIpKVxuICAgICAgICAgICAgLmNhdGNoKGUgPT4gc2VuZFJlc3BvbnNlKHsgb2s6IGZhbHNlLCBlcnJvcjogZS5tZXNzYWdlIH0pKTtcbiAgICAgICAgcmV0dXJuIHRydWU7XG4gICAgfVxufSk7XG4vLyDilIDilIAgdGFiIOeKtuaAgeebkeWQrCDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIBcbi8vIOebkeWQrCBVUkwg5Y+Y5YyW77yM56Gu5L+dIGRlYnVnIOmhtemdouiDveWunuaXtuWPjeaYoCByb3V0ZUtpbmQg5Y+Y5YyWXG5jaHJvbWUudGFicy5vblVwZGF0ZWQuYWRkTGlzdGVuZXIoKHRhYklkLCBjaGFuZ2VJbmZvLCB0YWIpID0+IHtcbiAgICBpZiAoY2hhbmdlSW5mby51cmwpIHtcbiAgICAgICAgY29uc3QgdXJsID0gY2hhbmdlSW5mby51cmw7XG4gICAgICAgIGNvbnN0IGlzWCA9IHVybC5pbmNsdWRlcygneC5jb20nKSB8fCB1cmwuaW5jbHVkZXMoJ3R3aXR0ZXIuY29tJyk7XG4gICAgICAgIC8vIOivhuWIq+eZu+WHuuihjOS4uuaIlueZu+W9lea1gemhtemdolxuICAgICAgICBjb25zdCBpc0xvZ291dCA9IHVybC5pbmNsdWRlcygnL2xvZ291dCcpIHx8IHVybC5pbmNsdWRlcygnL2kvZmxvdy9sb2dpbicpIHx8IHVybC5pbmNsdWRlcygnP2xvZ2dlZF9vdXQ9MScpO1xuICAgICAgICBpZiAoaXNYKSB7XG4gICAgICAgICAgICBjb25zdCBzdGF0ZSA9IHRhYkRhdGFTdG9yZS5nZXQodGFiSWQpO1xuICAgICAgICAgICAgaWYgKHN0YXRlKVxuICAgICAgICAgICAgICAgIHN0YXRlLnVybCA9IHVybDtcbiAgICAgICAgICAgIGlmIChpc0xvZ291dCkge1xuICAgICAgICAgICAgICAgIGludmFsaWRhdGVUYWJTZXNzaW9uKHRhYklkKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGVsc2Uge1xuICAgICAgICAgICAgICAgIG5vdGlmeURlYnVnUGFnZXModGFiSWQsICdTVEFUVVMnKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgIH1cbn0pO1xuLy8g4pSA4pSAIHRhYiDlhbPpl63ml7bmuIXnkIblhoXlrZjvvIhzdG9yYWdlIOmHjOeVmeedgOS+myBTVyDph43lkK/mgaLlpI3vvInilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIBcbmNocm9tZS50YWJzLm9uUmVtb3ZlZC5hZGRMaXN0ZW5lcih0YWJJZCA9PiB7XG4gICAgdGFiRGF0YVN0b3JlLmRlbGV0ZSh0YWJJZCk7XG4gICAgc2F2ZVN0b3JlKCk7XG4gICAgLy8g6YCa55+lIGRlYnVnIOmhtemdoiB0YWIg5YiX6KGo5bey5Y+Y5YqoXG4gICAgbm90aWZ5RGVidWdQYWdlcyh0YWJJZCwgJ1NUQVRVUycpO1xufSk7XG4vLyDilIDilIAgQ29va2llIOebkeWQrO+8muaNleaNieeZu+W9leeKtuaAgeWPmOWMliDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIBcbmNocm9tZS5jb29raWVzLm9uQ2hhbmdlZC5hZGRMaXN0ZW5lcigoY2hhbmdlSW5mbykgPT4ge1xuICAgIGlmIChjaGFuZ2VJbmZvLmNvb2tpZS5kb21haW4uaW5jbHVkZXMoJ3guY29tJykgfHwgY2hhbmdlSW5mby5jb29raWUuZG9tYWluLmluY2x1ZGVzKCd0d2l0dGVyLmNvbScpKSB7XG4gICAgICAgIGlmIChjaGFuZ2VJbmZvLmNvb2tpZS5uYW1lID09PSAndHdpZCcpIHtcbiAgICAgICAgICAgIGlmIChjaGFuZ2VJbmZvLnJlbW92ZWQpIHtcbiAgICAgICAgICAgICAgICAvLyDlho3mrKHnoa7orqTmmK/lkKbnnJ/nmoTmsqHkuobvvIjpmLLmraIgWCDlnKjlkIzkuIDmr6vnp5LlhoXmm7TmlrAgY29va2llIOWvvOiHtOmikee5gea4heeQhu+8iVxuICAgICAgICAgICAgICAgIGdldEF1dGhlbnRpY1VpZCgpLnRoZW4odWlkID0+IHtcbiAgICAgICAgICAgICAgICAgICAgaWYgKCF1aWQpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIGludmFsaWRhdGVBbGxTZXNzaW9ucygpO1xuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBlbHNlIHtcbiAgICAgICAgICAgICAgICAvLyBDb29raWUg5pu05pawIC0+IOmHjeaWsOaOoua1i1xuICAgICAgICAgICAgICAgIGNocm9tZS50YWJzLnF1ZXJ5KHsgdXJsOiBbJyo6Ly90d2l0dGVyLmNvbS8qJywgJyo6Ly94LmNvbS8qJ10gfSkudGhlbih0YWJzID0+IHtcbiAgICAgICAgICAgICAgICAgICAgZm9yIChjb25zdCB0IG9mIHRhYnMpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIGlmICh0LmlkKVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIG5vdGlmeURlYnVnUGFnZXModC5pZCwgJ1NUQVRVUycpO1xuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICB9XG59KTtcbi8vIOKUgOKUgCDlhajlsYDor7fmsYLnuqcgUXVlcnlJRCDlj4ogQmVhcmVyIOaLpuaIqu+8iOWPgueFpyBUd2VldENhdO+8ieKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgFxuY2hyb21lLndlYlJlcXVlc3Qub25CZWZvcmVTZW5kSGVhZGVycy5hZGRMaXN0ZW5lcigoZGV0YWlscykgPT4ge1xuICAgIGNvbnN0IGhlYWRlcnMgPSBkZXRhaWxzLnJlcXVlc3RIZWFkZXJzIHx8IFtdO1xuICAgIGNvbnN0IGF1dGhIZWFkZXIgPSBoZWFkZXJzLmZpbmQoaCA9PiBoLm5hbWUudG9Mb3dlckNhc2UoKSA9PT0gJ2F1dGhvcml6YXRpb24nKTtcbiAgICBpZiAoYXV0aEhlYWRlciAmJiBhdXRoSGVhZGVyLnZhbHVlPy5zdGFydHNXaXRoKCdCZWFyZXIgJykpIHtcbiAgICAgICAgY29uc3QgdG9rZW4gPSBhdXRoSGVhZGVyLnZhbHVlO1xuICAgICAgICBjaHJvbWUuc3RvcmFnZS5sb2NhbC5nZXQoX19EQktfYmVhcmVyX3Rva2VuKS50aGVuKHJlcyA9PiB7XG4gICAgICAgICAgICBpZiAocmVzW19fREJLX2JlYXJlcl90b2tlbl0gIT09IHRva2VuKSB7XG4gICAgICAgICAgICAgICAgY2hyb21lLnN0b3JhZ2UubG9jYWwuc2V0KHsgW19fREJLX2JlYXJlcl90b2tlbl06IHRva2VuIH0pLnRoZW4oKCkgPT4ge1xuICAgICAgICAgICAgICAgICAgICBjb25zb2xlLmxvZyhcIltUd2VldENsYXctQkddIPCfjJAgR2xvYmFsIEludGVyY2VwdCBVcGRhdGUgQmVhcmVyIFRva2VuXCIpO1xuICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgfVxuICAgICAgICB9KTtcbiAgICB9XG4gICAgcmV0dXJuIHsgcmVxdWVzdEhlYWRlcnM6IGhlYWRlcnMgfTtcbn0sIHsgdXJsczogW1wiaHR0cHM6Ly94LmNvbS9pL2FwaS9ncmFwaHFsLypcIl0gfSwgW1wicmVxdWVzdEhlYWRlcnNcIl0pO1xuY2hyb21lLndlYlJlcXVlc3Qub25CZWZvcmVSZXF1ZXN0LmFkZExpc3RlbmVyKChkZXRhaWxzKSA9PiB7XG4gICAgY29uc3QgdXJsID0gbmV3IFVSTChkZXRhaWxzLnVybCk7XG4gICAgY29uc3QgbWF0Y2ggPSB1cmwucGF0aG5hbWUubWF0Y2goL15cXC9pXFwvYXBpXFwvZ3JhcGhxbFxcLyhbXi9dKylcXC8oW14vXSspLyk7XG4gICAgaWYgKCFtYXRjaClcbiAgICAgICAgcmV0dXJuO1xuICAgIGNvbnN0IHF1ZXJ5SWQgPSBtYXRjaFsxXTtcbiAgICBjb25zdCBvcGVyYXRpb25OYW1lID0gbWF0Y2hbMl07XG4gICAgaWYgKCF3YXRjaGVkT3BzLmluY2x1ZGVzKG9wZXJhdGlvbk5hbWUpKSB7XG4gICAgICAgIHJldHVybjtcbiAgICB9XG4gICAgY2hyb21lLnN0b3JhZ2UubG9jYWwuZ2V0KF9fREJLX3F1ZXJ5X2lkX21hcCkudGhlbihkYXRhID0+IHtcbiAgICAgICAgY29uc3QgZXhpc3RpbmdNYXAgPSBkYXRhW19fREJLX3F1ZXJ5X2lkX21hcF0gfHwge307XG4gICAgICAgIGlmIChleGlzdGluZ01hcFtvcGVyYXRpb25OYW1lXSAhPT0gcXVlcnlJZCkge1xuICAgICAgICAgICAgZXhpc3RpbmdNYXBbb3BlcmF0aW9uTmFtZV0gPSBxdWVyeUlkO1xuICAgICAgICAgICAgY2hyb21lLnN0b3JhZ2UubG9jYWwuc2V0KHsgW19fREJLX3F1ZXJ5X2lkX21hcF06IGV4aXN0aW5nTWFwIH0pLnRoZW4oKCkgPT4ge1xuICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKGAlY1tUd2VldENsYXctQkddIPCfm7DvuI8gR0xPQkFMIElOVEVSQ0VQVCAoV2ViUmVxdWVzdCk6ICR7b3BlcmF0aW9uTmFtZX0g4oaSICR7cXVlcnlJZH1gLCBcImNvbG9yOiM2MGE1ZmE7IGZvbnQtd2VpZ2h0OmJvbGQ7IGJvcmRlcjoxcHggc29saWQgIzYwYTVmYTsgcGFkZGluZzoycHggNHB4OyBib3JkZXItcmFkaXVzOjRweDtcIik7XG4gICAgICAgICAgICB9KTtcbiAgICAgICAgfVxuICAgIH0pO1xuICAgIHJldHVybiB7fTtcbn0sIHtcbiAgICB1cmxzOiBbXCJodHRwczovL3guY29tL2kvYXBpLypcIl0sIC8vIOaJqeWkp+WMuemFjeiMg+WbtOWIsOaJgOaciSBBUEkg5a2Q6Lev5b6EXG4gICAgdHlwZXM6IFtcInhtbGh0dHByZXF1ZXN0XCIsIFwib3RoZXJcIiwgXCJwaW5nXCJdXG59KTtcbi8vIOKUgOKUgCDkuLTml7bosIPor5Xnm5HlkKzvvJrmjZXmjYnkuIDliIfpnZ4gR3JhcGhRTCDnmoTlhbPms6jor7fmsYIg4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSAXG5jaHJvbWUud2ViUmVxdWVzdC5vbkJlZm9yZVJlcXVlc3QuYWRkTGlzdGVuZXIoKGRldGFpbHMpID0+IHtcbiAgICBjb25zdCB1cmwgPSBuZXcgVVJMKGRldGFpbHMudXJsKTtcbiAgICBpZiAodXJsLnBhdGhuYW1lLmluY2x1ZGVzKCdmcmllbmRzaGlwcycpIHx8IHVybC5wYXRobmFtZS5pbmNsdWRlcygnZm9sbG93JykpIHtcbiAgICAgICAgY29uc29sZS5sb2coYCVjW1R3ZWV0Q2xhdy1ERUJVR10g8J+UjSBERVRFQ1RFRCBQT1RFTlRJQUwgRk9MTE9XIEFQSTogJHt1cmwucGF0aG5hbWV9YCwgXCJjb2xvcjogI2ZiYmYyNDsgZm9udC13ZWlnaHQ6IGJvbGQ7XCIpO1xuICAgIH1cbiAgICByZXR1cm4ge307XG59LCB7IHVybHM6IFtcImh0dHBzOi8veC5jb20vaS9hcGkvKlwiXSB9KTtcbi8vIOKUgOKUgCBMb2NhbEJyaWRnZSDkuJrliqHpgLvovpEg4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSAXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gcXVlcnlYVGFic1N0YXR1cygpIHtcbiAgICBjb25zb2xlLmxvZygnW1R3ZWV0Q2xhdy1CR10gcXVlcnlYVGFic1N0YXR1cyBjYWxsZWQnKTtcbiAgICAvLyAxLiBRdWVyeSBhbGwgWCB0YWJzXG4gICAgY29uc3QgdGFicyA9IGF3YWl0IGNocm9tZS50YWJzLnF1ZXJ5KHsgdXJsOiBbXCIqOi8veC5jb20vKlwiLCBcIio6Ly90d2l0dGVyLmNvbS8qXCJdIH0pO1xuICAgIC8vIDIuIFF1ZXJ5IGFjdGl2ZSB0YWIgaW4gY3VycmVudCB3aW5kb3dcbiAgICBjb25zdCBbYWN0aXZlVGFiXSA9IGF3YWl0IGNocm9tZS50YWJzLnF1ZXJ5KHsgYWN0aXZlOiB0cnVlLCBjdXJyZW50V2luZG93OiB0cnVlIH0pO1xuICAgIC8vIDMuIEZpbmQgaWYgYWN0aXZlIHRhYiBpcyBhbiBYIHRhYlxuICAgIGNvbnN0IGlzWFRhYk5hdGl2ZSA9ICh1cmwpID0+IHtcbiAgICAgICAgaWYgKCF1cmwpXG4gICAgICAgICAgICByZXR1cm4gZmFsc2U7XG4gICAgICAgIHJldHVybiB1cmwuaW5jbHVkZXMoJ3guY29tJykgfHwgdXJsLmluY2x1ZGVzKCd0d2l0dGVyLmNvbScpO1xuICAgIH07XG4gICAgbGV0IGFjdGl2ZVhUYWJJZCA9IG51bGw7XG4gICAgbGV0IGFjdGl2ZVhVcmwgPSBudWxsO1xuICAgIGlmIChhY3RpdmVUYWIgJiYgaXNYVGFiTmF0aXZlKGFjdGl2ZVRhYi51cmwpKSB7XG4gICAgICAgIGFjdGl2ZVhUYWJJZCA9IGFjdGl2ZVRhYi5pZCB8fCBudWxsO1xuICAgICAgICBhY3RpdmVYVXJsID0gYWN0aXZlVGFiLnVybCB8fCBudWxsO1xuICAgIH1cbiAgICAvLyA0LiBDaGVjayBsb2dpbiBzdGF0dXMgKHR3aWQgY29va2llKVxuICAgIGNvbnN0IHVpZCA9IGF3YWl0IGdldEF1dGhlbnRpY1VpZCgpO1xuICAgIGNvbnN0IGlzTG9nZ2VkSW4gPSAhIXVpZDtcbiAgICAvLyA1LiBNYXAgdGFicyB0byBYVGFiSW5mb1xuICAgIGNvbnN0IHRhYkluZm9zID0gdGFicy5tYXAodCA9PiAoe1xuICAgICAgICB0YWJJZDogdC5pZCB8fCAwLFxuICAgICAgICB1cmw6IHQudXJsIHx8ICcnLFxuICAgICAgICBhY3RpdmU6IHQuYWN0aXZlXG4gICAgfSkpO1xuICAgIGNvbnN0IHBheWxvYWQgPSB7XG4gICAgICAgIGhhc1hUYWJzOiB0YWJzLmxlbmd0aCA+IDAsXG4gICAgICAgIGlzTG9nZ2VkSW46IGlzTG9nZ2VkSW4sXG4gICAgICAgIGFjdGl2ZVhUYWJJZDogYWN0aXZlWFRhYklkLFxuICAgICAgICBhY3RpdmVYVXJsOiBhY3RpdmVYVXJsLFxuICAgICAgICB0YWJzOiB0YWJJbmZvc1xuICAgIH07XG4gICAgY29uc29sZS5sb2coJ1tUd2VldENsYXctQkddIHF1ZXJ5WFRhYnNTdGF0dXMgcmVzdWx0OicsIHBheWxvYWQpO1xuICAgIHJldHVybiBwYXlsb2FkO1xufVxuLyoqXG4gKiDku44gcmF3IHVzZXIgcmVzdWx0IOWvueixoeS4ree7hOijheagh+WHhiBwcm9maWxl77yI5LiN5L6d6LWWIGZpbmRWaWV3ZXJTdW1tYXJ577yJXG4gKi9cbmZ1bmN0aW9uIGJ1aWxkUHJvZmlsZUZyb21SYXcocmF3LCB1aWQpIHtcbiAgICBjb25zdCBsZWdhY3kgPSByYXc/LmxlZ2FjeSA/PyB7fTtcbiAgICAvLyBYIOeahCBHcmFwaFFMIOWTjeW6lOS4re+8jHNjcmVlbl9uYW1lIOWSjCBuYW1lIOWPr+iDveWcqOWkmuS4quS9jee9ru+8mlxuICAgIC8vIDEuIGxlZ2FjeS5zY3JlZW5fbmFtZSDvvIjmoIflh4bot6/lvoTvvIlcbiAgICAvLyAyLiBjb3JlLnNjcmVlbl9uYW1lIO+8iOaWsOeJiOacrCBBUEkg5oqK5Z+656GA5a2X5q615pS257Sn5YiwIGNvcmUg6aG25bGC77yJXG4gICAgLy8gMy4gY29yZS51c2VyX3Jlc3VsdHMucmVzdWx0LmxlZ2FjeS5zY3JlZW5fbmFtZSDvvIjltYzlpZflvJXnlKjvvIlcbiAgICBjb25zdCBzY3JlZW5OYW1lID0gbGVnYWN5LnNjcmVlbl9uYW1lIHx8XG4gICAgICAgIHJhdz8uY29yZT8uc2NyZWVuX25hbWUgfHxcbiAgICAgICAgcmF3Py5jb3JlPy51c2VyX3Jlc3VsdHM/LnJlc3VsdD8ubGVnYWN5Py5zY3JlZW5fbmFtZSB8fFxuICAgICAgICAnJztcbiAgICBjb25zdCBuYW1lID0gbGVnYWN5Lm5hbWUgfHxcbiAgICAgICAgcmF3Py5jb3JlPy5uYW1lIHx8XG4gICAgICAgIHJhdz8uY29yZT8udXNlcl9yZXN1bHRzPy5yZXN1bHQ/LmxlZ2FjeT8ubmFtZSB8fFxuICAgICAgICBzY3JlZW5OYW1lO1xuICAgIGNvbnN0IGNyZWF0ZWRBdCA9IGxlZ2FjeS5jcmVhdGVkX2F0IHx8IHJhdz8uY29yZT8uY3JlYXRlZF9hdCB8fCAnJztcbiAgICBjb25zdCBhdmF0YXIgPSBsZWdhY3kucHJvZmlsZV9pbWFnZV91cmxfaHR0cHNcbiAgICAgICAgLy8gWCDmnInml7bov5Tlm54gX25vcm1hbCDnvKnnlaXlm77vvIzmjaLmiJDljp/lm75cbiAgICAgICAgPyBsZWdhY3kucHJvZmlsZV9pbWFnZV91cmxfaHR0cHMucmVwbGFjZSgnX25vcm1hbCcsICcnKVxuICAgICAgICA6IHVuZGVmaW5lZDtcbiAgICByZXR1cm4ge1xuICAgICAgICBpc0xvZ2dlZEluOiB0cnVlLFxuICAgICAgICB0d2l0dGVySWQ6IHVpZCB8fCByYXc/LnJlc3RfaWQgfHwgJycsXG4gICAgICAgIG5hbWUsXG4gICAgICAgIHNjcmVlbk5hbWU6IHNjcmVlbk5hbWUgPyBgQCR7c2NyZWVuTmFtZX1gIDogJycsXG4gICAgICAgIHZlcmlmaWVkOiByYXc/LmlzX2JsdWVfdmVyaWZpZWQgfHwgbGVnYWN5LnZlcmlmaWVkIHx8IGZhbHNlLFxuICAgICAgICBmb2xsb3dlcnNDb3VudDogbGVnYWN5LmZvbGxvd2Vyc19jb3VudCxcbiAgICAgICAgZnJpZW5kc0NvdW50OiBsZWdhY3kuZnJpZW5kc19jb3VudCxcbiAgICAgICAgc3RhdHVzZXNDb3VudDogbGVnYWN5LnN0YXR1c2VzX2NvdW50LFxuICAgICAgICBhdmF0YXIsXG4gICAgICAgIGRlc2NyaXB0aW9uOiBsZWdhY3kuZGVzY3JpcHRpb24sXG4gICAgICAgIGNyZWF0ZWRBdCxcbiAgICAgICAgcmF3LCAvLyDlrozmlbTljp/lp4vmlbDmja7pgI/kvKDnu5kgTWFjIEFwcFxuICAgICAgICB1cGRhdGVkQXQ6IERhdGUubm93KClcbiAgICB9O1xufVxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIHF1ZXJ5WEJhc2ljSW5mbygpIHtcbiAgICBjb25zb2xlLmxvZygnW1R3ZWV0Q2xhdy1CR10gcXVlcnlYQmFzaWNJbmZvIGNhbGxlZCcpO1xuICAgIC8vIDEuIOaJvua0u+i3g+eahCB4LmNvbSDmoIfnrb7pobVcbiAgICBjb25zdCB4VGFicyA9IGF3YWl0IGNocm9tZS50YWJzLnF1ZXJ5KHsgdXJsOiBbJyo6Ly94LmNvbS8qJywgJyo6Ly90d2l0dGVyLmNvbS8qJ10gfSk7XG4gICAgY29uc3QgdGFyZ2V0VGFiID0geFRhYnMuZmluZCh0ID0+IHQuYWN0aXZlKSB8fCB4VGFic1swXTtcbiAgICBpZiAoIXRhcmdldFRhYj8uaWQpXG4gICAgICAgIHRocm93IG5ldyBFcnJvcignTm8gYWN0aXZlIHguY29tIHRhYiBmb3VuZCcpO1xuICAgIGNvbnN0IHVpZCA9IGF3YWl0IGdldEF1dGhlbnRpY1VpZCgpO1xuICAgIC8vIDIuIOWnlOaJmCBDb250ZW50IFNjcmlwdCDlnKjpobXpnaLkuIrkuIvmlofmiafooYwgZmV0Y2hVc2VyQnlTY3JlZW5OYW1lXG4gICAgY29uc29sZS5sb2coJ1tUd2VldENsYXctQkddIHF1ZXJ5WEJhc2ljSW5mbzogZGVsZWdhdGluZyB0byBjb250ZW50IHNjcmlwdCwgdGFiJywgdGFyZ2V0VGFiLmlkKTtcbiAgICBjb25zdCBtZXNzYWdlUHJvbWlzZSA9IGNocm9tZS50YWJzLnNlbmRNZXNzYWdlKHRhcmdldFRhYi5pZCwge1xuICAgICAgICB0eXBlOiAnRkVUQ0hfU0VUVElOR1NfQU5EX1BST0ZJTEUnLFxuICAgIH0pLmNhdGNoKChlKSA9PiB7XG4gICAgICAgIGNvbnNvbGUud2FybignW1R3ZWV0Q2xhdy1CR10gc2VuZE1lc3NhZ2UgZXJyb3I6JywgZT8ubWVzc2FnZSk7XG4gICAgICAgIHJldHVybiBudWxsO1xuICAgIH0pO1xuICAgIGNvbnN0IHRpbWVvdXRQcm9taXNlID0gbmV3IFByb21pc2UocmVzb2x2ZSA9PiBzZXRUaW1lb3V0KCgpID0+IHJlc29sdmUobnVsbCksIDE1MDAwKSk7XG4gICAgY29uc3QgcmVzdWx0ID0gYXdhaXQgUHJvbWlzZS5yYWNlKFttZXNzYWdlUHJvbWlzZSwgdGltZW91dFByb21pc2VdKTtcbiAgICAvLyAzLiBDb250ZW50IFNjcmlwdCDmiJDlip/ov5Tlm55cbiAgICBpZiAocmVzdWx0Py5zdWNjZXNzICYmIHJlc3VsdD8ucmF3KSB7XG4gICAgICAgIGNvbnNvbGUubG9nKCdbVHdlZXRDbGF3LUJHXSBxdWVyeVhCYXNpY0luZm86IHN1Y2Nlc3MgZnJvbSBjb250ZW50IHNjcmlwdCcpO1xuICAgICAgICByZXR1cm4gYnVpbGRQcm9maWxlRnJvbVJhdyhyZXN1bHQucmF3LCB1aWQpO1xuICAgIH1cbiAgICAvLyA0LiBGYWxsYmFja++8mnRhYkRhdGFTdG9yZSDph4zmib4gdWlkIOWMuemFjSBvZiBVc2VyQnlTY3JlZW5OYW1lXG4gICAgY29uc29sZS53YXJuKCdbVHdlZXRDbGF3LUJHXSBxdWVyeVhCYXNpY0luZm86IGNvbnRlbnQgc2NyaXB0IGZhaWxlZC90aW1lb3V0LCB0cnlpbmcgdGFiRGF0YVN0b3JlIGZhbGxiYWNrJyk7XG4gICAgaWYgKHVpZCkge1xuICAgICAgICBjb25zdCBjYXB0dXJlZERhdGEgPSB0YWJEYXRhU3RvcmUuZ2V0KHRhcmdldFRhYi5pZCk/LmRhdGE/LlsnVXNlckJ5U2NyZWVuTmFtZSddO1xuICAgICAgICBpZiAoY2FwdHVyZWREYXRhKSB7XG4gICAgICAgICAgICBjb25zdCByYXdGcm9tU3RvcmUgPSBmaW5kRGVlcFVzZXIoY2FwdHVyZWREYXRhKTtcbiAgICAgICAgICAgIGlmIChyYXdGcm9tU3RvcmU/LnJlc3RfaWQgPT09IHVpZCkge1xuICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKCdbVHdlZXRDbGF3LUJHXSBxdWVyeVhCYXNpY0luZm86IGZhbGxiYWNrIG9rIGZyb20gdGFiRGF0YVN0b3JlJyk7XG4gICAgICAgICAgICAgICAgcmV0dXJuIGJ1aWxkUHJvZmlsZUZyb21SYXcocmF3RnJvbVN0b3JlLCB1aWQpO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgY29uc29sZS53YXJuKCdbVHdlZXRDbGF3LUJHXSBxdWVyeVhCYXNpY0luZm86IHRhYkRhdGFTdG9yZSB1aWQgbWlzbWF0Y2gsIHNraXBwaW5nJyk7XG4gICAgICAgIH1cbiAgICB9XG4gICAgLy8gNS4g5pyA57uI5YWc5bqV77ya6L+U5Zue5Z+656GA55m75b2V5L+h5oGvXG4gICAgY29uc29sZS5lcnJvcignW1R3ZWV0Q2xhdy1CR10gcXVlcnlYQmFzaWNJbmZvOiBhbGwgc3RyYXRlZ2llcyBmYWlsZWQsIHJldHVybmluZyBtaW5pbWFsIHByb2ZpbGUnKTtcbiAgICBjb25zdCBzdG9yZWRTY3JlZW5OYW1lID0gKGF3YWl0IGNocm9tZS5zdG9yYWdlLmxvY2FsLmdldCgnc2NyZWVuTmFtZScpKS5zY3JlZW5OYW1lO1xuICAgIHJldHVybiB7XG4gICAgICAgIGlzTG9nZ2VkSW46IHRydWUsXG4gICAgICAgIHR3aXR0ZXJJZDogdWlkIHx8ICcnLFxuICAgICAgICBuYW1lOiBzdG9yZWRTY3JlZW5OYW1lIHx8ICcnLFxuICAgICAgICBzY3JlZW5OYW1lOiBzdG9yZWRTY3JlZW5OYW1lID8gYEAke3N0b3JlZFNjcmVlbk5hbWV9YCA6ICcnLFxuICAgICAgICB2ZXJpZmllZDogZmFsc2UsXG4gICAgICAgIHJhdzogbnVsbCxcbiAgICAgICAgdXBkYXRlZEF0OiBEYXRlLm5vdygpXG4gICAgfTtcbn1cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBvcGVuWFRhYihwYXlsb2FkKSB7XG4gICAgY29uc3QgcGF0aCA9IHBheWxvYWQucGF0aCB8fCBcImhvbWVcIjtcbiAgICBjb25zdCB1cmwgPSBcImh0dHBzOi8veC5jb20vXCIgKyAocGF0aC5zdGFydHNXaXRoKFwiL1wiKSA/IHBhdGguc3Vic3RyaW5nKDEpIDogcGF0aCk7XG4gICAgcmV0dXJuIG5ldyBQcm9taXNlKChyZXNvbHZlKSA9PiB7XG4gICAgICAgIGNocm9tZS50YWJzLmNyZWF0ZSh7IHVybCB9LCAodGFiKSA9PiB7XG4gICAgICAgICAgICBpZiAoY2hyb21lLnJ1bnRpbWUubGFzdEVycm9yKSB7XG4gICAgICAgICAgICAgICAgcmVzb2x2ZSh7IHN1Y2Nlc3M6IGZhbHNlLCBlcnJvcjogY2hyb21lLnJ1bnRpbWUubGFzdEVycm9yLm1lc3NhZ2UgfSk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBlbHNlIHtcbiAgICAgICAgICAgICAgICByZXNvbHZlKHtcbiAgICAgICAgICAgICAgICAgICAgc3VjY2VzczogdHJ1ZSxcbiAgICAgICAgICAgICAgICAgICAgdGFiSWQ6IHRhYi5pZCxcbiAgICAgICAgICAgICAgICAgICAgdXJsOiB0YWIudXJsIHx8IHVybFxuICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgfVxuICAgICAgICB9KTtcbiAgICB9KTtcbn1cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBjbG9zZVhUYWIocGF5bG9hZCkge1xuICAgIGNvbnN0IHRhYklkID0gcGF5bG9hZC50YWJJZDtcbiAgICByZXR1cm4gbmV3IFByb21pc2UoKHJlc29sdmUpID0+IHtcbiAgICAgICAgY2hyb21lLnRhYnMuZ2V0KHRhYklkLCAodGFiKSA9PiB7XG4gICAgICAgICAgICBpZiAoY2hyb21lLnJ1bnRpbWUubGFzdEVycm9yIHx8ICF0YWIpIHtcbiAgICAgICAgICAgICAgICByZXNvbHZlKHsgc3VjY2VzczogZmFsc2UsIHJlYXNvbjogXCJub3RfZm91bmRcIiB9KTtcbiAgICAgICAgICAgICAgICByZXR1cm47XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICAvLyBDaGVjayBpZiBpdCdzIGFuIHguY29tIHRhYlxuICAgICAgICAgICAgY29uc3QgdXJsID0gdGFiLnVybCB8fCBcIlwiO1xuICAgICAgICAgICAgaWYgKCF1cmwuaW5jbHVkZXMoXCJ4LmNvbVwiKSAmJiAhdXJsLmluY2x1ZGVzKFwidHdpdHRlci5jb21cIikpIHtcbiAgICAgICAgICAgICAgICByZXNvbHZlKHsgc3VjY2VzczogZmFsc2UsIHJlYXNvbjogXCJub3RfZm91bmRcIiB9KTtcbiAgICAgICAgICAgICAgICByZXR1cm47XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBjaHJvbWUudGFicy5yZW1vdmUodGFiSWQsICgpID0+IHtcbiAgICAgICAgICAgICAgICBpZiAoY2hyb21lLnJ1bnRpbWUubGFzdEVycm9yKSB7XG4gICAgICAgICAgICAgICAgICAgIHJlc29sdmUoe1xuICAgICAgICAgICAgICAgICAgICAgICAgc3VjY2VzczogZmFsc2UsXG4gICAgICAgICAgICAgICAgICAgICAgICByZWFzb246IFwiZmFpbGVkXCIsXG4gICAgICAgICAgICAgICAgICAgICAgICBlcnJvcjogY2hyb21lLnJ1bnRpbWUubGFzdEVycm9yLm1lc3NhZ2VcbiAgICAgICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIGVsc2Uge1xuICAgICAgICAgICAgICAgICAgICByZXNvbHZlKHsgc3VjY2VzczogdHJ1ZSwgcmVhc29uOiBcInN1Y2Nlc3NcIiB9KTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9KTtcbiAgICAgICAgfSk7XG4gICAgfSk7XG59XG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gbmF2aWdhdGVYVGFiKHBheWxvYWQpIHtcbiAgICBsZXQgdGFiSWQgPSBwYXlsb2FkLnRhYklkO1xuICAgIGNvbnN0IHBhdGggPSBwYXlsb2FkLnBhdGggfHwgXCJob21lXCI7XG4gICAgY29uc3QgdXJsID0gXCJodHRwczovL3guY29tL1wiICsgKHBhdGguc3RhcnRzV2l0aChcIi9cIikgPyBwYXRoLnN1YnN0cmluZygxKSA6IHBhdGgpO1xuICAgIGlmICghdGFiSWQpIHtcbiAgICAgICAgLy8gRmluZCB0aGUgZmlyc3QgeC5jb20gdGFiXG4gICAgICAgIGNvbnN0IHRhYnMgPSBhd2FpdCBjaHJvbWUudGFicy5xdWVyeSh7IHVybDogW1wiKjovL3guY29tLypcIiwgXCIqOi8vdHdpdHRlci5jb20vKlwiXSB9KTtcbiAgICAgICAgaWYgKHRhYnMubGVuZ3RoID09PSAwKSB7XG4gICAgICAgICAgICB0aHJvdyBuZXcgRXJyb3IoXCJObyB4LmNvbSB0YWJzIGZvdW5kIHRvIG5hdmlnYXRlXCIpO1xuICAgICAgICB9XG4gICAgICAgIHRhYklkID0gdGFic1swXS5pZDtcbiAgICB9XG4gICAgaWYgKCF0YWJJZCkge1xuICAgICAgICB0aHJvdyBuZXcgRXJyb3IoXCJJbnZhbGlkIHRhYklkXCIpO1xuICAgIH1cbiAgICBjb25zdCB0YXJnZXRUYWJJZCA9IHRhYklkO1xuICAgIHJldHVybiBuZXcgUHJvbWlzZSgocmVzb2x2ZSkgPT4ge1xuICAgICAgICBjaHJvbWUudGFicy51cGRhdGUodGFyZ2V0VGFiSWQsIHsgdXJsIH0sICh0YWIpID0+IHtcbiAgICAgICAgICAgIGlmIChjaHJvbWUucnVudGltZS5sYXN0RXJyb3IpIHtcbiAgICAgICAgICAgICAgICByZXNvbHZlKHsgc3VjY2VzczogZmFsc2UsIHRhYklkOiB0YXJnZXRUYWJJZCwgdXJsLCBlcnJvcjogY2hyb21lLnJ1bnRpbWUubGFzdEVycm9yLm1lc3NhZ2UgfSk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBlbHNlIHtcbiAgICAgICAgICAgICAgICByZXNvbHZlKHtcbiAgICAgICAgICAgICAgICAgICAgc3VjY2VzczogdHJ1ZSxcbiAgICAgICAgICAgICAgICAgICAgdGFiSWQ6IHRhcmdldFRhYklkLFxuICAgICAgICAgICAgICAgICAgICB1cmw6IHRhYj8udXJsIHx8IHVybFxuICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgfVxuICAgICAgICB9KTtcbiAgICB9KTtcbn1cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBleGVjQWN0aW9uKHBheWxvYWQpIHtcbiAgICBjb25zdCB7IGFjdGlvbiwgdHdlZXRJZCwgdXNlcklkLCB0YWJJZCB9ID0gcGF5bG9hZDtcbiAgICBjb25zb2xlLmxvZyhgW1R3ZWV0Q2xhdy1CR10gZXhlY0FjdGlvbiBjYWxsZWQ6ICR7YWN0aW9ufWAsIHsgdHdlZXRJZCwgdXNlcklkLCB0YWJJZCB9KTtcbiAgICBsZXQgdGFyZ2V0VGFiSWQgPSB0YWJJZDtcbiAgICBpZiAoIXRhcmdldFRhYklkKSB7XG4gICAgICAgIGNvbnN0IHhUYWJzID0gYXdhaXQgY2hyb21lLnRhYnMucXVlcnkoeyB1cmw6IFsnKjovL3guY29tLyonLCAnKjovL3R3aXR0ZXIuY29tLyonXSB9KTtcbiAgICAgICAgY29uc3QgdGFyZ2V0VGFiID0geFRhYnMuZmluZCh0ID0+IHQuYWN0aXZlKSB8fCB4VGFic1swXTtcbiAgICAgICAgdGFyZ2V0VGFiSWQgPSB0YXJnZXRUYWI/LmlkO1xuICAgIH1cbiAgICBpZiAoIXRhcmdldFRhYklkKSB7XG4gICAgICAgIHRocm93IG5ldyBFcnJvcignTm8gdGFyZ2V0IHRhYiBmb3VuZCBmb3IgYWN0aW9uJyk7XG4gICAgfVxuICAgIHJldHVybiBuZXcgUHJvbWlzZSgocmVzb2x2ZSwgcmVqZWN0KSA9PiB7XG4gICAgICAgIGNvbnN0IHRpbWVyID0gc2V0VGltZW91dCgoKSA9PiB7XG4gICAgICAgICAgICByZWplY3QobmV3IEVycm9yKCdDb250ZW50IHNjcmlwdCByZXNwb25zZSB0aW1lb3V0JykpO1xuICAgICAgICB9LCA4MDAwKTtcbiAgICAgICAgY2hyb21lLnRhYnMuc2VuZE1lc3NhZ2UodGFyZ2V0VGFiSWQsIHtcbiAgICAgICAgICAgIHR5cGU6IE1zZ1R5cGUuRVhFQ1VURV9BQ1RJT04sXG4gICAgICAgICAgICBhY3Rpb24sXG4gICAgICAgICAgICB0d2VldElkLFxuICAgICAgICAgICAgdXNlcklkLFxuICAgICAgICAgICAgdGV4dDogcGF5bG9hZD8udGV4dCB8fCBudWxsIC8vIOaWsOWinu+8mumAj+S8oCB0ZXh0IOWtl+autee7mSBjb250ZW50IHNjcmlwdFxuICAgICAgICB9KS50aGVuKHJlcyA9PiB7XG4gICAgICAgICAgICBjbGVhclRpbWVvdXQodGltZXIpO1xuICAgICAgICAgICAgcmVzb2x2ZShyZXMpO1xuICAgICAgICB9KS5jYXRjaChlcnIgPT4ge1xuICAgICAgICAgICAgY2xlYXJUaW1lb3V0KHRpbWVyKTtcbiAgICAgICAgICAgIHJlamVjdChlcnIpO1xuICAgICAgICB9KTtcbiAgICB9KTtcbn1cbi8vIOWQr+WKqOaXtuehruS/neWtmOWCqOW3suWwsee7qlxuaW5pdERlZmF1bHRRdWVyeUtleXMoKTtcbi8vIEIxOiDor7vlj5bkuLvpobXml7bpl7Tnur9cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBxdWVyeUhvbWVUaW1lbGluZShwYXlsb2FkKSB7XG4gICAgY29uc3QgeFRhYnMgPSBhd2FpdCBjaHJvbWUudGFicy5xdWVyeSh7IHVybDogWycqOi8veC5jb20vKicsICcqOi8vdHdpdHRlci5jb20vKiddIH0pO1xuICAgIGxldCB0YXJnZXRUYWJJZCA9IHBheWxvYWQ/LnRhYklkO1xuICAgIGlmICghdGFyZ2V0VGFiSWQpIHtcbiAgICAgICAgY29uc3QgYWN0aXZlVGFiID0geFRhYnMuZmluZCh0ID0+IHQuYWN0aXZlKSB8fCB4VGFic1swXTtcbiAgICAgICAgdGFyZ2V0VGFiSWQgPSBhY3RpdmVUYWI/LmlkO1xuICAgIH1cbiAgICBpZiAoIXRhcmdldFRhYklkKVxuICAgICAgICByZXR1cm4geyBvazogZmFsc2UsIGVycm9yOiAnTm8geC5jb20gdGFiIGZvdW5kJywgZGF0YTogbnVsbCB9O1xuICAgIGNvbnN0IHN0YXRlID0gdGFiRGF0YVN0b3JlLmdldCh0YXJnZXRUYWJJZCk7XG4gICAgY29uc3QgcmF3VGltZWxpbmUgPSBzdGF0ZT8uZGF0YT8uWydIb21lTGF0ZXN0VGltZWxpbmUnXVxuICAgICAgICB8fCBzdGF0ZT8uZGF0YT8uWydIb21lVGltZWxpbmUnXVxuICAgICAgICB8fCBzdGF0ZT8uZGF0YT8uWydUaW1lbGluZUhvbWUnXTtcbiAgICBpZiAoIXJhd1RpbWVsaW5lKSB7XG4gICAgICAgIHJldHVybiB7XG4gICAgICAgICAgICBvazogZmFsc2UsXG4gICAgICAgICAgICBlcnJvcjogJ0hvbWUgdGltZWxpbmUgbm90IHlldCBjYXB0dXJlZC4gTmF2aWdhdGUgdG8geC5jb20vaG9tZSBhbmQgd2FpdCBmb3IgdGhlIHBhZ2UgdG8gbG9hZC4nLFxuICAgICAgICAgICAgZGF0YTogbnVsbFxuICAgICAgICB9O1xuICAgIH1cbiAgICBjb25zdCB7IGV4dHJhY3RUd2VldHNGcm9tVGltZWxpbmUgfSA9IGF3YWl0IGltcG9ydCgnLi4vY2FwdHVyZS90aW1lbGluZS1leHRyYWN0b3InKTtcbiAgICBjb25zdCB0d2VldHMgPSBleHRyYWN0VHdlZXRzRnJvbVRpbWVsaW5lKHJhd1RpbWVsaW5lKTtcbiAgICByZXR1cm4geyBvazogdHJ1ZSwgZGF0YTogeyB0d2VldHMsIGNvdW50OiB0d2VldHMubGVuZ3RoIH0sIGVycm9yOiBudWxsIH07XG59XG4vLyBCMjog6K+75Y+W5o6o5paH6K+m5oOF5Y+K5Zue5aSNXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gcXVlcnlUd2VldERldGFpbChwYXlsb2FkKSB7XG4gICAgY29uc3QgeyB0d2VldElkLCB0YWJJZCB9ID0gcGF5bG9hZDtcbiAgICBjb25zdCB4VGFicyA9IGF3YWl0IGNocm9tZS50YWJzLnF1ZXJ5KHsgdXJsOiBbJyo6Ly94LmNvbS8qJywgJyo6Ly90d2l0dGVyLmNvbS8qJ10gfSk7XG4gICAgbGV0IHRhcmdldFRhYklkID0gdGFiSWQ7XG4gICAgaWYgKCF0YXJnZXRUYWJJZCkge1xuICAgICAgICBjb25zdCBhY3RpdmVUYWIgPSB4VGFicy5maW5kKHQgPT4gdC5hY3RpdmUpIHx8IHhUYWJzWzBdO1xuICAgICAgICB0YXJnZXRUYWJJZCA9IGFjdGl2ZVRhYj8uaWQ7XG4gICAgfVxuICAgIGlmICghdGFyZ2V0VGFiSWQpXG4gICAgICAgIHJldHVybiB7IG9rOiBmYWxzZSwgZXJyb3I6ICdObyB4LmNvbSB0YWIgZm91bmQnLCBkYXRhOiBudWxsIH07XG4gICAgY29uc3Qgc3RhdGUgPSB0YWJEYXRhU3RvcmUuZ2V0KHRhcmdldFRhYklkKTtcbiAgICBjb25zdCByYXdEZXRhaWwgPSAodHdlZXRJZCAmJiBzdGF0ZT8uZGF0YT8uW2BUd2VldERldGFpbF8ke3R3ZWV0SWR9YF0pXG4gICAgICAgIHx8IHN0YXRlPy5kYXRhPy5bJ1R3ZWV0RGV0YWlsJ107XG4gICAgaWYgKCFyYXdEZXRhaWwpIHtcbiAgICAgICAgcmV0dXJuIHtcbiAgICAgICAgICAgIG9rOiBmYWxzZSxcbiAgICAgICAgICAgIGVycm9yOiBgVHdlZXREZXRhaWwgbm90IGNhcHR1cmVkIHlldC4gTmF2aWdhdGUgdG8gdGhlIHR3ZWV0IGRldGFpbCBwYWdlIGZpcnN0LmAsXG4gICAgICAgICAgICBkYXRhOiBudWxsXG4gICAgICAgIH07XG4gICAgfVxuICAgIGNvbnN0IHsgZXh0cmFjdFR3ZWV0c0Zyb21UaW1lbGluZSB9ID0gYXdhaXQgaW1wb3J0KCcuLi9jYXB0dXJlL3RpbWVsaW5lLWV4dHJhY3RvcicpO1xuICAgIGNvbnN0IHR3ZWV0cyA9IGV4dHJhY3RUd2VldHNGcm9tVGltZWxpbmUocmF3RGV0YWlsKTtcbiAgICByZXR1cm4ge1xuICAgICAgICBvazogdHJ1ZSxcbiAgICAgICAgZGF0YToge1xuICAgICAgICAgICAgZmVhdHVyZWRUd2VldDogc3RhdGU/LmZlYXR1cmVkVHdlZXQgfHwgbnVsbCxcbiAgICAgICAgICAgIHJlcGxpZXM6IHN0YXRlPy5yZXBsaWVzU25hcHNob3QgfHwgW10sXG4gICAgICAgICAgICBhbGxUd2VldHM6IHR3ZWV0cyxcbiAgICAgICAgICAgIGNvdW50OiB0d2VldHMubGVuZ3RoXG4gICAgICAgIH0sXG4gICAgICAgIGVycm9yOiBudWxsXG4gICAgfTtcbn1cbi8vIEIzOiDojrflj5bmjIflrprnlKjmiLfnmoQgUHJvZmlsZe+8iOS4u+WKqOiwg+eUqO+8jOS4jeS+nei1lumhtemdouWvvOiIqu+8iVxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIHF1ZXJ5VXNlclByb2ZpbGUocGF5bG9hZCkge1xuICAgIGNvbnN0IHsgc2NyZWVuTmFtZSwgdGFiSWQgfSA9IHBheWxvYWQ7XG4gICAgaWYgKCFzY3JlZW5OYW1lKVxuICAgICAgICByZXR1cm4geyBvazogZmFsc2UsIGVycm9yOiAnc2NyZWVuTmFtZSBpcyByZXF1aXJlZCcsIGRhdGE6IG51bGwgfTtcbiAgICBjb25zdCB4VGFicyA9IGF3YWl0IGNocm9tZS50YWJzLnF1ZXJ5KHsgdXJsOiBbJyo6Ly94LmNvbS8qJywgJyo6Ly90d2l0dGVyLmNvbS8qJ10gfSk7XG4gICAgbGV0IHRhcmdldFRhYklkID0gdGFiSWQ7XG4gICAgaWYgKCF0YXJnZXRUYWJJZCkge1xuICAgICAgICBjb25zdCBhY3RpdmVUYWIgPSB4VGFicy5maW5kKHQgPT4gdC5hY3RpdmUpIHx8IHhUYWJzWzBdO1xuICAgICAgICB0YXJnZXRUYWJJZCA9IGFjdGl2ZVRhYj8uaWQ7XG4gICAgfVxuICAgIGlmICghdGFyZ2V0VGFiSWQpXG4gICAgICAgIHJldHVybiB7IG9rOiBmYWxzZSwgZXJyb3I6ICdObyB4LmNvbSB0YWIgZm91bmQnLCBkYXRhOiBudWxsIH07XG4gICAgY29uc3QgcmVzdWx0ID0gYXdhaXQgbmV3IFByb21pc2UocmVzb2x2ZSA9PiB7XG4gICAgICAgIGNocm9tZS50YWJzLnNlbmRNZXNzYWdlKHRhcmdldFRhYklkLCB7XG4gICAgICAgICAgICB0eXBlOiAnRkVUQ0hfVVNFUl9QUk9GSUxFX0JZX1NDUkVFTl9OQU1FJyxcbiAgICAgICAgICAgIHNjcmVlbk5hbWU6IHNjcmVlbk5hbWUucmVwbGFjZSgnQCcsICcnKVxuICAgICAgICB9LCAocmVzcCkgPT4gcmVzb2x2ZShyZXNwIHx8IHsgc3VjY2VzczogZmFsc2UsIGVycm9yOiAnTm8gcmVzcG9uc2UnIH0pKTtcbiAgICB9KTtcbiAgICBpZiAocmVzdWx0Py5zdWNjZXNzICYmIHJlc3VsdD8uZGF0YSlcbiAgICAgICAgcmV0dXJuIHsgb2s6IHRydWUsIGRhdGE6IHJlc3VsdC5kYXRhLCBlcnJvcjogbnVsbCB9O1xuICAgIHJldHVybiB7IG9rOiBmYWxzZSwgZXJyb3I6IHJlc3VsdD8uZXJyb3IgfHwgJ0ZhaWxlZCB0byBmZXRjaCB1c2VyIHByb2ZpbGUnLCBkYXRhOiBudWxsIH07XG59XG4vLyBCNDog6K+75Y+W5pCc57Si57uT5p6cXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gcXVlcnlTZWFyY2hUaW1lbGluZShwYXlsb2FkKSB7XG4gICAgY29uc3QgeFRhYnMgPSBhd2FpdCBjaHJvbWUudGFicy5xdWVyeSh7IHVybDogWycqOi8veC5jb20vKicsICcqOi8vdHdpdHRlci5jb20vKiddIH0pO1xuICAgIGxldCB0YXJnZXRUYWJJZCA9IHBheWxvYWQ/LnRhYklkO1xuICAgIGlmICghdGFyZ2V0VGFiSWQpIHtcbiAgICAgICAgY29uc3QgYWN0aXZlVGFiID0geFRhYnMuZmluZCh0ID0+IHQuYWN0aXZlKSB8fCB4VGFic1swXTtcbiAgICAgICAgdGFyZ2V0VGFiSWQgPSBhY3RpdmVUYWI/LmlkO1xuICAgIH1cbiAgICBpZiAoIXRhcmdldFRhYklkKVxuICAgICAgICByZXR1cm4geyBvazogZmFsc2UsIGVycm9yOiAnTm8geC5jb20gdGFiIGZvdW5kJywgZGF0YTogbnVsbCB9O1xuICAgIGNvbnN0IHN0YXRlID0gdGFiRGF0YVN0b3JlLmdldCh0YXJnZXRUYWJJZCk7XG4gICAgY29uc3QgcmF3U2VhcmNoID0gc3RhdGU/LmRhdGE/LlsnU2VhcmNoVGltZWxpbmUnXTtcbiAgICBpZiAoIXJhd1NlYXJjaCkge1xuICAgICAgICByZXR1cm4ge1xuICAgICAgICAgICAgb2s6IGZhbHNlLFxuICAgICAgICAgICAgZXJyb3I6ICdTZWFyY2ggcmVzdWx0cyBub3QgY2FwdHVyZWQuIE5hdmlnYXRlIHRvIHguY29tL3NlYXJjaD9xPS4uLiBmaXJzdC4nLFxuICAgICAgICAgICAgZGF0YTogbnVsbFxuICAgICAgICB9O1xuICAgIH1cbiAgICBjb25zdCB7IGV4dHJhY3RUd2VldHNGcm9tVGltZWxpbmUgfSA9IGF3YWl0IGltcG9ydCgnLi4vY2FwdHVyZS90aW1lbGluZS1leHRyYWN0b3InKTtcbiAgICBjb25zdCB0d2VldHMgPSBleHRyYWN0VHdlZXRzRnJvbVRpbWVsaW5lKHJhd1NlYXJjaCk7XG4gICAgcmV0dXJuIHsgb2s6IHRydWUsIGRhdGE6IHsgdHdlZXRzLCBjb3VudDogdHdlZXRzLmxlbmd0aCB9LCBlcnJvcjogbnVsbCB9O1xufVxuIl0sIm5hbWVzIjpbXSwic291cmNlUm9vdCI6IiJ9